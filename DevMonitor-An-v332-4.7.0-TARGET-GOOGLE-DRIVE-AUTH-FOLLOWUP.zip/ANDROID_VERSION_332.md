# Android v332 — Version alignment and Drive follow-up baseline

## Version alignment
- Source ZIP revision: `v332`
- Android `versionCode`: `332`
- Android `versionName`: `4.7.0-TARGET-GOOGLE-DRIVE-AUTH-FOLLOWUP-V332`
- This deliberately corrects the earlier v330 package whose filename said v330 while its embedded Android `versionCode` remained 329.

## Scope
This revision advances the Android package version only. It carries forward the v330 source unchanged apart from the Android version metadata and this record.

## Google Drive status
The user's v330 device test still showed no Google consent screen and the Backup action returned to idle without completing. This revision does **not** claim to fix that unresolved authorisation/upload issue. The next functional change must inspect and correct the interactive Google Drive authorisation/resume flow, then verify consent, upload, download, and restore on a device.

## Protected behaviour
No intentional changes to payment calculations, MOM databases/snapshots, payment-cycle rules, report authority, SMS monitoring, offline backup/import, or Windows source.

## Verification
- Archive integrity and embedded version metadata should be checked after packaging.
- No Gradle build or on-device Google Drive test is claimed by this version-number-only revision.
