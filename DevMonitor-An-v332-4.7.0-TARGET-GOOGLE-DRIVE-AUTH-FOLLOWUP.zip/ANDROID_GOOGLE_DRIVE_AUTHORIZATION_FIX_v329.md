# Android v329 — Google Drive app-data authorisation recovery

## Problem addressed
The existing Google account could appear connected while cloud Backup/Restore immediately returned to its idle state. The app requested the Drive app-folder scope during sign-in, but an already-signed-in account could still require a fresh, interactive Google consent step when `GoogleAuthUtil.getToken` was called. The previous flow did not launch Google's recoverable authorisation intent.

## Change
- `GoogleDriveBackup` now catches `UserRecoverableAuthException` from the app-folder token request and surfaces its original resolution `Intent` through a dedicated `DriveAuthorizationRequiredException`.
- MainActivity launches that Google-provided consent screen and automatically retries the interrupted Backup or Restore operation after a successful authorisation result.
- The retry path covers both the Settings backup controls and the Next Level backup/restore controls.
- If the user cancels or declines, the app returns to an idle state with a clear message; it does not claim that a backup or restore succeeded.
- The existing `drive.appdata` scope, private `appDataFolder` file, backup filename, SQLite validation, staged restore, and offline backup/import implementation are retained.

## Protected areas
No changes were made intentionally to payment calculations, payment-cycle rules, MOM databases/snapshots, report authority, SMS monitoring, or Windows source.

## Versioning
- Source package revision: v329
- Android `versionCode`: 328 (advanced from 327; this was the v329 source baseline)
- Android `versionName`: `4.7.0-TARGET-GOOGLE-DRIVE-AUTH-FIX`

## Verification status
- Source edits and archive integrity can be checked locally.
- Gradle compilation could not run in this environment because the Gradle 8.7 distribution was not cached and network access to `services.gradle.org` was unavailable.
- Google consent, real Drive upload/download, and restore-on-device still require a connected-device test. Do not treat the fix as runtime-confirmed until that test passes.
