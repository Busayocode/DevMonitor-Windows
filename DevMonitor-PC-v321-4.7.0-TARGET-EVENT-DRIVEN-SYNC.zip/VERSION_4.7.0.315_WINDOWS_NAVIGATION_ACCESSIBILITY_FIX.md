# DevMonitor Windows v317 — Navigation accessibility fix

Changes:
- Improved inactive sidebar text contrast.
- Selected navigation item uses a pale teal background and dark text.
- Hover state is more distinguishable.
- Removed the narrow vertical offline-first explanatory panel that wrapped text one character at a time.
- Existing navigation tags and page routes retained.
- No payment, MOM, HQ activation snapshot, target, or sync logic intentionally changed.

Verification: source ZIP integrity and XAML XML parsing only. Windows compile and runtime still require the Windows GitHub Actions workflow and app testing.
