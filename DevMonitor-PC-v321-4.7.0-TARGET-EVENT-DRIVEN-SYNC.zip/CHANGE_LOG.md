## Windows v317 — prominent Phone ↔ PC pairing entry point

- Renamed the persistent sidebar entry and Dashboard shortcut to **Pair Phone ↔ PC** so users can find the existing bridge without searching for “Exchange”.
- Reworked the page heading and first-step text to explain the current pairing flow and where to enter the PC URL/key on Android.
- Existing encrypted bridge protocol and sync boundaries retained. This is an entry-point/usability improvement; automatic LAN discovery and QR-code pairing are not implemented in this package.
- No payment, MOM, HQ snapshot, or target logic changed. ZIP/XML/source checks only; Windows compilation/runtime not verified.


- **v314 — Firebase broadcast ticker and read-only What's New:** Windows now reads active broadcast messages and current release highlights from the existing Firebase project, while remaining offline-first and read-only. No payment/MOM/HQ/target logic changed. Source-level change; Windows compilation and live cloud runtime remain unverified.

## Windows/PC v288 — agent-directory photo thumbnail and placeholder (2026-10-23)

- Cumulative from PC v287: retained monthly target forecast, offline notification audio, Android-authoritative agent/contact/device-link directory, and OpenStreetMap map handoff.
- Added a dedicated agent photo thumbnail slot. It displays a local image only when the referenced file is accessible on Windows; otherwise it displays initials as a friendly placeholder.
- Made the image-transfer limitation explicit: the current sync transfers the Android-local photo path, not image bytes, so phone-only photos cannot yet appear as actual images on PC.
- No payment/MOM/HQ/target calculation or ownership logic intentionally changed.
- Windows compile/runtime verification pending; see `VERSION_4.7.0.288_AGENT_DIRECTORY_PHOTO_THUMBNAIL.md`.

## Windows v286 — Android-authoritative agent directory (2026-10-22)

- Windows Agents view is read-only for Android-originated agent details and device links. Android remains the source of truth; edit agent records on Android and sync them to Windows.
- Removed the shortcut suggesting Windows-native agent editing. Agent/phone/email/device-link record families are no longer offered as editable archive record types, while received records remain viewable/exportable as part of the archive.
- Windows continues to show agent name, postal address, phones, emails and linked device codes. Android-local photo paths are not treated as transferable image files.
- OpenStreetMap is used for Android pin selection without a Google Maps SDK/API key requirement; Windows receives saved coordinates in the synced agent record and can open the selected pin on OpenStreetMap.
- Build/runtime verification pending. Payment/MOM behavior remains protected.



## Windows v281 — AI voice + notification sound plan (2026-10-21)

- Recorded the approved JARVIS-inspired direction: original futuristic sound effects plus robotic/futuristic spoken announcements for important alerts and completed tasks only.
- This is planning/documentation only; notification feature code has not been implemented in this package.
- Proposed Windows approach uses the available Windows speech facility and local original/licensed WAV effects, with parity controls, preview, duplicate suppression, privacy-safe generic phrases, and fallback when speech is unavailable.
- Excludes routine progress, repeated device updates, navigation, and background events from spoken announcements.
- PaymentRules/payment calculations, payment cards, MOM databases/snapshots, two-month retention, HQ import authority, and explicit-refresh behavior remain protected.
- Compile/runtime verification pending. See DEVMonitor_AI_VOICE_NOTIFICATION_PLAN.md.

## Windows v280 — Monthly target delivery forecast (2026-10-21)

- Replaced the 7-day / 30-day Trends & Insights page with a single current-month view against the configured monthly target.
- Shows neutral figures only: monthly target, delivered so far, projected month-end, target achieved percentage, and remaining target balance. No management verdicts/status labels.
- Daily sales table lists recorded current-month dates only; missing days are not treated as zero.
- Preserved two-month retention, role-specific target scoping, and all payment/MOM/HQ import rules.
- Build/runtime verification pending.

## 4.7 Target refinement + WPF compile fix (v278)
- Target achievement percentage is actual activity divided by the expected cumulative target for the same reporting day.
- No shortfall/deficit amount or behind-pace warning is displayed. Full-month target progress remains a separate, neutral percentage.
- Removed an unsupported WPF FormattedText.TextRenderingMode assignment that prevented Windows compilation; retained normal WPF text rendering.


## Windows 4.7.0.276 — Target
- Added a monthly target field to Profile & Company. Staff and Partner require a positive target; Agent target is fixed at 150.
- Added a Monthly Target card to Month-on-Month with cumulative current-month HQ activations, target achievement percentage, expected-to-date pace, and shortfall/on-track status.
- Staff and Partner totals are aggregated across all matching devices in the current HQ month; Agent totals use the saved My Devices scope.
- No payment formula or authoritative HQ snapshot/import behavior changed. Source-level review completed; Windows compilation remains pending.

## Windows v235 — Strict payment-card history and My Partners search parity (2026-10-17)
- Ported the Android v275 evidence-based payment-card eligibility principle to PC-initiated SMS Checker card batches: require device-specific Active history from the previous calendar month, a successful current-month phone Active result, and after the 20th a qualifying baseline through the 20th plus a successful post-20th Active result.
- Missing evidence now produces a specific skip reason at every point in the month; missing history is never treated as zero. Loaded Report card sourcing remains independent and is not filled from SMS Checker values.
- Aligned Windows My Partners lookup with Android v239/v252: searches the latest retained HQ directory, supports case-insensitive partial partner-name/Trade-Code matching, ignores blank Trade Codes, deduplicates by canonical Trade Code, and caps visible matches at 12. Historical snapshots remain accessible in Loaded Report.
- Preserved the established payment tier table, FRC weekly separation, Sunday-bonus qualification, next-tier projection, native Android share handoff, HQ snapshot data, and existing Windows offline workflows.
- Verification: source-level review and ZIP integrity checks; Windows compilation and paired-device runtime verification remain to be run in GitHub Actions.

## Windows v234 — Historical eligibility gate for payment progression (2026-10-17)
- PC-initiated SMS Checker share-card batches now skip devices lacking a valid historical Active baseline through the 20th once the payment cycle enters the 21st-to-month-end period.
- Baseline evidence may come from a successful dated phone Active result or a qualifying imported HQ report covering the calendar month through the 20th for that device. A successful post-20th Active observation is also required before a current-cycle card can be queued. Missing history/current evidence is reported as a skipped card rather than treated as zero.
- Loaded Report card source remains independent; FRC separation, tier rewards, Sunday qualification, next-tier display, and PC-to-Android handoff are preserved.
- Added stored report coverage-start lookup to verify that an imported snapshot actually covers the required historical boundary.
- Static source/archive checks only; Windows compilation and paired-device runtime verification pending.

## Windows v233 — Share-card next-tier earnings opportunity (2026-10-17)
- PC-generated share cards now show clearly labelled current payment estimate, activations remaining to the next configured tier, projected main estimate at that tier, and incremental gain.
- Projection uses the already-selected source's existing `IncentiveEstimate`; retains the currently qualified Sunday bonus only, does not assume future Sunday bonus eligibility, and excludes weekly-paid FRC from both totals.
- Preserved source isolation and PC-to-Android PNG handoff; extended canvas height to fit the new panel and retain footer spacing.
- Static source/archive checks only; Windows compilation and paired-device runtime verification pending.

## Windows v232 — FRC weekly payment separation (2026-10-17)
- Kept the existing FRC cumulative calculation and display, with the clarification “Progressively paid weekly”.
- Excluded FRC from the main payment estimate subtotal; the main estimate is now fixed performance reward plus qualifying Sunday bonus only.
- Applied the changed subtotal consistently to Earning Progress and PC-generated earnings flyers and their sync payloads, while retaining the separately visible FRC value.
- Preserved activation tiers, Sunday qualification, and source selection/isolation.
- Source/archive checks only; Windows compilation and paired-device runtime verification remain pending.

- v231: Confirmed the PC flyer hero uses “ESTIMATED EARNINGS” / “ESTIMATE UNAVAILABLE” and monitoring-only disclaimer; aligned release notes with Android estimate-label correction. No payment calculation changes.
## Windows v230 — High-definition share-card components (2026-10-15)
- Increased the complete PC earnings-card rasterization from 2x to 3x (3240 × 4260 pixels at 288 DPI).
- Improved vector text rendering with explicit Segoe UI font weights and grayscale anti-aliasing for clean text on the transparent raster surface; shapes and typography remain vector until final export.
- Payment estimate pass-through and selected-source isolation unchanged.
- Windows build and share-image inspection pending.

## 4.6.0.224 — My Partners loaded-report lookup and share cards (2026-10-14)
- Added Staff-only visibility after profile save; Agent/Partner profiles cannot open My Partners.
- Improved partner name/Trade Code lookup and selection, personalized partner result preview, and PNG export.
- Updated partner-specific labels/examples and retained the separate partner database.

## 4.6.0.223 — My Partner workspace and parity update (2026-10-13)
- Added My Partner as a distinct Windows workspace.
- Searches loaded HQ report snapshots by partner name or trade code; selecting a match populates the partner form.
- Saves profile-scoped partner entries in a separate local SQLite database, `my_partner.db`.
- Clearly labels the PC limitation: no SMS sending and no invented partner-check results.
- Updated master work sheet and Android/Windows parity notes.
- Preserved `PaymentRules.cs`, HQ snapshot data, and payment calculations.
- Verification: archive integrity and XAML XML checked; Windows compilation and desktop-notification delivery are not verified in this environment.

## Windows v222 — Connection refresh and navigation visibility (2026-10-13)
- Improved inactive sidebar contrast and font size.
- Top refresh now checks the bridge health endpoint and provides useful next steps when stopped.
- No payment formula changes.

## v221 — Earnings flier and reach-step messaging parity (2026-10-12)

- Refined earnings-card presentation toward the approved promotional flier concept.
- Encouragement now varies by the existing activation reach step; wording selection does not recalculate earnings or alter thresholds.
- Preserved exact source figures, selected-source isolation, and PC–Android connection visibility.
- Build status: not compiled in this environment.

## 4.6.0.220 — Version identity advance
- Advanced Windows assembly, file and informational versions from 4.6.0.219 to 4.6.0.220 to distinguish this package from the previous flier/connection-status build.
- Carried forward the earnings-flier and persistent PC-link status UI without intended feature or payment-logic changes.
- Build and paired-device behaviour still require GitHub Actions and device testing.

# DevMonitor Windows Change Log

## 4.6.0.218 — Earnings-card handoff build fix
- Fixed an unterminated interpolated string in the PC-initiated earnings-card sharing message by escaping line breaks.
- Retained the v217 sharing workflow and payment calculation boundaries; no payment rules were changed.
- Build verification must be completed by the repository's Windows GitHub Actions workflow.

## 4.6.0.217 — PC-initiated earnings-card handoff
- Added a native Share Earnings Cards page and an entry point from Earning Progress.
- Allows agent selection and a single source per batch: SMS Checker or Loaded Report.
- Reuses source-held/device-monitor figures only; cards contain Today, MTD and Active where available. No new payment estimate is calculated and no cross-source fallback is allowed.
- Generates per-device PNGs and stores them in a local `share_queue`; the encrypted sync response hands them to Android.
- Android opens its native share sheet after receiving the prepared images. Phone acknowledges card IDs on the next exchange; Windows removes acknowledged items.
- No change to payment rules, HQ/payment data sync exclusion, or existing retry/standby sync policy.
- Verification: ZIP integrity and XAML XML checked. Build and live paired-device handoff require GitHub Actions and device testing.

## 4.6.0.225 — Earnings card activation progression parity (2026-10-15)
- Updated PC-generated SMS Checker and Loaded Report share-card PNGs to a portrait, branded DevMonitor flyer style with blue/teal/green accents.
- Added an activation-tier progression track using the existing `PaymentRules` tier thresholds and the selected source's Active figure only. The graphic is presentation-only; it does not introduce payment calculations or cross-source filling.
- Added reach-step-specific encouragement text and a clear unavailable state when Active is absent.
- Retained the PC-to-Android queued image handoff, source period/timestamp labels, batch limits, and acknowledgement flow.
- My Partners already has its own result PNG export; its lookup metrics remain distinct from activation/payment data and are not misrepresented as payment progression.
- No duplicate Flags navigation item was found in the Windows XAML/C# navigation source; no unrelated Flags control was changed.
- Verification: source/archive checks only. Windows compilation and paired Android sharing require GitHub Actions/device testing.


## v226 — Activation progress scale parity (2026-10-15)
- Corrected the Windows-generated share card's activation progress fill to use the full configured 0–300 scale, matching Android behavior.
- Kept PC cards strictly source-figure cards; they do not manufacture payment estimates or combine report sources.

## v227 — Photographic earnings flyer
- Added an embedded hero-photo asset to the PC share-card renderer for visual parity with Android's flyer direction.
- Source figures remain isolated; no payment recalculation was introduced.
- Build verification pending.


## v228 — Share-card estimate and photo resolution
- PC-queued share cards now include the PaymentRules estimate and component breakdown from the selected source.
- Loaded Report Sunday bonus is derived only from qualifying Sunday rows in that same selected HQ report and payment cycle; SMS Checker does not mix in HQ values.
- Missing Active data results in “Estimate unavailable,” not an invented estimate.
- Queue metadata now records activation and estimate components.
- Hero asset prepared at 3× dimensions for cleaner export rendering. Build verification pending.


## v229 — Share card estimate pass-through and 2x output
- Windows share-card renderer now accepts the already-selected `IncentiveEstimate` as an argument and displays it without performing its own payment calculation.
- PNG rasterization increased from 1080 × 1420 at 96 DPI to 2160 × 2840 at 192 DPI so the entire card renders sharper, not only the hero photo.
- The estimate is prepared once in the source-specific share workflow and passed to the renderer.
- Validation pending: compile with the Windows .NET SDK.


## Windows v279 — Android 4.7 parity review and share-card legibility

- Based on the supplied Windows Native v278 source and reviewed against Android v292.
- Ported the latest applicable share-card legibility direction to the Windows earnings-card renderer: stronger contrast for supporting labels, larger supporting text, and width-fitting for long source/period, estimate breakdown, tier, and projection-note lines.
- Rendering remains presentation-only and consumes the existing `IncentiveEstimate`; no payment formula, source-selection, Sunday qualification, FRC treatment, or Target calculation was changed.
- Advanced Windows assembly/file/informational version and installer identity to `4.7.0.279`.
- Android v291 on-demand location permission is Android-specific and has no equivalent Windows runtime permission flow.
- Android v292 AdMob report-export credits and SMS-monitoring interstitial threshold are Android SDK/phone behaviours. They are documented as not ported to Windows; no unsupported AdMob SDK or artificial desktop ad gate was added.
- Broader parity items remain tracked in `ANDROID_WINDOWS_PARITY_MATRIX.md`, including dedicated typed editors, complete operational-history reconciliation, company activation report-history views, and full role/screen parity.
- Verification: source-level checks and ZIP integrity only. The .NET 8 Windows build and generated PNG visual review require Windows/GitHub Actions; this environment has no `dotnet` SDK.

## WINDOWS/PC v280 — monthly target forecast and package naming correction

- Trend scope is the current calendar month only, projecting month-end sales from the observed delivery rate against the existing monthly target.
- Display only neutral figures: target, sales so far, projected month-end, target achieved percentage, and remaining balance. No management verdicts, risk labels, or red shortfall warnings.
- Existing two-month retention and protected payment/MOM/HQ logic remain unchanged.
- Packaging rule documented in `PACKAGE_NAMING_AND_MONTHLY_FORECAST_RULE.md`: Android uses `DevMonitor-An-v{VERSION}-...zip`; Windows native uses `DevMonitor-PC-v{VERSION}-...zip`. GitHub workflow unchanged.
- Source ZIP integrity checked; compile/runtime testing must be reported separately and is not implied by this entry.


## Windows/PC v282 — bundled pre-rendered AI voice notifications

- Replaced the earlier device-speech-engine proposal with fixed, bundled WAV audio; no phone or PC text-to-speech engine is required.
- Added an original futuristic chime plus the fixed spoken alert and task-completion phrases.
- Alert clip is limited to warning/error kinds; completion clip is limited to explicit completed-task notifications. Routine information stays silent.
- Audio is best-effort and must not interrupt or trigger business operations. Payment/MOM/HQ logic and two-month retention are protected and unchanged by design.
- Build and runtime playback verification remain pending.

## Windows/PC v283 — first-launch and staff-profile welcome audio

- Integrated the supplied Perfect F1 first-launch recording and Perfect M1 staff-profile recording as bundled WAV assets for offline playback.
- First-launch welcome plays once on the first app startup using a persistent local setting.
- Staff-profile welcome plays after the first successful save of a STAFF profile, once only. Existing profile edits and non-STAFF profiles do not trigger this staff-specific clip.
- Welcome clips are queued and best-effort. No Windows speech synthesis is used; profile, payment, MOM, report and sync logic is unchanged by design.
- PARTNER and AGENT profile welcomes are not substituted with the staff recording; their own exact recordings are still needed.
- Build/runtime verification pending.

## Windows/PC v284 — Agent contact parity support

- Accepts and retains the new `agent_emails` record family in sync and Android archive workflows.
- Local Android photo paths are not treated as portable Windows photo references; native Windows photo/contact editing and rendering remain outstanding.
- Payment/MOM/HQ logic unchanged by design. Compile/runtime verification pending.

## Windows v285 — Agents email visibility and photo-path clarity (2026-10-22)
- Agents directory now displays synced email addresses alongside phone numbers, addresses, and device links.
- The directory labels a saved Android photo path as Android-local metadata, not as an image available on Windows.
- This is not full native contact/photo parity; Windows native agent contact editing, photo-byte transfer and photo-personalized share-card rendering remain outstanding.
- Payment/MOM logic was not intentionally changed.


## Windows v287 — OpenStreetMap agent-location parity (2026-10-22)
- Added a read-only OpenStreetMap launch action for the selected synced agent when valid saved coordinates are available.
- Added validation and helpful messaging when an agent has no valid pin. The pin is managed on Android and appears on Windows after explicit sync.
- Updated parity and master documentation to remove the obsolete Google Maps API-key/billing dependency.
- No payment, MOM, HQ snapshot, or target formulas were changed.


## v317 — Windows navigation accessibility fix
- Increased inactive navigation label contrast.
- Changed selected navigation item to a pale teal with dark text for clear focus.
- Strengthened hover contrast.
- Removed the narrow vertical OFFLINE-FIRST explanatory sidebar panel that wrapped text vertically.
- Navigation routes and business logic unchanged. Source package ZIP integrity and XAML XML parsing checked; Windows compilation/runtime not verified in this environment.
