# Version 4.7.0.321 — Event-driven phone/PC sync

See `REALTIME_SYNC_v321.md`. Windows database/WAL writes increment an event version served through long polling. The Android listener initiates the unchanged encrypted sync exchange. The five-second fallback remains until device-level reliability testing is complete.
