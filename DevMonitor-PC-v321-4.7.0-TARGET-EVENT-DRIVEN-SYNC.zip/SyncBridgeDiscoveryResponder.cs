using System.Net;
using System.Net.Sockets;
using System.Text;

namespace DevMonitor.Windows;

/// <summary>Local-only UDP discovery responder. It advertises no pairing secret or user data.</summary>
public sealed class SyncBridgeDiscoveryResponder : IDisposable
{
    private readonly UdpClient _udp;
    private readonly CancellationTokenSource _stop = new();
    private readonly int _httpPort;
    public SyncBridgeDiscoveryResponder(int httpPort = 43827, int discoveryPort = 43828)
    {
        _httpPort = httpPort;
        _udp = new UdpClient(new IPEndPoint(IPAddress.Any, discoveryPort));
        _udp.EnableBroadcast = true;
        _ = Serve();
    }
    private async Task Serve()
    {
        while (!_stop.IsCancellationRequested)
        {
            UdpReceiveResult packet;
            try { packet = await _udp.ReceiveAsync(_stop.Token); }
            catch { break; }
            var request = Encoding.UTF8.GetString(packet.Buffer).Trim();
            if (!string.Equals(request, "DEVMONITOR_DISCOVER_V1", StringComparison.Ordinal)) continue;
            var host = Environment.MachineName.Replace('|', '-').Replace('\r', ' ').Replace('\n', ' ');
            var response = Encoding.UTF8.GetBytes($"DEVMONITOR_PC_V1|{host}|{_httpPort}");
            try { await _udp.SendAsync(response, packet.RemoteEndPoint, _stop.Token); } catch { }
        }
    }
    public void Dispose() { _stop.Cancel(); _udp.Dispose(); _stop.Dispose(); }
}
