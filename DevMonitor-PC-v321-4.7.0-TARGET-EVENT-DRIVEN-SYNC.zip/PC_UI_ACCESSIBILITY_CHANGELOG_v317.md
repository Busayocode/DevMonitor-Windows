# DevMonitor PC v317 — navigation and typography

- Wrapped the full left navigation list in a vertical ScrollViewer with automatic scrollbar, vertical-only panning, and horizontal scrolling disabled. The brand/header remains fixed while menu entries scroll independently.
- Set the window typography to Segoe UI Variable Text with Segoe UI fallback; increased default button and navigation label sizing slightly and increased navigation hit target height.
- No payment, MOM, HQ snapshot, target, or sync payload/business logic changed in this UI-only update.
- Validation: source ZIP integrity verified after modification. WPF compile/runtime validation has not yet been run in this environment.
