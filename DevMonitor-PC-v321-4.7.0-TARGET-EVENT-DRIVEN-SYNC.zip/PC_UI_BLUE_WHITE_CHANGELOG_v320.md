# DevMonitor PC v320 — Blue buttons on white background

- Replaced the dark navy sidebar with a white sidebar consistent with the main workspace.
- Standardized the app background and alternate surfaces to white.
- Standardized primary action buttons and accent controls on blue (`#2563EB`) with darker blue hover/pressed states.
- Navigation labels are blue on white, with the active page using a blue background and white text; hover uses a pale blue background.
- Preserved the scrollable navigation panel and existing operational logic.

## Verification
- Source ZIP integrity checked after packaging.
- Windows compilation and runtime appearance have not been verified in this environment.
- This is a UI change only. It does not claim to implement event-driven synchronization.
