# DevMonitor PC v318 — LAN discovery, QR invitation, and first-exchange approval

- Added a local UDP discovery responder on port 43828. It advertises only the PC name and sync port; no pairing key or user data is broadcast.
- Added a QR invitation containing the LAN endpoint and pairing key for scanning directly into DevMonitor Android. Treat the QR as a secret; it should only be displayed to the intended device on a trusted network.
- Added explicit PC-side approval before the first encrypted sync exchange for a pairing-key fingerprint. The approved fingerprint is stored in the local DevMonitor settings database and requested again if the key changes.
- Existing AES-GCM payload protocol, sync merge callback, manual URL/key entry, and `.dmdata` fallback remain in place.
- Android must still initiate the first sync using the explicit Sync now action; automatic retries start only after a successful user-initiated exchange.
- Build/runtime verification remains pending in an environment with the .NET 8 Windows Desktop SDK, Android Gradle dependencies, and a Windows/Android device pair available.
