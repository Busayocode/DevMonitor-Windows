# DevMonitor near-real-time sync — Windows v319

- The Windows bridge continues to respond to encrypted Android sync requests. Android now polls every 5 seconds while the Next Level screen is active, allowing operational changes to flow in either direction on the next successful request.
- The bridge remains dependent on DevMonitor running and the PC being awake and reachable on the trusted LAN.
- This is near-real-time polling, not server push. Android backgrounding, network interruptions, Windows sleep, or a stopped bridge pause sync.
- Existing AES-GCM envelope and sync protocol remain unchanged. HQ snapshots and payment records remain excluded and protected.
- Build and paired-device behavior must be verified before calling this a verified release.
