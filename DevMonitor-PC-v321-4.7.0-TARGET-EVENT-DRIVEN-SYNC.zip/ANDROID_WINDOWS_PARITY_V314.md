# Android–Windows parity note — v314

- Android v313 remains the source reference for Firebase public broadcast and release-note document paths.
- Windows v314 implements read-only display of those public documents; it does not duplicate Android's authenticated broadcast publishing UI.
- Android retains Google sign-in for its existing cloud-backup identity; Windows does not introduce new authentication behavior in this release.
- The partner-authorization request/approval workflow is retired. This is separate from existing partner/contact directory features, which remain.
- Month-on-month trends remain the intended trend view; no 7/30-day trend feature was introduced here.
- Payment, MOM, HQ activation snapshot, target, monthly forecast and sync ownership rules are protected and were not intentionally changed.
- Compilation and runtime parity are unverified until a Windows build and paired-device test are performed.
