# DevMonitor Windows v317 — Phone/PC pairing entry point

This update makes the existing encrypted Android sync bridge easier to find. The sidebar and Dashboard use “Pair Phone ↔ PC”; the connection page gives the current Android navigation path and pairing steps.

Scope: entry point and user guidance only. Current pairing still requires manually entering the PC URL and private pairing key on Android. Automatic local-network discovery, QR-code pairing, and mutual trust confirmation are not included in this release and must not be claimed as available.

The AES-GCM protocol is retained. Payment logic, MOM records/snapshots, HQ activation snapshots, and target calculations are not intentionally modified.

Validation: ZIP integrity and XAML XML parsing only. Windows compilation and runtime are not verified.
