using System.IO;
using System.Net.NetworkInformation;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DevMonitor.Windows;

/// <summary>Local LAN endpoint. Only encrypted AES-GCM envelopes are accepted.</summary>
public sealed class SyncBridgeServer : IDisposable
{
    private readonly HttpListener _listener = new();
    private readonly string _token;
    private readonly Func<string,string> _exchange;
    private readonly Func<Task<bool>> _approveFirstExchange;
    private int _approvedForThisRun;
    private CancellationTokenSource? _stop;
    private FileSystemWatcher? _dbWatcher;
    private readonly object _eventLock = new();
    private TaskCompletionSource<long> _eventPulse = NewPulse();
    private long _changeVersion = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
    private long _suppressFileEventsUntilTicks;
    private static TaskCompletionSource<long> NewPulse() => new(TaskCreationOptions.RunContinuationsAsynchronously);
    private void SignalChange()
    {
        TaskCompletionSource<long> old;
        long version;
        lock (_eventLock) { version = ++_changeVersion; old = _eventPulse; _eventPulse = NewPulse(); }
        old.TrySetResult(version);
    }
    public bool IsRunning => _listener.IsListening;
    public DateTimeOffset? LastSuccessfulExchange { get; private set; }
    public int Port { get; }
    public SyncBridgeServer(string token, Func<string,string> exchange, Func<Task<bool>> approveFirstExchange, int port=43827, string? databasePath=null)
    {
        if (string.IsNullOrWhiteSpace(token) || token.Length < 16) throw new ArgumentException("Pairing key must contain at least 16 characters.", nameof(token));
        _token=token; _exchange=exchange; _approveFirstExchange=approveFirstExchange; Port=port;
        if (!string.IsNullOrWhiteSpace(databasePath))
        {
            var fullPath = Path.GetFullPath(databasePath);
            var dir = Path.GetDirectoryName(fullPath);
            if (!string.IsNullOrWhiteSpace(dir) && Directory.Exists(dir))
            {
                _dbWatcher = new FileSystemWatcher(dir) { NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size | NotifyFilters.FileName, IncludeSubdirectories = false, EnableRaisingEvents = false };
                void OnDbFileEvent(string changedPath)
                {
                    var changed = Path.GetFullPath(changedPath);
                    var isDb = changed.Equals(fullPath, StringComparison.OrdinalIgnoreCase) || changed.Equals(fullPath + "-wal", StringComparison.OrdinalIgnoreCase);
                    if (isDb && DateTime.UtcNow.Ticks > Interlocked.Read(ref _suppressFileEventsUntilTicks)) SignalChange();
                }
                _dbWatcher.Changed += (_, e) => OnDbFileEvent(e.FullPath);
                _dbWatcher.Created += (_, e) => OnDbFileEvent(e.FullPath);
                _dbWatcher.Renamed += (_, e) => OnDbFileEvent(e.FullPath);
            }
        }
        _listener.Prefixes.Add($"http://+:{port}/");
    }
    public void Start(){ if(IsRunning)return; _stop=new CancellationTokenSource(); _listener.Start(); if (_dbWatcher is not null) _dbWatcher.EnableRaisingEvents=true; _=Serve(_stop.Token); }
    public void Stop(){try{_stop?.Cancel();_listener.Stop();}catch{} }
    private async Task Serve(CancellationToken ct)
    {
        while(!ct.IsCancellationRequested && _listener.IsListening)
        {
            HttpListenerContext ctx;
            try{ctx=await _listener.GetContextAsync().WaitAsync(ct);}catch{break;}
            _=Task.Run(()=>Handle(ctx),ct);
        }
    }
    private async Task Handle(HttpListenerContext ctx)
    {
        try
        {
            ctx.Response.Headers["Cache-Control"]="no-store";
            ctx.Response.Headers["X-Content-Type-Options"]="nosniff";
            if(ctx.Request.HttpMethod=="GET" && ctx.Request.Url?.AbsolutePath=="/health")
            { await Write(ctx,200,"{\"service\":\"DevMonitor Sync Bridge\",\"protocol\":1,\"encrypted\":true,\"events\":true}"); return; }
            if(ctx.Request.HttpMethod=="GET" && ctx.Request.Url?.AbsolutePath=="/events")
            {
                long after = long.TryParse(ctx.Request.QueryString["after"], out var parsed) ? parsed : 0;
                Task<long>? waitTask = null; long current;
                lock (_eventLock) { current = _changeVersion; if (current <= after) waitTask = _eventPulse.Task; }
                if (current <= after && waitTask is not null) { try { current = await waitTask.WaitAsync(TimeSpan.FromSeconds(25), _stop?.Token ?? CancellationToken.None); } catch (TimeoutException) { lock (_eventLock) current = _changeVersion; } catch (OperationCanceledException) { } }
                await Write(ctx,200,JsonSerializer.Serialize(new { version=current, changed=current>after })); return;
            }
            if(ctx.Request.HttpMethod!="POST" || ctx.Request.Url?.AbsolutePath!="/sync") { await Write(ctx,404,"{\"error\":\"not_found\"}");return; }
            if(ctx.Request.ContentLength64>15*1024*1024){await Write(ctx,413,"{\"error\":\"too_large\"}");return;}
            using var reader=new StreamReader(ctx.Request.InputStream,ctx.Request.ContentEncoding);
            var envelope=JsonDocument.Parse(await reader.ReadToEndAsync());
            var cipher=Convert.FromBase64String(envelope.RootElement.GetProperty("payload").GetString()??"");
            if(cipher.Length<12+16) throw new InvalidDataException("Invalid encrypted payload.");
            var key=SHA256.HashData(Encoding.UTF8.GetBytes(_token)); var nonce=cipher[..12]; var data=cipher[12..]; var plain=new byte[data.Length-16];
            using(var aes=new AesGcm(key,16)) aes.Decrypt(nonce,data.AsSpan(0,data.Length-16),data.AsSpan(data.Length-16,16),plain);
            var request=Encoding.UTF8.GetString(plain);
            if (Volatile.Read(ref _approvedForThisRun) == 0)
            {
                var approved = await _approveFirstExchange();
                if (!approved) { await Write(ctx, 403, "{\"error\":\"pairing_not_approved\"}"); return; }
                Interlocked.Exchange(ref _approvedForThisRun, 1);
            }
            // Ignore database file notifications caused by applying the incoming sync package.
            Interlocked.Exchange(ref _suppressFileEventsUntilTicks, DateTime.UtcNow.AddSeconds(5).Ticks);
            var response=_exchange(request);
            LastSuccessfulExchange=DateTimeOffset.UtcNow;
            var outNonce=RandomNumberGenerator.GetBytes(12); var outCipher=new byte[response.Length==0?16:Encoding.UTF8.GetByteCount(response)+16]; var outPlain=Encoding.UTF8.GetBytes(response);
            using(var aes=new AesGcm(key,16)) aes.Encrypt(outNonce,outPlain,outCipher.AsSpan(0,outPlain.Length),outCipher.AsSpan(outPlain.Length,16));
            await Write(ctx,200,JsonSerializer.Serialize(new{payload=Convert.ToBase64String(outNonce.Concat(outCipher).ToArray())}));
        }
        catch(Exception ex){try{await Write(ctx,400,JsonSerializer.Serialize(new{error="sync_failed",message=ex.Message}));}catch{}}
    }
    private static async Task Write(HttpListenerContext c,int status,string body){var bytes=Encoding.UTF8.GetBytes(body);c.Response.StatusCode=status;c.Response.ContentType="application/json; charset=utf-8";c.Response.ContentLength64=bytes.Length;await c.Response.OutputStream.WriteAsync(bytes);c.Response.Close();}
    public static string GetLanAddresses()=>string.Join(", ",NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up).SelectMany(n=>n.GetIPProperties().UnicastAddresses).Where(a=>a.Address.AddressFamily==AddressFamily.InterNetwork&&!IPAddress.IsLoopback(a.Address)).Select(a=>a.Address.ToString()).Distinct());
    public void Dispose(){Stop();_dbWatcher?.Dispose();_listener.Close();_stop?.Dispose();}
}
