# DevMonitor Windows/PC v314 — Firebase broadcast and release tracking (read-only)

## Base
- Cumulative Windows-native source based on v288 agent-directory photo thumbnail package.
- Windows assembly, file and informational versions advanced to `4.7.0.314`.

## Changes
- Added a global broadcast ticker that reads `app_config/devmonitor_broadcast` from the existing Firebase project `fieldpulse-b3eb3` using the Firestore REST API.
- The ticker displays only an active, non-expired message. Cloud failure is non-fatal and does not prevent the offline-first desktop app from opening.
- Added a Dashboard “What's New” area that reads the latest version code/name from `app_config/devmonitor_version`, then reads that release's highlights from `app_releases/{latestVersionCode}`.
- The Windows integration is read-only. It does not add a second sign-in system, publish broadcasts, alter Firestore rules, or bypass staff authorization. Staff publishing remains a separately authenticated workflow.
- The PC source contained no `partner_authorization_requests` implementation or Firestore authorization-request code. This update does not add any such feature; the agent/contact directory and existing partner-management business functions remain distinct from the retired authorization-request workflow.

## Firebase expectations
- Firestore public read rules must be published for `app_config/devmonitor_broadcast`, `app_config/devmonitor_version`, and `app_releases/{releaseId}`.
- The configured `latestVersionCode` must match a release document ID. The app uses bundled/local functionality if the network, Firestore API, or remote documents are unavailable.
- The broadcast document supports `message` (string), `active` (boolean), and optional `expiresAt` (timestamp). Placement is currently rendered in the top banner on Windows.
- This is a public-read-only client. Do not store secrets or private data in these public documents.

## Protected logic
- No payment calculations, eligibility gates, MOM snapshots/databases, HQ activation snapshots, target calculations, monthly forecast formulas, import/replace rules, agent identity ownership, or Android-PC sync ownership were intentionally changed.

## Validation status
- Source ZIP integrity, XML parsing, and source-level checks are performed for this package.
- A .NET/WPF compile and live Firebase runtime test are not confirmed in this environment because the .NET SDK is unavailable and the app has not been launched against the live project.
