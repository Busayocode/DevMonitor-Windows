# DevMonitor PC v321 — Event-driven sync bridge

- Added `GET /events?after=<version>` long-poll endpoint. It returns only a monotonic change version, never operational payload data.
- The Windows bridge watches the local SQLite database and WAL file; writes caused by an incoming sync are briefly suppressed to reduce echo-triggered exchanges.
- Android can wait on this event endpoint and immediately run the existing encrypted `/sync` exchange when the PC database changes.
- Kept the five-second Android fallback and existing retry/backoff behavior. Do not raise the fallback to 30 seconds until Android/Windows device testing confirms event delivery, reconnect behavior, and missed-event recovery.
- Existing AES-GCM encrypted sync payload and first-pair approval remain in place.
- Protected HQ snapshots, target values, payment records, and MOM/payment calculations remain outside the sync payload. `monthly_target` was removed from the `daily_observations` transfer projection; Android's local target column is not overwritten by an absent field.
- The event listener is available only while the PC bridge is running and Android's pairing/Next Level screen is active. It is not an always-on service.

## Verification status

Source-level changes and ZIP integrity are checked. A Windows build and Android Gradle compile could not be run in this environment (the .NET SDK is unavailable and Gradle distribution download is blocked by unavailable network access). Device-level two-way latency, reconnect, and sleep/resume tests remain required; this package must not be treated as runtime-verified.
