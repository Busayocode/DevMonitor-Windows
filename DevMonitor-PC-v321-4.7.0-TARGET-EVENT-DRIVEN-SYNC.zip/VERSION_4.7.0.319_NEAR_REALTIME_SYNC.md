# DevMonitor Windows v319 — near-real-time sync

This source carries the existing PC v318 pairing/bridge code and documents the matching Android v318 polling interval. The Android client initiates encrypted sync requests every five seconds while the Next Level screen is active. The Windows bridge merges the operational package and returns the PC's current operational data on each request.

No sync protocol or protected financial/HQ data merge scope was changed. This is polling-based near-real-time sync, not push streaming. Runtime and build verification remain outstanding.
