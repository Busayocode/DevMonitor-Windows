package com.aziitech.simregmonitor

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed interface NextLevelResult {
    data class Trends(val rows: List<NextLevelEngine.AdvancedTrend>) : NextLevelResult
    data class Anomalies(val rows: List<NextLevelEngine.Anomaly>) : NextLevelResult
    data class Reconciliation(val rows: List<NextLevelEngine.Reconciliation>) : NextLevelResult
    data class Health(val value: NextLevelEngine.Health) : NextLevelResult
}

@Composable
fun NextLevelScreen(
    context: Context,
    db: DatabaseStore,
    company: CompanyActivationStore,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onClose: () -> Unit
) {
    var section by remember { mutableStateOf(0) }
    var trends by remember { mutableStateOf<List<NextLevelEngine.AdvancedTrend>>(emptyList()) }
    var anomalies by remember { mutableStateOf<List<NextLevelEngine.Anomaly>>(emptyList()) }
    var reconciliation by remember { mutableStateOf<List<NextLevelEngine.Reconciliation>>(emptyList()) }
    var health by remember { mutableStateOf<NextLevelEngine.Health?>(null) }
    var busy by remember { mutableStateOf(false) }
    var refreshedAt by remember { mutableStateOf<String?>(null) }
    var trendDays by remember { mutableIntStateOf(30) }
    var bridgeEndpoint by remember { mutableStateOf(db.getSetting("sync_bridge_endpoint") ?: "http://192.168.1.10:43827") }
    var bridgeKey by remember { mutableStateOf(db.getSetting("sync_pairing_key") ?: "") }
    var bridgeStatus by remember { mutableStateOf("Not connected") }
    var bridgeBusy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun refresh(target: Int = section) {
        if (busy) return
        busy = true
        scope.launch {
            val result = withContext(Dispatchers.Default) {
                when (target) {
                    0 -> NextLevelResult.Trends(NextLevelEngine.advancedTrends(db, days = trendDays))
                    1 -> NextLevelResult.Anomalies(NextLevelEngine.anomalies(db))
                    2 -> NextLevelResult.Reconciliation(NextLevelEngine.reconcile(db, company))
                    else -> NextLevelResult.Health(NextLevelEngine.health(context, db, company))
                }
            }
            when (result) {
                is NextLevelResult.Trends -> trends = result.rows
                is NextLevelResult.Anomalies -> anomalies = result.rows
                is NextLevelResult.Reconciliation -> reconciliation = result.rows
                is NextLevelResult.Health -> health = result.value
            }
            refreshedAt = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date())
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        modifier = Modifier.fillMaxWidth(),
        title = { Text("NEXT LEVEL", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Text("Advanced intelligence, reconciliation, health and recovery — all refresh-driven.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Trends", "Anomalies", "HQ", "Health").forEachIndexed { i, label ->
                        FilterChip(selected = section == i, onClick = { section = i }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                DevMonitorOutlinedButton(onClick = { refresh() }, enabled = !busy) { Text(if (busy) "Working…" else "↻ Refresh") }
                if (refreshedAt != null) Text("Refreshed $refreshedAt", style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(8.dp))
                when (section) {
                    0 -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = trendDays == 7, onClick = { trendDays = 7 }, label = { Text("7 days") })
                            FilterChip(selected = trendDays == 30, onClick = { trendDays = 30 }, label = { Text("30 days") })
                        }
                        AdvancedTrendsBody(trends, onRefresh = { refresh(0) })
                    }
                    1 -> AnomalyBody(anomalies, onRefresh = { refresh(1) })
                    2 -> ReconciliationBody(reconciliation, onRefresh = { refresh(2) })
                    3 -> HealthBody(
                        health = health,
                        onBackup = onBackup,
                        onRestore = onRestore,
                        onOptimize = {
                            if (!busy) {
                                busy = true
                                scope.launch {
                                    withContext(Dispatchers.IO) { NextLevelEngine.optimizeDatabase(db) }
                                    refreshedAt = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date())
                                    busy = false
                                }
                            }
                        },
                        onRefresh = { refresh(3) },
                        context = context,
                        db = db,
                        bridgeEndpoint = bridgeEndpoint,
                        onBridgeEndpointChange = { bridgeEndpoint = it },
                        bridgeKey = bridgeKey,
                        onBridgeKeyChange = { bridgeKey = it },
                        bridgeStatus = bridgeStatus,
                        onBridgeStatusChange = { bridgeStatus = it },
                        bridgeBusy = bridgeBusy,
                        onBridgeBusyChange = { bridgeBusy = it },
                        scope = scope
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable private fun AdvancedTrendsBody(rows: List<NextLevelEngine.AdvancedTrend>, onRefresh: () -> Unit) {
    if (rows.isEmpty()) { DevMonitorEmptyState("No advanced trend data", "Press Refresh after observations or a report are available.", "Refresh", onRefresh) ; return }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(rows.asReversed()) { r ->
            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.date, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Sales ${r.sales}  •  Active ${r.active}", style = MaterialTheme.typography.labelSmall)
                }
                Text("7-day avg ${"%.1f".format(r.sevenDayAverage)}  •  Δ ${if (r.salesDelta >= 0) "+" else ""}${r.salesDelta}  •  Bar48 ${r.bar48}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable private fun AnomalyBody(rows: List<NextLevelEngine.Anomaly>, onRefresh: () -> Unit) {
    if (rows.isEmpty()) { DevMonitorEmptyState("No deterministic anomalies", "No configured operational signal was detected in the selected period.", "Refresh", onRefresh) ; return }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(rows) { r ->
            AuroraGlassCard(Modifier.fillMaxWidth(), if (r.severity == "HIGH") MaterialTheme.colorScheme.error else AuroraEmerald) {
                Text("${r.severity} • ${r.title}", fontWeight = FontWeight.ExtraBold)
                Text(r.code, style = MaterialTheme.typography.labelMedium)
                Text(r.detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable private fun ReconciliationBody(rows: List<NextLevelEngine.Reconciliation>, onRefresh: () -> Unit) {
    if (rows.isEmpty()) { DevMonitorEmptyState("No reconciliation rows", "Load a current report and have local observations available, then refresh.", "Refresh", onRefresh) ; return }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(rows) { r ->
            AuroraGlassCard(Modifier.fillMaxWidth(), if (r.status == "MATCH") AuroraGreen else MaterialTheme.colorScheme.error) {
                Text(r.date, fontWeight = FontWeight.Bold)
                Text("Local ${r.localObserved}  •  HQ ${r.hqObserved}  •  Difference ${r.difference}", style = MaterialTheme.typography.bodySmall)
                Text(r.status, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable private fun HealthBody(
    health: NextLevelEngine.Health?,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onOptimize: () -> Unit,
    onRefresh: () -> Unit,
    context: Context,
    db: DatabaseStore,
    bridgeEndpoint: String,
    onBridgeEndpointChange: (String) -> Unit,
    bridgeKey: String,
    onBridgeKeyChange: (String) -> Unit,
    bridgeStatus: String,
    onBridgeStatusChange: (String) -> Unit,
    bridgeBusy: Boolean,
    onBridgeBusyChange: (Boolean) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    if (health == null) { DevMonitorEmptyState("Diagnostics not run", "Refresh to inspect connectivity, data freshness, SMS storage and database health.", "Refresh", onRefresh) ; return }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item { AuroraGlassCard(Modifier.fillMaxWidth(), if (health.online) AuroraGreen else MaterialTheme.colorScheme.error) {
            Text(if (health.online) "ONLINE" else "OFFLINE", fontWeight = FontWeight.ExtraBold)
            Text("Observation rows: ${health.observationRows}  •  SMS inbox: ${health.smsRows}")
            Text("Latest HQ coverage: ${health.reportCoverage ?: "none"}")
            Text("Database: ${health.databaseRows} indexed records  •  Free storage ${health.freeStorageMb} MB", style = MaterialTheme.typography.bodySmall)
            Text("SQLite integrity: ${health.databaseIntegrity}", style = MaterialTheme.typography.bodySmall)
        } }
        item { Text("Phone ↔ PC Sync Bridge", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
        item { Text("Operational two-way sync over local Wi-Fi or a trusted HTTPS endpoint. The pairing key encrypts each payload with AES-GCM. HQ monthly snapshots, imported reports and payment records are excluded.", style = MaterialTheme.typography.bodySmall) }
        item { OutlinedTextField(value=bridgeEndpoint,onValueChange=onBridgeEndpointChange,label={Text("PC bridge URL")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value=bridgeKey,onValueChange=onBridgeKeyChange,label={Text("Pairing key")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
        item { Text(bridgeStatus, style = MaterialTheme.typography.bodySmall) }
        item { DevMonitorOutlinedButton(onClick={
            if (bridgeBusy) return@DevMonitorOutlinedButton
            db.setSetting("sync_bridge_endpoint", bridgeEndpoint.trim())
            db.setSetting("sync_pairing_key", bridgeKey)
            onBridgeBusyChange(true)
            onBridgeStatusChange("Synchronizing…")
            scope.launch {
                val result = runCatching {
                    withContext(Dispatchers.IO) { SyncBridgeClient.sync(context, db, bridgeEndpoint, bridgeKey) }
                }
                onBridgeStatusChange(result.fold(
                    { "Synced • ${it.devices} device codes, ${it.tasks} tasks, ${it.notes} notes, ${it.sms} SMS records, ${it.extended} archived Android records" },
                    { "Sync failed: ${it.message ?: "unknown error"}" }
                ))
                onBridgeBusyChange(false)
            }
        },enabled=!bridgeBusy) { Text(if(bridgeBusy)"Synchronizing…" else "Sync now") } }
        item { Text("Pairing key is private. For remote sync, use an HTTPS reverse proxy or trusted VPN; never expose the plain HTTP LAN port directly to the public internet.", style = MaterialTheme.typography.bodySmall) }
        item { Text("Sync Centre", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DevMonitorOutlinedButton(onClick = onBackup, modifier = Modifier.weight(1f)) { Text("Backup") }
            DevMonitorOutlinedButton(onClick = onRestore, modifier = Modifier.weight(1f)) { Text("Restore") }
        } }
        item {
            DevMonitorOutlinedButton(onClick = onOptimize) { Text("Optimize local database") }
        }
        item { Text("Recovery remains explicit: no automatic cloud sync or heavy background operation is started from this screen.", style = MaterialTheme.typography.bodySmall) }
        item { Text("Explain-this: local observations are Device Monitor evidence; HQ values come from the latest Loaded Report available to the current month. Differences are surfaced, not silently corrected.", style = MaterialTheme.typography.bodySmall) }
    }
}
