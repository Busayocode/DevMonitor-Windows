## 4.7 Target refinement + WPF compile fix (v278)
- Target achievement percentage is actual activity divided by the expected cumulative target for the same reporting day.
- No shortfall/deficit amount or behind-pace warning is displayed. Full-month target progress remains a separate, neutral percentage.
- Removed an unsupported WPF FormattedText.TextRenderingMode assignment that prevented Windows compilation; retained normal WPF text rendering.


## Windows 4.7.0.276 — Target
- Added a monthly target field to Profile & Company. Staff and Partner require a positive target; Agent target is fixed at 150.
- Added a Monthly Target card to Month-on-Month with cumulative current-month HQ activations, target achievement percentage, expected-to-date pace, and shortfall/on-track status.
- Staff and Partner totals are aggregated across all matching devices in the current HQ month; Agent totals use the saved My Devices scope.
- No payment formula or authoritative HQ snapshot/import behavior changed. Source-level review completed; Windows compilation remains pending.

## Windows v235 — Strict payment-card history and My Partners search parity (2026-10-17)
- Ported the Android v275 evidence-based payment-card eligibility principle to PC-initiated SMS Checker card batches: require device-specific Active history from the previous calendar month, a successful current-month phone Active result, and after the 20th a qualifying baseline through the 20th plus a successful post-20th Active result.
- Missing evidence now produces a specific skip reason at every point in the month; missing history is never treated as zero. Loaded Report card sourcing remains independent and is not filled from SMS Checker values.
- Aligned Windows My Partners lookup with Android v239/v252: searches the latest retained HQ directory, supports case-insensitive partial partner-name/Trade-Code matching, ignores blank Trade Codes, deduplicates by canonical Trade Code, and caps visible matches at 12. Historical snapshots remain accessible in Loaded Report.
- Preserved the established payment tier table, FRC weekly separation, Sunday-bonus qualification, next-tier projection, native Android share handoff, HQ snapshot data, and existing Windows offline workflows.
- Verification: source-level review and ZIP integrity checks; Windows compilation and paired-device runtime verification remain to be run in GitHub Actions.

## Windows v234 — Historical eligibility gate for payment progression (2026-10-17)
- PC-initiated SMS Checker share-card batches now skip devices lacking a valid historical Active baseline through the 20th once the payment cycle enters the 21st-to-month-end period.
- Baseline evidence may come from a successful dated phone Active result or a qualifying imported HQ report covering the calendar month through the 20th for that device. A successful post-20th Active observation is also required before a current-cycle card can be queued. Missing history/current evidence is reported as a skipped card rather than treated as zero.
- Loaded Report card source remains independent; FRC separation, tier rewards, Sunday qualification, next-tier display, and PC-to-Android handoff are preserved.
- Added stored report coverage-start lookup to verify that an imported snapshot actually covers the required historical boundary.
- Static source/archive checks only; Windows compilation and paired-device runtime verification pending.

## Windows v233 — Share-card next-tier earnings opportunity (2026-10-17)
- PC-generated share cards now show clearly labelled current payment estimate, activations remaining to the next configured tier, projected main estimate at that tier, and incremental gain.
- Projection uses the already-selected source's existing `IncentiveEstimate`; retains the currently qualified Sunday bonus only, does not assume future Sunday bonus eligibility, and excludes weekly-paid FRC from both totals.
- Preserved source isolation and PC-to-Android PNG handoff; extended canvas height to fit the new panel and retain footer spacing.
- Static source/archive checks only; Windows compilation and paired-device runtime verification pending.

## Windows v232 — FRC weekly payment separation (2026-10-17)
- Kept the existing FRC cumulative calculation and display, with the clarification “Progressively paid weekly”.
- Excluded FRC from the main payment estimate subtotal; the main estimate is now fixed performance reward plus qualifying Sunday bonus only.
- Applied the changed subtotal consistently to Earning Progress and PC-generated earnings flyers and their sync payloads, while retaining the separately visible FRC value.
- Preserved activation tiers, Sunday qualification, and source selection/isolation.
- Source/archive checks only; Windows compilation and paired-device runtime verification remain pending.

- v231: Confirmed the PC flyer hero uses “ESTIMATED EARNINGS” / “ESTIMATE UNAVAILABLE” and monitoring-only disclaimer; aligned release notes with Android estimate-label correction. No payment calculation changes.
## Windows v230 — High-definition share-card components (2026-10-15)
- Increased the complete PC earnings-card rasterization from 2x to 3x (3240 × 4260 pixels at 288 DPI).
- Improved vector text rendering with explicit Segoe UI font weights and grayscale anti-aliasing for clean text on the transparent raster surface; shapes and typography remain vector until final export.
- Payment estimate pass-through and selected-source isolation unchanged.
- Windows build and share-image inspection pending.

## 4.6.0.224 — My Partners loaded-report lookup and share cards (2026-10-14)
- Added Staff-only visibility after profile save; Agent/Partner profiles cannot open My Partners.
- Improved partner name/Trade Code lookup and selection, personalized partner result preview, and PNG export.
- Updated partner-specific labels/examples and retained the separate partner database.

## 4.6.0.223 — My Partner workspace and parity update (2026-10-13)
- Added My Partner as a distinct Windows workspace.
- Searches loaded HQ report snapshots by partner name or trade code; selecting a match populates the partner form.
- Saves profile-scoped partner entries in a separate local SQLite database, `my_partner.db`.
- Clearly labels the PC limitation: no SMS sending and no invented partner-check results.
- Updated master work sheet and Android/Windows parity notes.
- Preserved `PaymentRules.cs`, HQ snapshot data, and payment calculations.
- Verification: archive integrity and XAML XML checked; Windows compilation and desktop-notification delivery are not verified in this environment.

## Windows v222 — Connection refresh and navigation visibility (2026-10-13)
- Improved inactive sidebar contrast and font size.
- Top refresh now checks the bridge health endpoint and provides useful next steps when stopped.
- No payment formula changes.

## v221 — Earnings flier and reach-step messaging parity (2026-10-12)

- Refined earnings-card presentation toward the approved promotional flier concept.
- Encouragement now varies by the existing activation reach step; wording selection does not recalculate earnings or alter thresholds.
- Preserved exact source figures, selected-source isolation, and PC–Android connection visibility.
- Build status: not compiled in this environment.

## 4.6.0.220 — Version identity advance
- Advanced Windows assembly, file and informational versions from 4.6.0.219 to 4.6.0.220 to distinguish this package from the previous flier/connection-status build.
- Carried forward the earnings-flier and persistent PC-link status UI without intended feature or payment-logic changes.
- Build and paired-device behaviour still require GitHub Actions and device testing.

# DevMonitor Windows Change Log

## 4.6.0.218 — Earnings-card handoff build fix
- Fixed an unterminated interpolated string in the PC-initiated earnings-card sharing message by escaping line breaks.
- Retained the v217 sharing workflow and payment calculation boundaries; no payment rules were changed.
- Build verification must be completed by the repository's Windows GitHub Actions workflow.

## 4.6.0.217 — PC-initiated earnings-card handoff
- Added a native Share Earnings Cards page and an entry point from Earning Progress.
- Allows agent selection and a single source per batch: SMS Checker or Loaded Report.
- Reuses source-held/device-monitor figures only; cards contain Today, MTD and Active where available. No new payment estimate is calculated and no cross-source fallback is allowed.
- Generates per-device PNGs and stores them in a local `share_queue`; the encrypted sync response hands them to Android.
- Android opens its native share sheet after receiving the prepared images. Phone acknowledges card IDs on the next exchange; Windows removes acknowledged items.
- No change to payment rules, HQ/payment data sync exclusion, or existing retry/standby sync policy.
- Verification: ZIP integrity and XAML XML checked. Build and live paired-device handoff require GitHub Actions and device testing.

## 4.6.0.225 — Earnings card activation progression parity (2026-10-15)
- Updated PC-generated SMS Checker and Loaded Report share-card PNGs to a portrait, branded DevMonitor flyer style with blue/teal/green accents.
- Added an activation-tier progression track using the existing `PaymentRules` tier thresholds and the selected source's Active figure only. The graphic is presentation-only; it does not introduce payment calculations or cross-source filling.
- Added reach-step-specific encouragement text and a clear unavailable state when Active is absent.
- Retained the PC-to-Android queued image handoff, source period/timestamp labels, batch limits, and acknowledgement flow.
- My Partners already has its own result PNG export; its lookup metrics remain distinct from activation/payment data and are not misrepresented as payment progression.
- No duplicate Flags navigation item was found in the Windows XAML/C# navigation source; no unrelated Flags control was changed.
- Verification: source/archive checks only. Windows compilation and paired Android sharing require GitHub Actions/device testing.


## v226 — Activation progress scale parity (2026-10-15)
- Corrected the Windows-generated share card's activation progress fill to use the full configured 0–300 scale, matching Android behavior.
- Kept PC cards strictly source-figure cards; they do not manufacture payment estimates or combine report sources.

## v227 — Photographic earnings flyer
- Added an embedded hero-photo asset to the PC share-card renderer for visual parity with Android's flyer direction.
- Source figures remain isolated; no payment recalculation was introduced.
- Build verification pending.


## v228 — Share-card estimate and photo resolution
- PC-queued share cards now include the PaymentRules estimate and component breakdown from the selected source.
- Loaded Report Sunday bonus is derived only from qualifying Sunday rows in that same selected HQ report and payment cycle; SMS Checker does not mix in HQ values.
- Missing Active data results in “Estimate unavailable,” not an invented estimate.
- Queue metadata now records activation and estimate components.
- Hero asset prepared at 3× dimensions for cleaner export rendering. Build verification pending.


## v229 — Share card estimate pass-through and 2x output
- Windows share-card renderer now accepts the already-selected `IncentiveEstimate` as an argument and displays it without performing its own payment calculation.
- PNG rasterization increased from 1080 × 1420 at 96 DPI to 2160 × 2840 at 192 DPI so the entire card renders sharper, not only the hero photo.
- The estimate is prepared once in the source-specific share workflow and passed to the renderer.
- Validation pending: compile with the Windows .NET SDK.
