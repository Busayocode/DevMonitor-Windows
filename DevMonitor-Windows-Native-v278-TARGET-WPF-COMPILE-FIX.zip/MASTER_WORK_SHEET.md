## 4.7 Target refinement + WPF compile fix (v278)
- Target achievement percentage is actual activity divided by the expected cumulative target for the same reporting day.
- No shortfall/deficit amount or behind-pace warning is displayed. Full-month target progress remains a separate, neutral percentage.
- Removed an unsupported WPF FormattedText.TextRenderingMode assignment that prevented Windows compilation; retained normal WPF text rendering.


## Windows 4.7.0.276 — Target
- Added a monthly target field to Profile & Company. Staff and Partner require a positive target; Agent target is fixed at 150.
- Added a Monthly Target card to Month-on-Month with cumulative current-month HQ activations, target achievement percentage, expected-to-date pace, and shortfall/on-track status.
- Staff and Partner totals are aggregated across all matching devices in the current HQ month; Agent totals use the saved My Devices scope.
- No payment formula or authoritative HQ snapshot/import behavior changed. Source-level review completed; Windows compilation remains pending.

## Windows v235 — Strict payment-card history and My Partners search parity (2026-10-17)
- Ported the Android v275 evidence-based payment-card eligibility principle to PC-initiated SMS Checker card batches: require device-specific Active history from the previous calendar month, a successful current-month phone Active result, and after the 20th a qualifying baseline through the 20th plus a successful post-20th Active result.
- Missing evidence now produces a specific skip reason at every point in the month; missing history is never treated as zero. Loaded Report card sourcing remains independent and is not filled from SMS Checker values.
- Aligned Windows My Partners lookup with Android v239/v252: searches the latest retained HQ directory, supports case-insensitive partial partner-name/Trade-Code matching, ignores blank Trade Codes, deduplicates by canonical Trade Code, and caps visible matches at 12. Historical snapshots remain accessible in Loaded Report.
- Preserved the established payment tier table, FRC weekly separation, Sunday-bonus qualification, next-tier projection, native Android share handoff, HQ snapshot data, and existing Windows offline workflows.
- Verification: source-level review and ZIP integrity checks; Windows compilation and paired-device runtime verification remain to be run in GitHub Actions.

## Windows v234 — Historical eligibility gate for payment progression (2026-10-17)
- PC-initiated SMS Checker card batches now require a valid historical Active baseline through the 20th after the 21st-cycle boundary. A missing baseline causes that device's card to be skipped with an explicit reason, never treated as zero.
- Baseline eligibility checks successful phone Active history or a device row in an imported HQ report whose coverage spans the required month start through the 20th; a successful post-20th Active observation is also required to create a current-cycle card.
- Loaded Report cards remain independent; next-tier card, FRC weekly separation, source isolation, and PC-to-Android handoff are preserved.
- Windows project version 4.6.0.234; compilation and paired-device verification pending.

## Windows v232 — FRC weekly payment separation (2026-10-17)
- Kept the existing FRC cumulative calculation and display, with the clarification “Progressively paid weekly”.
- Excluded FRC from the main payment estimate subtotal; the main estimate is now fixed performance reward plus qualifying Sunday bonus only.
- Applied the changed subtotal consistently to Earning Progress and PC-generated earnings flyers and their sync payloads, while retaining the separately visible FRC value.
- Preserved activation tiers, Sunday qualification, and source selection/isolation.
- Source/archive checks only; Windows compilation and paired-device runtime verification remain pending.

- Share-card truth-in-labeling: PC hero must say “ESTIMATED EARNINGS” or “ESTIMATE UNAVAILABLE”, never imply a payment has already been received. Renderer remains presentation-only.
## Current update — Windows v230 share-card component sharpness
- Earnings card is rasterized at 3x (3240 × 4260) with explicit Segoe UI typography and grayscale antialiasing for clearer individual components.
- Renderer remains presentation-only and consumes the existing estimate object; payment rules unchanged.
- Windows build verification pending.

## Current update — Windows v221 (2026-10-12)

- Deliverable: DevMonitor-Windows-Native-v221-EARNINGS-FLIER-REACH-MESSAGES-CONNECTION-STATUS.zip
- Scope: earnings flier visual direction, reach-step-specific encouragement copy, and PC–Android connection-status visibility/parity.
- Guardrail: payment calculations and category thresholds remain unchanged; card values must come only from the chosen source.
- Verification: ZIP integrity checked; no claim of a successful platform build.

# DevMonitor Windows Master Work Sheet

## Current package
- Windows native version: **4.6.0.232** (source package; build not yet verified).
- Android handoff baseline: **4.6.0-NEXT versionCode 227**.

## Cross-device earnings-card sharing
- Start on Windows from **Earning Progress → Share an agent card via Android** or **Share Earnings Cards**.
- Select one source for the whole batch: SMS Checker or Loaded Report. Select agent rows; every linked device with values in that source gets a separate PNG.
- Cards show source-only Today, MTD and Active values, the selected source, reporting period, as-of timestamp, and a monitoring-only warning. This PC handoff does not compute a new payment estimate or fill missing values from another source.
- Cards are queued locally as `share_queue` records, included in the existing AES-GCM encrypted sync response, then presented by Android in the native share sheet. Android sends card IDs back as acknowledgements on the next exchange. The PC removes acknowledged queue entries.
- The share-sheet handoff is not proof that WhatsApp or another recipient received a message. User selects recipient and confirms sending.
- Limits: up to 20 cards per batch; transfer uses the existing 15 MB encrypted bridge request limit; Android rejects individual PNG payloads above 2 MB.

## Protected boundaries
- No changes to `PaymentRules.cs` or the Android payment calculation paths.
- HQ snapshots and payment records remain excluded from synchronization.
- Existing five-minute standby reachability policy and bounded retry/backoff behavior are unchanged.

## Verification status
- Source archive and documentation prepared. Android Gradle compilation could not be completed in this environment because the Gradle distribution download requires network access. Windows compilation and paired Android↔PC handoff remain to be verified by GitHub Actions and a real paired-device test.


## Windows v222 connection feedback and navigation contrast (2026-10-13)
- Inactive sidebar navigation now uses higher-contrast white text and a slightly larger font.
- Header refresh still refreshes the current page and now also checks the local bridge health endpoint when the bridge is running. If stopped, it explains the exact Phone Data Exchange action needed to start it.
- A local health response is not represented as proof of a successful Android sync. Payment calculations remain unchanged.


## Windows v223 — My Partner workspace and Android v237 parity pass
- Added a dedicated My Partner navigation page. It searches imported HQ snapshots by partner name/trade code and selecting a row fills the form.
- Partner entries and history tables live in a separate `%LOCALAPPDATA%\DevMonitor\my_partner.db`, scoped to the local profile; no writes to My Devices, SMS Checker observations, HQ snapshots, or payment progression.
- Windows does not send SMS and does not fabricate partner-check outcomes. Phone-side result delivery and native desktop toast notifications remain follow-up verification/work items.
- Payment rules are unchanged.
- Validation: ZIP integrity and XAML XML validation performed; .NET/Windows compilation unavailable in this environment.


## Windows v224 — My Partners refinement
- My Partners is revealed only for a saved STAFF profile and is hidden for AGENT/PARTNER roles.
- Search loaded report by partner name or Trade Code, select a match to populate official details, and view personalized result details.
- Export the current My Partners result preview as a PNG share card.
- Separate `my_partner.db` retained; original SMS Checker and payment rules remain unchanged.

## Windows v225 — Share-card progression parity (2026-10-15)
- PC-generated SMS Checker and Loaded Report earnings cards now use the branded flyer layout and show activation tiers at 30, 50, 70, 100, 150, 200, 250 and 300 based only on the selected source's Active value.
- The progression graphic and encouragement copy are presentation-only; all payment calculations remain governed by the existing payment rules. Missing Active values are labelled unavailable rather than guessed.
- PC continues to queue PNGs for Android's native share sheet. The separate My Partners result card remains a lookup-result artifact and is not assigned invented payment progression.
- No duplicate Flags menu item was found in Windows navigation source. Build verification still requires the Windows GitHub Actions workflow.


## v226 follow-up — Share card parity
- [x] Correct PC activation progress fill to represent 0–300 scale instead of progress toward the next milestone only.
- [ ] Run Windows GitHub Actions build and inspect generated PNG before release.

## v227 — Photographic earnings flyer
- Windows share cards now include an embedded photographic hero asset alongside branded promotional copy.
- Figures remain source-specific; activation progression is based only on the selected source's Active count.
- Build verification pending.


## v228 share-card correction
- Share-card output includes the established estimated subtotal, fixed reward, FRC component, and Sunday bonus.
- Estimate is calculated using PaymentRules from the chosen source's Active figure. Loaded Report Sunday bonus only uses qualifying Sundays from the same selected HQ report; SMS Checker estimate does not mix sources.
- Missing Active input is reported as unavailable.
- Photo asset dimensions: 1542 × 1545 for cleaner downsampling. Build verification pending.


## v229 — Share card display-only estimate and full-card resolution
- `RenderSharePng` accepts `IncentiveEstimate?` and only displays the supplied values; it no longer calls `PaymentRules.Estimate` internally.
- Whole-card output is now 2160 × 2840 at 192 DPI.
- Source-specific data selection remains in `QueueShareCards`; the rendering function is a presentation layer.


## Shareable payment card — next-tier earnings opportunity (v233, 2026-10-17)
- PC-generated earnings-card PNGs now show clearly labelled current payment estimate, the exact activations remaining to the next configured tier, projected main estimate at that tier, and incremental gain.
- The renderer consumes the selected source's existing `IncentiveEstimate`. It retains the current qualifying Sunday bonus, does not forecast future Sunday bonuses, and excludes weekly-paid FRC from current/projected totals.
- Source selection and PC-to-Android handoff remain unchanged; canvas expanded to keep the new panel separate from the footer.
- Validation: source-level checks; Windows compile and generated-PNG visual review pending.
