package com.aziitech.simregmonitor

import com.google.android.gms.ads.MobileAds
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.Scope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.FirebaseUser

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.content.Intent
import android.provider.OpenableColumns
import android.location.LocationManager
import android.provider.ContactsContract
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.app.PendingIntent
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.geometry.Rect
import androidx.compose.material3.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.animation.core.*
import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.time.YearMonth
import java.time.LocalDate
import java.io.File
import java.security.MessageDigest

private const val DEFAULT_SMS_DESTINATION = "3030"
private const val DEFAULT_TIMEOUT_MS = 120_000L
private const val SETTING_SMS_SUB_ID = "sms_subscription_id"
private const val SETTING_DESTINATIONS = "sms_destinations"
private const val SETTING_RETENTION = DatabaseStore.SETTING_RETENTION_MONTHS
private const val SETTING_ONBOARDING_SEEN = "onboarding_seen"
private const val SETTING_WELCOME_SEEN = "welcome_introduction_seen"
private const val SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN = "first_launch_permission_setup_seen"
private const val ONBOARDING_PREFS = "devmonitor_onboarding_state"
private const val PREF_WELCOME_SEEN = "welcome_introduction_seen"

/**
 * The welcome tour has existed across several onboarding implementations. Read both historical
 * SQLite flags and a dedicated SharedPreferences latch so database migrations/rebuilds or older
 * releases that only wrote onboarding_seen cannot make the welcome tour repeat.
 */
private fun hasWelcomeBeenSeen(context: Context, store: StateStore): Boolean {
    val preferences = context.getSharedPreferences(ONBOARDING_PREFS, Context.MODE_PRIVATE)
    val sqliteSeen = store.getSetting(SETTING_WELCOME_SEEN) == "true" ||
        store.getSetting(SETTING_ONBOARDING_SEEN) == "true"
    if (sqliteSeen && !preferences.getBoolean(PREF_WELCOME_SEEN, false)) {
        preferences.edit().putBoolean(PREF_WELCOME_SEEN, true).apply()
    }
    return sqliteSeen || preferences.getBoolean(PREF_WELCOME_SEEN, false)
}

private fun persistWelcomeSeen(context: Context, store: StateStore) {
    store.setSetting(SETTING_WELCOME_SEEN, "true")
    store.setSetting(SETTING_ONBOARDING_SEEN, "true")
    context.getSharedPreferences(ONBOARDING_PREFS, Context.MODE_PRIVATE)
        .edit().putBoolean(PREF_WELCOME_SEEN, true).apply()
}
private const val SETTING_ATTACHED_FILES = "attached_files"
private const val SETTING_EXPORT_COUNT = "export_count"
private const val SETTING_EXPORT_CREDITS = "export_reward_credits"
private const val SETTING_SHOW_SENSITIVE_FLAGS = "show_sensitive_flags"
private const val SETTING_THEME = "theme_preference"
private const val SETTING_PARTNER_TARGET = "hq_partner_activation_target"
private const val SETTING_GOOGLE_EMAIL = "google_account_email"
private const val SETTING_GOOGLE_NAME = "google_account_name"
private const val SETTING_GOOGLE_PHOTO = "google_account_photo"
private const val SETTING_MY_DEVICES_USER_TYPE = "my_devices_user_type"
private const val SETTING_MY_DEVICES_STAFF_LEVEL = "my_devices_staff_level"
private const val SETTING_MY_DEVICES_PARTNER_CODE = "my_devices_partner_code"
private const val SETTING_MY_DEVICES_DEVICE_ID = "my_devices_device_id"
private const val SETTING_MY_DEVICES_DIVISION = "my_devices_division"
private const val SETTING_MY_DEVICES_REGION = "my_devices_region"
private const val SETTING_MY_DEVICES_STAFF_NAME = "my_devices_staff_name"
private const val SETTING_MY_DEVICES_TERRITORY = "my_devices_territory"
private const val SETTING_MY_DEVICES_CODES = "my_devices_codes"
private const val SETTING_MY_DEVICES_SETUP = "my_devices_setup_complete"
private const val SETTING_MOM_STAFF_CLASSIFICATION = "mom_staff_classification"
private const val SETTING_MONTH_TO_MONTH_COMPARISON = "month_to_month_comparison"
private const val SETTING_USER_SCOPED_NOTICE_ELIGIBLE = "user_scoped_notice_eligible"
private const val SETTING_USER_SCOPED_NOTICE_SHOWN = "user_scoped_notice_shown"
private const val FREE_EXPORT_LIMIT = 10
private const val EXPORTS_PER_REWARDED = 5
private const val INTERSTITIAL_FREQUENCY = 10

private val DevMonitorLightScheme = lightColorScheme(
    primary = Color(0xFF146EF5), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEAFF), onPrimaryContainer = Color(0xFF06224F),
    secondary = Color(0xFF7A42F4), onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE2FF), onSecondaryContainer = Color(0xFF28104F),
    tertiary = Color(0xFF00A9C7), onTertiary = Color.White,
    background = AuroraLightSurface, surface = AuroraLightCard,
    surfaceVariant = Color(0xFFEAF2FB), error = Color(0xFFD92D4B),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8FBFF),
    surfaceContainer = Color(0xFFF4F8FD),
    surfaceContainerHigh = Color(0xFFEEF4FB),
    surfaceContainerHighest = Color(0xFFE8F0F8)
)

private val DevMonitorDarkScheme = darkColorScheme(
    primary = Color(0xFF62B0FF), onPrimary = Color(0xFF002B55),
    primaryContainer = Color(0xFF0D4F88), onPrimaryContainer = Color(0xFFD9ECFF),
    secondary = Color(0xFFB69AFF), onSecondary = Color(0xFF241044),
    secondaryContainer = Color(0xFF432878), onSecondaryContainer = Color(0xFFEBDDFF),
    tertiary = Color(0xFF48D9E9), onTertiary = Color(0xFF00363D),
    background = Color(0xFF06101E), surface = Color(0xFF0B192B),
    surfaceVariant = Color(0xFF17283C), error = Color(0xFFFF7188),
    surfaceContainerLowest = Color(0xFF030B14),
    surfaceContainerLow = Color(0xFF091525),
    surfaceContainer = Color(0xFF0D1B2D),
    surfaceContainerHigh = Color(0xFF12233A),
    surfaceContainerHighest = Color(0xFF172A43)
)

data class StoredMonthToMonthComparison(
    val asOf: LocalDate,
    val currentTotal: Int,
    val previousTotal: Int,
    val delta: Int,
    val percentChange: Double?
)

data class MonthToMonthSearchHit(
    val type: String,
    val label: String,
    val detail: String,
    val deviceIds: List<String> = emptyList()
)

data class DashboardPaymentSearchResult(
    val deviceId: String,
    val source: String,
    val progression: PaymentEngine.Progression?,
    val estimate: IncentiveEstimate?,
    val selectable: Boolean,
    val freshnessDate: LocalDate?
)

data class MonthToMonthDetailRow(
    val deviceId: String,
    val comparison: StoredMonthToMonthComparison?
)

data class MonthToMonthChildResult(
    val label: String,
    val levelLabel: String,
    val comparison: StoredMonthToMonthComparison,
    val region: String = "",
    val staffName: String = "",
    val territory: String = "",
    val canDrillDown: Boolean = false
)

private fun signingCertificateFingerprints(context: Context): Pair<String, String> {
    return runCatching {
        val pm = context.packageManager
        val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val packageInfo = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signingInfo = packageInfo.signingInfo
            signingInfo?.apkContentsSigners?.toList().orEmpty()
        } else {
            @Suppress("DEPRECATION")
            val packageInfo = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
            packageInfo.signatures?.toList().orEmpty()
        }
        val cert = info.firstOrNull() ?: return@runCatching "unavailable" to "unavailable"
        fun digest(algorithm: String): String = MessageDigest.getInstance(algorithm).digest(cert.toByteArray())
            .joinToString(":") { "%02X".format(it) }
        digest("SHA-1") to digest("SHA-256")
    }.getOrDefault("unavailable" to "unavailable")
}

class MainActivity : ComponentActivity() {
    /** Installs only a validated cloud database and retains a rollback copy until replacement succeeds. */
    private fun installRestoredDatabase(temp: File) {
        val live = database.databaseFile()
        val parent = live.parentFile ?: throw IllegalStateException("Database directory is unavailable")
        if (!temp.isFile || temp.length() < 1000L) throw IllegalStateException("The validated restore file is missing")
        parent.mkdirs()
        val staged = File(parent, live.name + ".restore-staged")
        val previous = File(parent, live.name + ".pre-restore")
        temp.copyTo(staged, overwrite = true)
        store.close()
        database.close()
        File(live.path + "-wal").delete()
        File(live.path + "-shm").delete()
        if (previous.exists() && !previous.delete()) {
            staged.delete()
            throw IllegalStateException("Could not clear the previous restore safety copy")
        }
        if (live.exists() && !live.renameTo(previous)) {
            staged.delete()
            throw IllegalStateException("Could not preserve the current database before restore")
        }
        if (!staged.renameTo(live)) {
            if (previous.exists()) previous.renameTo(live)
            staged.delete()
            throw IllegalStateException("Could not install the restored database; the previous data was preserved")
        }
        previous.delete()
        File(live.path + "-wal").delete()
        File(live.path + "-shm").delete()
    }

    // When an .xlsx file is opened from another Android app/file manager,
    // hold the URI until the user explicitly confirms importing it.
    private var pendingExternalExcelUri by mutableStateOf<Uri?>(null)
    private var importingSimReg by mutableStateOf(false)
    private var simRegImportMessage by mutableStateOf("")
    private var simRegLoadingTitle by mutableStateOf("Loading SIMReg report…")
    private var simRegLoadingProgress by mutableFloatStateOf(0f)
    private var companySkeletonLoading by mutableStateOf(false)
    private var companySkeletonLoadingProgress by mutableFloatStateOf(0f)
    private var companySkeletonLoadingTitle by mutableStateOf("Loading company directory…")
    private var companySkeletonLoadingMessage by mutableStateOf("")
    // Monotonic revision used to invalidate mounted payment cards after report import.
    private var paymentDataRevision by mutableLongStateOf(0L)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val store by lazy { StateStore(this) }
    // My Partners uses a dedicated database file and never profile-switches into the primary store.
    private val smsChecker2Store by lazy { StateStore(this, "sms_checker_2.db") }
    private val database: DatabaseStore get() = store.database
    private val companyActivations by lazy { CompanyActivationStore(this) }
    private val companySkeleton by lazy { CompanySkeletonStore(this) }
    private var myDevicesDatabase = MyDevicesStore(this)
    private val billingManager by lazy { DevMonitorBillingManager(this) }
    private val appVersionManager by lazy { AppVersionManager(this) }
    private val profileStore by lazy { ProfileStore(this) }
    private val feedback by lazy { DevMonitorSound(this) }

    private suspend fun rebuildMyDevicesWorkingSet(codesToUse: List<String>) {
        val codes = codesToUse.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        if (codes.isEmpty()) return
        val (start, end) = PaymentRules.myDevicesWorkingWindow()
        val targeted = companyActivations.loadWorkingSetForDevices(codes, start, end)
        if (targeted != null) {
            myDevicesDatabase.replaceWorkingSet(targeted.rows, codes, start, end)
            DevMonitorLogger.db("My Devices primary working set rebuilt devices=${codes.size} range=$start..$end")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DevMonitorAnalytics.initialize(this)
        handleExternalExcelIntent(intent)
        // Initialize AdMob. Test App ID is used until the publisher replaces it with their own.
        if (BuildConfig.MONETIZED_BUILD) {
            MobileAds.initialize(this)
            DevMonitorInterstitialAd.preload(this)
            DevMonitorRewardedAd.preload(this)
        }
        billingManager.start()
        // Heavy operational work is user-initiated; do not schedule background monitoring.
        // Company reports are user-selected input only. There is no bundled historical
        // workbook and no automatic report import at startup.
        setContent { SimRegMonitorApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleExternalExcelIntent(intent)
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the app's permission flow")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2301 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            NotificationStore.flushPendingSystemNotification(this)
            android.widget.Toast.makeText(this, "DevMonitor notifications are enabled.", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleExternalExcelIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        val uri = intent.data ?: return
        if (isSupportedExcelUri(uri, intent.type)) {
            pendingExternalExcelUri = uri
        }
    }

    private fun isSupportedExcelUri(uri: Uri, mimeType: String?): Boolean {
        val mime = mimeType?.lowercase(Locale.US).orEmpty()
        val name = uri.lastPathSegment?.lowercase(Locale.US).orEmpty()
        return mime == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
            (mime == "application/octet-stream" && name.endsWith(".xlsx")) ||
            name.endsWith(".xlsx")
    }

    private fun displayNameForUri(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Excel sheet"
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Excel sheet" } ?: "Excel sheet"
    }

    private fun importSimRegWorkbook(
        uri: Uri,
        sourceName: String,
        onSuccess: (SimRegReport) -> Unit,
        onFailure: (Throwable) -> Unit
    ) {
        if (importingSimReg) return
        importingSimReg = true
        simRegLoadingTitle = "Opening your report…"
        simRegLoadingProgress = 0.08f
        simRegImportMessage = "Opening the Excel workbook…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    withContext(Dispatchers.Main.immediate) {
                        simRegLoadingTitle = "Reading the report…"
                        simRegLoadingProgress = 0.28f
                        simRegImportMessage = "Reading the complete workbook…"
                    }
                    val parsed = contentResolver.openInputStream(uri)?.use { input ->
                        SimRegReportParser.parse(input, sourceName)
                    } ?: error("Unable to open the selected workbook")
                    withContext(Dispatchers.Main.immediate) {
                        simRegLoadingTitle = "Analysing device records…"
                        simRegLoadingProgress = 0.62f
                        simRegImportMessage = "Processing sheets and device records…"
                    }
                    withContext(Dispatchers.Main.immediate) {
                        simRegLoadingTitle = "Building DevMonitor intelligence…"
                        simRegLoadingProgress = 0.88f
                        simRegImportMessage = "Saving normalized activation data…"
                    }
                    val imported = companyActivations.importReport(parsed)
                    // Import is storage-only. Do not refresh My Devices, Month-on-Month,
                    // payment progression, dashboards, estimations, or other derived
                    // calculations here. Those operations are explicitly user initiated.
                    DevMonitorLogger.import("import persistence complete reportId=${imported.reportId}; monthly HQ snapshot stored only")
                    parsed
                }
            }
            result.onSuccess { parsed ->
                simRegLoadingTitle = "Rendering the imported table…"
                simRegLoadingProgress = 0.94f
                simRegImportMessage = "The validated report is saved; preparing the My Devices-first table…"
                onSuccess(parsed)
            }.onFailure { error ->
                DevMonitorLogger.error("IMPORT", "UI import failed: ${error.message}", error)
                simRegLoadingProgress = 0f
                importingSimReg = false
                simRegImportMessage = ""
                onFailure(error)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        billingManager.close()
        runCatching { myDevicesDatabase.close() }
        runCatching { smsChecker2Store.close() }
        runCatching { companyActivations.close() }
        runCatching { feedback.release() }
        super.onDestroy()
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    /**
     * 3030 accepts the short device form only. Keep the user's original long
     * code in the database/UI, but convert it immediately before transmission.
     * Example: GLO-GD-OGN-da3-3GOGN047-666D -> GLO-GD-666D.
     */
    private fun smsCodeForDestination(code: String, destination: String): String {
        val cleanCode = code.trim().uppercase(Locale.US)
        if (destination.trim() != DEFAULT_SMS_DESTINATION) return cleanCode
        val match = Regex("^(GLO-(?:GD|DD|FD))-(?:.+)-([A-Z0-9]+)$").matchEntire(cleanCode)
        return if (match != null) {
            "${match.groupValues[1]}-${match.groupValues[2]}"
        } else {
            cleanCode
        }
    }

    private fun sendSms(code: String, subscriptionId: Int?, destination: String): Boolean {
        if (!hasPermission(Manifest.permission.SEND_SMS)) return false
        return try {
            val subId = subscriptionId ?: SubscriptionManager.getDefaultSmsSubscriptionId()
            val manager = if (subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                SmsManager.getSmsManagerForSubscriptionId(subId)
            } else {
                SmsManager.getDefault()
            }
            // Explicitly use Android's SMS telephony API. This is an SMS submission, not an RCS/chat send.
            manager.sendTextMessage(destination, null, smsCodeForDestination(code, destination), null, null)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun importSimRegWorkbookFile(
        file: File,
        sourceName: String,
        onSuccess: (SimRegReport) -> Unit,
        onFailure: (Throwable) -> Unit
    ) {
        if (importingSimReg) return
        importingSimReg = true
        simRegLoadingTitle = "Opening the downloaded report…"
        simRegLoadingProgress = 0.08f
        simRegImportMessage = "Opening the downloaded Excel workbook…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    withContext(Dispatchers.Main.immediate) {
                        simRegLoadingTitle = "Reading the report…"
                        simRegLoadingProgress = 0.28f
                        simRegImportMessage = "Reading the complete workbook…"
                    }
                    val parsed = file.inputStream().use { input -> SimRegReportParser.parse(input, sourceName) }
                    withContext(Dispatchers.Main.immediate) {
                        simRegLoadingTitle = "Building DevMonitor intelligence…"
                        simRegLoadingProgress = 0.88f
                        simRegImportMessage = "Saving normalized activation data…"
                    }
                    val imported = companyActivations.importReport(parsed)
                    // Online imports follow the same storage-only rule as local imports.
                    DevMonitorLogger.import("online import persistence complete reportId=${imported.reportId}; monthly HQ snapshot stored only")
                    parsed
                }
            }
            result.onSuccess { parsed ->
                simRegLoadingTitle = "Rendering the imported table…"
                simRegLoadingProgress = 0.94f
                simRegImportMessage = "The validated report is saved; preparing the My Devices-first table…"
                onSuccess(parsed)
            }.onFailure { error ->
                DevMonitorLogger.error("IMPORT", "Online report import failed: ${error.message}", error)
                simRegLoadingProgress = 0f
                importingSimReg = false
                simRegImportMessage = ""
                onFailure(error)
            }
        }
    }

    private suspend fun sendSmsWithDeliveryMonitoring(
        code: String, subscriptionId: Int?, destination: String, maxImmediateRetries: Int = 2
    ): SmsDeliverySendResult = withContext(Dispatchers.IO) {
        if (!hasPermission(Manifest.permission.SEND_SMS)) return@withContext SmsDeliverySendResult(false, false, false, false, 0, false)
        var attempt = 0
        var deliveryReportingObserved = false
        var deliveryFailure = false
        while (attempt <= maxImmediateRetries) {
            attempt++
            val token = SmsDeliveryTracker.begin()
            try {
                val subId = subscriptionId ?: SubscriptionManager.getDefaultSmsSubscriptionId()
                val manager = if (subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                    SmsManager.getSmsManagerForSubscriptionId(subId)
                } else SmsManager.getDefault()

                val sentIntent = PendingIntent.getBroadcast(
                    this@MainActivity, token.hashCode(),
                    Intent(this@MainActivity, SmsDeliveryReceiver::class.java).setAction(SmsDeliveryReceiver.ACTION_SENT).putExtra(SmsDeliveryReceiver.EXTRA_TOKEN, token),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val deliveredIntent = PendingIntent.getBroadcast(
                    this@MainActivity, token.hashCode() xor 0x5f3759df,
                    Intent(this@MainActivity, SmsDeliveryReceiver::class.java).setAction(SmsDeliveryReceiver.ACTION_DELIVERED).putExtra(SmsDeliveryReceiver.EXTRA_TOKEN, token),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // sendTextMessage is the SMS protocol path; no RCS API is used.
                manager.sendTextMessage(destination, null, smsCodeForDestination(code, destination), sentIntent, deliveredIntent)

                val status = SmsDeliveryTracker.await(token, 4500L)
                if (status.sentKnown || status.deliveredKnown) deliveryReportingObserved = true
                if (status.sentKnown && !status.sentOk) {
                    deliveryFailure = true
                } else if (status.deliveredKnown && !status.deliveredOk) {
                    deliveryFailure = true
                } else {
                    // No negative report: continue with the normal response wait.
                    SmsDeliveryTracker.remove(token)
                    return@withContext SmsDeliverySendResult(true, deliveryReportingObserved, status.sentKnown, status.deliveredKnown, attempt, false)
                }
            } catch (_: Exception) {
                deliveryFailure = true
            }
            SmsDeliveryTracker.remove(token)
            if (attempt <= maxImmediateRetries) {
                delay(300)
            }
        }
        SmsDeliverySendResult(true, deliveryReportingObserved, true, true, attempt, deliveryFailure)
    }

    private data class SmsDeliverySendResult(
        val apiAccepted: Boolean,
        val reportObserved: Boolean,
        val sentReportKnown: Boolean,
        val deliveredReportKnown: Boolean,
        val attempts: Int,
        val deliveryFailure: Boolean
    )

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun SimRegMonitorApp() {
        val context = LocalContext.current
        // Declare the selected checker before its store is chosen below.
        var selectedTab by remember { mutableIntStateOf(0) }
        var pcLinkStatus by remember { mutableStateOf(store.getSetting("sync_bridge_status") ?: "Not configured") }
        var pcLinkLastSuccess by remember { mutableStateOf(store.getSetting("sync_bridge_last_success")) }
        var pcLinkStatusUpdatedAt by remember { mutableStateOf(store.getSetting("sync_bridge_status_updated_at")) }
        LaunchedEffect(Unit) {
            while (true) {
                pcLinkStatus = store.getSetting("sync_bridge_status") ?: "Not configured"
                pcLinkLastSuccess = store.getSetting("sync_bridge_last_success")
                pcLinkStatusUpdatedAt = store.getSetting("sync_bridge_status_updated_at")
                delay(5_000L)
            }
        }
        var profiles by remember { mutableStateOf(profileStore.load()) }
        // This set reflects committed profiles only. While a profile editor is open,
        // changing its selected type must not reveal or hide My Partners prematurely.
        var myPartnersEligibleProfileIds by remember {
            mutableStateOf(profiles.filter { it.userType.trim().equals("STAFF", ignoreCase = true) || it.userType.trim().equals("PARTNER", ignoreCase = true) }.map { it.id }.toSet())
        }
        val loaded = remember { store.loadCurrent() }
        var activeProfileId by remember { mutableStateOf(profileStore.activeId() ?: profiles.firstOrNull()?.id) }
        val showMyPartnersCard = activeProfileId != null &&
            activeProfileId in myPartnersEligibleProfileIds &&
            profiles.firstOrNull { it.id == activeProfileId }?.userType?.trim()?.let { it.equals("STAFF", ignoreCase = true) || it.equals("PARTNER", ignoreCase = true) } == true
        LaunchedEffect(activeProfileId, myPartnersEligibleProfileIds, showMyPartnersCard) {
            if (selectedTab == 6 && !showMyPartnersCard) selectedTab = 0
        }
        var profileEditorNew by remember { mutableStateOf(false) }
        var profileEditorId by remember { mutableStateOf<String?>(activeProfileId) }
        var profileSkeletonQuery by remember { mutableStateOf("") }
        var profileSkeletonResults by remember { mutableStateOf<List<CompanySkeletonRecord>>(emptyList()) }

        var input by remember { mutableStateOf("") }
        var codes by remember { mutableStateOf(loaded.first) }
        var records by remember { mutableStateOf(loaded.second) }
        val checkerStore = if (selectedTab == 6) smsChecker2Store else store
        var smsListSearchQuery by remember { mutableStateOf("") }
        var partnerReportSearchQuery by remember { mutableStateOf("") }
        // Full loaded HQ partner directory, independent of the active profile's My Devices list.
        var partnerDirectoryRows by remember { mutableStateOf<List<CompanyActivationStore.DeviceScopeRow>>(emptyList()) }
        var partnerSearchMatches by remember { mutableStateOf<List<CompanyActivationStore.DeviceScopeRow>>(emptyList()) }
        var fork3PartnerPerformance by remember { mutableStateOf<Map<String, Fork3ActivationPerformance.PartnerResult>>(emptyMap()) }
        var fork3PerformanceLoading by remember { mutableStateOf(false) }
        val smsCheckerUserType = (activeProfileId?.let { id -> profiles.firstOrNull { it.id == id }?.userType }
            ?: store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty()).trim().uppercase(Locale.US)
        val showZeroDevicesButton = smsCheckerUserType != "AGENT"
        var zeroDevicesLoading by remember { mutableStateOf(false) }
        var zeroDeviceTargetCodes by remember { mutableStateOf<List<String>>(emptyList()) }
        var currentIndex by remember { mutableIntStateOf(-1) }
        var running by remember { mutableStateOf(false) }
        var waitingCode by remember { mutableStateOf<String?>(null) }
        var secondsLeft by remember { mutableLongStateOf(0L) }
        var message by remember {
            mutableStateOf(if (loaded.first.isNotEmpty()) "Restored previous progress" else "Ready")
        }
        LaunchedEffect(selectedTab) {
            if (selectedTab == 1 || selectedTab == 6) {
                val snapshot = withContext(Dispatchers.IO) { checkerStore.loadCurrent() }
                codes = snapshot.first
                records = snapshot.second
                input = ""
                message = if (snapshot.first.isEmpty()) "Ready" else "Restored previous progress"
            }
            if (selectedTab == 6) {
                // My Partners searches the loaded HQ directory, not the active profile's
                // filtered My Devices working set (which can legitimately omit partners).
                partnerDirectoryRows = withContext(Dispatchers.IO) { companyActivations.latestDeviceScopeRows() }
                partnerReportSearchQuery = ""
            }
        }
        LaunchedEffect(selectedTab, codes, partnerDirectoryRows) {
            if (selectedTab != 6 || codes.isEmpty() || partnerDirectoryRows.isEmpty()) {
                fork3PartnerPerformance = emptyMap()
                fork3PerformanceLoading = false
            } else {
                fork3PerformanceLoading = true
                val partnerCodesSnapshot = codes.toList()
                fork3PartnerPerformance = withContext(Dispatchers.IO) {
                    runCatching {
                        Fork3ActivationPerformance.calculate(partnerCodesSnapshot, companyActivations, store.database)
                    }.getOrDefault(emptyMap())
                }
                fork3PerformanceLoading = false
            }
        }
        LaunchedEffect(selectedTab, partnerReportSearchQuery, partnerDirectoryRows) {
            val query = partnerReportSearchQuery.trim()
            if (selectedTab != 6 || query.length < 2 || partnerDirectoryRows.isEmpty()) {
                partnerSearchMatches = emptyList()
            } else {
                // Keep the proven v239 matching semantics, but filter the directory snapshot
                // already loaded when My Partners opens. The old path re-read SQLite on every
                // keystroke, causing avoidable latency and contention with other app work.
                val directorySnapshot = partnerDirectoryRows
                delay(90)
                partnerSearchMatches = withContext(Dispatchers.Default) {
                    val normalizedQuery = query.lowercase(Locale.US)
                    directorySnapshot.asSequence()
                        .filter {
                            it.partnerName.lowercase(Locale.US).contains(normalizedQuery) ||
                                it.tradeCode.lowercase(Locale.US).contains(normalizedQuery)
                        }
                        .filter { it.tradeCode.isNotBlank() }
                        .distinctBy { it.tradeCode.trim().uppercase(Locale.US) }
                        .take(12)
                        .toList()
                }
            }
        }

        var repeatCount by remember { mutableIntStateOf(1) }
        var runJob by remember { mutableStateOf<Job?>(null) }
        // Do not cancel checker work or clear its progress merely because the user navigates.
        // Existing background activity is intentional; a rare cross-menu display issue should
        // not be addressed by interrupting an active run. Keep navigation non-destructive.

        // Dashboard values are cached for the active profile. Switching profiles only
        // changes which cached values are displayed; Refresh is the user-authorized
        // action that performs the dashboard aggregation.
        var dashboardSummary by remember {
            mutableStateOf(
                DashboardSummary(
                    date = PaymentRules.currentAwareDate().toString(),
                    month = PaymentRules.currentAwareDate().toString().substring(0, 7),
                    deviceCount = 0, todayTotal = 0, mtdTotal = 0, activeTotal = 0,
                    bar48Total = 0, bar96Total = 0, companyToday = 0, companyMtd = 0,
                    partnerToday = 0, partnerMtd = 0, flags = emptyList()
                )
            )
        }
        var dashboardRefreshing by remember { mutableStateOf(false) }
        var trendPoints by remember { mutableStateOf<List<TrendPoint>>(emptyList()) }
        var trendsRefreshing by remember { mutableStateOf(false) }
        var trendsLastUpdated by remember { mutableStateOf<String?>(null) }
        fun refreshDashboard() {
            if (dashboardRefreshing) return
            dashboardRefreshing = true
            scope.launch {
                try {
                    val next = withContext(Dispatchers.IO) {
                        store.dashboard(PaymentRules.currentAwareDate().toString())
                    }
                    dashboardSummary = next
                    feedback.success()
                } finally {
                    dashboardRefreshing = false
                }
            }
        }
        fun refreshVisualTrends() {
            if (trendsRefreshing) return
            trendsRefreshing = true
            scope.launch {
                try {
                    val end = PaymentRules.currentAwareDate()
                    val start = end.withDayOfMonth(1)
                    val observations = withContext(Dispatchers.IO) { store.observationsBetween(start, end) }
                    val activeCodes = profiles.firstOrNull { it.id == activeProfileId }?.codes.orEmpty()
                        .map(::canonicalDeviceCode).filter { it.isNotBlank() }.toSet()
                    val scoped = if (activeCodes.isEmpty()) observations else observations.filter { canonicalDeviceCode(it.code) in activeCodes }
                    // Keep the chart to the current calendar month only. Missing observation days
                    // stay missing; they are not manufactured as zero-sales days.
                    trendPoints = scoped.groupBy { it.date }.map { (date, rows) ->
                        TrendPoint(
                            date = date,
                            sales = rows.sumOf { it.today ?: 0 },
                            active = rows.maxByOrNull { it.date }?.active ?: 0,
                            bar48 = rows.sumOf { it.bar48 ?: 0 },
                            companySales = rows.filter { it.ownership == Ownership.COMPANY }.sumOf { it.today ?: 0 },
                            partnerSales = rows.filter { it.ownership == Ownership.PARTNER }.sumOf { it.today ?: 0 },
                            observedDevices = rows.map { canonicalDeviceCode(it.code) }.distinct().size
                        )
                    }.sortedBy { it.date }
                    trendsLastUpdated = end.toString()
                    feedback.success()
                } finally {
                    trendsRefreshing = false
                }
            }
        }

        val monitorListState = rememberLazyListState()
        val dashboardListState = rememberLazyListState()
        var lastExportUri by remember { mutableStateOf<Uri?>(null) }
        var showExportMenu by remember { mutableStateOf(false) }
        var exportMode by remember { mutableStateOf(ReportExportMode.DETAILED) }
        var showSnapshotMenu by remember { mutableStateOf(false) }

        var showSavedLists by remember { mutableStateOf(false) }
        var savedListBeingEdited by remember { mutableStateOf<SavedQueryList?>(null) }
        var savedListAddText by remember { mutableStateOf("") }
        val savedListRemoveSelection = remember { mutableStateListOf<String>() }
        var showHistory by remember { mutableStateOf(false) }
        var showSmsInbox by remember { mutableStateOf(false) }
        var showArchived by remember { mutableStateOf(false) }
        var showDatabase by remember { mutableStateOf(false) }
        var showSaveDialog by remember { mutableStateOf(false) }
        var showDashboard by remember { mutableStateOf(false) }
        var showVisualTrends by remember { mutableStateOf(false) }
        var showNextLevel by remember { mutableStateOf(false) }
        var showMonthToMonthComparison by remember { mutableStateOf(false) }
        var refreshingMonthToMonthComparison by remember { mutableStateOf(false) }
        var monthToMonthComparison by remember { mutableStateOf<StoredMonthToMonthComparison?>(null) }
        var dashboardSearchQuery by remember { mutableStateOf("") }
        var dashboardPaymentSearchResults by remember { mutableStateOf<List<DashboardPaymentSearchResult>>(emptyList()) }
        var dashboardPaymentSearchLoading by remember { mutableStateOf(false) }
        var dashboardSearchSelectedSource by remember { mutableStateOf<String?>(null) }
        var dashboardCycleTotal by remember { mutableIntStateOf(0) }
        var dashboardCycleEstimate by remember { mutableStateOf<IncentiveEstimate?>(null) }
        var dashboardCycleLoading by remember { mutableStateOf(false) }
        var monthToMonthChildComparisons by remember { mutableStateOf<List<MonthToMonthChildResult>>(emptyList()) }
        var monthToMonthChildLoading by remember { mutableStateOf(false) }
        var monthToMonthChildLevel by remember { mutableStateOf("") }
        var monthToMonthSelectedParent by remember { mutableStateOf("") }
        var monthToMonthDeviceComparisons by remember { mutableStateOf<List<MonthToMonthChildResult>>(emptyList()) }
        var monthToMonthDeviceLoading by remember { mutableStateOf(false) }
        var monthToMonthSearchQuery by remember { mutableStateOf("") }
        var monthToMonthSearchHits by remember { mutableStateOf<List<MonthToMonthSearchHit>>(emptyList()) }
        var monthToMonthSearchLoading by remember { mutableStateOf(false) }
        var monthToMonthSelectedSearchHit by remember { mutableStateOf<MonthToMonthSearchHit?>(null) }
        var monthToMonthDetailRows by remember { mutableStateOf<List<MonthToMonthDetailRow>>(emptyList()) }
        var monthToMonthDetailLoading by remember { mutableStateOf(false) }
        var profileDeleteTarget by remember { mutableStateOf<DeviceProfile?>(null) }
        var deviceDeleteTarget by remember { mutableStateOf<String?>(null) }
        var versionUpdateInfo by remember { mutableStateOf<AppVersionManager.UpdateInfo?>(null) }
        var versionUpdateReason by remember { mutableStateOf("") }
        val broadcastReleaseManager = remember { BroadcastReleaseManager(this@MainActivity) }
        var activeBroadcast by remember { mutableStateOf<DevMonitorBroadcast?>(null) }
        var showBroadcastCentre by remember { mutableStateOf(false) }
        var broadcastDraft by remember { mutableStateOf("") }
        var broadcastPlacement by remember { mutableStateOf("TOP") }
        var broadcastExpiryDays by remember { mutableIntStateOf(2) }
        var broadcastBusy by remember { mutableStateOf(false) }
        var broadcastStatus by remember { mutableStateOf("") }
        var broadcastDiagnostic by remember { mutableStateOf("Broadcast status has not been checked yet.") }
        var showWhatsNew by remember { mutableStateOf(false) }
        var whatsNewHighlights by remember { mutableStateOf<List<String>>(emptyList()) }
        var showSimRegReport by remember { mutableStateOf(false) }
        var loadingSavedReport by remember { mutableStateOf(false) }
        var userScopedNoticePending by remember { mutableStateOf(false) }
        var userScopedNoticeBusy by remember { mutableStateOf(false) }
        var showFlags by remember { mutableStateOf(false) }
        var showNotificationInbox by remember { mutableStateOf(false) }
        var showTasks by remember { mutableStateOf(false) }
        var showNotes by remember { mutableStateOf(false) }
        var showTimeline by remember { mutableStateOf(false) }
        val notificationProfileId = activeProfileId ?: profiles.firstOrNull()?.id ?: "default"
        var notifications by remember { mutableStateOf(NotificationStore.list(this@MainActivity, notificationProfileId)) }
        val unreadNotificationCount = notifications.count { !it.read }
        fun addNotification(title: String, text: String, kind: String = "info") {
            NotificationStore.add(this@MainActivity, notificationProfileId, title, text, kind)
            notifications = NotificationStore.list(this@MainActivity, notificationProfileId)
        }
        fun markNotificationRead(id: String) {
            NotificationStore.markRead(this@MainActivity, notificationProfileId, id)
            notifications = NotificationStore.list(this@MainActivity, notificationProfileId)
        }
        LaunchedEffect(activeProfileId) {
            notifications = NotificationStore.list(this@MainActivity, notificationProfileId)
        }
        LaunchedEffect(dashboardSearchQuery, paymentDataRevision, activeProfileId) {
            val query = dashboardSearchQuery.trim()
            if (query.length < 2) {
                dashboardPaymentSearchResults = emptyList()
                dashboardPaymentSearchLoading = false
            } else {
                dashboardPaymentSearchLoading = true
                dashboardPaymentSearchResults = withContext(Dispatchers.IO) {
                    // Search My Devices first. Only when there is no My Devices
                    // match do we fall back to the complete retained HQ database.
                    // The table/viewer scope remains My Devices; this fallback is
                    // only for dashboard lookup and must never narrow the database.
                    val myDeviceCandidates = codes
                        .map(::canonicalDeviceCode)
                        .filter { it.contains(query, ignoreCase = true) }
                        .distinct()
                        .take(8)
                    val candidates = if (myDeviceCandidates.isNotEmpty()) {
                        myDeviceCandidates
                    } else {
                        companyActivations.searchWholeDatabaseDeviceCodes(query, 8)
                    }
                    val asOf = PaymentRules.currentAwareDate()
                    candidates.flatMap { code ->
                        val loaded = PaymentEngine.LoadedReports.calculate(code, asOf, companyActivations)
                        val monitor = PaymentEngine.DeviceMonitor.calculate(code, asOf, database, companyActivations)
                        listOf(
                            DashboardPaymentSearchResult(code, "Device Monitor", monitor, monitor.estimate, monitor.estimate != null, monitor.availableThrough),
                            DashboardPaymentSearchResult(code, "Loaded Report", loaded, loaded.estimate, loaded.estimate != null, loaded.availableThrough)
                        )
                    }.sortedWith(
                        compareByDescending<DashboardPaymentSearchResult> { it.freshnessDate ?: LocalDate.MIN }
                            .thenByDescending { it.estimate != null }
                            .thenBy { it.deviceId }
                            .thenBy { it.source }
                    )
                }
                dashboardPaymentSearchLoading = false
            }
        }

        var deviceMonitorPaymentCode by remember { mutableStateOf<String?>(null) }
        var paymentGateMessageCode by remember { mutableStateOf<String?>(null) }
        var paymentGateMessage by remember { mutableStateOf<String?>(null) }
        var workflowRecoveryReason by remember { mutableStateOf<String?>(null) }
        val paymentGateScope = rememberCoroutineScope()

        fun openDeviceMonitorPaymentCard(code: String) {
            val canonical = canonicalDeviceCode(code)
            paymentGateScope.launch {
                val liveDate = PaymentRules.currentAwareDate()
                val gateResult = withContext(Dispatchers.IO) {
                    // The payment calculator can legitimately return a pre-21st estimate
                    // from current-month Active alone. Card visibility has a stricter
                    // evidence rule: real device-specific prior-month history AND current
                    // month evidence. The Company Directory skeleton is never queried here.
                    val progression = PaymentEngine.DeviceMonitor.calculate(
                        deviceId = canonical,
                        asOfRequested = liveDate,
                        deviceStore = database,
                        companyStore = companyActivations
                    )
                    val previousMonth = java.time.YearMonth.from(liveDate).minusMonths(1)
                    val previousStart = previousMonth.atDay(1)
                    val previousEnd = previousMonth.atEndOfMonth()
                    val priorSmsHistory = database.observationsBetween(canonical, previousStart, previousEnd)
                        .any { it.active != null }
                    val priorReportHistory = companyActivations
                        .dailyCoverageForDevice(canonical, previousStart, previousEnd).isNotEmpty()
                    val hasPriorMonthHistory = priorSmsHistory || priorReportHistory

                    val currentMonth = java.time.YearMonth.from(liveDate)
                    val currentStart = currentMonth.atDay(1)
                    val currentSmsEvidence = database.observationsBetween(canonical, currentStart, liveDate)
                        .any { it.active != null }
                    val currentReportEvidence = companyActivations
                        .dailyCoverageForDevice(canonical, currentStart, liveDate).isNotEmpty()
                    val hasCurrentMonthEvidence = currentSmsEvidence || currentReportEvidence
                    val baselineRequired = liveDate.dayOfMonth >= 21
                    val hasRequiredBaseline = !baselineRequired ||
                        (progression.baselineDate != null && progression.baselineActive != null)
                    val allowed = progression.activations != null && hasPriorMonthHistory &&
                        hasCurrentMonthEvidence && hasRequiredBaseline
                    val reason = when {
                        progression.activations == null -> progression.warning
                        !hasPriorMonthHistory -> "Payment progression is unavailable: no genuine device-specific Active history was found for ${previousMonth}. Company Directory entries do not count as activation history. Record a valid Device Monitor Active observation or load a qualifying company report, then refresh."
                        !hasCurrentMonthEvidence -> "Payment progression is unavailable: no current-month Active evidence was found for this device. Record a Device Monitor Active observation or load a qualifying company report, then refresh."
                        !hasRequiredBaseline -> "Payment progression is unavailable: a valid cumulative Active baseline through the 20th is required. Record that history or load a qualifying company report, then refresh."
                        else -> null
                    }
                    Triple(progression, allowed, reason)
                }
                val gateProgression = gateResult.first
                val allowed = gateResult.second
                val gateReason = gateResult.third
                DevMonitorLogger.payment(
                    "Device Monitor payment button gate code=$canonical date=$liveDate " +
                        "baselineDate=${gateProgression.baselineDate} baselineActive=${gateProgression.baselineActive} " +
                        "activations=${gateProgression.activations} allowed=$allowed warning=$gateReason"
                )

                if (allowed) {
                    paymentGateMessage = null
                    paymentGateMessageCode = null
                    DevMonitorLogger.screen("Device Monitor payment card revealed by button for $canonical")
                    deviceMonitorPaymentCode = canonical
                } else {
                    DevMonitorLogger.payment(
                        "Device Monitor payment card gated by button code=$canonical reason=historical-evidence-requirements-not-met"
                    )
                    deviceMonitorPaymentCode = null
                    paymentGateMessageCode = canonical
                    paymentGateMessage = gateReason
                        ?: "There isn't enough valid historical Active data to calculate this payment progression. Record cumulative Active history or load a qualifying company report, then refresh."
                }
            }
        }

        fun normalizedList(raw: String): List<String> = raw.lines()
            .flatMap { it.split(',', '\t', ';').asSequence() }
            .map { canonicalDeviceCode(it) }
            .map { it.trim().uppercase(Locale.US) }
            .filter { it.isNotBlank() }
            .distinct()

        fun savedMyDevices(): List<String> = normalizedList(
            store.getSetting(SETTING_MY_DEVICES_CODES).orEmpty().replace('|', '\n')
        )


        fun profileDatabaseName(profileId: String): String {
            if (profileId == "default") return "my_devices.db"
            val safe = profileId.filter { it.isLetterOrDigit() }.take(24).ifBlank { "profile" }
            return "my_devices_profile_$safe.db"
        }

        fun saveActiveProfileSnapshot(codesOverride: List<String>? = null) {
            val id = activeProfileId ?: return
            val current = profiles.firstOrNull { it.id == id } ?: return
            val updated = current.copy(
                name = store.getSetting("my_devices_name").orEmpty().ifBlank { current.name },
                phone = store.getSetting("my_devices_phone").orEmpty(),
                userType = store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty(),
                staffLevel = store.getSetting(SETTING_MY_DEVICES_STAFF_LEVEL).orEmpty(),
                partnerCode = store.getSetting(SETTING_MY_DEVICES_PARTNER_CODE).orEmpty(),
                deviceId = store.getSetting(SETTING_MY_DEVICES_DEVICE_ID).orEmpty(),
                division = store.getSetting(SETTING_MY_DEVICES_DIVISION).orEmpty(),
                region = store.getSetting(SETTING_MY_DEVICES_REGION).orEmpty(),
                staffName = store.getSetting(SETTING_MY_DEVICES_STAFF_NAME).orEmpty(),
                territory = store.getSetting(SETTING_MY_DEVICES_TERRITORY).orEmpty(),
                codes = codesOverride ?: savedMyDevices()
            )
            profiles = profiles.map { if (it.id == id) updated else it }
            profileStore.saveAll(profiles)
        }

        fun applyProfile(profile: DeviceProfile) {
            saveActiveProfileSnapshot()
            runCatching { myDevicesDatabase.close() }
            myDevicesDatabase = MyDevicesStore(this@MainActivity, profileDatabaseName(profile.id))
            activeProfileId = profile.id
            profileStore.setActive(profile.id)
            store.switchProfile(profile.id)
            companyActivations.setDeviceMonitorStore(database)
            store.setSetting("my_devices_name", profile.name)
            store.setSetting("my_devices_phone", profile.phone)
            store.setSetting(SETTING_MY_DEVICES_USER_TYPE, profile.userType)
            store.setSetting(SETTING_MY_DEVICES_STAFF_LEVEL, profile.staffLevel)
            store.setSetting(SETTING_MY_DEVICES_PARTNER_CODE, profile.partnerCode)
            store.setSetting(SETTING_MY_DEVICES_DEVICE_ID, profile.deviceId)
            store.setSetting(SETTING_MY_DEVICES_DIVISION, profile.division)
            store.setSetting(SETTING_MY_DEVICES_REGION, profile.region)
            store.setSetting(SETTING_MY_DEVICES_STAFF_NAME, profile.staffName)
            store.setSetting(SETTING_MY_DEVICES_TERRITORY, profile.territory)
            store.setSetting(SETTING_MY_DEVICES_CODES, profile.codes.joinToString("|"))
            store.setSetting(SETTING_MY_DEVICES_SETUP, if (profile.userType.isBlank() && profile.codes.isEmpty()) "false" else "true")
            codes = profile.codes
            records = emptyMap()
            store.saveCurrent(codes, records)
        }

        fun switchProfile(profile: DeviceProfile) {
            if (profile.id == activeProfileId) return
            applyProfile(profile)
            message = "Switched to ${profile.name}."
        }

        fun monthToMonthStaffSearchAllowed(): Boolean {
            val stored = store.getSetting(SETTING_MOM_STAFF_CLASSIFICATION).orEmpty().uppercase(Locale.US)
            if (stored == "STAFF") return true
            if (stored == "NON_STAFF") return false

            // This is deliberately a one-time installation-level type check. Do not
            // normalize, strip formatting, or reclassify later if the profile phone
            // changes. Staff numbers must be exactly 11 digits and start with 0805557.
            val phone = store.getSetting("my_devices_phone").orEmpty()
            val isStaff = phone.length == 11 && phone.all(Char::isDigit) && phone.startsWith("0805557")
            store.setSetting(SETTING_MOM_STAFF_CLASSIFICATION, if (isStaff) "STAFF" else "NON_STAFF")
            return isStaff
        }

        fun refreshMonthToMonthComparison(openPage: Boolean = true) {
            if (refreshingMonthToMonthComparison) return
            refreshingMonthToMonthComparison = true
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    companyActivations.monthToMonthComparison(
                        userType = store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty(),
                        staffLevel = store.getSetting(SETTING_MY_DEVICES_STAFF_LEVEL).orEmpty(),
                        partnerCode = store.getSetting(SETTING_MY_DEVICES_PARTNER_CODE).orEmpty(),
                        deviceId = store.getSetting(SETTING_MY_DEVICES_DEVICE_ID).orEmpty(),
                        division = store.getSetting(SETTING_MY_DEVICES_DIVISION).orEmpty(),
                        region = store.getSetting(SETTING_MY_DEVICES_REGION).orEmpty(),
                        staffName = store.getSetting(SETTING_MY_DEVICES_STAFF_NAME).orEmpty(),
                        territory = store.getSetting(SETTING_MY_DEVICES_TERRITORY).orEmpty(),
                        currentCodes = savedMyDevices(),
                        asOf = PaymentRules.currentAwareDate()
                    )
                }
                monthToMonthComparison = result?.let {
                    StoredMonthToMonthComparison(it.asOf, it.currentTotal, it.previousTotal, it.delta, it.percentChange)
                }
                if (result == null) workflowRecoveryReason = "MOM_DATA"
                refreshingMonthToMonthComparison = false
                monthToMonthChildComparisons = emptyList()
                monthToMonthChildLevel = ""
                monthToMonthSelectedParent = ""
                monthToMonthDeviceComparisons = emptyList()
                if (openPage) showMonthToMonthComparison = true
            }
        }

        fun openMonthToMonthComparison() {
            val activeProfile = profiles.firstOrNull { it.id == activeProfileId }
            val profileCodes = activeProfile?.codes.orEmpty().ifEmpty { savedMyDevices() }
            if (activeProfile == null || profileCodes.isEmpty()) {
                workflowRecoveryReason = "MOM_PROFILE"
                return
            }
            monthToMonthStaffSearchAllowed()
            scope.launch {
                val update = withContext(Dispatchers.IO) { appVersionManager.checkFeature("month_on_month") }
                if (update != null) {
                    versionUpdateReason = update.reason.ifBlank { "This feature requires a newer version of DevMonitor." }
                    versionUpdateInfo = update
                    DevMonitorAnalytics.log(this@MainActivity, "update_prompt_shown", mapOf("prompt_type" to "feature_gate", "feature" to "month_on_month"))
                    return@launch
                }
                showMonthToMonthComparison = true
                if (monthToMonthComparison == null) refreshMonthToMonthComparison()
            }
        }

        LaunchedEffect(Unit) {
            // Poll once at launch and keep a visible diagnostic for troubleshooting.
            val broadcastCheck = withContext(Dispatchers.IO) { broadcastReleaseManager.checkBroadcastFromServer() }
            activeBroadcast = broadcastCheck.broadcast
            broadcastDiagnostic = broadcastCheck.status
            val prefs = getSharedPreferences("devmonitor_release_tracker", MODE_PRIVATE)
            val seenVersion = prefs.getLong("whats_new_seen_version", 0L)
            if (seenVersion < BuildConfig.VERSION_CODE.toLong()) {
                val generated = broadcastReleaseManager.bundledReleaseNotes()
                val remote = withContext(Dispatchers.IO) { broadcastReleaseManager.remoteReleaseNotes(BuildConfig.VERSION_CODE.toLong()) }
                whatsNewHighlights = remote.ifEmpty { generated }
                if (whatsNewHighlights.isNotEmpty()) showWhatsNew = true
                prefs.edit().putLong("whats_new_seen_version", BuildConfig.VERSION_CODE.toLong()).apply()
            }
            val update = withContext(Dispatchers.IO) { appVersionManager.checkUpdateAvailable() }
            versionUpdateReason = update?.reason.orEmpty()
            versionUpdateInfo = update
            if (update != null) {
                val mandatory = update.minimumVersionCode > BuildConfig.VERSION_CODE.toLong()
                DevMonitorAnalytics.log(this@MainActivity, "update_prompt_shown", mapOf("prompt_type" to if (mandatory) "mandatory" else "optional"))
            }
        }

        LaunchedEffect(showMonthToMonthComparison, monthToMonthSearchQuery) {
            if (!showMonthToMonthComparison) return@LaunchedEffect
            if (!monthToMonthStaffSearchAllowed()) {
                monthToMonthSearchHits = emptyList()
                monthToMonthSearchLoading = false
                return@LaunchedEffect
            }
            val query = monthToMonthSearchQuery.trim()
            if (query.length < 2) {
                monthToMonthSearchHits = emptyList()
                monthToMonthSearchLoading = false
                return@LaunchedEffect
            }
            monthToMonthSearchLoading = true
            val hits = withContext(Dispatchers.IO) {
                companyActivations.searchMonthToMonth(query, PaymentRules.currentAwareDate()).map { hit ->
                    MonthToMonthSearchHit(
                        type = hit.type,
                        label = hit.label,
                        detail = hit.detail,
                        deviceIds = hit.deviceIds
                    )
                }
            }
            monthToMonthSearchHits = hits
            monthToMonthSearchLoading = false
        }

        fun openMonthToMonthSearchDetail(hit: MonthToMonthSearchHit) {
            monthToMonthSelectedSearchHit = hit
            monthToMonthDetailRows = emptyList()
            monthToMonthDetailLoading = true
            scope.launch {
                val rows = withContext(Dispatchers.IO) {
                    hit.deviceIds.distinct().take(50).map { code ->
                        val result = companyActivations.monthToMonthComparison(
                            userType = "AGENT", staffLevel = "", partnerCode = "", deviceId = code,
                            division = "", region = "", staffName = "", territory = "",
                            currentCodes = listOf(code), asOf = PaymentRules.currentAwareDate()
                        )
                        MonthToMonthDetailRow(code, result?.let {
                            StoredMonthToMonthComparison(it.asOf, it.currentTotal, it.previousTotal, it.delta, it.percentChange)
                        })
                    }
                }
                monthToMonthDetailRows = rows
                monthToMonthDetailLoading = false
            }
        }

        fun loadMonthToMonthDeviceComparisons() {
            if (monthToMonthDeviceLoading) return
            monthToMonthDeviceLoading = true
            scope.launch {
                // Device-level Month-on-Month is scoped to the user's saved My Devices list.
                // Do not hide this workflow based on profile labels: profile values can vary
                // between role naming conventions, while the saved device list is the actual scope.
                val codes = savedMyDevices()
                val asOf = PaymentRules.currentAwareDate()
                val next = if (codes.isEmpty()) emptyList() else withContext(Dispatchers.IO) {
                    val comparisons = companyActivations.monthToMonthDeviceComparisons(codes, asOf)
                    codes.mapNotNull { code ->
                        val comparison = comparisons[canonicalDeviceCode(code)] ?: return@mapNotNull null
                        MonthToMonthChildResult(
                            label = code,
                            levelLabel = "DEVICE",
                            comparison = StoredMonthToMonthComparison(
                                comparison.asOf, comparison.currentTotal, comparison.previousTotal,
                                comparison.delta, comparison.percentChange
                            )
                        )
                    }
                }
                monthToMonthDeviceComparisons = next
                monthToMonthDeviceLoading = false
            }
        }

        fun loadMonthToMonthChildren(parentStaffName: String = "", parentTerritory: String = "") {
            if (monthToMonthChildLoading) return
            monthToMonthChildLoading = true
            scope.launch {
                val userType = store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty()
                val staffLevel = store.getSetting(SETTING_MY_DEVICES_STAFF_LEVEL).orEmpty().uppercase(Locale.US)
                val division = store.getSetting(SETTING_MY_DEVICES_DIVISION).orEmpty()
                val region = store.getSetting(SETTING_MY_DEVICES_REGION).orEmpty()
                val rootStaffName = store.getSetting(SETTING_MY_DEVICES_STAFF_NAME).orEmpty()
                val next = withContext(Dispatchers.IO) {
                    val rows = companyActivations.latestDeviceScopeRows()
                    val candidates = when {
                        userType.uppercase(Locale.US) != "STAFF" -> emptyList()
                        staffLevel == "CLUSTER HEAD" -> rows
                            .filter { it.cluster.equals(division.trim(), true) && it.region.isNotBlank() }
                            .groupBy { it.region.trim() }
                            .map { (childRegion, grouped) ->
                                childRegion to grouped.map { it.deviceId }.distinct()
                            }
                            .sortedBy { it.first.lowercase(Locale.US) }
                        staffLevel == "REGIONAL MANAGER" && parentStaffName.isBlank() -> rows
                            .filter { it.region.equals(region.trim(), true) && it.staffName.isNotBlank() }
                            .groupBy { it.staffName.trim() }
                            .map { (childStaff, grouped) ->
                                childStaff to grouped.map { it.deviceId }.distinct()
                            }
                            .sortedBy { it.first.lowercase(Locale.US) }
                        else -> emptyList()
                    }
                    val asOf = PaymentRules.currentAwareDate()
                    candidates.mapNotNull { (label, codes) ->
                        val comparison = when {
                            staffLevel == "CLUSTER HEAD" && parentStaffName.isBlank() -> companyActivations.monthToMonthComparison(
                                userType = "STAFF", staffLevel = "REGIONAL MANAGER", partnerCode = "", deviceId = "",
                                division = division, region = label, staffName = "", territory = "", currentCodes = codes, asOf = asOf, restrictToCodes = true
                            )
                            staffLevel == "REGIONAL MANAGER" && parentStaffName.isBlank() -> companyActivations.monthToMonthComparison(
                                userType = "STAFF", staffLevel = "STAFF", partnerCode = "", deviceId = "",
                                division = division, region = region, staffName = label, territory = "", currentCodes = codes, asOf = asOf, restrictToCodes = true
                            )
                            else -> null
                        } ?: return@mapNotNull null
                        val canDrill = when {
                            staffLevel == "REGIONAL MANAGER" && parentStaffName.isBlank() -> rows.any { it.region.equals(region.trim(), true) && it.staffName.equals(label, true) && it.territory.isNotBlank() }
                            else -> false
                        }
                        MonthToMonthChildResult(
                            label = label,
                            levelLabel = when {
                                staffLevel == "CLUSTER HEAD" && parentStaffName.isBlank() -> "REGION"
                                staffLevel == "REGIONAL MANAGER" && parentStaffName.isBlank() -> "CLUSTER MANAGER"
                                else -> ""
                            },
                            comparison = StoredMonthToMonthComparison(comparison.asOf, comparison.currentTotal, comparison.previousTotal, comparison.delta, comparison.percentChange),
                            region = if (staffLevel == "CLUSTER HEAD" && parentStaffName.isBlank()) label else region,
                            staffName = if (staffLevel == "REGIONAL MANAGER" && parentStaffName.isBlank()) label else parentStaffName.ifBlank { rootStaffName },
                            territory = "",
                            canDrillDown = false
                        )
                    }
                }
                monthToMonthChildComparisons = next
                monthToMonthChildLevel = next.firstOrNull()?.levelLabel.orEmpty()
                monthToMonthSelectedParent = parentStaffName
                monthToMonthChildLoading = false
            }
        }

        // The user-scoped education notice is deliberately deferred until a Check My Devices
        // operation has actually finished and the app has been idle for a short period. It is
        // an onboarding message, not a recurring alert. Existing installs are not made eligible
        // retroactively; only fresh installs that complete the welcome flow are eligible.
        LaunchedEffect(showSimRegReport, userScopedNoticePending, userScopedNoticeBusy) {
            if (!userScopedNoticePending || userScopedNoticeBusy || showSimRegReport) return@LaunchedEffect
            if (store.getSetting(SETTING_USER_SCOPED_NOTICE_ELIGIBLE) != "true") {
                userScopedNoticePending = false
                return@LaunchedEffect
            }
            if (store.getSetting(SETTING_USER_SCOPED_NOTICE_SHOWN) == "true") {
                userScopedNoticePending = false
                return@LaunchedEffect
            }
            delay(6000)
            if (userScopedNoticePending && !userScopedNoticeBusy && !showSimRegReport) {
                store.setSetting(SETTING_USER_SCOPED_NOTICE_SHOWN, "true")
                userScopedNoticePending = false
            }
        }

        LaunchedEffect(deviceMonitorPaymentCode) {
            deviceMonitorPaymentCode?.let { code ->
                DevMonitorLogger.screen("Device Monitor payment card navigation requested for $code")
            }
        }
        var showSettings by remember { mutableStateOf(false) }
        var themePreference by remember { mutableStateOf(store.getSetting(SETTING_THEME) ?: "system") }
        val welcomeSeenAtLaunch = remember { hasWelcomeBeenSeen(this@MainActivity, store) }
        LaunchedEffect(welcomeSeenAtLaunch) {
            if (!welcomeSeenAtLaunch) DevMonitorWelcomeAudio.playFirstLaunchOnce(this@MainActivity)
        }
        var showWelcome by remember { mutableStateOf(!welcomeSeenAtLaunch) }
        // Only fresh installs that have not completed the welcome flow receive this one-time setup.
        // Permission setup is independent of the online-report/Google Drive configuration.
        var showPermissionSetup by remember { mutableStateOf(
            !welcomeSeenAtLaunch && store.getSetting(SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN) != "true"
        ) }
        var permissionSetupStep by remember { mutableIntStateOf(0) }
        var showSaveHelp by remember { mutableStateOf(false) }
        var showAbout by remember { mutableStateOf(false) }
        var showFeedback by remember { mutableStateOf(false) }
        var showFiles by remember { mutableStateOf(false) }
        var showSimMenu by remember { mutableStateOf(false) }
        var showLogViewer by remember { mutableStateOf(false) }
        var logVersion by remember { mutableIntStateOf(0) }
        var showSmsDisclosure by remember { mutableStateOf(false) }
        // A user can start a DevMonitor run before Android has granted SMS access.
        // Keep that exact run request alive while the disclosure/permission UI is shown,
        // then resume it automatically once SEND_SMS + RECEIVE_SMS are granted.
        var pendingSmsRunCodes by remember { mutableStateOf<List<String>?>(null) }
        var pendingSmsRunRetryOnly by remember { mutableStateOf(false) }
        // One-off enquiries are deliberately separate from the persistent My Devices
        // working set. They can be checked immediately without joining the batch queue.
        var oneOffRunRequested by remember { mutableStateOf(false) }
        var oneOffCodes by remember { mutableStateOf<List<String>>(emptyList()) }
        var showRecoverySummary by remember { mutableStateOf(false) }
        var recoveryMessage by remember { mutableStateOf("") }
        var showAgents by remember { mutableStateOf(false) }
        var showOnlineReports by remember { mutableStateOf(false) }
        var showMyDevicesProfile by remember { mutableStateOf(false) }
        var showBuildProfileHint by remember { mutableStateOf(profiles.isEmpty() && store.getSetting("build_profile_hint_seen") != "true") }
        var checkingMyDevices by remember { mutableStateOf(false) }
        var pendingCheckMyDevicesAfterReport by remember { mutableStateOf(false) }
        // First-time Check My Devices: keep the user journey alive through profile setup.
        var pendingCheckMyDevicesAfterProfile by remember { mutableStateOf(false) }
        // Check My Devices SMS actions must always pass through SIM selection first.
        var pendingMyDevicesSmsRunCodes by remember { mutableStateOf<List<String>>(emptyList()) }
        var pendingPartnerSummaryCodeAfterSim by remember { mutableStateOf<String?>(null) }
        var showMyDevicesActionMenu by remember { mutableStateOf(false) }
        var showPartnerSourceMenu by remember { mutableStateOf(false) }
        var partnerActionMode by remember { mutableStateOf("") }
        var partnerSummaryLoading by remember { mutableStateOf(false) }
        var partnerSummaryCode by remember { mutableStateOf("") }
        var partnerLookupQuery by remember { mutableStateOf("") }
        var partnerLookupError by remember { mutableStateOf<String?>(null) }
        var partnerSummaryResult by remember { mutableStateOf<SimRegResult?>(null) }
        var onlineReportLoading by remember { mutableStateOf(false) }
        var onlineReportSelectedName by remember { mutableStateOf<String?>(null) }
        var importedSimRegReport by remember { mutableStateOf<SimRegReport?>(null) }
        var partnerActivationTarget by remember { mutableIntStateOf((store.getSetting(SETTING_PARTNER_TARGET)?.toIntOrNull() ?: PaymentRules.DEFAULT_PARTNER_MIN_ACTIVATIONS).coerceAtLeast(1)) }
        var pendingAgentId by remember { mutableStateOf<Long?>(null) }
        var pendingAgentCreateNew by remember { mutableStateOf(false) }
        var pendingAgentPhotoId by remember { mutableStateOf<Long?>(null) }
        var pendingAgentDraftPhotoPath by remember { mutableStateOf<String?>(null) }
        var pendingAgentEditorId by remember { mutableStateOf<Long?>(null) }
        var agentRefreshToken by remember { mutableIntStateOf(0) }
        var pendingAgentContactImport by remember { mutableStateOf<AgentContactImportPreview?>(null) }
        var pendingAgentContactName by remember { mutableStateOf("") }
        var pendingAgentContactAddress by remember { mutableStateOf("") }

        fun deleteProfile(profile: DeviceProfile) {
            val wasActive = profile.id == activeProfileId
            if (wasActive) {
                runCatching { myDevicesDatabase.close() }
                runCatching { store.clearActiveProfile() }
            }
            val myDbName = profileDatabaseName(profile.id)
            val monitorDbName = ProfileDatabaseNames.deviceMonitor(profile.id)
            listOf(myDbName, "$myDbName-wal", "$myDbName-shm", monitorDbName, "$monitorDbName-wal", "$monitorDbName-shm")
                .forEach { name -> runCatching { File(applicationContext.getDatabasePath(name).path).delete() } }

            profiles = profiles.filterNot { it.id == profile.id }
            profileStore.saveAll(profiles)
            if (wasActive) {
                val next = profiles.firstOrNull()
                if (next != null) {
                    applyProfile(next)
                    runCatching { companyActivations.refreshMonthOnMonthMyDevices(next.codes) }
                } else {
                    profileStore.clearActive()
                    activeProfileId = null
                    store.clearActiveProfile()
                    codes = emptyList()
                    records = emptyMap()
                    importedSimRegReport = null
                    runCatching { companyActivations.refreshMonthOnMonthMyDevices(emptyList()) }
                }
            }
            profileDeleteTarget = null
            showMyDevicesProfile = false
            showSettings = false
            profileEditorNew = false
            profileEditorId = null
            message = "Profile '${profile.name}' was deleted."
        }


        LaunchedEffect(activeProfileId) {
            val profile = profiles.firstOrNull { it.id == activeProfileId }
            if (profile != null) {
                profileStore.setActive(profile.id)
                store.switchProfile(profile.id)
                companyActivations.setDeviceMonitorStore(database)
                runCatching { myDevicesDatabase.close() }
                myDevicesDatabase = MyDevicesStore(this@MainActivity, profileDatabaseName(profile.id))
                store.setSetting("my_devices_name", profile.name)
                store.setSetting("my_devices_phone", profile.phone)
                store.setSetting(SETTING_MY_DEVICES_USER_TYPE, profile.userType)
                store.setSetting(SETTING_MY_DEVICES_STAFF_LEVEL, profile.staffLevel)
                store.setSetting(SETTING_MY_DEVICES_PARTNER_CODE, profile.partnerCode)
                store.setSetting(SETTING_MY_DEVICES_DEVICE_ID, profile.deviceId)
                store.setSetting(SETTING_MY_DEVICES_DIVISION, profile.division)
                store.setSetting(SETTING_MY_DEVICES_REGION, profile.region)
                store.setSetting(SETTING_MY_DEVICES_STAFF_NAME, profile.staffName)
                store.setSetting(SETTING_MY_DEVICES_TERRITORY, profile.territory)
                store.setSetting(SETTING_MY_DEVICES_CODES, profile.codes.joinToString("|"))
                store.setSetting(SETTING_MY_DEVICES_SETUP, if (profile.userType.isBlank() && profile.codes.isEmpty()) "false" else "true")
                codes = profile.codes
                records = emptyMap()
            }
            monthToMonthComparison = null
            monthToMonthChildComparisons = emptyList()
            monthToMonthDeviceComparisons = emptyList()
            importedSimRegReport = null
            deviceMonitorPaymentCode = null
            showMyDevicesActionMenu = false
        }

        fun openLoadedReportViewer(focusDeviceId: String? = null) {
            if (importingSimReg) return

            // Navigate immediately. The old path waited for the complete HQ snapshot
            // to be reconstructed before showing the screen, which made an already-
            // loaded report feel like the button had not responded. The viewer can
            // render the cached My Devices working set while the authoritative HQ
            // report is reconstructed in the background.
            importedSimRegReport = null
            loadingSavedReport = true
            showSimRegReport = true
            selectedTab = 5

            scope.launch {
                val latest = withContext(Dispatchers.IO) {
                    val stored = companyActivations.listReports().firstOrNull()
                    if (stored == null) null
                    else if (focusDeviceId.isNullOrBlank()) companyActivations.loadReport(stored.id)
                    else companyActivations.loadReportForDevice(stored.id, focusDeviceId)
                }
                importedSimRegReport = latest
                loadingSavedReport = false
                if (latest == null) {
                    message = if (focusDeviceId.isNullOrBlank()) {
                        "No saved HQ report is available yet. Import a valid report to begin."
                    } else {
                        "The matching Loaded Report record could not be opened."
                    }
                }
            }
        }


        pendingExternalExcelUri?.let { externalUri ->
            AlertDialog(
                onDismissRequest = { pendingExternalExcelUri = null },
                title = { Text("Load Excel sheet?") },
                text = {
                    Text(
                        "DevMonitor received an Excel workbook from another Android app.\n\n" +
                            "Load \"${displayNameForUri(externalUri)}\" into the SIMReg Report analyzer?"
                    )
                },
                confirmButton = {
                    DevMonitorButton(onClick = {
                        val name = displayNameForUri(externalUri)
                        pendingExternalExcelUri = null
                        importedSimRegReport = null
                        showSimRegReport = true
                        importSimRegWorkbook(externalUri, name,
                            onSuccess = { parsed ->
                                importedSimRegReport = parsed
                                showSimRegReport = true
                                message = "Excel report imported: ${parsed.rows.size} device records. The verified HQ snapshot was stored for ${parsed.coverageStart?.let { YearMonth.from(it) } ?: "its report month"}; refresh any view when you want it updated."
                                DevMonitorAnalytics.log(this@MainActivity, "report_import_success", mapOf("source" to "local_excel"))
                                addNotification("Report imported", "Excel report loaded with ${parsed.rows.size} device records.", "success")
                                if (pendingCheckMyDevicesAfterReport) {
                                    pendingCheckMyDevicesAfterReport = false
                                    pendingCheckMyDevicesAfterProfile = true
                                    profileEditorNew = true
                                    profileEditorId = null
                                    showSimRegReport = false
                                    importingSimReg = false
                                    simRegImportMessage = ""
                                    selectedTab = 4
                                                                        showMyDevicesProfile = true
                                }
                            },
                            onFailure = { error -> message = "This workbook could not be imported: ${error.message ?: "unsupported workbook"}" }
                        )
                    }) { Text("Load") }
                },
                dismissButton = {
                    DevMonitorOutlinedButton(onClick = { pendingExternalExcelUri = null }) { Text("Cancel") }
                }
            )
        }

        if (showOnlineReports) {
            OnlineReportsDialog(
                onDismiss = {
                    if (!onlineReportLoading) {
                        showOnlineReports = false
                        onlineReportSelectedName = null
                    }
                },
                loadingSelection = onlineReportLoading,
                selectedName = onlineReportSelectedName,
                onSelect = { onlineFile ->
                    if (!onlineReportLoading) {
                    onlineReportLoading = true
                    onlineReportSelectedName = onlineFile.name
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            runCatching { OnlineReportStore.downloadToCache(this@MainActivity, onlineFile) }
                        }
                        result.onSuccess { tempFile ->
                            importedSimRegReport = null
                            showSimRegReport = true
                            showOnlineReports = false
                            onlineReportLoading = false
                            importSimRegWorkbookFile(
                                tempFile,
                                onlineFile.name,
                                onSuccess = { parsed ->
                                    tempFile.delete()
                                    onlineReportSelectedName = null
                                    importedSimRegReport = parsed
                                    showSimRegReport = true
                                    message = "Online report imported: ${parsed.rows.size} device records. The verified HQ snapshot was stored for ${parsed.coverageStart?.let { YearMonth.from(it) } ?: "its report month"}; refresh any view when you want it updated."
                                    DevMonitorAnalytics.log(this@MainActivity, "report_import_success", mapOf("source" to "online_report"))
                                    addNotification("Online report imported", "Online report loaded with ${parsed.rows.size} device records.", "success")
                                    if (pendingCheckMyDevicesAfterReport) {
                                        pendingCheckMyDevicesAfterReport = false
                                        showSimRegReport = false
                                        importingSimReg = false
                                        simRegImportMessage = ""
                                        selectedTab = 4
                                                                                showMyDevicesProfile = true
                                    }
                                },
                                onFailure = { error ->
                                    tempFile.delete()
                                    onlineReportSelectedName = null
                                    message = "Online report could not be imported: ${error.message ?: "unsupported workbook"}"
                                }
                            )
                        }.onFailure { error ->
                            onlineReportLoading = false
                            onlineReportSelectedName = null
                            message = "Could not download online report: ${error.message ?: error.javaClass.simpleName}"
                        }
                    }
                    }
                }
            )
        }

        var saveName by remember { mutableStateOf("") }
        var destinationInput by remember { mutableStateOf("") }
        var activeSims by remember { mutableStateOf<List<SubscriptionInfo>>(emptyList()) }
        var selectedSubId by remember {
            mutableIntStateOf(
                store.getSetting(SETTING_SMS_SUB_ID)?.toIntOrNull()
                    ?: SubscriptionManager.INVALID_SUBSCRIPTION_ID
            )
        }
        var destinations by remember {
            mutableStateOf(loadDestinations(store.getSetting(SETTING_DESTINATIONS)))
        }
        var destination by remember {
            mutableStateOf(destinations.firstOrNull() ?: DEFAULT_SMS_DESTINATION)
        }
        var retention by remember {
            mutableIntStateOf(
                (store.getSetting(SETTING_RETENTION)?.toIntOrNull() ?: 60).coerceIn(1, 60)
            )
        }
        var dbSearch by remember { mutableStateOf("") }
        var dbItems by remember { mutableStateOf(store.databaseCodes()) }
        var permissionTick by remember { mutableIntStateOf(0) }
        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner, showPermissionSetup) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME && showPermissionSetup) permissionTick++
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }
        var attachedFiles by remember { mutableStateOf(loadAttachedFiles(store.getSetting(SETTING_ATTACHED_FILES))) }
        var lastAttachedUri by remember { mutableStateOf<Uri?>(null) }
        val initialGoogleAccount = GoogleSignIn.getLastSignedInAccount(this)
        val initialFirebaseUser = FirebaseAuth.getInstance().currentUser
        var googleEmail by remember { mutableStateOf(initialGoogleAccount?.email ?: initialFirebaseUser?.email ?: store.getSetting(SETTING_GOOGLE_EMAIL)) }
        var googleName by remember { mutableStateOf(initialGoogleAccount?.displayName ?: initialFirebaseUser?.displayName ?: store.getSetting(SETTING_GOOGLE_NAME)) }
        var googlePhotoUrl by remember { mutableStateOf(initialGoogleAccount?.photoUrl?.toString() ?: initialFirebaseUser?.photoUrl?.toString() ?: store.getSetting(SETTING_GOOGLE_PHOTO)) }
        var authAccount by remember { mutableStateOf(database.fieldPulseAccount()) }
        var cloudBusy by remember { mutableStateOf(false) }
        var exportCount by remember { mutableIntStateOf(store.getSetting(SETTING_EXPORT_COUNT)?.toIntOrNull() ?: 0) }
        var rewardCredits by remember { mutableIntStateOf(store.getSetting(SETTING_EXPORT_CREDITS)?.toIntOrNull() ?: 0) }
        var pendingRewardCredit by remember { mutableStateOf(false) }
        var showBilling by remember { mutableStateOf(false) }
        var showSensitiveFlags by remember { mutableStateOf(store.getSetting(SETTING_SHOW_SENSITIVE_FLAGS) == "true") }
        var soundEnabled by remember { mutableStateOf(feedback.soundEnabled) }
        var hapticEnabled by remember { mutableStateOf(feedback.hapticEnabled) }
        var saveHintActive by remember { mutableStateOf(false) }
        var titleTapCount by remember { mutableIntStateOf(0) }
        var lastTitleTapAt by remember { mutableLongStateOf(0L) }
        val adsRemoved by billingManager.adsRemoved.collectAsState()
        val monthlyProduct by billingManager.monthly.collectAsState()
        val yearlyProduct by billingManager.yearly.collectAsState()
        val focusManager = LocalFocusManager.current
        val keyboardController = LocalSoftwareKeyboardController.current

        // Local function declarations in Kotlin must be visible before use.
        // The permission and Check My Devices callbacks are created before the
        // full run implementation below, so keep a function variable here and
        // assign the real implementation later in this composition.
        var beginRun: (List<String>, Boolean) -> Unit = { _, _ -> }

        val smsPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            permissionTick++

            // If a run was started before Android's SMS permission prompt, resume
            // that exact run immediately once the two permissions required for
            // sending are actually granted. Do not make the user press Start a
            // second time after the permission dialog closes.
            val sendReceiveGranted =
                hasPermission(Manifest.permission.SEND_SMS) &&
                hasPermission(Manifest.permission.RECEIVE_SMS)

            if (!sendReceiveGranted) {
                pendingSmsRunCodes = null
                pendingSmsRunRetryOnly = false
                oneOffRunRequested = false
            } else {
                val pending = pendingSmsRunCodes
                if (pending != null && pending.isNotEmpty() && !running) {
                    val retryOnly = pendingSmsRunRetryOnly
                    pendingSmsRunCodes = null
                    pendingSmsRunRetryOnly = false
                    scope.launch {
                        delay(150)
                        beginRun(pending, retryOnly)
                    }
                }
            }
        }
        val phonePermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { permissionTick++ }

        val locationPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissionTick++ }

        val firstLaunchPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissionTick++ }

        val agentPhotoLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            val agentId = pendingAgentPhotoId
            if (uri != null) {
                runCatching {
                    if (agentId != null) {
                        val photoDir = java.io.File(filesDir, "agent_photos").apply { mkdirs() }
                        val photoFile = java.io.File(photoDir, "agent_${agentId}_${System.currentTimeMillis()}.jpg")
                        contentResolver.openInputStream(uri)?.use { input -> photoFile.outputStream().use { output -> input.copyTo(output) } }
                        val current = database.agents().firstOrNull { it.id == agentId }
                        if (current != null && photoFile.exists() && photoFile.length() > 0L) {
                            database.saveAgent(current.copy(photoPath = photoFile.absolutePath, updatedAt = System.currentTimeMillis()))
                        } else photoFile.delete()
                        agentRefreshToken++
                    } else {
                        val previewDir = java.io.File(cacheDir, "agent_photo_previews").apply { mkdirs() }
                        val previewFile = java.io.File(previewDir, "selected_${System.currentTimeMillis()}.jpg")
                        contentResolver.openInputStream(uri)?.use { input -> previewFile.outputStream().use { output -> input.copyTo(output) } }
                        if (previewFile.exists() && previewFile.length() > 0L) {
                            pendingAgentDraftPhotoPath?.let { java.io.File(it).delete() }
                            pendingAgentDraftPhotoPath = previewFile.absolutePath
                        } else previewFile.delete()
                    }
                }.onFailure { error -> android.widget.Toast.makeText(context, "Could not load the selected photo: ${error.message ?: "unavailable image"}", android.widget.Toast.LENGTH_LONG).show() }
            }
            pendingAgentPhotoId = null
        }

        val contactLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.PickContact()
        ) { uri ->
            val agentId = pendingAgentId
            val createNew = pendingAgentCreateNew
            if (uri != null && (agentId != null || createNew)) {
                runCatching {
                    val displayName = contentResolver.query(uri, arrayOf(ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0).orEmpty() else "" }.orEmpty()
                    val contactId = contentResolver.query(uri, arrayOf(ContactsContract.Contacts._ID), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                        ?: uri.lastPathSegment
                        ?: throw IllegalStateException("The selected contact could not be identified.")
                    val phones = mutableListOf<Pair<String, String>>()
                    contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.TYPE), "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?", arrayOf(contactId), null)?.use { c ->
                        while (c.moveToNext()) {
                            val number = c.getString(0)?.trim().orEmpty()
                            if (number.isNotBlank()) phones += number to ContactsContract.CommonDataKinds.Phone.getTypeLabel(resources, c.getInt(1), "").toString()
                        }
                    }
                    val emails = mutableListOf<Pair<String, String>>()
                    contentResolver.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS, ContactsContract.CommonDataKinds.Email.TYPE), "${ContactsContract.CommonDataKinds.Email.CONTACT_ID}=?", arrayOf(contactId), null)?.use { c ->
                        while (c.moveToNext()) {
                            val email = c.getString(0)?.trim().orEmpty()
                            if (email.isNotBlank()) emails += email to ContactsContract.CommonDataKinds.Email.getTypeLabel(resources, c.getInt(1), "").toString()
                        }
                    }
                    val postal = contentResolver.query(ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.StructuredPostal.FORMATTED_ADDRESS), "${ContactsContract.CommonDataKinds.StructuredPostal.CONTACT_ID}=?", arrayOf(contactId), null)?.use { c ->
                        var result = ""
                        while (c.moveToNext() && result.isBlank()) result = c.getString(0).orEmpty()
                        result
                    }.orEmpty()
                    var photoPreviewPath: String? = null
                    runCatching {
                        val photoUriString = contentResolver.query(uri, arrayOf(ContactsContract.Contacts.PHOTO_URI), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                        val photoStream = ContactsContract.Contacts.openContactPhotoInputStream(contentResolver, uri, true)
                            ?: photoUriString?.let { photoString -> runCatching { contentResolver.openInputStream(Uri.parse(photoString)) }.getOrNull() }
                        if (photoStream != null) {
                            val previewDir = java.io.File(cacheDir, "agent_photo_previews").apply { mkdirs() }
                            val previewFile = java.io.File(previewDir, "contact_${contactId}_${System.currentTimeMillis()}.jpg")
                            photoStream.use { input -> previewFile.outputStream().use { output -> input.copyTo(output) } }
                            if (previewFile.exists() && previewFile.length() > 0L) photoPreviewPath = previewFile.absolutePath else previewFile.delete()
                        }
                    }
                    val current = agentId?.let { id -> database.agents().firstOrNull { it.id == id } }
                    if (createNew || current != null) {
                        pendingAgentContactName = displayName.ifBlank { current?.name.orEmpty() }
                        pendingAgentContactAddress = postal.ifBlank { current?.address.orEmpty() }
                        pendingAgentContactImport = AgentContactImportPreview(agentId, uri.toString(), displayName, phones.distinct(), emails.distinct(), postal, photoPreviewPath)
                    } else photoPreviewPath?.let { java.io.File(it).delete() }
                }.onFailure {
                    android.widget.Toast.makeText(context, "Could not read this contact. Allow DevMonitor Contacts access in Android Settings, then try again. Details: ${it.message ?: "access denied"}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
            pendingAgentId = null
            pendingAgentCreateNew = false
        }
        val contactsPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) contactLauncher.launch(null)
            else {
                pendingAgentId = null
                pendingAgentCreateNew = false
                android.widget.Toast.makeText(context, "Contacts permission is needed to import the selected contact details.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
        fun startAgentContactImport(agentId: Long?) {
            pendingAgentId = agentId
            pendingAgentCreateNew = agentId == null
            if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                contactLauncher.launch(null)
            } else contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }

        fun requestLocationPermissions() {
            val needed = listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                .filterNot(::hasPermission)
            if (needed.isNotEmpty()) locationPermissionLauncher.launch(needed.toTypedArray())
        }

        fun currentLocation(): Pair<Double, Double>? {
            if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) && !hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                requestLocationPermissions()
                return null
            }
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            return providers.asSequence().mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }
                .maxByOrNull { it.time }?.let { it.latitude to it.longitude }
        }

        fun openMaps(latitude: Double?, longitude: Double?) {
            val query = if (latitude != null && longitude != null) "$latitude,$longitude" else "Nigeria"
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}"))
            runCatching { startActivity(intent) }
        }

        fun requestSmsPermissions(
            resumeCodes: List<String>? = null,
            resumeRetryOnly: Boolean = false
        ) {
            if (resumeCodes != null && resumeCodes.isNotEmpty()) {
                pendingSmsRunCodes = resumeCodes.toList()
                pendingSmsRunRetryOnly = resumeRetryOnly
            }
            val needed = listOf(
                Manifest.permission.SEND_SMS,
                Manifest.permission.RECEIVE_SMS
            ).filterNot(::hasPermission)
            if (needed.isNotEmpty()) {
                // Request SMS access only in the context of the user-initiated
                // batch automation feature, after a clear disclosure.
                showSmsDisclosure = true
            }
        }

        fun requestPhoneStatePermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                !hasPermission(Manifest.permission.READ_PHONE_STATE)
            ) {
                phonePermissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
            }
        }

        /**
         * Build a temporary Zero Devices target list from the existing My Devices
         * working set. A Zero Device is a company-owned My Device with zero
         * current-month sales activity. This is a target-list operation only:
         * it must never replace the normal SMS Checker device list or its results.
         */
        fun refreshSims(): List<SubscriptionInfo> {
            if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
                activeSims = emptyList()
                return emptyList()
            }
            val freshSims = runCatching {
                SubscriptionManager.from(context).activeSubscriptionInfoList ?: emptyList()
            }.getOrDefault(emptyList())
            activeSims = freshSims

            if (selectedSubId == SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                val defaultId = runCatching {
                    SubscriptionManager.getDefaultSmsSubscriptionId()
                }.getOrDefault(SubscriptionManager.INVALID_SUBSCRIPTION_ID)
                val chosen = activeSims.firstOrNull { it.subscriptionId == defaultId }?.subscriptionId
                    ?: activeSims.firstOrNull()?.subscriptionId
                if (chosen != null) {
                    selectedSubId = chosen
                    store.setSetting(SETTING_SMS_SUB_ID, chosen.toString())
                }
            }
            return freshSims
        }

        LaunchedEffect(permissionTick) { refreshSims() }

        val permissionOk = hasPermission(Manifest.permission.SEND_SMS) &&
            hasPermission(Manifest.permission.RECEIVE_SMS)
        val smsRecoveryPermissionOk = hasPermission(Manifest.permission.READ_SMS)
        val phonePermissionOk = hasPermission(Manifest.permission.READ_PHONE_STATE)

        fun loadZeroDevicesForSmsChecker() {
            // Device Monitor only: never run this device-specific action in My Partners.
            if (selectedTab == 6 || running || zeroDevicesLoading) return
            val ownedCompany = savedMyDevices()
                .filter { Ownership.from(it) == Ownership.COMPANY }
                .distinct()
            if (ownedCompany.isEmpty()) {
                zeroDeviceTargetCodes = emptyList()
                message = if (savedMyDevices().isEmpty()) {
                    "Set up My Devices first. Zero Devices is a subset of your My Devices with zero current-month sales."
                } else {
                    "No company-owned devices are currently in My Devices."
                }
                return
            }
            zeroDevicesLoading = true
            scope.launch {
                try {
                    val asOf = PaymentRules.currentAwareDate()
                    val currentMonth = YearMonth.from(asOf)
                    val candidates = withContext(Dispatchers.IO) {
                        val currentReportExists = companyActivations.latestReportForMonth(
                            currentMonth.year, currentMonth.monthValue
                        ) != null
                        val smsObservations = database.observationsForMonth(currentMonth.toString())
                            .groupBy { canonicalDeviceCode(it.code) }

                        ownedCompany.mapNotNull { code ->
                            val loadedActivity = if (currentReportExists) {
                                companyActivations.currentMonthLoadedActivity(code, asOf)
                            } else 0
                            val smsActivity = smsObservations[code].orEmpty().maxOfOrNull { obs ->
                                maxOf(obs.today ?: 0, obs.mtd ?: 0)
                            } ?: 0
                            val activity = maxOf(loadedActivity, smsActivity)
                            if (activity == 0) code else null
                        }.sorted()
                    }

                    zeroDeviceTargetCodes = candidates
                    if (candidates.isEmpty()) {
                        message = "No Zero Devices found. Every company-owned device in My Devices has recorded current-month sales activity."
                    } else {
                        message = "Zero Devices ready: ${candidates.size}. Checking only these My Devices; existing SMS Checker results will remain intact."
                        if (!permissionOk) {
                            requestSmsPermissions(candidates, false)
                        } else {
                            beginRun(candidates, false)
                        }
                    }
                } finally {
                    zeroDevicesLoading = false
                }
            }
        }


        fun persist() = checkerStore.saveCurrent(codes, records)

        fun saveMyDevices(codesToSave: List<String>) {
            val normalized = codesToSave.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
            store.setSetting(SETTING_MY_DEVICES_CODES, normalized.joinToString("|"))
            store.setSetting(SETTING_MY_DEVICES_SETUP, "true")
            myDevicesDatabase.replaceCodes(normalized)
            saveActiveProfileSnapshot(normalized)
        }

        fun openCheckMyDevices() {
            if (checkingMyDevices) return
            // Check My Devices is a source-selection entry point. It must not
            // silently route the user to Loaded Report merely because a report
            // is absent. The user chooses Loaded Report or Device Monitor/SMS
            // from the action menu; each path handles its own data requirements.
            if (store.getSetting(SETTING_MY_DEVICES_SETUP) == "true" && savedMyDevices().isNotEmpty()) {
                showMyDevicesActionMenu = true
            } else {
                // First-time journey: create the device scope/profile, then
                // return to the same source-selection menu.
                pendingCheckMyDevicesAfterProfile = true
                profileEditorNew = true
                profileEditorId = null
                selectedTab = 4
                                showMyDevicesProfile = true
            }
        }

        fun startCheckMyDevicesDeviceMonitor(deviceCodes: List<String>) {
            val normalized = deviceCodes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
            if (normalized.isEmpty()) {
                message = "No devices are available for this Check My Devices profile."
                return
            }

            userScopedNoticePending = true
            userScopedNoticeBusy = true
            codes = normalized
            records = emptyMap()
            persist()
            selectedTab = 1

            val sims = refreshSims()

            // Check My Devices must not ask for a SIM every time. The persisted
            // sms_subscription_id is the app's default-SIM selection. Only show
            // the selector when that saved SIM is absent or is no longer active.
            val savedDefaultSimIsActive =
                selectedSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID &&
                    sims.any { it.subscriptionId == selectedSubId }

            if (!savedDefaultSimIsActive) {
                if (sims.isEmpty()) {
                    // Let the existing SIM/phone-permission flow establish the
                    // available SIMs, then allow the user to choose one.
                    requestPhoneStatePermission()
                }
                pendingMyDevicesSmsRunCodes = normalized
                showSimMenu = true
                return
            }

            // A default SIM already exists, so continue directly into the same
            // SMS workflow that the SIM dialog used to trigger.
            pendingMyDevicesSmsRunCodes = normalized
            if (permissionOk) {
                scope.launch {
                    delay(150)
                    val pending = pendingMyDevicesSmsRunCodes
                    if (pending.isNotEmpty()) {
                        pendingMyDevicesSmsRunCodes = emptyList()
                        beginRun(pending, false)
                    }
                }
            } else {
                requestSmsPermissions(normalized, resumeRetryOnly = false)
            }
        }

        fun updateRecord(code: String, record: QueryRecord) {
            records = records.toMutableMap().apply { put(code, record) }
            persist()
        }

        fun dayStartMillis(): Long {
            val cal = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        fun recoverFromSystemSms(showSummary: Boolean = true) {
            if (!smsRecoveryPermissionOk || codes.isEmpty() || running) return
            scope.launch {
                val todayStart = dayStartMillis()
                val messages = SmsInbox.systemInbox(this@MainActivity, todayStart)
                    .filter { it.sender.filter { it.isDigit() }.takeLast(4) == destination.filter { it.isDigit() }.takeLast(4) }
                    .filter { SmsParser.parse("", it.body, formatTime(it.receivedAt)).status == AttemptStatus.SUCCESS ||
                              SmsParser.parse("", it.body, formatTime(it.receivedAt)).status == AttemptStatus.NOT_FOUND }
                    .sortedBy { it.receivedAt }
                val attempts = store.smsQueryAttemptsForCodes(codes, todayStart)
                val matchedCodes = mutableMapOf<String, SmsInbox.ReceivedSms>()
                var ambiguous = 0
                for (sms in messages) {
                    val explicit = SmsParser.extractCode(sms.body)?.let(::canonicalDeviceCode)
                    if (explicit != null && codes.contains(explicit)) {
                        matchedCodes[explicit] = sms
                        continue
                    }
                    if (explicit != null) continue
                    val candidates = attempts.filter { a ->
                        records[a.code]?.result == null &&
                        codes.contains(a.code) &&
                        a.destination.filter { it.isDigit() }.takeLast(4) == destination.filter { it.isDigit() }.takeLast(4) &&
                        sms.receivedAt >= a.sentAt && sms.receivedAt - a.sentAt <= 10 * 60 * 1000L
                    }
                    if (candidates.isEmpty()) continue
                    val ranked = candidates.sortedBy { sms.receivedAt - it.sentAt }
                    if (ranked.size > 1 && (sms.receivedAt - ranked[0].sentAt) == (sms.receivedAt - ranked[1].sentAt)) {
                        ambiguous++; continue
                    }
                    matchedCodes[ranked.first().code] = sms
                }
                var recovered = 0
                for ((code, sms) in matchedCodes) {
                    val parsed = SmsParser.parse(code, sms.body, formatTime(sms.receivedAt))
                    val existing = records[code]
                    // Recovery never blocks future rechecks. It only restores the latest
                    // trustworthy result that was actually received by the phone.
                    updateRecord(code, QueryRecord(
                        code = code,
                        type = QueryType.from(code),
                        attempt = existing?.attempt ?: 1,
                        repetitionsSent = existing?.repetitionsSent ?: 0,
                        responseCount = 1,
                        status = parsed.status,
                        result = parsed,
                        error = "Recovered from the device SMS inbox at ${formatTime(sms.receivedAt)}.",
                        firstAttemptStatus = existing?.firstAttemptStatus,
                        completedAt = sms.receivedAt
                    ))
                    if (selectedTab != 6) store.recordObservation(parsed)
                    recovered++
                }
                checkerStore.pruneSmsQueryAttempts()
                recoveryMessage = if (recovered == 0) {
                    if (ambiguous > 0) "No safe matches were recovered. $ambiguous SMS response${if (ambiguous == 1) " was" else "s were"} ambiguous and were left unresolved."
                    else "No trustworthy 3030 SIMReg responses were found for this list today."
                } else {
                    "Recovered $recovered result${if (recovered == 1) "" else "s"} from the phone's SMS inbox.${if (ambiguous > 0) " $ambiguous ambiguous response${if (ambiguous == 1) " was" else "s were"} left unresolved." else ""}"
                }
                message = recoveryMessage
                if (showSummary) showRecoverySummary = true
            }
        }

        fun requestSmsRecoveryPermission() {
            if (!smsRecoveryPermissionOk) {
                showSmsDisclosure = true
            } else recoverFromSystemSms()
        }

        LaunchedEffect(permissionTick, codes.size, smsRecoveryPermissionOk) {
            if (smsRecoveryPermissionOk && codes.isNotEmpty() && !running) {
                delay(300)
                recoverFromSystemSms(showSummary = false)
            }
        }
        fun addCodes(newCodes: List<String>) {
            if (newCodes.isEmpty()) return
            val normalized = newCodes.map(::canonicalDeviceCode).filter { it.isNotBlank() }
            val before = codes.size
            codes = (codes + normalized).distinct()
            persist()
            val added = codes.size - before
            message = if (added == 0) {
                "No new devices added — matching short/long device codes are already in the list."
            } else {
                "Added $added device${if (added == 1) "" else "s"}."
            }
        }

        suspend fun sendRepeated(code: String, count: Int): Pair<Int, Boolean> {
            var sent = 0
            var deliveryWarning = false
            repeat(count.coerceIn(1, 6)) { index ->
                val result = sendSmsWithDeliveryMonitoring(
                    code,
                    selectedSubId.takeIf { it != SubscriptionManager.INVALID_SUBSCRIPTION_ID },
                    destination,
                    maxImmediateRetries = 2
                )
                if (result.apiAccepted) sent++
                if (result.deliveryFailure) deliveryWarning = true
                if (result.reportObserved && result.deliveryFailure) {
                    message = "SMS delivery problem: $code — retried ${result.attempts}× immediately; continuing with the query."
                }
                if (index < count - 1) delay(250)
            }
            return sent to deliveryWarning
        }

        var qualifyingInterstitialEvents by remember { mutableIntStateOf(0) }

        suspend fun maybeShowInterstitialAfterQualifiedEvent() {
            if (adsRemoved || !BuildConfig.MONETIZED_BUILD) return
            qualifyingInterstitialEvents++
            if (qualifyingInterstitialEvents % INTERSTITIAL_FREQUENCY != 0) return

            // Show only at a natural task-completion pause. If an ad is not ready,
            // continue immediately and preload the next one.
            val finished = CompletableDeferred<Unit>()
            DevMonitorInterstitialAd.showIfReady(this@MainActivity) {
                if (!finished.isCompleted) finished.complete(Unit)
            }
            finished.await()
        }

        beginRun = fun(list: List<String>, retryOnly: Boolean) {
            if (list.isEmpty()) return
            val oneOff = oneOffRunRequested
            oneOffRunRequested = false
            if (oneOff) oneOffCodes = list.distinct()
            runJob?.cancel()
            running = true
            message = if (retryOnly) {
                "Retrying unresolved queries after first pass"
            } else {
                "Starting monitoring pass — existing results will be refreshed"
            }
            feedback.monitoringStarted()

            runJob = scope.launch {
                list.forEachIndexed { index, code ->
                    if (!isActive) return@launch

                    val existing = records[code]
                    // A device may be checked repeatedly during the same day.
                    // Do not skip successful results: each new SMS response refreshes
                    // today's observation instead of creating a duplicate device.

                    currentIndex = if (oneOff) index else codes.indexOf(code).takeIf { it >= 0 } ?: index
                    waitingCode = code
                    val attempt = if (retryOnly) {
                        (existing?.attempt ?: 1) + 1
                    } else {
                        existing?.attempt ?: 1
                    }
                    val baseline = SmsInbox.latestId(this@MainActivity)
                    val operationId = UUID.randomUUID().toString()
                    val queryPreparedAt = System.currentTimeMillis()
                    checkerStore.recordSmsQuery(operationId, code, destination, queryPreparedAt, attempt)

                    updateRecord(
                        code,
                        QueryRecord(
                            code = code,
                            type = QueryType.from(code),
                            attempt = attempt,
                            repetitionsSent = repeatCount,
                            status = AttemptStatus.SENDING,
                            firstAttemptStatus = existing?.status
                        )
                    )

                    val start = System.currentTimeMillis()
                    val sendOutcome = sendRepeated(code, repeatCount)
                    val sent = sendOutcome.first
                    val deliveryWarning = sendOutcome.second

                    if (sent == 0) {
                        updateRecord(
                            code,
                            QueryRecord(
                                code, QueryType.from(code), attempt, 0,
                                status = AttemptStatus.SEND_FAILED,
                                error = "SMS could not be sent. Check permission, SIM service and selected SIM.",
                                firstAttemptStatus = existing?.status
                            )
                        )
                        message = "Send failed: $code"
                        return@forEachIndexed
                    }

                    updateRecord(
                        code,
                        QueryRecord(
                            code, QueryType.from(code), attempt, sent,
                            status = AttemptStatus.WAITING,
                            firstAttemptStatus = existing?.status
                        )
                    )

                    message = if (deliveryWarning) {
                        "SMS sending/delivery is reporting a problem. Retried failed sends and continued. Sent ${sent}× via SMS to $destination using ${simLabel(activeSims, selectedSubId)}. Waiting up to 2 minutes: $code"
                    } else {
                        "Sent ${sent}× via SMS to $destination using ${simLabel(activeSims, selectedSubId)}. Waiting up to 2 minutes: $code"
                    }
                    var matched: SimRegResult? = null
                    var lastId = baseline
                    val seen = mutableSetOf<String>()

                    while (isActive &&
                        System.currentTimeMillis() - start < DEFAULT_TIMEOUT_MS &&
                        matched == null
                    ) {
                        val elapsed = System.currentTimeMillis() - start
                        secondsLeft = ((DEFAULT_TIMEOUT_MS - elapsed + 999) / 1000).coerceAtLeast(0)

                        for (sms in SmsInbox.after(this@MainActivity, lastId).sortedBy { it.receivedAt }) {
                            lastId = maxOf(lastId, sms.id)
                            if (sms.receivedAt < start) continue
                            if (sms.sender.filter { it.isDigit() }.takeLast(4) != destination.takeLast(4)) continue

                            val signature = "${sms.receivedAt}|${sms.sender}|${sms.body.trim()}"
                            if (!seen.add(signature)) continue

                            val parsed = SmsParser.parse(code, sms.body, formatTime(sms.receivedAt))
                            if (parsed.status == AttemptStatus.SUCCESS ||
                                parsed.status == AttemptStatus.NOT_FOUND
                            ) {
                                matched = parsed
                                break
                            }
                        }

                        if (matched == null) delay(750)
                    }

                    if (matched != null) {
                        val previous = records[code]
                        updateRecord(
                            code,
                            QueryRecord(
                                code, QueryType.from(code), attempt, sent, 1,
                                matched.status, matched,
                                error = if (deliveryWarning) "SMS delivery reporting indicated a sending/delivery problem; immediate retries were attempted." else null,
                                firstAttemptStatus = previous?.firstAttemptStatus ?: existing?.status
                            )
                        )
                        if (selectedTab != 6) store.recordObservation(matched)
                        message = "Completed: $code"
                        maybeShowInterstitialAfterQualifiedEvent()
                    } else {
                        val previous = records[code]
                        updateRecord(
                            code,
                            QueryRecord(
                                code, QueryType.from(code), attempt, sent, 0,
                                AttemptStatus.TIMEOUT,
                                error = if (deliveryWarning) {
                                    "No valid response within 2 minutes. SMS delivery reporting indicated a sending/delivery problem; immediate retries were attempted."
                                } else {
                                    "No valid response within 2 minutes"
                                },
                                firstAttemptStatus = previous?.firstAttemptStatus ?: existing?.status
                            )
                        )
                        message = "Timeout: $code — retry after the batch"
                    }
                    secondsLeft = 0
                }

                checkerStore.addHistory(records)
                running = false
                if (userScopedNoticePending) userScopedNoticeBusy = false
                waitingCode = null
                repeatCount = 1
                persist()
                message = if (retryOnly) "Retry pass complete" else "First pass complete. Review the Dashboard for flags."
                val runHadProblems = list.any { code ->
                    records[code]?.status == AttemptStatus.TIMEOUT || records[code]?.status == AttemptStatus.SEND_FAILED
                }
                if (runHadProblems) {
                    feedback.warning()
                    addNotification("Monitoring needs attention", "The ${if (retryOnly) "retry" else "monitoring"} pass completed with one or more timeout or send-failure results.", "warning")
                } else {
                    if (retryOnly) feedback.completed() else feedback.success()
                    addNotification(if (retryOnly) "Retry pass completed" else "Monitoring completed", if (retryOnly) "The retry pass completed successfully. Review the refreshed results when ready." else "The monitoring pass completed successfully. Dashboard values were refreshed as the natural next step.", "success")
                }
                if (!retryOnly) refreshDashboard()
            }
        }

        // If Start/Refresh was tapped before Android's SMS permission dialog,
        // resume that exact operation automatically after permission is granted.
        // Without this, the permission callback only caused recomposition and the
        // user had to press Start a second time.
        LaunchedEffect(permissionTick, permissionOk, pendingSmsRunCodes) {
            val pending = pendingSmsRunCodes
            if (pending != null && permissionOk && !running) {
                val retryOnly = pendingSmsRunRetryOnly
                pendingSmsRunCodes = null
                pendingSmsRunRetryOnly = false
                beginRun(pending, retryOnly)
            }
        }

        fun stopRun() {
            runJob?.cancel()
            runJob = null
            running = false
            waitingCode = null
            secondsLeft = 0
            persist()
            repeatCount = 1
            message = "Stopped — completed results were kept."
        }

        val retryCodes = codes.filter {
            records[it]?.status == AttemptStatus.TIMEOUT ||
                records[it]?.status == AttemptStatus.SEND_FAILED
        }
        val successful = records.values.count { it.status == AttemptStatus.SUCCESS }
        val notFound = records.values.count { it.status == AttemptStatus.NOT_FOUND }
        val timeouts = records.values.count { it.status == AttemptStatus.TIMEOUT }
        val sendFailed = records.values.count { it.status == AttemptStatus.SEND_FAILED }

        val googleSignInLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val intent = result.data
            if (intent == null) {
                message = if (result.resultCode == Activity.RESULT_CANCELED) {
                    "Google sign-in was cancelled."
                } else {
                    "Google sign-in returned no result (code ${result.resultCode})."
                }
                return@rememberLauncherForActivityResult
            }

            try {
                val account = GoogleSignIn.getSignedInAccountFromIntent(intent)
                    .getResult(ApiException::class.java)
                val idToken = account.idToken
                if (idToken.isNullOrBlank()) {
                    message = "Google account was selected, but no ID token was returned. Check that Google Sign-In is enabled in Firebase and that the Android app SHA-1/SHA-256 fingerprints are configured."
                    return@rememberLauncherForActivityResult
                }

                FirebaseAuth.getInstance()
                    .signInWithCredential(GoogleAuthProvider.getCredential(idToken, null))
                    .addOnSuccessListener { authResult ->
                        val firebaseUser = authResult.user
                        googleEmail = account.email ?: firebaseUser?.email
                        googleName = account.displayName ?: firebaseUser?.displayName
                        googlePhotoUrl = account.photoUrl?.toString() ?: firebaseUser?.photoUrl?.toString()
                        store.setSetting(SETTING_GOOGLE_EMAIL, googleEmail ?: "")
                        store.setSetting(SETTING_GOOGLE_NAME, googleName ?: "")
                        store.setSetting(SETTING_GOOGLE_PHOTO, googlePhotoUrl ?: "")
                        val email = googleEmail.orEmpty()
                        val existing = database.fieldPulseAccount()
                        val now = System.currentTimeMillis()
                        val fp = existing?.copy(
                            googleEmail = email,
                            firebaseUid = firebaseUser?.uid ?: existing.firebaseUid,
                            updatedAt = now
                        ) ?: DevMonitorAccount(
                            DevMonitorAuth.newAccountId(), email, "", null,
                            firebaseUser?.uid, null,
                            AccountClassification.UNKNOWN, AuthState.PHONE_REQUIRED, now, now
                        )
                        database.saveDevMonitorAccount(fp)
                        authAccount = fp
                        message = "Google account connected successfully as ${googleName ?: email}."
                    }
                    .addOnFailureListener { e ->
                        message = "Google account selected, but Firebase authentication failed: ${e.message ?: e.javaClass.simpleName}"
                    }
            } catch (e: ApiException) {
                val (sha1, sha256) = signingCertificateFingerprints(this@MainActivity)
                message = "Google sign-in failed (code ${e.statusCode}): ${e.status?.statusMessage ?: "Google/Firebase configuration error"}. SHA-1: $sha1"
                DevMonitorLogger.db("Google sign-in failed status=${e.statusCode} sha1=$sha1 sha256=$sha256 package=${packageName}")
            } catch (e: Exception) {
                val (sha1, sha256) = signingCertificateFingerprints(this@MainActivity)
                message = "Google sign-in failed: ${e.message ?: e.javaClass.simpleName}. SHA-1: $sha1"
                DevMonitorLogger.db("Google sign-in exception=${e.javaClass.simpleName} message=${e.message} sha1=$sha1 sha256=$sha256 package=${packageName}")
            }
        }

        DisposableEffect(Unit) {
            val firebaseAuth = FirebaseAuth.getInstance()
            val listener = FirebaseAuth.AuthStateListener { auth ->
                val firebaseUser = auth.currentUser
                if (firebaseUser != null) {
                    googleEmail = firebaseUser.email ?: googleEmail
                    googleName = firebaseUser.displayName ?: googleName
                    googlePhotoUrl = firebaseUser.photoUrl?.toString() ?: googlePhotoUrl
                }
            }
            firebaseAuth.addAuthStateListener(listener)
            onDispose { firebaseAuth.removeAuthStateListener(listener) }
        }
        val googleOptions = remember {
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(com.aziitech.simregmonitor.R.string.default_web_client_id))
                .requestEmail()
                .requestScopes(Scope(Scopes.DRIVE_APPFOLDER))
                .build()
        }

        val importLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) addCodes(readCodesFromExcel(uri))
        }
        val simRegReportLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                importedSimRegReport = null
                showSimRegReport = true
                importSimRegWorkbook(uri, displayNameForUri(uri),
                onSuccess = { parsed ->
                    importedSimRegReport = parsed
                    showSimRegReport = true
                    message = "SIMREG report imported and saved: ${parsed.rows.size} device records. The verified HQ snapshot was stored for ${parsed.coverageStart?.let { YearMonth.from(it) } ?: "its report month"}; refresh any view when you want it updated."
                    DevMonitorAnalytics.log(this@MainActivity, "report_import_success", mapOf("source" to "simreg_report"))
                    addNotification("SIMReg report imported", "SIMReg report saved with ${parsed.rows.size} device records.", "success")
                    if (pendingCheckMyDevicesAfterReport) {
                        pendingCheckMyDevicesAfterReport = false
                        pendingCheckMyDevicesAfterProfile = true
                        profileEditorNew = true
                        profileEditorId = null
                        showSimRegReport = false
                        importingSimReg = false
                        simRegImportMessage = ""
                        selectedTab = 4
                        showMyDevicesProfile = true
                    }
                },
                onFailure = { error -> message = "Could not import SIMREG report: ${error.message ?: "unsupported workbook"}" }
                )
            }
        }
        val companySkeletonLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null && !companySkeletonLoading) {
                companySkeletonLoading = true
                companySkeletonLoadingTitle = "Opening company data…"
                companySkeletonLoadingProgress = 0.10f
                companySkeletonLoadingMessage = "Reading the selected workbook…"
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            withContext(Dispatchers.Main.immediate) {
                                companySkeletonLoadingTitle = "Reading company data…"
                                companySkeletonLoadingProgress = 0.40f
                                companySkeletonLoadingMessage = "Extracting identifiers and organisational relationships…"
                            }
                            val parsed = contentResolver.openInputStream(uri)?.use { input ->
                                SimRegReportParser.parse(input, displayNameForUri(uri))
                            } ?: error("Unable to open the selected workbook")
                            withContext(Dispatchers.Main.immediate) {
                                companySkeletonLoadingTitle = "Building company directory…"
                                companySkeletonLoadingProgress = 0.82f
                                companySkeletonLoadingMessage = "Saving identity data without activation values…"
                            }
                            companySkeleton.replaceFromReport(parsed)
                        }
                    }
                    result.onSuccess { count ->
                        companySkeletonLoadingTitle = "Company directory ready"
                        companySkeletonLoadingProgress = 1f
                        companySkeletonLoadingMessage = "$count company records are available for profile building."
                        profileSkeletonResults = emptyList()
                        profileSkeletonQuery = ""
                        message = "Company directory updated from the selected workbook. No activation or payment data was imported."
                        scope.launch {
                            delay(500)
                            companySkeletonLoading = false
                        }
                    }.onFailure { error ->
                        companySkeletonLoading = false
                        message = "Could not update company directory: ${error.message ?: "unsupported workbook"}"
                    }
                }
            }
        }
        val exportLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        ) { uri ->
            if (uri != null) {
                val exported = writeResultsToExcel(uri, codes, records, store.dashboard(), exportMode)
                if (exported) {
                    lastExportUri = uri
                    exportCount += 1
                    store.setSetting(SETTING_EXPORT_COUNT, exportCount.toString())
                    if (pendingRewardCredit && rewardCredits > 0) {
                        rewardCredits -= 1
                        store.setSetting(SETTING_EXPORT_CREDITS, rewardCredits.toString())
                    }
                    pendingRewardCredit = false
                    message = "Excel report exported"
                    addNotification("Export completed", "Your Excel report was exported successfully.", "success")
                    feedback.success()
                } else {
                    pendingRewardCredit = false
                    message = "Excel export failed"
                    addNotification("Export failed", "The Excel report could not be exported. You can try again when ready.", "warning")
                    feedback.warning()
                }
            }
        }

        val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                val label = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: uri.toString()
                attachedFiles = (attachedFiles + label).distinct().takeLast(20)
                lastAttachedUri = uri
                store.setSetting(SETTING_ATTACHED_FILES, JSONArray(attachedFiles).toString())
                message = "File attached: $label"
            }
        }

        if (showSnapshotMenu) {
            AlertDialog(
                onDismissRequest = { showSnapshotMenu = false },
                title = { Text("Share Daily Snapshot") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Create a compact, user-triggered summary from the current dashboard data.", style = MaterialTheme.typography.bodySmall)
                        DevMonitorOutlinedButton(onClick = {
                            showSnapshotMenu = false
                            val ok = ReportExportPack.shareDailySnapshot(this@MainActivity, store.dashboard(), SnapshotFormat.IMAGE)
                            message = if (ok) "Daily snapshot ready to share" else "Could not create the daily snapshot"
                        }, Modifier.fillMaxWidth()) { Text("Share as Image") }
                        DevMonitorOutlinedButton(onClick = {
                            showSnapshotMenu = false
                            val ok = ReportExportPack.shareDailySnapshot(this@MainActivity, store.dashboard(), SnapshotFormat.PDF)
                            message = if (ok) "PDF snapshot ready to share" else "Could not create the PDF snapshot"
                        }, Modifier.fillMaxWidth()) { Text("Share as PDF") }
                    }
                },
                confirmButton = { TextButton(onClick = { showSnapshotMenu = false }) { Text("Cancel") } }
            )
        }

        if (showExportMenu) {
            AlertDialog(
                onDismissRequest = { showExportMenu = false },
                title = { Text("Intelligent Export") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Choose only the report you need. Export remains user-initiated.", style = MaterialTheme.typography.bodySmall)
                        val options = listOf(
                            ReportExportMode.QUICK to Pair("Quick", "Compact working export"),
                            ReportExportMode.DETAILED to Pair("Detailed", "Full device-level report"),
                            ReportExportMode.PAYMENT to Pair("Payment", "Rows carrying payment-estimate data"),
                            ReportExportMode.EXCEPTIONS to Pair("Exceptions", "Devices currently carrying flags"),
                            ReportExportMode.HQ to Pair("HQ", "GLO device ownership working set"),
                            ReportExportMode.FULL to Pair("Full", "Complete workbook with all report sheets")
                        )
                        options.forEach { (mode, title) ->
                            val selected = exportMode == mode
                            Surface(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    exportMode = mode
                                    showExportMenu = false
                                    val launchExport = {
                                        pendingRewardCredit = rewardCredits > 0
                                        exportLauncher.launch("DevMonitor_${title.first}_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.xlsx")
                                    }
                                    if (!BuildConfig.MONETIZED_BUILD || adsRemoved || exportCount < FREE_EXPORT_LIMIT) {
                                        pendingRewardCredit = false
                                        exportLauncher.launch("DevMonitor_${title.first}_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.xlsx")
                                    } else if (rewardCredits > 0) launchExport() else {
                                        pendingRewardCredit = true
                                        DevMonitorRewardedAd.show(this@MainActivity, onRewarded = {
                                            rewardCredits += EXPORTS_PER_REWARDED
                                            store.setSetting(SETTING_EXPORT_CREDITS, rewardCredits.toString())
                                            message = "Reward received. Your next 3 exports are unlocked."
                                            exportLauncher.launch("DevMonitor_${title.first}_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.xlsx")
                                        }, onFinished = { if (rewardCredits == 0) message = "Rewarded ad was not available. Please try again." })
                                    }
                                },
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(title.first, fontWeight = FontWeight.ExtraBold)
                                        Text(when(mode) {
                                            ReportExportMode.QUICK -> "Compact working export"
                                            ReportExportMode.DETAILED -> "Full device-level report"
                                            ReportExportMode.PAYMENT -> "Rows carrying payment-estimate data"
                                            ReportExportMode.EXCEPTIONS -> "Devices currently carrying flags"
                                            ReportExportMode.HQ -> "GLO device ownership working set"
                                            ReportExportMode.FULL -> "Complete workbook with all report sheets"
                                            else -> title.second
                                        }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (selected) Text("Selected", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showExportMenu = false }) { Text("Cancel") } }
            )
        }

        if (showLogViewer) {
            LaunchedEffect(Unit) {
                while (showLogViewer) {
                    delay(500L)
                    logVersion++
                }
            }
            val visibleLogs = remember(logVersion) { DevMonitorLogger.snapshot() }
            AlertDialog(
                onDismissRequest = { showLogViewer = false },
                title = { Text("DevMonitor Log") },
                text = {
                    Column(Modifier.fillMaxWidth()) {
                        Text(
                            "Recent import, database, screen and error events. Up to 400 entries are kept for this session.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        if (visibleLogs.isEmpty()) {
                            Text("No log entries yet.")
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp),
                                reverseLayout = true,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(visibleLogs.asReversed()) { line ->
                                    Text(
                                        line,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        DevMonitorLogger.clear()
                        logVersion++
                    }) { Text("Clear") }
                },
                dismissButton = {
                    TextButton(onClick = { showLogViewer = false }) { Text("Close") }
                }
            )
        }

        if (showAbout) AboutBusayoDialog(
            adsRemoved = adsRemoved,
            onPremium = { showAbout = false; showBilling = true },
            onDismiss = { showAbout = false }
        )

        if (showSmsDisclosure) {
            AlertDialog(
                onDismissRequest = { showSmsDisclosure = false; pendingSmsRunCodes = null; pendingSmsRunRetryOnly = false; oneOffRunRequested = false },
                title = { Text("SMS access for device automation") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "DevMonitor uses Android's SMS service to carry out the batch device-monitoring task you start. " +
                                "It sends the queries you have selected, listens for the corresponding service responses, " +
                                "and optionally checks carrier SMS sent/delivery reports when your phone and network provide them."
                        )
                        Text(
                            "SMS content is used only for this monitoring workflow. It is not used for advertising, profiling, or marketing, " +
                                "and the app does not use RCS/chat APIs for these queries.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "For recovery after DevMonitor is closed, the app can also read relevant SMS already stored in your phone's inbox. This is optional and is used only to reconcile today's 3030 monitoring responses. It is not used for advertising, profiling, or marketing.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "You can decline access. Sending requires SMS send/receive access; inbox recovery requires the additional SMS read permission.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showSmsDisclosure = false
                        val needed = listOf(
                            Manifest.permission.SEND_SMS,
                            Manifest.permission.RECEIVE_SMS,
                            Manifest.permission.READ_SMS
                        ).filterNot(::hasPermission)
                        if (needed.isNotEmpty()) smsPermissionLauncher.launch(needed.toTypedArray())
                    }) { Text("Continue") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showSmsDisclosure = false
                        pendingSmsRunCodes = null
                        pendingSmsRunRetryOnly = false
                        oneOffRunRequested = false
                    }) { Text("Not now") }
                }
            )
        }

        if (showRecoverySummary) {
            AlertDialog(
                onDismissRequest = { showRecoverySummary = false },
                title = { Text("SMS recovery") },
                text = { Text(recoveryMessage) },
                confirmButton = { TextButton(onClick = { showRecoverySummary = false }) { Text("OK") } }
            )
        }

        if (showFiles) {
            AlertDialog(
                onDismissRequest = { showFiles = false },
                title = { Text("Files for analysis") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Attach spreadsheets, reports or other reference files you want to keep associated with this workspace.")
                        DevMonitorButton(onClick = { fileLauncher.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Attach file") }
                        if (lastAttachedUri != null) {
                            DevMonitorOutlinedButton(onClick = {
                                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                    type = contentResolver.getType(lastAttachedUri!!) ?: "application/octet-stream"
                                    putExtra(Intent.EXTRA_STREAM, lastAttachedUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }, "Share file"))
                            }, Modifier.fillMaxWidth()) { Text("Share last attached file") }
                        }
                        if (lastExportUri != null) {
                            DevMonitorOutlinedButton(onClick = {
                                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                    putExtra(Intent.EXTRA_STREAM, lastExportUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }, "Share Excel report"))
                            }, Modifier.fillMaxWidth()) { Text("Share last Excel report") }
                        }
                        Text("Linked files", fontWeight = FontWeight.Bold)
                        if (attachedFiles.isEmpty()) Text("No files attached yet.")
                        else attachedFiles.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        Text("Use Android's Share sheet to send a report or attached file to WPS Office, email, cloud storage, or an analysis service such as ChatGPT when available on the phone.", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { showFiles = false }) { Text("Done") } }
            )
        }

        if (showSaveDialog) {
            AlertDialog(
                onDismissRequest = { showSaveDialog = false },
                title = { Text("Save current list") },
                text = {
                    TextField(
                        value = saveName,
                        onValueChange = { saveName = it },
                        label = { Text("List name") },
                        placeholder = { Text("e.g. Ayetoro 52 Devices") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (saveName.isNotBlank()) {
                            checkerStore.saveList(saveName, codes)
                            saveName = ""
                            showSaveDialog = false
                            message = "List saved"
                        }
                    }) { Text("Save") }
                },
                dismissButton = {
                    TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
                }
            )
        }

        if (showSavedLists) {
            val lists = checkerStore.loadLists()
            AlertDialog(
                onDismissRequest = { showSavedLists = false },
                title = { Text("Saved lists") },
                text = {
                    if (lists.isEmpty()) {
                        Text("No saved lists yet.")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 430.dp)) {
                            items(lists, key = { it.name }) { list ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(list.name, fontWeight = FontWeight.Bold)
                                        Text("${list.codes.size} codes")
                                    }
                                    TextButton(onClick = {
                                        if (!running) {
                                            codes = list.codes
                                            records = emptyMap()
                                            persist()
                                            showSavedLists = false
                                        }
                                    }) { Text("Load") }
                                    TextButton(onClick = {
                                        savedListBeingEdited = list
                                        savedListAddText = ""
                                        savedListRemoveSelection.clear()
                                    }) { Text("Manage") }
                                    TextButton(onClick = {
                                        store.deleteList(list.name)
                                        showSavedLists = false
                                        showSavedLists = true
                                    }) { Text("Delete") }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSavedLists = false }) { Text("Close") }
                }
            )
        }

        savedListBeingEdited?.let { selectedList ->
            val currentList = checkerStore.loadLists().firstOrNull { it.name == selectedList.name } ?: selectedList
            AlertDialog(
                onDismissRequest = { savedListBeingEdited = null },
                title = { Text("Manage: ${currentList.name}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Add codes to this saved list or select codes below to remove. Changes affect only this saved list; device history is not deleted.", style = MaterialTheme.typography.bodySmall)
                        TextField(
                            value = savedListAddText,
                            onValueChange = { savedListAddText = it },
                            label = { Text("Add code(s)") },
                            placeholder = { Text("One per line, comma, tab or semicolon separated") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                        DevMonitorButton(onClick = {
                            val additions = normalizedList(savedListAddText)
                            if (additions.isEmpty()) {
                                message = "Enter at least one valid code to add."
                            } else {
                                val before = currentList.codes.toSet()
                                checkerStore.updateSavedListMembership(currentList.name, addCodes = additions)
                                val added = additions.count { it !in before }
                                savedListAddText = ""
                                savedListBeingEdited = checkerStore.loadLists().firstOrNull { it.name == currentList.name }
                                message = if (added == 0) "No new codes added — those codes are already in the saved list." else "Added $added code${if (added == 1) "" else "s"} to the saved list."
                            }
                        }, Modifier.fillMaxWidth()) { Text("Add to saved list") }
                        Text("Codes in this list (${currentList.codes.size})", fontWeight = FontWeight.Bold)
                        if (currentList.codes.isEmpty()) Text("No codes in this list yet.")
                        else LazyColumn(Modifier.heightIn(max = 300.dp)) {
                            items(currentList.codes, key = { it }) { code ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = code in savedListRemoveSelection,
                                        onCheckedChange = { checked ->
                                            if (checked) savedListRemoveSelection.add(code) else savedListRemoveSelection.remove(code)
                                        }
                                    )
                                    Text(code, Modifier.weight(1f))
                                }
                            }
                        }
                        if (savedListRemoveSelection.isNotEmpty()) {
                            DevMonitorOutlinedButton(onClick = {
                                val removed = savedListRemoveSelection.size
                                checkerStore.updateSavedListMembership(currentList.name, removeCodes = savedListRemoveSelection.toList())
                                savedListRemoveSelection.clear()
                                savedListBeingEdited = checkerStore.loadLists().firstOrNull { it.name == currentList.name }
                                message = "Removed $removed code${if (removed == 1) "" else "s"} from the saved list."
                            }, Modifier.fillMaxWidth()) { Text("Remove selected (${'$'}{savedListRemoveSelection.size})") }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { savedListBeingEdited = null }) { Text("Done") } }
            )
        }

        if (showArchived) {
            val archived = checkerStore.loadArchived()
            AlertDialog(
                onDismissRequest = { showArchived = false },
                title = { Text("Archived codes") },
                text = {
                    if (archived.isEmpty()) {
                        Text("No archived codes.")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 430.dp)) {
                            items(archived) { code ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(code, Modifier.weight(1f))
                                    TextButton(onClick = {
                                        checkerStore.restoreArchived(code)
                                        codes = (codes + code).distinct()
                                        persist()
                                        showArchived = false
                                    }) { Text("Restore") }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showArchived = false }) { Text("Close") }
                }
            )
        }

        if (showHistory) {
            val history = checkerStore.loadHistory(100)
            AlertDialog(
                onDismissRequest = { showHistory = false },
                title = { Text("History") },
                text = {
                    if (history.isEmpty()) {
                        Text("No completed results yet.")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(history) { item ->
                                Text(formatDate(item.completedAt), fontWeight = FontWeight.Bold)
                                Text("${item.record.code} • ${item.record.status}")
                                Text("Today ${item.record.result?.today ?: "-"} • MTD ${item.record.result?.mtd ?: "-"}")
                                HorizontalDivider()
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showHistory = false }) { Text("Close") }
                }
            )
        }

        if (showSmsInbox) {
            val inbox = SmsInbox.all(this@MainActivity).asReversed().take(50)
            AlertDialog(
                onDismissRequest = { showSmsInbox = false },
                title = { Text("Recent SMS") },
                text = {
                    if (inbox.isEmpty()) {
                        Text("No captured SMS.")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 440.dp)) {
                            items(inbox) { sms ->
                                Column {
                                    Text("${formatDate(sms.receivedAt)} • ${sms.sender}", fontWeight = FontWeight.Bold)
                                    Text(sms.body)
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSmsInbox = false }) { Text("Close") }
                }
            )
        }

        if (showTasks) {
            TasksDialog(
                store = database,
                deviceCodes = codes,
                agents = database.agents(),
                onDismiss = { showTasks = false }
            )
        }

        if (showNotes) {
            NotesDialog(
                store = database,
                deviceCodes = codes,
                agents = database.agents(),
                onDismiss = { showNotes = false }
            )
        }

        if (showTimeline) {
            DeviceActivityTimelineDialog(
                store = database,
                deviceCodes = codes,
                onDismiss = { showTimeline = false }
            )
        }

        if (showAgents) {
            AgentManagementDialog(
                store = database,
                codes = codes,
                onDismiss = { showAgents = false },
                onPickContact = { agentId -> startAgentContactImport(agentId) },
                onPickPhoto = { agentId -> pendingAgentPhotoId = agentId; agentPhotoLauncher.launch("image/*") },
                draftPhotoPath = pendingAgentDraftPhotoPath,
                onDraftPhotoPathChanged = { newPath ->
                    if (newPath == null) { pendingAgentDraftPhotoPath?.let { java.io.File(it).delete() }; pendingAgentDraftPhotoPath = null }
                    else pendingAgentDraftPhotoPath = newPath
                },
                refreshToken = agentRefreshToken,
                onGetLocation = { currentLocation() },
                onOpenMaps = { lat, lon -> openMaps(lat, lon) },
                onEditAgentRequestHandled = { pendingAgentEditorId = null },
                editAgentRequestId = pendingAgentEditorId,
                onAgentsChanged = { agentRefreshToken++ },
                onBatchShare = { source, selectedAgents ->
                    val asOf = PaymentRules.currentAwareDate()
                    val payloads = mutableListOf<PaymentCardSharePayload>()
                    val skipped = mutableListOf<String>()
                    selectedAgents.forEach { agent ->
                        val linkedCodes = database.devicesForAgent(agent.id)
                        if (linkedCodes.isEmpty()) skipped += "${agent.name} (no linked devices)"
                        linkedCodes.forEach { deviceCode ->
                            val progression = if (source == "SMS Checker") {
                                PaymentEngine.DeviceMonitor.calculate(deviceCode, asOf, database, null)
                            } else {
                                companyActivations?.let { PaymentEngine.LoadedReports.calculate(deviceCode, asOf, it) }
                            }
                            val activations = progression?.activations
                            if (activations == null) {
                                skipped += "$deviceCode (${agent.name}: no $source figures)"
                            } else {
                                val estimate = if (source == "Loaded Report" && companyActivations != null) {
                                    PaymentRules.estimate(activations, companyActivations.cycleSundayActivations(deviceCode))
                                } else PaymentRules.estimate(activations, 0)
                                payloads += PaymentCardSharePayload(
                                    agentName = agent.name,
                                    deviceCode = deviceCode,
                                    source = source,
                                    agentPhotoPath = agent.photoPath,
                                    agentPhone = database.phonesForAgent(agent.id).firstOrNull()?.phone.orEmpty(),
                                    period = PaymentRules.paymentCycleLabel(asOf),
                                    asOf = progression?.availableThrough?.toString() ?: asOf.toString(),
                                    estimate = estimate,
                                    activationDetail = "Source figures only; no cross-source fill."
                                )
                            }
                        }
                    }
                    if (payloads.isNotEmpty()) ReportExportPack.sharePaymentCards(context, payloads)
                    val message = buildString {
                        append("Prepared ${payloads.size} card(s) from $source.")
                        if (skipped.isNotEmpty()) append(" Skipped ${skipped.size}: ${skipped.take(5).joinToString()}")
                        if (payloads.isEmpty()) append(" No shareable figures were found for the selected source.")
                    }
                    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
                }
            )
        }

        pendingAgentContactImport?.let { preview ->
            val currentAgent = preview.agentId?.let { targetId -> database.agents().firstOrNull { it.id == targetId } }
            val existingPhones = currentAgent?.let { database.phonesForAgent(it.id).map { p -> p.phone.trim() }.toSet() } ?: emptySet()
            val existingEmails = currentAgent?.let { database.emailsForAgent(it.id).map { e -> e.email.trim().lowercase() }.toSet() } ?: emptySet()
            val duplicatePhones = preview.phones.count { it.first.trim() in existingPhones }
            val duplicateEmails = preview.emails.count { it.first.trim().lowercase() in existingEmails }
            var selectedPhones by remember(preview.contactUri) { mutableStateOf(preview.phones.map { it.first }.toSet()) }
            var selectedEmails by remember(preview.contactUri) { mutableStateOf(preview.emails.map { it.first }.toSet()) }
            AlertDialog(
                onDismissRequest = { preview.photoPreviewPath?.let { java.io.File(it).delete() }; pendingAgentContactImport = null },
                title = { Text("Review contact import") },
                text = {
                    Column(Modifier.fillMaxWidth().heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Nothing is changed until you confirm. Review the contact name and address; duplicate phone/email values will be skipped.")
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            val previewPhoto = currentAgent?.photoPath?.takeIf { it.isNotBlank() }?.let { java.io.File(it) }
                                ?.takeIf { it.exists() && it.length() > 0L }
                                ?: preview.photoPreviewPath?.let { java.io.File(it) }?.takeIf { it.exists() && it.length() > 0L }
                            if (previewPhoto != null) {
                                AsyncImage(model = previewPhoto, contentDescription = "Imported contact photo preview", modifier = Modifier.size(88.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                            } else {
                                Box(Modifier.size(88.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                                    Text("👤", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Column(Modifier.weight(1f)) {
                                Text("Contact photo", fontWeight = FontWeight.Bold)
                                Text(when {
                                    !currentAgent?.photoPath.isNullOrBlank() -> "Existing agent photo will be kept"
                                    previewPhoto != null -> "Photo ready to import"
                                    else -> "No contact photo available"
                                }, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        TextField(pendingAgentContactName, { pendingAgentContactName = it }, Modifier.fillMaxWidth(), label = { Text("Agent name") }, singleLine = true)
                        TextField(pendingAgentContactAddress, { pendingAgentContactAddress = it }, Modifier.fillMaxWidth(), label = { Text("Address") }, minLines = 2)
                        Text("Choose phone numbers to save", fontWeight = FontWeight.Bold)
                        Text("Uncheck landlines, old numbers, time-related entries, or anything you do not want attached to this agent.", style = MaterialTheme.typography.bodySmall)
                        preview.phones.forEach { (value, label) ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = value in selectedPhones, onCheckedChange = { checked -> selectedPhones = if (checked) selectedPhones + value else selectedPhones - value })
                                Column(Modifier.weight(1f)) {
                                    Text(value)
                                    if (label.isNotBlank()) Text(label, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        Text("Choose email addresses to save", fontWeight = FontWeight.Bold)
                        preview.emails.forEach { (value, label) ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = value in selectedEmails, onCheckedChange = { checked -> selectedEmails = if (checked) selectedEmails + value else selectedEmails - value })
                                Column(Modifier.weight(1f)) {
                                    Text(value)
                                    if (label.isNotBlank()) Text(label, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        if (duplicatePhones + duplicateEmails > 0) Text("Already saved: $duplicatePhones phone(s), $duplicateEmails email(s). These duplicates will be skipped.", color = MaterialTheme.colorScheme.primary)
                        Text(if (currentAgent?.photoPath.isNullOrBlank()) "Contact photo will be imported if available." else "Existing agent photo will be kept; contact import will not replace it.")
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val current = preview.agentId?.let { id -> database.agents().firstOrNull { it.id == id } }
                        if ((preview.agentId == null || current != null) && pendingAgentContactName.isNotBlank()) {
                            val now = System.currentTimeMillis()
                            val savedId = if (current == null) {
                                database.saveAgent(Agent(0L, pendingAgentContactName.trim(), pendingAgentContactAddress.trim(), null, null, now, now, null))
                            } else {
                                database.saveAgent(current.copy(name = pendingAgentContactName.trim(), address = pendingAgentContactAddress.trim(), updatedAt = now))
                            }
                            preview.phones.filter { it.first in selectedPhones }.forEach { (value, label) -> database.addAgentPhone(savedId, value, label) }
                            preview.emails.filter { it.first in selectedEmails }.forEach { (value, label) -> database.addAgentEmail(savedId, value, label) }
                            var importedPhotoSaved = false
                            if (current?.photoPath.isNullOrBlank()) {
                                runCatching {
                                    val photoDir = java.io.File(filesDir, "agent_photos").apply { mkdirs() }
                                    val photoFile = java.io.File(photoDir, "agent_${savedId}_${System.currentTimeMillis()}.jpg")
                                    val previewFile = preview.photoPreviewPath?.let { java.io.File(it) }
                                    if (previewFile != null && previewFile.exists() && previewFile.length() > 0L) {
                                        previewFile.inputStream().use { input -> photoFile.outputStream().use { output -> input.copyTo(output) } }
                                    } else {
                                        val contactUri = Uri.parse(preview.contactUri)
                                        val photoUriString = contentResolver.query(contactUri, arrayOf(ContactsContract.Contacts.PHOTO_URI), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                                        val photoStream = ContactsContract.Contacts.openContactPhotoInputStream(contentResolver, contactUri, true)
                                            ?: photoUriString?.let { photoString -> runCatching { contentResolver.openInputStream(Uri.parse(photoString)) }.getOrNull() }
                                        if (photoStream != null) photoStream.use { input -> photoFile.outputStream().use { output -> input.copyTo(output) } }
                                    }
                                    if (photoFile.exists() && photoFile.length() > 0L) {
                                        database.saveAgent(database.agents().first { it.id == savedId }.copy(photoPath = photoFile.absolutePath, updatedAt = System.currentTimeMillis()))
                                        importedPhotoSaved = true
                                    } else photoFile.delete()
                                }
                            } else importedPhotoSaved = true
                            preview.photoPreviewPath?.let { java.io.File(it).delete() }
                            if (current == null) pendingAgentEditorId = savedId
                            android.widget.Toast.makeText(context, buildString {
                                append(if (current == null) "Agent created from contact details with ${selectedPhones.size} phone number(s) and ${selectedEmails.size} email address(es)." else "Contact details merged; ${selectedPhones.size} phone number(s) and ${selectedEmails.size} email address(es) selected. Existing device links and saved photo were preserved.")
                                if (current == null && !importedPhotoSaved) append(" No contact photo was available to import.")
                            }, android.widget.Toast.LENGTH_LONG).show()
                            agentRefreshToken++
                        }
                        pendingAgentContactImport = null
                    }) { Text(if (preview.agentId == null) "Create agent" else "Confirm merge") }
                },
                dismissButton = { TextButton(onClick = { preview.photoPreviewPath?.let { java.io.File(it).delete() }; pendingAgentContactImport = null }) { Text("Cancel") } }
            )
        }

        if (showDatabase) {
            AlertDialog(
                onDismissRequest = { showDatabase = false },
                title = { Text("Database management") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${store.countCodes()} active • ${store.countArchived()} archived • ${store.countHistory()} history • ${store.smsCount()} SMS")
                        TextField(
                            value = dbSearch,
                            onValueChange = {
                                dbSearch = it
                                dbItems = store.databaseCodes(it)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Search code") },
                            placeholder = { Text("e.g. AAGENCY079 or GLO-GD-") },
                            singleLine = true
                        )
                        LazyColumn(Modifier.heightIn(max = 330.dp)) {
                            items(dbItems, key = { it.code }) { item ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.code, fontWeight = FontWeight.Bold)
                                        Text("${item.type} • ${if (item.archived) "Archived" else "Active"}")
                                    }
                                    if (item.archived) {
                                        TextButton(onClick = {
                                            checkerStore.restoreArchived(item.code)
                                            dbItems = store.databaseCodes(dbSearch)
                                        }) { Text("Restore") }
                                    } else {
                                        TextButton(onClick = {
                                            checkerStore.archive(item.code)
                                            codes = codes.filterNot { it == item.code }
                                            records = records - item.code
                                            persist()
                                            dbItems = store.databaseCodes(dbSearch)
                                        }) { Text("Archive") }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Row {
                        TextButton(onClick = {
                            checkerStore.clearAllData()
                            codes = emptyList()
                            records = emptyMap()
                            dbItems = emptyList()
                            showDatabase = false
                            message = "Database cleared"
                        }) { Text("Clear all") }
                        TextButton(onClick = { showDatabase = false }) { Text("Close") }
                    }
                }
            )
        }


        if (showDashboard) {
            val dashboard = store.dashboard()
            AlertDialog(
                onDismissRequest = {
                    showDashboard = false
                },
                title = { Text("Daily & Monthly Monitor") },
                text = {
                    LazyColumn(
                        Modifier.heightIn(max = 520.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("${dashboard.date} • ${dashboard.deviceCount} devices", fontWeight = FontWeight.Bold)
                            Text("Today sales: ${dashboard.todayTotal}")
                            Text("MTD sales: ${dashboard.mtdTotal}")
                            Text("Active: ${dashboard.activeTotal}")
                            Text("Bar 48: ${dashboard.bar48Total} • Bar 96: ${dashboard.bar96Total}")
                            Text("Company: Today ${dashboard.companyToday} • MTD ${dashboard.companyMtd}")
                            Text("Partner: Today ${dashboard.partnerToday} • MTD ${dashboard.partnerMtd}")
                        }
                        item { Text("Flags (${dashboard.flags.size})", fontWeight = FontWeight.Bold) }
                        items(dashboard.flags) { flag ->
                            Text("${flag.code} • ${flag.severity}", fontWeight = FontWeight.Bold)
                            Text(flag.reason)
                            HorizontalDivider()
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showDashboard = false
                        }) { Text("Close") }
                }
            )
        }

        if (showBroadcastCentre) {
            AlertDialog(
                onDismissRequest = { if (!broadcastBusy) showBroadcastCentre = false },
                title = { Text("Broadcast Centre") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Publish one scrolling announcement for all DevMonitor installations. Connected apps check for it when they open.", style = MaterialTheme.typography.bodySmall)
                        TextField(value = broadcastDraft, onValueChange = { broadcastDraft = it.take(500) }, label = { Text("Announcement message") }, minLines = 3, maxLines = 5)
                        Text("Position")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = broadcastPlacement == "TOP", onClick = { broadcastPlacement = "TOP" }, label = { Text("Top") })
                            FilterChip(selected = broadcastPlacement == "BOTTOM", onClick = { broadcastPlacement = "BOTTOM" }, label = { Text("Bottom") })
                        }
                        Text("Display schedule: intermittently for 48 hours (15 seconds every 5 minutes), then expire automatically.", style = MaterialTheme.typography.bodySmall)
                        Text("Broadcast duration is fixed at 2 days.", style = MaterialTheme.typography.labelMedium)
                        if (broadcastStatus.isNotBlank()) Text(broadcastStatus, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(enabled = !broadcastBusy && broadcastDraft.isNotBlank(), onClick = {
                        scope.launch {
                            broadcastBusy = true
                            broadcastStatus = "Publishing…"
                            runCatching { withContext(Dispatchers.IO) { broadcastReleaseManager.publishBroadcast(broadcastDraft, broadcastPlacement, broadcastExpiryDays) } }
                                .onSuccess {
                                    activeBroadcast = withContext(Dispatchers.IO) { broadcastReleaseManager.activeBroadcast() }
                                    broadcastStatus = "Published. Connected installations will show the ticker when they next check in."
                                }
                                .onFailure { broadcastStatus = "Could not publish: ${it.message ?: "check connection and administrator access"}" }
                            broadcastBusy = false
                        }
                    }) { Text(if (broadcastBusy) "Working…" else "Publish") }
                },
                dismissButton = {
                    Row {
                        TextButton(enabled = !broadcastBusy && activeBroadcast != null, onClick = {
                            scope.launch {
                                broadcastBusy = true
                                runCatching { withContext(Dispatchers.IO) { broadcastReleaseManager.stopBroadcast() } }
                                    .onSuccess { activeBroadcast = null; broadcastDraft = ""; broadcastStatus = "Broadcast stopped." }
                                    .onFailure { broadcastStatus = "Could not stop: ${it.message ?: "check administrator access"}" }
                                broadcastBusy = false
                            }
                        }) { Text("Stop broadcast") }
                        TextButton(enabled = !broadcastBusy, onClick = { showBroadcastCentre = false }) { Text("Close") }
                    }
                }
            )
        }

        if (showWhatsNew) {
            AlertDialog(
                onDismissRequest = { showWhatsNew = false },
                title = { Text("What's New in DevMonitor ${BuildConfig.VERSION_NAME}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                        Text("These highlights were generated from the release documentation.", style = MaterialTheme.typography.bodySmall)
                        whatsNewHighlights.forEach { item ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                                Text("•", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(item, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showWhatsNew = false }) { Text("Got it") } }
            )
        }

        versionUpdateInfo?.let { update ->
            AlertDialog(
                onDismissRequest = { if (update.minimumVersionCode <= BuildConfig.VERSION_CODE.toLong()) versionUpdateInfo = null },
                title = { Text(if (update.minimumVersionCode > BuildConfig.VERSION_CODE.toLong()) "DevMonitor update required" else "DevMonitor update available") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Your current version is ${BuildConfig.VERSION_NAME}.")
                        Text(if (update.minimumVersionCode > BuildConfig.VERSION_CODE.toLong()) "This feature or resource requires DevMonitor ${update.minimumVersionName} or newer." else "DevMonitor ${update.latestVersionName} is available with improvements and fixes.")
                        if (update.latestVersionName.isNotBlank() && update.latestVersionName != update.minimumVersionName) {
                            Text("Latest available version: ${update.latestVersionName}")
                        }
                        if (versionUpdateReason.isNotBlank()) {
                            Text(versionUpdateReason, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        DevMonitorAnalytics.log(this@MainActivity, "update_action_tapped", mapOf("action" to "update_now"))
                        appVersionManager.openUpdate(this@MainActivity, update.updateUrl)
                    }) {
                        Text("Update to ${update.latestVersionName}")
                    }
                },
                dismissButton = {
                    if (update.minimumVersionCode <= BuildConfig.VERSION_CODE.toLong()) {
                        TextButton(onClick = { versionUpdateInfo = null }) { Text("Later") }
                    }
                }
            )
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Monitor settings") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SMS destination numbers")
                        destinations.forEach { number ->
                            FilterChip(
                                selected = destination == number,
                                onClick = { destination = number },
                                label = { Text(number) },
                                enabled = !running
                            )
                        }
                        TextField(
                            value = destinationInput,
                            onValueChange = { destinationInput = it.filter { it.isDigit() } },
                            label = { Text("Add destination code") },
                            placeholder = { Text("e.g. 3030") },
                            singleLine = true
                        )
                        Row {
                            TextButton(onClick = {
                                if (destinationInput.length >= 3 && !destinations.contains(destinationInput)) {
                                    destinations = (destinations + destinationInput).distinct().take(6)
                                    store.setSetting(SETTING_DESTINATIONS, JSONArray(destinations).toString())
                                    destination = destinationInput
                                    destinationInput = ""
                                }
                            }) { Text("Add") }
                            TextButton(onClick = {
                                if (destinations.size > 1) {
                                    destinations = destinations.filterNot { it == destination }
                                    destination = destinations.first()
                                    store.setSetting(SETTING_DESTINATIONS, JSONArray(destinations).toString())
                                }
                            }) { Text("Remove selected") }
                        }
                        HorizontalDivider()
                        Text("Sound & Haptics", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("Event sounds")
                                Text("Short sounds for monitoring, completion, exports and important actions.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = soundEnabled, onCheckedChange = {
                                soundEnabled = it
                                feedback.soundEnabled = it
                                if (it) feedback.success()
                            })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("Haptic feedback")
                                Text("Light vibration for important confirmations.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = hapticEnabled, onCheckedChange = {
                                hapticEnabled = it
                                feedback.hapticEnabled = it
                                if (it) feedback.hapticConfirm()
                            })
                        }
                        HorizontalDivider()
                        Text("Keep analytics history: $retention months (maximum 60)")
                        Row {
                            DevMonitorButton(onClick = {
                                retention = (retention - 1).coerceAtLeast(1)
                                store.setRetentionMonths(retention)
                            }) { Text("−") }
                            Text("  $retention months  ")
                            DevMonitorButton(onClick = {
                                retention = (retention + 1).coerceAtMost(60)
                                store.setRetentionMonths(retention)
                            }) { Text("+") }
                        }
                        Text("Pattern deviation uses recent daily Today-sales history and flags marked drops or spikes after enough history exists.")
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSettings = false }) { Text("Close") }
                }
            )
        }

        fun loadMyDevicesLoadedReport(): SimRegReport? {
            val mine = savedMyDevices().map(::canonicalDeviceCode).filter { it.isNotBlank() }
            if (mine.isEmpty()) return null
            val (start, end) = PaymentRules.myDevicesWorkingWindow()
            val rows = myDevicesDatabase.cachedRows()
            return SimRegReport(
                sourceName = "My Devices working set", reportType = "ACTIVATIONS",
                coverageStart = start, coverageEnd = end, sheetName = "My Devices",
                rows = rows.filter { canonicalDeviceCode(it.deviceId) in mine }, isContinuous = true
            )
        }

        fun refreshMyDevicesFromProfile(startDeviceMonitor: Boolean = true) {
            scope.launch {
                val userType = store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty()
                val codesFound = withContext(Dispatchers.IO) {
                    companyActivations.devicesForScope(
                        userType = userType,
                        partnerCode = store.getSetting(SETTING_MY_DEVICES_PARTNER_CODE).orEmpty(),
                        deviceId = store.getSetting(SETTING_MY_DEVICES_DEVICE_ID).orEmpty(),
                        staffLevel = store.getSetting(SETTING_MY_DEVICES_STAFF_LEVEL).orEmpty(),
                        division = store.getSetting(SETTING_MY_DEVICES_DIVISION).orEmpty(),
                        region = store.getSetting(SETTING_MY_DEVICES_REGION).orEmpty(),
                        staffName = store.getSetting(SETTING_MY_DEVICES_STAFF_NAME).orEmpty(),
                        territory = store.getSetting(SETTING_MY_DEVICES_TERRITORY).orEmpty()
                    )
                }
                saveMyDevices(codesFound)
                withContext(Dispatchers.IO) {
                    rebuildMyDevicesWorkingSet(codesFound)
                    companyActivations.refreshMonthOnMonthMyDevices(codesFound)
                }
                importedSimRegReport = withContext(Dispatchers.IO) { loadMyDevicesLoadedReport() }
                codes = codesFound
                records = emptyMap()
                persist()
                message = if (codesFound.isEmpty()) "No devices matched the saved profile in the loaded report." else "My Devices updated: ${codesFound.size} device${if (codesFound.size == 1) "" else "s"}."
                if (codesFound.isNotEmpty() && startDeviceMonitor) {
                    selectedTab = 1
                    refreshSims()
                    delay(250)
                    beginRun(codesFound, false)
                }
            }
        }


        suspend fun resolvePartnerTradeCode(query: String): String? = withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isBlank()) return@withContext null
            val rows = companyActivations.latestDeviceScopeRows()
            val exactTrade = rows.firstOrNull { it.tradeCode.equals(q, ignoreCase = true) }?.tradeCode?.trim()
            if (!exactTrade.isNullOrBlank()) return@withContext exactTrade.uppercase(Locale.US)

            val exactNames = rows.filter { it.partnerName.equals(q, ignoreCase = true) }
                .map { it.tradeCode.trim().uppercase(Locale.US) }
                .filter { it.isNotBlank() }
                .distinct()
            if (exactNames.size == 1) return@withContext exactNames.first()
            if (exactNames.size > 1) return@withContext null

            val partialNames = rows.filter { it.partnerName.contains(q, ignoreCase = true) }
                .map { it.tradeCode.trim().uppercase(Locale.US) }
                .filter { it.isNotBlank() }
                .distinct()
            if (partialNames.size == 1) partialNames.first() else null
        }

        suspend fun partnerLookupMessage(query: String): String? = withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isBlank()) return@withContext "Enter a Trade Code or Channel Partner Name."
            val rows = companyActivations.latestDeviceScopeRows()
            if (rows.any { it.tradeCode.equals(q, ignoreCase = true) }) return@withContext null
            val exact = rows.filter { it.partnerName.equals(q, ignoreCase = true) }
                .map { it.tradeCode.trim().uppercase(Locale.US) }.filter { it.isNotBlank() }.distinct()
            if (exact.size > 1) return@withContext "That Channel Partner Name matches more than one Trade Code. Please use the Trade Code."
            val partial = rows.filter { it.partnerName.contains(q, ignoreCase = true) }
                .map { it.tradeCode.trim().uppercase(Locale.US) }.filter { it.isNotBlank() }.distinct()
            when {
                partial.size > 1 -> "That Channel Partner Name matches more than one Trade Code. Please use the Trade Code."
                partial.isEmpty() -> "No Trade Code or Channel Partner Name matched the loaded data."
                else -> null
            }
        }

        suspend fun loadPartnerSummaryLoadedReport(tradeCode: String): SimRegReport? = withContext(Dispatchers.IO) {
            val report = companyActivations.loadContinuousReport() ?: return@withContext null
            val matches = report.rows.filter { it.tradeCode.equals(tradeCode.trim(), ignoreCase = true) }
            if (matches.isEmpty()) return@withContext report.copy(rows = emptyList())
            val byDate = linkedMapOf<java.time.LocalDate, Int>()
            matches.forEach { row ->
                row.dailyByDate.forEach { (date, value) -> byDate[date] = (byDate[date] ?: 0) + value }
            }
            val dailyByDay = byDate.entries.associate { it.key.dayOfMonth to it.value }
            val summaryRow = SimRegReportRow(
                tradeCode = tradeCode.trim().uppercase(Locale.US),
                partnerName = matches.firstOrNull { it.partnerName.isNotBlank() }?.partnerName.orEmpty(),
                deviceId = tradeCode.trim().uppercase(Locale.US),
                cluster = matches.map { it.cluster }.firstOrNull { it.isNotBlank() }.orEmpty(),
                region = "",
                territory = "",
                staffName = "",
                daily = dailyByDay,
                grandTotal = byDate.values.sum(),
                dailyByDate = byDate
            )
            report.copy(
                sourceName = "Partner Summary — ${tradeCode.trim().uppercase(Locale.US)}",
                rows = listOf(summaryRow)
            )
        }

        suspend fun loadPartnerDevicesLoadedReport(tradeCode: String): SimRegReport? = withContext(Dispatchers.IO) {
            val report = companyActivations.loadContinuousReport() ?: return@withContext null
            val partnerCodes = companyActivations.latestDeviceScopeRows()
                .filter { it.tradeCode.equals(tradeCode.trim(), ignoreCase = true) }
                .map { canonicalDeviceCode(it.deviceId) }
                .filter { it.isNotBlank() }
                .toSet()
            report.copy(rows = report.rows.filter { canonicalDeviceCode(it.deviceId) in partnerCodes })
        }

        fun beginPartnerSummary(tradeCode: String) {
            val cleanTradeCode = tradeCode.trim().uppercase(Locale.US)
            if (cleanTradeCode.isBlank() || partnerSummaryLoading) return
            if (!permissionOk) {
                pendingPartnerSummaryCodeAfterSim = cleanTradeCode
                requestSmsPermissions()
                return
            }
            partnerSummaryLoading = true
            partnerSummaryCode = cleanTradeCode
            partnerSummaryResult = null
            showPartnerSourceMenu = false
            showMyDevicesActionMenu = false
            scope.launch {
                val baseline = SmsInbox.latestId(this@MainActivity)
                val sent = sendRepeated(cleanTradeCode, 1).first
                if (sent == 0) {
                    partnerSummaryLoading = false
                    message = "Could not send the partner summary request for $cleanTradeCode."
                    return@launch
                }
                message = "Sent partner summary request for $cleanTradeCode to $destination. Waiting for the 30-30 response…"
                val start = System.currentTimeMillis()
                var matched: SimRegResult? = null
                var lastId = baseline
                val seen = mutableSetOf<String>()
                while (isActive && System.currentTimeMillis() - start < DEFAULT_TIMEOUT_MS && matched == null) {
                    for (sms in SmsInbox.after(this@MainActivity, lastId).sortedBy { it.receivedAt }) {
                        lastId = maxOf(lastId, sms.id)
                        if (sms.receivedAt < start) continue
                        if (sms.sender.filter { it.isDigit() }.takeLast(4) != destination.filter { it.isDigit() }.takeLast(4)) continue
                        val signature = "${sms.receivedAt}|${sms.sender}|${sms.body.trim()}"
                        if (!seen.add(signature)) continue
                        val parsed = SmsParser.parse(cleanTradeCode, sms.body, formatTime(sms.receivedAt))
                        if (parsed.status == AttemptStatus.SUCCESS || parsed.status == AttemptStatus.NOT_FOUND) {
                            matched = parsed
                            break
                        }
                    }
                    if (matched == null) delay(750)
                }
                partnerSummaryResult = matched
                partnerSummaryLoading = false
                message = when (matched?.status) {
                    AttemptStatus.SUCCESS -> "Partner summary received for $cleanTradeCode."
                    AttemptStatus.NOT_FOUND -> "30-30 reported that partner code $cleanTradeCode was not found."
                    else -> "No valid 30-30 partner summary response was received for $cleanTradeCode."
                }
            }
        }

        LaunchedEffect(permissionTick, permissionOk, pendingPartnerSummaryCodeAfterSim) {
            val code = pendingPartnerSummaryCodeAfterSim
            if (permissionOk && !code.isNullOrBlank() && !showSmsDisclosure && !partnerSummaryLoading && !showSimMenu) {
                pendingPartnerSummaryCodeAfterSim = null
                delay(150)
                beginPartnerSummary(code)
            }
        }

        if (showMyDevicesActionMenu) {
            val isPartner = store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty().equals("PARTNER", ignoreCase = true)
            AlertDialog(
                onDismissRequest = { showMyDevicesActionMenu = false },
                title = { Text(if (isPartner) "Check My Devices" else "Check My Devices") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (isPartner) {
                            Text("Choose whether to check the partner's combined activity or the individual devices.")
                            Text("Trade Code: ${store.getSetting(SETTING_MY_DEVICES_PARTNER_CODE).orEmpty()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Text("${savedMyDevices().size} device${if (savedMyDevices().size == 1) "" else "s"} are saved under your profile.")
                            Text("Choose how you want to check them today.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                confirmButton = {
                    if (isPartner) {
                        DevMonitorButton(onClick = {
                            partnerActionMode = "SUMMARY"
                            partnerLookupQuery = store.getSetting(SETTING_MY_DEVICES_PARTNER_CODE).orEmpty()
                            partnerLookupError = null
                            showMyDevicesActionMenu = false
                            showPartnerSourceMenu = true
                        }) { Text("Summary") }
                    } else {
                        DevMonitorButton(onClick = {
                            showMyDevicesActionMenu = false
                            val mine = savedMyDevices()
                            codes = mine
                            records = emptyMap()
                            persist()
                            startCheckMyDevicesDeviceMonitor(mine)
                        }, enabled = savedMyDevices().isNotEmpty()) { Text("Device Monitor") }
                    }
                },
                dismissButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (isPartner) {
                            DevMonitorOutlinedButton(onClick = {
                                partnerActionMode = "MY_DEVICES"
                                partnerLookupQuery = store.getSetting(SETTING_MY_DEVICES_PARTNER_CODE).orEmpty()
                                partnerLookupError = null
                                showMyDevicesActionMenu = false
                                showPartnerSourceMenu = true
                            }) { Text("My Devices") }
                        } else {
                            DevMonitorOutlinedButton(onClick = {
                                showMyDevicesActionMenu = false
                                userScopedNoticePending = true
                                userScopedNoticeBusy = true
                                importedSimRegReport = loadMyDevicesLoadedReport()
                                showSimRegReport = true
                                selectedTab = 5
                            }) { Text("Loaded Report") }
                        }
                    }
                }
            )
        }

        if (showPartnerSourceMenu) {
            val lookup = partnerLookupQuery.trim()
            AlertDialog(
                onDismissRequest = { showPartnerSourceMenu = false },
                title = { Text(if (partnerActionMode == "SUMMARY") "Partner Summary" else "My Devices") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (partnerActionMode == "SUMMARY")
                                "Enter either the Trade Code or the Channel Partner Name. Channel Partner Name is supported for everyday lookups; Device Monitor will translate it to the Trade Code before sending the 30-30 request."
                            else
                                "Enter either the Trade Code or the Channel Partner Name to find the partner's devices in the loaded data."
                        )
                        TextField(
                            value = partnerLookupQuery,
                            onValueChange = { partnerLookupQuery = it; partnerLookupError = null },
                            label = { Text("Trade Code or Channel Partner Name") },
                            placeholder = { Text("e.g. ABC123 or partner name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (!partnerLookupError.isNullOrBlank()) {
                            Text(
                                partnerLookupError.orEmpty(),
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                confirmButton = {
                    DevMonitorButton(onClick = {
                        scope.launch {
                            val error = partnerLookupMessage(lookup)
                            if (error != null) {
                                partnerLookupError = error
                                return@launch
                            }
                            val resolved = resolvePartnerTradeCode(lookup)
                            if (resolved.isNullOrBlank()) {
                                partnerLookupError = "No unique partner match was found. Please use the Trade Code."
                                return@launch
                            }
                            partnerLookupError = null
                            partnerSummaryCode = resolved
                            showPartnerSourceMenu = false
                            if (partnerActionMode == "SUMMARY") {
                                selectedTab = 1
                                val sims = refreshSims()
                                if (sims.isEmpty()) requestPhoneStatePermission()
                                pendingPartnerSummaryCodeAfterSim = resolved
                                showSimMenu = true
                            } else {
                                val found = withContext(Dispatchers.IO) {
                                    companyActivations.devicesForScope(
                                        userType = "PARTNER",
                                        partnerCode = resolved
                                    )
                                }
                                saveMyDevices(found)
                                monthToMonthComparison = null
                                codes = found
                                records = emptyMap()
                                persist()
                                if (found.isEmpty()) {
                                    message = "No devices matched partner Trade Code $resolved in the loaded report."
                                } else {
                                    startCheckMyDevicesDeviceMonitor(found)
                                }
                            }
                        }
                    }, enabled = lookup.isNotBlank()) { Text("Device Monitor") }
                },
                dismissButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DevMonitorOutlinedButton(onClick = {
                            scope.launch {
                                val error = partnerLookupMessage(lookup)
                                if (error != null) {
                                    partnerLookupError = error
                                    return@launch
                                }
                                val resolved = resolvePartnerTradeCode(lookup)
                                if (resolved.isNullOrBlank()) {
                                    partnerLookupError = "No unique partner match was found. Please use the Trade Code."
                                    return@launch
                                }
                                partnerLookupError = null
                                showPartnerSourceMenu = false
                                importedSimRegReport = if (partnerActionMode == "SUMMARY") {
                                    loadPartnerSummaryLoadedReport(resolved)
                                } else {
                                    loadPartnerDevicesLoadedReport(resolved)
                                }
                                showSimRegReport = true
                                selectedTab = 5
                            }
                        }, enabled = lookup.isNotBlank()) { Text("Loaded Report") }
                        TextButton(onClick = { showPartnerSourceMenu = false }) { Text("Cancel") }
                    }
                }
            )
        }

        if (partnerSummaryLoading) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Partner Summary") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Sending Trade Code ${partnerSummaryCode} to $destination and waiting for the 30-30 summary…")
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                },
                confirmButton = {}
            )
        }

        if (partnerSummaryResult != null) {
            val result = partnerSummaryResult!!
            AlertDialog(
                onDismissRequest = { partnerSummaryResult = null },
                title = { Text("Partner Summary — $partnerSummaryCode") },
                text = {
                    Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (result.status == AttemptStatus.SUCCESS) "30-30 summary received" else result.status.name)
                        Text("Today: ${result.today ?: "-"}")
                        Text("MTD: ${result.mtd ?: "-"}")
                        Text("Active: ${result.active ?: "-"}")
                        Text("Bar 48: ${result.bar48 ?: "-"}")
                        Text("Bar 96: ${result.bar96 ?: "-"}")
                        result.duplicates?.let { Text("Duplicates: $it") }
                        Spacer(Modifier.height(4.dp))
                        Text("30-30 response", fontWeight = FontWeight.Bold)
                        Text(result.raw.ifBlank { "No response text available." }, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { partnerSummaryResult = null }) { Text("Done") } }
            )
        }

        if (showMyDevicesProfile) {
            val editingProfile = profiles.firstOrNull { it.id == profileEditorId }
            val creatingProfile = profileEditorNew || editingProfile == null
            var profileType by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.userType.orEmpty()) }
            var staffLevel by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.staffLevel.orEmpty()) }
            var profilePartnerCode by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.partnerCode.orEmpty()) }
            var profileDeviceId by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.deviceId.orEmpty()) }
            var profileDivision by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.division.orEmpty()) }
            var profileRegion by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.region.orEmpty()) }
            var profileStaffName by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.staffName.orEmpty()) }
            var profileTerritory by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.territory.orEmpty()) }
            var profileName by remember { mutableStateOf(if (creatingProfile) googleName.orEmpty() else editingProfile?.name.orEmpty()) }
            var profilePhone by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.phone.orEmpty()) }
            var profileMonthlyTarget by remember { mutableStateOf(if (creatingProfile) "" else editingProfile?.monthlyTarget?.takeIf { it > 0 }?.toString().orEmpty()) }
            var typeExpanded by remember { mutableStateOf(false) }
            var levelExpanded by remember { mutableStateOf(false) }
            var divisionExpanded by remember { mutableStateOf(false) }
            var regionExpanded by remember { mutableStateOf(false) }
            var staffExpanded by remember { mutableStateOf(false) }
            var territoryExpanded by remember { mutableStateOf(false) }
            var savingProfile by remember { mutableStateOf(false) }
            var skeletonReady by remember { mutableStateOf(false) }
            // Profile identity follows the new company structure exactly: Cluster (Division) → Region → Territory → Staff.
            // The company directory is the identity source here so this builder works before activation data exists.
            val divisions = remember(skeletonReady) { companySkeleton.divisions() }
            val regions = remember(profileDivision, skeletonReady) { companySkeleton.regions(profileDivision) }
            val territories = remember(profileDivision, profileRegion, skeletonReady) {
                if (profileRegion.isBlank()) emptyList() else companySkeleton.territories(profileDivision, profileRegion)
            }
            val staffNames = remember(profileDivision, profileRegion, profileTerritory, skeletonReady) {
                if (profileRegion.isBlank() || profileTerritory.isBlank()) emptyList() else companySkeleton.staff(profileDivision, profileRegion, profileTerritory)
            }
            LaunchedEffect(Unit) { withContext(Dispatchers.IO) { companySkeleton.records() }; skeletonReady = true }

            AlertDialog(
                onDismissRequest = { if (!savingProfile) showMyDevicesProfile = false },
                title = { Text(if (creatingProfile) "Create My Devices Profile" else "My Devices Profile") },
                text = {
                    // Profile Builder can contain several scope controls on smaller
                    // screens. Keep the dialog itself usable by making the complete
                    // form vertically scrollable instead of allowing the lower fields
                    // and buttons to be clipped.
                    Column(
                        Modifier
                            .heightIn(max = 560.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            if (companySkeleton.hasData())
                                "Build your profile from the Company Directory. It contains company identity and organisational relationships, not activation or payment data."
                            else
                                "Load Company Data to refresh the company directory, then build your profile without loading the full activation report.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                            Text("COMPANY DIRECTORY", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraBlue)
                            Spacer(Modifier.height(4.dp))
                            Text("Find your company record", fontWeight = FontWeight.ExtraBold)
                            Text("Search by your name, Trade Code, partner name, device ID, region or territory.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            TextField(
                                value = profileSkeletonQuery,
                                onValueChange = {
                                    profileSkeletonQuery = it
                                    profileSkeletonResults = if (it.trim().length >= 2) companySkeleton.search(it, 30) else emptyList()
                                },
                                label = { Text("Search company records") },
                                placeholder = { Text("e.g. your name, trade code or device ID") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (profileSkeletonResults.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                profileSkeletonResults.take(8).forEach { hit ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            profileName = if (profileName.isBlank()) hit.staffName.ifBlank { hit.partnerName } else profileName
                                            profilePartnerCode = hit.tradeCode
                                            profileDeviceId = canonicalDeviceCode(hit.deviceId)
                                            profileDivision = hit.division
                                            profileRegion = hit.region
                                            profileStaffName = hit.staffName
                                            profileTerritory = hit.territory
                                            if (hit.deviceId.isNotBlank()) profileType = "AGENT" else if (hit.tradeCode.isNotBlank()) profileType = "PARTNER"
                                            profileSkeletonResults = emptyList()
                                            profileSkeletonQuery = hit.deviceId.ifBlank { hit.tradeCode.ifBlank { hit.staffName } }
                                        },
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(Modifier.padding(10.dp)) {
                                            Text(hit.deviceId.ifBlank { hit.tradeCode }, fontWeight = FontWeight.ExtraBold)
                                            Text(listOf(hit.partnerName, hit.staffName, hit.region, hit.territory).filter { it.isNotBlank() }.distinct().joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                }
                            }
                            DevMonitorOutlinedButton(
                                onClick = { companySkeletonLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !savingProfile && !companySkeletonLoading
                            ) { Text("LOAD COMPANY DATA") }
                        }
                        if (googleEmail.isNullOrBlank()) {
                            DevMonitorButton(onClick = {
                                if (NetworkUtils.hasActiveInternet(this@MainActivity)) {
                                    googleSignInLauncher.launch(GoogleSignIn.getClient(this@MainActivity, googleOptions).signInIntent)
                                } else {
                                    message = NetworkUtils.OFFLINE_MESSAGE
                                }
                            }, Modifier.fillMaxWidth(), enabled = !savingProfile) { Text("Sign in with Google") }
                        } else {
                            Text("Google: ${googleName?.ifBlank { null } ?: "Account"} • $googleEmail", fontWeight = FontWeight.SemiBold)
                        }
                        TextField(value = profileName, onValueChange = { profileName = it }, label = { Text("Your name") }, singleLine = true)
                        TextField(value = profilePhone, onValueChange = { profilePhone = it.filter { ch -> ch.isDigit() || ch == '+' || ch == ' ' || ch == '-' } }, label = { Text("Phone number") }, singleLine = true)

                        ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = !typeExpanded }) {
                            TextField(value = profileType, onValueChange = {}, readOnly = true, label = { Text("User type") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(typeExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                                listOf("PARTNER", "AGENT", "STAFF").forEach { type ->
                                    DropdownMenuItem(text = { Text(type.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { profileType = type; typeExpanded = false })
                                }
                            }
                        }

                        when (profileType) {
                            "PARTNER" -> TextField(value = profilePartnerCode, onValueChange = { profilePartnerCode = it.trim().uppercase(Locale.US) }, label = { Text("Partner code") }, supportingText = { Text("The report's Trade Code is used as the partner-code key.") }, singleLine = true)
                            "AGENT" -> TextField(value = profileDeviceId, onValueChange = { profileDeviceId = canonicalDeviceCode(it) }, label = { Text("Device ID") }, singleLine = true)
                            "STAFF" -> {
                                ExposedDropdownMenuBox(expanded = levelExpanded, onExpandedChange = { levelExpanded = !levelExpanded }) {
                                    TextField(value = staffLevel, onValueChange = {}, readOnly = true, label = { Text("Staff level") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(levelExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                    ExposedDropdownMenu(expanded = levelExpanded, onDismissRequest = { levelExpanded = false }) {
                                        listOf("CLUSTER HEAD", "REGIONAL MANAGER", "STAFF").forEach { level ->
                                            DropdownMenuItem(text = { Text(level.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { staffLevel = level; levelExpanded = false })
                                        }
                                    }
                                }
                                if (staffLevel.isNotBlank() && divisions.isNotEmpty()) {
                                    ExposedDropdownMenuBox(expanded = divisionExpanded, onExpandedChange = { divisionExpanded = !divisionExpanded }) {
                                        TextField(value = profileDivision, onValueChange = {}, readOnly = true, label = { Text("Cluster (Division)") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(divisionExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                        ExposedDropdownMenu(expanded = divisionExpanded, onDismissRequest = { divisionExpanded = false }) {
                                            divisions.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { profileDivision = value; profileRegion = ""; profileStaffName = ""; profileTerritory = ""; divisionExpanded = false }) }
                                        }
                                    }
                                }
                                if (regions.isNotEmpty()) {
                                    ExposedDropdownMenuBox(expanded = regionExpanded, onExpandedChange = { regionExpanded = !regionExpanded }) {
                                        TextField(value = profileRegion, onValueChange = {}, readOnly = true, label = { Text("Region") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(regionExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                        ExposedDropdownMenu(expanded = regionExpanded, onDismissRequest = { regionExpanded = false }) {
                                            regions.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { profileRegion = value; profileTerritory = ""; profileStaffName = ""; regionExpanded = false }) }
                                        }
                                    }
                                }
                                if (profileRegion.isNotBlank() && territories.isNotEmpty()) {
                                    ExposedDropdownMenuBox(expanded = territoryExpanded, onExpandedChange = { territoryExpanded = !territoryExpanded }) {
                                        TextField(value = profileTerritory, onValueChange = {}, readOnly = true, label = { Text("Territory") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(territoryExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                        ExposedDropdownMenu(expanded = territoryExpanded, onDismissRequest = { territoryExpanded = false }) {
                                            territories.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { profileTerritory = value; profileStaffName = ""; territoryExpanded = false }) }
                                        }
                                    }
                                }
                                if (profileTerritory.isNotBlank() && staffNames.isNotEmpty()) {
                                    ExposedDropdownMenuBox(expanded = staffExpanded, onExpandedChange = { staffExpanded = !staffExpanded }) {
                                        TextField(value = profileStaffName, onValueChange = {}, readOnly = true, label = { Text("Staff name") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(staffExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                        ExposedDropdownMenu(expanded = staffExpanded, onDismissRequest = { staffExpanded = false }) {
                                            staffNames.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { profileStaffName = value; staffExpanded = false }) }
                                        }
                                    }
                                }
                            }
                        }

                        if (profileType == "STAFF" || profileType == "PARTNER") {
                            TextField(
                                value = profileMonthlyTarget,
                                onValueChange = { value -> profileMonthlyTarget = value.filter(Char::isDigit).take(9) },
                                label = { Text("Monthly target") },
                                supportingText = { Text("Enter the total monthly activation target for this ${profileType.lowercase()} profile.") },
                                singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else if (profileType == "AGENT") {
                            TextField(value = "150", onValueChange = {}, readOnly = true, label = { Text("Fixed monthly target") }, supportingText = { Text("Agent target is fixed at 150 activations per month." ) }, modifier = Modifier.fillMaxWidth())
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.35f))
                        ) {
                            Text(
                                "Check your profile details. Confirm that your name, role, division, region, territory and selected device accurately describe who you are in company operations before saving.",
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (!creatingProfile) {
                            DevMonitorOutlinedButton(
                                onClick = { profileDeleteTarget = editingProfile },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !savingProfile
                            ) { Text("Delete Profile") }
                        }

                        val existingCodes = savedMyDevices()
                        Text("Saved My Devices: ${existingCodes.size}", fontWeight = FontWeight.SemiBold)
                        if (existingCodes.isNotEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                existingCodes.forEach { code ->
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(code, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                        TextButton(onClick = { deviceDeleteTarget = code }, enabled = !savingProfile) { Text("Remove") }
                                    }
                                }
                            }
                        }
                        Text("Manage the devices saved under this profile. Removing a device only removes it from My Devices; its report history remains intact.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (store.getSetting(SETTING_MY_DEVICES_SETUP) == "true") {
                            DevMonitorOutlinedButton(onClick = { showMyDevicesProfile = false; refreshMyDevicesFromProfile() }, modifier = Modifier.fillMaxWidth(), enabled = !savingProfile) { Text("Update My Devices from Loaded Report") }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (profileType.isBlank() || profileName.trim().isBlank()) return@TextButton
                        if ((profileType == "STAFF" || profileType == "PARTNER") && (profileMonthlyTarget.toIntOrNull() ?: 0) <= 0) {
                            message = "Enter a monthly target greater than zero for this ${profileType.lowercase()} profile."
                            return@TextButton
                        }
                        savingProfile = true
                        scope.launch {
                            try {
                                val found = withContext(Dispatchers.IO) {
                                    val loadedHq = companyActivations.listReports().isNotEmpty()
                                    if (loadedHq) {
                                        companyActivations.devicesForScope(profileType, profilePartnerCode, profileDeviceId, staffLevel, profileDivision, profileRegion, profileStaffName, profileTerritory)
                                    } else {
                                        companySkeleton.records().asSequence()
                                            .filter {
                                                when (profileType) {
                                                    "PARTNER" -> profilePartnerCode.isBlank() || it.tradeCode.equals(profilePartnerCode, true)
                                                    "AGENT" -> profileDeviceId.isBlank() || canonicalDeviceCode(it.deviceId).equals(canonicalDeviceCode(profileDeviceId), true)
                                                    "STAFF" -> true
                                                    else -> false
                                                }
                                            }
                                            .filter { profileDivision.isBlank() || it.division.equals(profileDivision, true) }
                                            .filter { profileRegion.isBlank() || it.region.equals(profileRegion, true) }
                                            .filter { profileStaffName.isBlank() || it.staffName.equals(profileStaffName, true) }
                                            .filter { profileTerritory.isBlank() || it.territory.equals(profileTerritory, true) }
                                            .map { canonicalDeviceCode(it.deviceId) }
                                            .filter { it.isNotBlank() }
                                            .distinct()
                                            .toList()
                                    }
                                }
                                if (profileType == "AGENT" && canonicalDeviceCode(profileDeviceId).isBlank()) {
                                    message = "Select one device for the Agent profile before continuing."
                                    return@launch
                                }
                                val finalCodes = if (profileType == "AGENT") {
                                    listOf(canonicalDeviceCode(profileDeviceId)).filter { it.isNotBlank() }
                                } else found
                                val targetId = if (creatingProfile) UUID.randomUUID().toString() else (editingProfile?.id ?: activeProfileId ?: "default")
                                val targetProfile = DeviceProfile(
                                    id = targetId,
                                    name = profileName.trim(),
                                    phone = profilePhone.trim(),
                                    userType = profileType,
                                    staffLevel = staffLevel,
                                    partnerCode = profilePartnerCode.trim().uppercase(Locale.US),
                                    deviceId = canonicalDeviceCode(profileDeviceId),
                                    division = profileDivision,
                                    region = profileRegion,
                                    staffName = profileStaffName,
                                    territory = profileTerritory,
                                    codes = finalCodes,
                                    monthlyTarget = when (profileType) {
                                        "AGENT" -> 150
                                        "STAFF", "PARTNER" -> profileMonthlyTarget.toIntOrNull() ?: 0
                                        else -> 0
                                    }
                                )

                                // Commit the profile first. The expensive report/working-set
                                // rebuild is a separate, recoverable phase so a large scope
                                // or database problem cannot turn profile saving into an app crash.
                                if (creatingProfile) {
                                    saveActiveProfileSnapshot()
                                    profiles = profiles + targetProfile
                                    profileStore.saveAll(profiles)
                                    applyProfile(targetProfile)
                                    if (targetProfile.userType.equals("STAFF", ignoreCase = true)) {
                                        DevMonitorWelcomeAudio.playStaffProfileOnce(this@MainActivity, targetProfile.id)
                                    }
                                } else {
                                    profiles = profiles.map { if (it.id == targetProfile.id) targetProfile else it }
                                    profileStore.saveAll(profiles)
                                    store.setSetting("my_devices_name", targetProfile.name)
                                    store.setSetting("my_devices_phone", targetProfile.phone)
                                    store.setSetting(SETTING_MY_DEVICES_USER_TYPE, targetProfile.userType)
                                    store.setSetting(SETTING_MY_DEVICES_STAFF_LEVEL, targetProfile.staffLevel)
                                    store.setSetting(SETTING_MY_DEVICES_PARTNER_CODE, targetProfile.partnerCode)
                                    store.setSetting(SETTING_MY_DEVICES_DEVICE_ID, targetProfile.deviceId)
                                    store.setSetting(SETTING_MY_DEVICES_DIVISION, targetProfile.division)
                                    store.setSetting(SETTING_MY_DEVICES_REGION, targetProfile.region)
                                    store.setSetting(SETTING_MY_DEVICES_STAFF_NAME, targetProfile.staffName)
                                    store.setSetting(SETTING_MY_DEVICES_TERRITORY, targetProfile.territory)
                                    store.setSetting(SETTING_MY_DEVICES_CODES, finalCodes.joinToString("|"))
                                    store.setSetting(SETTING_MY_DEVICES_SETUP, "true")
                                }

                                saveMyDevices(finalCodes)
                                val hasLoadedHq = withContext(Dispatchers.IO) { companyActivations.listReports().isNotEmpty() }
                                if (hasLoadedHq) {
                                    withContext(Dispatchers.IO) {
                                        rebuildMyDevicesWorkingSet(finalCodes)
                                        companyActivations.refreshMonthOnMonthMyDevices(finalCodes)
                                    }
                                    importedSimRegReport = withContext(Dispatchers.IO) { loadMyDevicesLoadedReport() }
                                } else {
                                    importedSimRegReport = null
                                }
                                codes = found
                                records = emptyMap()
                                persist()
                                val partnersMenuEligible = targetProfile.userType.trim().let {
                                    it.equals("STAFF", ignoreCase = true) || it.equals("PARTNER", ignoreCase = true)
                                }
                                myPartnersEligibleProfileIds = if (partnersMenuEligible) {
                                    myPartnersEligibleProfileIds + targetProfile.id
                                } else {
                                    myPartnersEligibleProfileIds - targetProfile.id
                                }
                                if (!partnersMenuEligible && selectedTab == 6) {
                                    selectedTab = 0
                                }
                                savingProfile = false
                                profileEditorNew = false
                                profileEditorId = activeProfileId
                                showMyDevicesProfile = false
                                showSettings = false
                                if (finalCodes.isEmpty()) {
                                    pendingCheckMyDevicesAfterProfile = false
                                    message = "Profile saved, but no devices matched it in the loaded report. Check the profile scope or update it after loading a newer report."
                                } else if (pendingCheckMyDevicesAfterProfile) {
                                    pendingCheckMyDevicesAfterProfile = false
                                    selectedTab = 0
                                    scope.launch {
                                        delay(150)
                                        if (!showMyDevicesProfile && !showSettings) {
                                            showMyDevicesActionMenu = true
                                        }
                                    }
                                } else {
                                    message = if (hasLoadedHq) "My Devices saved: ${finalCodes.size} device${if (finalCodes.size == 1) "" else "s"}." else "Profile saved from Company Directory: ${finalCodes.size} device${if (finalCodes.size == 1) "" else "s"} identified. Load Company Data/your HQ report later to populate activation performance."
                                }
                            } catch (t: Throwable) {
                                DevMonitorLogger.error("PROFILE", "Profile save/rebuild failed: ${t.message}", t)
                                savingProfile = false
                                message = "Profile was saved, but My Devices could not finish rebuilding: ${t.message ?: t.javaClass.simpleName}. You can retry from Profile settings."
                            }
                        }
                    }, enabled = !savingProfile && profileType.isNotBlank()) { Text(if (savingProfile) "Saving…" else "Save & Update My Devices") }
                },
                dismissButton = { TextButton(onClick = { showMyDevicesProfile = false }, enabled = !savingProfile) { Text("Cancel") } }
            )
        }

        if (deviceDeleteTarget != null) {
            val targetCode = deviceDeleteTarget!!
            AlertDialog(
                onDismissRequest = { deviceDeleteTarget = null },
                title = { Text("Remove device?") },
                text = { Text("Remove $targetCode from this profile's My Devices list? Its report history and underlying device data will remain intact.") },
                confirmButton = {
                    TextButton(onClick = {
                        val updated = savedMyDevices().filterNot { it.equals(targetCode, ignoreCase = true) }
                        saveMyDevices(updated)
                        codes = updated
                        records = records.filterKeys { key -> updated.any { it.equals(key, ignoreCase = true) } }
                        persist()
                        deviceDeleteTarget = null
                        message = "$targetCode removed from My Devices."
                    }) { Text("Remove") }
                },
                dismissButton = { TextButton(onClick = { deviceDeleteTarget = null }) { Text("Cancel") } }
            )
        }

        if (profileDeleteTarget != null) {
            val target = profileDeleteTarget!!
            AlertDialog(
                onDismissRequest = { profileDeleteTarget = null },
                title = { Text("Delete profile?") },
                text = {
                    Text("Delete '${target.name}' and its saved My Devices data? This cannot be undone. Other profiles and the shared Month-on-Month history will remain intact.")
                },
                confirmButton = {
                    TextButton(onClick = { deleteProfile(target) }) { Text("Delete") }
                },
                dismissButton = { TextButton(onClick = { profileDeleteTarget = null }) { Text("Cancel") } }
            )
        }

        if (monthToMonthSelectedSearchHit != null) {
            val hit = monthToMonthSelectedSearchHit!!
            AlertDialog(
                onDismissRequest = { if (!monthToMonthDetailLoading) monthToMonthSelectedSearchHit = null },
                title = { Text("Month-on-Month • ${hit.label}") },
                text = {
                    Column(
                        Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("${hit.type} result", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        if (hit.detail.isNotBlank()) Text(hit.detail, style = MaterialTheme.typography.bodySmall)
                        if (monthToMonthDetailLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                                Text("Building the full comparison…")
                            }
                        } else if (monthToMonthDetailRows.isEmpty()) {
                            Text("No detailed device comparison is available for this result.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            val available = monthToMonthDetailRows.mapNotNull { it.comparison }
                            val totalCurrent = available.sumOf { it.currentTotal }
                            val totalPrevious = available.sumOf { it.previousTotal }
                            val totalDelta = totalCurrent - totalPrevious
                            Text("FULL RESULT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraViolet)
                            Text("Devices matched: ${monthToMonthDetailRows.size}", fontWeight = FontWeight.SemiBold)
                            Text("Current total: $totalCurrent", fontWeight = FontWeight.Bold)
                            Text("Previous total: $totalPrevious", fontWeight = FontWeight.Bold)
                            Text("Change: ${if (totalDelta > 0) "+" else ""}$totalDelta", fontWeight = FontWeight.Bold)
                            HorizontalDivider()
                            monthToMonthDetailRows.forEach { row ->
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                    Text(row.deviceId, fontWeight = FontWeight.ExtraBold)
                                    val c = row.comparison
                                    if (c == null) {
                                        Text("No comparable data available", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    } else {
                                        Text("This month: ${c.currentTotal} • Previous month: ${c.previousTotal}", fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "Change: ${if (c.delta > 0) "+" else ""}${c.delta}" +
                                                (c.percentChange?.let { " (${if (it > 0) "+" else ""}${String.format(Locale.US, "%.1f", it)}%)" } ?: ""),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text("As of ${c.asOf}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { monthToMonthSelectedSearchHit = null }, enabled = !monthToMonthDetailLoading) { Text("Done") } }
            )
        }

        if (showVisualTrends) {
            val trendProfile = profiles.firstOrNull { it.id == activeProfileId }
            val trendTarget = trendProfile?.let { if (it.userType.equals("AGENT", true)) 150 else it.monthlyTarget } ?: 0
            VisualTrendsDialog(
                points = trendPoints,
                monthlyTarget = trendTarget,
                refreshing = trendsRefreshing,
                lastUpdated = trendsLastUpdated,
                onRefresh = { refreshVisualTrends() },
                onDismiss = { showVisualTrends = false }
            )
        }

        if (showNextLevel) {
            NextLevelScreen(
                context = this@MainActivity,
                db = database,
                company = companyActivations,
                monthlyTarget = profiles.firstOrNull { it.id == activeProfileId }?.let { if (it.userType.equals("AGENT", true)) 150 else it.monthlyTarget } ?: 0,
                onBackup = {
                    val account = GoogleSignIn.getLastSignedInAccount(this@MainActivity)
                    if (!NetworkUtils.hasActiveInternet(this@MainActivity)) message = "Cloud backup requires an active Internet connection."
                    else if (account == null) message = "Sign in to Google first"
                    else scope.launch {
                        runCatching { database.checkpointForBackup(); GoogleDriveBackup.backup(this@MainActivity, account, database.databaseFile()) }
                            .onSuccess { message = it }.onFailure { message = "Backup failed: ${it.message ?: "unknown error"}" }
                    }
                },
                onRestore = {
                    val account = GoogleSignIn.getLastSignedInAccount(this@MainActivity)
                    if (!NetworkUtils.hasActiveInternet(this@MainActivity)) message = "Cloud restore requires an active Internet connection."
                    else if (account == null) message = "Sign in to Google first"
                    else scope.launch {
                        val temp = File(cacheDir, "fieldpulse-cloud-restore.db")
                        runCatching { GoogleDriveBackup.restore(this@MainActivity, account, temp); installRestoredDatabase(temp) }
                            .onSuccess { message = "Cloud backup restored. Reloading DevMonitor…"; window.decorView.postDelayed({ recreate() }, 250) }
                            .onFailure { temp.delete(); message = "Restore failed: ${it.message ?: "unknown error"}" }
                    }
                },
                onClose = { showNextLevel = false }
            )
        }

        if (showNotificationInbox) {
            AlertDialog(
                onDismissRequest = { showNotificationInbox = false },
                title = { Text("Notifications & Inbox") },
                text = {
                    Column(Modifier.fillMaxWidth().heightIn(max = 430.dp)) {
                        if (notifications.isEmpty()) {
                            Text("You are all caught up. DevMonitor will place useful operational reminders and completed-action notices here.")
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(notifications, key = { it.id }) { note ->
                                    val accent = when (note.kind) { "warning" -> MaterialTheme.colorScheme.error; "success" -> AuroraGreen; "reminder" -> AuroraEmerald; else -> MaterialTheme.colorScheme.primary }
                                    Surface(
                                        Modifier.fillMaxWidth().clickable { if (!note.read) markNotificationRead(note.id) },
                                        color = if (note.read) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f) else accent.copy(alpha = .09f),
                                        shape = RoundedCornerShape(14.dp),
                                        border = BorderStroke(1.dp, if (note.read) MaterialTheme.colorScheme.outlineVariant else accent.copy(alpha = .35f))
                                    ) {
                                        Column(Modifier.padding(12.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(note.title, Modifier.weight(1f), fontWeight = if (note.read) FontWeight.SemiBold else FontWeight.ExtraBold)
                                                if (!note.read) Text("NEW", color = accent, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                                            }
                                            Spacer(Modifier.height(3.dp))
                                            Text(note.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(Modifier.height(4.dp))
                                            Text(SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(note.timestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { NotificationStore.markAllRead(this@MainActivity, notificationProfileId); notifications = NotificationStore.list(this@MainActivity, notificationProfileId) }) { Text("Mark all read") }
                },
                dismissButton = {
                    TextButton(onClick = { showNotificationInbox = false }) { Text("Close") }
                }
            )
        }

        if (showSimMenu) {
            AlertDialog(
                onDismissRequest = { showSimMenu = false },
                title = { Text("Select SIM for SMS") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (activeSims.isEmpty()) {
                            Text("No active SIMs were detected. Allow Phone permission, then try again.")
                        } else {
                            activeSims.forEach { sim ->
                                val selected = sim.subscriptionId == selectedSubId
                                DevMonitorButton(
                                    onClick = {
                                        selectedSubId = sim.subscriptionId
                                        store.setSetting(SETTING_SMS_SUB_ID, sim.subscriptionId.toString())
                                        showSimMenu = false
                                        message = "SMS will use ${simLabel(activeSims, selectedSubId)}"
                                        val checkCodes = pendingMyDevicesSmsRunCodes
                                        val checkPartner = pendingPartnerSummaryCodeAfterSim
                                        pendingMyDevicesSmsRunCodes = emptyList()
                                        pendingPartnerSummaryCodeAfterSim = null
                                        if (checkCodes.isNotEmpty()) {
                                            if (permissionOk) {
                                                scope.launch { delay(150); beginRun(checkCodes, false) }
                                            } else {
                                                requestSmsPermissions(checkCodes, resumeRetryOnly = false)
                                            }
                                        } else if (!checkPartner.isNullOrBlank()) {
                                            if (permissionOk) {
                                                scope.launch { delay(150); beginPartnerSummary(checkPartner) }
                                            } else {
                                                pendingPartnerSummaryCodeAfterSim = checkPartner
                                                requestSmsPermissions()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = if (selected) ButtonDefaults.buttonColors() else ButtonDefaults.outlinedButtonColors()
                                ) {
                                    Text(if (selected) "✓ ${simLabel(activeSims, sim.subscriptionId)}" else simLabel(activeSims, sim.subscriptionId))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { requestPhoneStatePermission(); refreshSims() }) { Text("Refresh SIMs") }
                }
            )
        }

        val darkTheme = when (themePreference) {
            "light" -> false
            "dark" -> true
            else -> isSystemInDarkTheme()
        }
        LaunchedEffect(showSimRegReport) { if (showSimRegReport) selectedTab = 5 }

        val rawDashboard = dashboardSummary
        val visibleFlags = remember(rawDashboard, showSensitiveFlags) {
            if (showSensitiveFlags) rawDashboard.flags
            else rawDashboard.flags.filterNot { it.reason.contains("below 10", ignoreCase = true) }
        }
        val liveDashboard = rawDashboard.copy(flags = visibleFlags)
        val dashboardAsOfDate = PaymentRules.currentAwareDate()
        val monthEndReminderVisible = dashboardAsOfDate.dayOfMonth in 18..20
        LaunchedEffect(activeProfileId, dashboardAsOfDate) {
            if (monthEndReminderVisible) {
                val reminderKey = "month_end_reminder_${dashboardAsOfDate}"
                if (store.getSetting(reminderKey) != "true") {
                    addNotification("Payment cycle reminder", "The current payment cycle closes on the 20th. Refresh the dashboard or open Payments when you are ready to review it.", "reminder")
                    store.setSetting(reminderKey, "true")
                }
            }
        }
        val companyFlags = liveDashboard.flags.count { it.ownership == Ownership.COMPANY }
        val partnerFlags = liveDashboard.flags.count { it.ownership == Ownership.PARTNER }

        val hasAppOverlay = showAbout || showFeedback || showFiles || showSettings || showSimMenu ||
            showSmsDisclosure || showRecoverySummary || showSaveHelp || showSavedLists ||
            showHistory || showSmsInbox || showArchived || showDatabase || showSaveDialog ||
            showDashboard || showMonthToMonthComparison || showFlags || showNotificationInbox || showTasks || showNotes || showTimeline || showVisualTrends || showNextLevel || showAgents || showSimRegReport || showLogViewer ||
            showExportMenu || showSnapshotMenu || showMyDevicesProfile || showMyDevicesActionMenu || showPartnerSourceMenu || partnerSummaryLoading || partnerSummaryResult != null ||
            showWelcome || showPermissionSetup

        BackHandler(enabled = hasAppOverlay || selectedTab != 0) {
            when {
                showSimRegReport -> { showSimRegReport = false; importedSimRegReport = null; loadingSavedReport = false; selectedTab = 0; if (userScopedNoticePending) userScopedNoticeBusy = false }
                showAbout -> showAbout = false
                showFeedback -> showFeedback = false
                showFiles -> showFiles = false
                showSettings -> showSettings = false
                showExportMenu -> showExportMenu = false
                showSnapshotMenu -> showSnapshotMenu = false
                showMyDevicesProfile -> showMyDevicesProfile = false
                partnerSummaryResult != null -> partnerSummaryResult = null
                showPartnerSourceMenu -> showPartnerSourceMenu = false
                showMyDevicesActionMenu -> showMyDevicesActionMenu = false
                showSimMenu -> showSimMenu = false
                showSmsDisclosure -> showSmsDisclosure = false
                showRecoverySummary -> showRecoverySummary = false
                showSaveHelp -> showSaveHelp = false
                showSavedLists -> showSavedLists = false
                showHistory -> showHistory = false
                showSmsInbox -> showSmsInbox = false
                showArchived -> showArchived = false
                showDatabase -> showDatabase = false
                showSaveDialog -> showSaveDialog = false
                showDashboard -> showDashboard = false
                showMonthToMonthComparison -> showMonthToMonthComparison = false
                showFlags -> showFlags = false
                showNotificationInbox -> showNotificationInbox = false
                showTasks -> showTasks = false
                showNotes -> showNotes = false
                showTimeline -> showTimeline = false
                showVisualTrends -> showVisualTrends = false
                showNextLevel -> showNextLevel = false
                showAgents -> showAgents = false
                showLogViewer -> showLogViewer = false
                showWelcome -> {
                    // Dismissing the first-run introduction with Android Back must be
                    // persisted just like using the wizard's Close/Continue actions.
                    // Otherwise the welcome menu can reappear on a later app launch.
                    persistWelcomeSeen(this@MainActivity, store)
                    showWelcome = false
                }
                showPermissionSetup -> {
                    store.setSetting(SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN, "true")
                    showPermissionSetup = false
                }
                selectedTab != 0 -> selectedTab = 0
            }
        }

        MaterialTheme(
            colorScheme = if (darkTheme) DevMonitorDarkScheme else DevMonitorLightScheme,
            shapes = MaterialTheme.shapes.copy(
                extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                small = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                large = androidx.compose.foundation.shape.RoundedCornerShape(26.dp)
            )
        ) {
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
            val drawerScope = rememberCoroutineScope()

            Box(Modifier.fillMaxSize().background(fieldPulseBackground(darkTheme))) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = selectedTab != 5,
                drawerContent = {
                    ModalDrawerSheet(
                        modifier = Modifier.fillMaxHeight().width(320.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(vertical = 18.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 24.dp, vertical = 10.dp)) {
                                Text(
                                    "DevMonitor",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    "SMS Automation & Reporting",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "App Menu",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(Modifier.height(8.dp))
                            NavigationDrawerItem(
                                label = {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("Notifications & Inbox", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                        if (unreadNotificationCount > 0) Badge { Text(unreadNotificationCount.coerceAtMost(99).toString()) }
                                    }
                                },
                                selected = false,
                                icon = { Text("🔔") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showNotificationInbox = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Notes", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("📝") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showNotes = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Tasks & Follow-ups", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("✓") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showTasks = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Device Activity Timeline", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("◷") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showTimeline = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Visual Trends", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("↗") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showVisualTrends = true
                                }
                            )
                            if (showMyPartnersCard) {
                                NavigationDrawerItem(
                                    label = { Text("My Partners", fontWeight = FontWeight.SemiBold) },
                                    selected = selectedTab == 6,
                                    icon = { Text("✉") },
                                    onClick = {
                                        drawerScope.launch { drawerState.close() }
                                        deviceMonitorPaymentCode = null
                                        selectedTab = 6
                                    }
                                )
                            }
                            NavigationDrawerItem(
                                label = { Text("Next Level Centre", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("⚡") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showNextLevel = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("About the App", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("ℹ") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showAbout = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Logs", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("▤") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    logVersion++
                                    showLogViewer = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Feedback & Suggestions", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("💬") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showFeedback = true
                                }
                            )
                            NavigationDrawerItem(
                                label = { Text("Files & Analysis", fontWeight = FontWeight.SemiBold) },
                                selected = false,
                                icon = { Text("📁") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    showFiles = true
                                }
                            )
                            if (store.getSetting(SETTING_MY_DEVICES_SETUP) == "true") {
                                NavigationDrawerItem(
                                    label = { Text("My Month-on-Month Performance", fontWeight = FontWeight.SemiBold) },
                                    selected = false,
                                    icon = { Text("↕") },
                                    onClick = {
                                        drawerScope.launch { drawerState.close() }
                                        openMonthToMonthComparison()
                                    }
                                )
                            }

                            NavigationDrawerItem(
                                label = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                                selected = selectedTab == 4,
                                icon = { Text("⚙") },
                                onClick = {
                                    drawerScope.launch { drawerState.close() }
                                    selectedTab = 4
                                }
                            )

                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(Modifier.height(12.dp))

                            Column(Modifier.padding(horizontal = 24.dp)) {
                                Text(
                                    "Quick access",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(6.dp))
                                TextButton(
                                    onClick = {
                                        drawerScope.launch { drawerState.close() }
                                        importedSimRegReport = null
                                        showSimRegReport = true
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Load SIMReg Report File", modifier = Modifier.fillMaxWidth()) }
                                TextButton(
                                    onClick = {
                                        drawerScope.launch { drawerState.close() }
                                        selectedTab = 1
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Open Device Monitor", modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                }
            )

 {
                Scaffold(
                topBar = {
                    Column(Modifier.fillMaxWidth()) {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFF071426).copy(alpha = .97f),
                            scrolledContainerColor = Color(0xFF071426).copy(alpha = .98f),
                            titleContentColor = Color.White,
                            navigationIconContentColor = Color.White,
                            actionIconContentColor = Color.White
                        ),
                        title = {
                            if (showMonthToMonthComparison) {
                                Text(
                                    "Month-on-Month Comparison",
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            } else Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Brush.linearGradient(listOf(AuroraBlue, AuroraCyan))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.devmonitor_icon),
                                        contentDescription = "DevMonitor",
                                        modifier = Modifier.size(31.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        "DevMonitor",
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.clickable {
                                        val now = System.currentTimeMillis()
                                        titleTapCount = if (now - lastTitleTapAt > 2200L) 1 else titleTapCount + 1
                                        lastTitleTapAt = now
                                        if (titleTapCount >= 7) {
                                            showSensitiveFlags = !showSensitiveFlags
                                            store.setSetting(SETTING_SHOW_SENSITIVE_FLAGS, showSensitiveFlags.toString())
                                            titleTapCount = 0
                                        }
                                    }
                                    )
                                    Text("SMS Automation & Reporting", color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.labelSmall)
                            if (!googleEmail.isNullOrBlank()) {
                                        Text(googleName?.takeIf { it.isNotBlank() } ?: googleEmail.orEmpty(), color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                    }
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    if (showMonthToMonthComparison) {
                                        if (!refreshingMonthToMonthComparison && !monthToMonthChildLoading) {
                                            showMonthToMonthComparison = false
                                        }
                                    } else {
                                        drawerScope.launch { drawerState.open() }
                                    }
                                },
                                modifier = Modifier.semantics {
                                    contentDescription = if (showMonthToMonthComparison) "Back from Month-on-Month Comparison" else "Open DevMonitor menu"
                                }
                            ) {
                                Text(
                                    if (showMonthToMonthComparison) "‹" else "☰",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        actions = {
                            Box {
                                IconButton(onClick = { showNotificationInbox = true }) {
                                    Text("🔔", style = MaterialTheme.typography.titleLarge)
                                }
                                if (unreadNotificationCount > 0) {
                                    Badge(modifier = Modifier.align(Alignment.TopEnd)) {
                                        Text(unreadNotificationCount.coerceAtMost(99).toString())
                                    }
                                }
                            }
                            // Compact PC-link state belongs in the app-bar action row, beside the bell and flag.
                            val iconLinkConfigured = !store.getSetting("sync_bridge_endpoint").isNullOrBlank() && !store.getSetting("sync_pairing_key").isNullOrBlank()
                            val iconLinkFresh = pcLinkLastSuccess?.toLongOrNull()?.let { System.currentTimeMillis() - it < 10 * 60 * 1000L } == true
                            val iconStatusFresh = pcLinkStatusUpdatedAt?.toLongOrNull()?.let { System.currentTimeMillis() - it < 60 * 1000L } == true
                            val iconConnected = iconLinkConfigured && iconLinkFresh && ((iconStatusFresh && pcLinkStatus.startsWith("Connected", true)) || !iconStatusFresh)
                            val iconReconnecting = iconLinkConfigured && (pcLinkStatus.startsWith("Reconnecting", true) || pcLinkStatus.startsWith("Offline", true) && iconStatusFresh || !iconLinkFresh && pcLinkLastSuccess == null)
                            val iconColor = when { iconConnected -> Color(0xFF27AE60); iconReconnecting -> Color(0xFFF4B942); else -> Color(0xFFE05B5B) }
                            val iconDescription = when { iconConnected -> "PC link connected"; iconReconnecting -> "PC link reconnecting or awaiting sync"; else -> "PC link offline or not configured" }
                            IconButton(
                                onClick = { showNextLevel = true },
                                modifier = Modifier.semantics { contentDescription = "$iconDescription. Tap for connection details" }
                            ) {
                                Text(
                                    if (iconConnected) "☁✓" else if (iconReconnecting) "☁↻" else "☁×",
                                    color = iconColor,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Box(Modifier.padding(end = 12.dp)) {
                                IconButton(onClick = { showFlags = true }) {
                                    Text("⚑", style = MaterialTheme.typography.titleLarge)
                                }
                                if (liveDashboard.flags.isNotEmpty()) {
                                    Badge(modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd)) {
                                        Text(liveDashboard.flags.size.toString())
                                    }
                                }
                            }
                            if (!googleEmail.isNullOrBlank()) {
                                AsyncImage(
                                    model = googlePhotoUrl,
                                    contentDescription = "Google profile picture",
                                    modifier = Modifier.size(32.dp).clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    )
                    if (profiles.isNotEmpty() && !showMonthToMonthComparison && selectedTab != 6) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            profiles.forEachIndexed { index, profile ->
                                val selected = profile.id == activeProfileId
                                Surface(
                                    modifier = Modifier
                                        .widthIn(min = 72.dp, max = 116.dp)
                                        .height(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { switchProfile(profile) },
                                    color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                                    tonalElevation = if (selected) 3.dp else 0.dp
                                ) {
                                    Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(Modifier.size(22.dp).clip(RoundedCornerShape(7.dp)).background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant), contentAlignment = Alignment.Center) {
                                            Text((index + 1).toString(), color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                                        }
                                        Text(profile.name, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold)
                                    }
                                }
                            }
                            Surface(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        profileEditorNew = true
                                        profileEditorId = null
                                                                                showMyDevicesProfile = true
                                    },
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("+", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    // Connection status is shown only in the app bar; detailed controls remain under Next Level → Health.
                    val linkConfigured = !store.getSetting("sync_bridge_endpoint").isNullOrBlank() && !store.getSetting("sync_pairing_key").isNullOrBlank()
                    val nowMs = System.currentTimeMillis()
                    val linkFresh = pcLinkLastSuccess?.toLongOrNull()?.let { nowMs - it < 10 * 60 * 1000L } == true
                    val statusFresh = pcLinkStatusUpdatedAt?.toLongOrNull()?.let { nowMs - it < 60 * 1000L } == true
                    val linkLabel = when {
                        !linkConfigured -> "PC link not configured"
                        statusFresh && pcLinkStatus.startsWith("Connected", true) && linkFresh -> "PC link connected"
                        statusFresh && pcLinkStatus.startsWith("Reconnecting", true) -> "PC link reconnecting"
                        statusFresh && pcLinkStatus.startsWith("Offline", true) -> "PC link offline; retry scheduled"
                        linkFresh -> "PC link: last sync recent"
                        pcLinkLastSuccess != null -> "PC link offline / no recent sync"
                        else -> "PC link configured; awaiting sync"
                    }
                    val linkColor = when {
                        linkLabel.contains("connected", true) || linkLabel.contains("last sync recent", true) -> Color(0xFF27AE60)
                        linkLabel.contains("reconnecting", true) || linkLabel.contains("awaiting", true) || linkLabel.contains("retry scheduled", true) -> Color(0xFFF4B942)
                        else -> Color(0xFFE05B5B)
                    }
                    if (userScopedNoticePending && !userScopedNoticeBusy && !showSimRegReport) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            tonalElevation = 3.dp,
                            shadowElevation = 2.dp,
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    "Scope update: monitoring, reports and estimates are primarily based on your profile and assigned devices.",
                                    Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                TextButton(onClick = {
                                    store.setSetting(SETTING_USER_SCOPED_NOTICE_SHOWN, "true")
                                    userScopedNoticePending = false
                                }) { Text("Dismiss") }
                            }
                        }
                    }
                    }
                },
                bottomBar = {
                    if (!showMonthToMonthComparison) Column {
                        // Anchored adaptive banner kept at the bottom, separated from navigation.
                        if (BuildConfig.MONETIZED_BUILD && !adsRemoved) {
                            DevMonitorBannerAd(Modifier.fillMaxWidth())
                        }
                        NavigationBar(
                            containerColor = Color(0xFF071426),
                            contentColor = Color.White,
                            tonalElevation = 0.dp
                        ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { DevMonitorNavGlyph("home", selectedTab == 0) },
                            label = { Text("Dashboard") },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Color(0xFF147BFF).copy(alpha = .24f), unselectedIconColor = Color(0xFF9FB0C7), unselectedTextColor = Color(0xFF9FB0C7))
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { DevMonitorNavGlyph("devices", selectedTab == 1) },
                            label = { Text("Devices") },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Color(0xFF147BFF).copy(alpha = .24f), unselectedIconColor = Color(0xFF9FB0C7), unselectedTextColor = Color(0xFF9FB0C7))
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { DevMonitorNavGlyph("agents", selectedTab == 2) },
                            label = { Text("Agents") },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Color(0xFF147BFF).copy(alpha = .24f), unselectedIconColor = Color(0xFF9FB0C7), unselectedTextColor = Color(0xFF9FB0C7))
                        )
                        NavigationBarItem(
                            selected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            icon = { DevMonitorNavGlyph("payments", selectedTab == 3) },
                            label = { Text("Earning Progress") },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Color(0xFF147BFF).copy(alpha = .24f), unselectedIconColor = Color(0xFF9FB0C7), unselectedTextColor = Color(0xFF9FB0C7))
                        )
                        NavigationBarItem(
                            selected = selectedTab == 4,
                            onClick = { selectedTab = 4 },
                            icon = { DevMonitorNavGlyph("settings", selectedTab == 4) },
                            label = { Text("Settings") },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Color(0xFF147BFF).copy(alpha = .24f), unselectedIconColor = Color(0xFF9FB0C7), unselectedTextColor = Color(0xFF9FB0C7))
                        )
                        }
                    }
                }
            ) { padding ->
                if (showMonthToMonthComparison) {
                    val comparison = monthToMonthComparison
                    val currentUserType = store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty().trim().uppercase(Locale.US)
                    val currentStaffLevel = store.getSetting(SETTING_MY_DEVICES_STAFF_LEVEL).orEmpty().trim().uppercase(Locale.US)
                    val canShowChildren = currentUserType == "STAFF" && currentStaffLevel.isNotBlank()
                    Column(
                        Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            "MONTH-ON-MONTH COMPARISON",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "Your performance for the current month compared with the same period last month.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (monthToMonthStaffSearchAllowed()) {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                                Text("SEARCH MONTH-TO-MONTH DATA", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.height(4.dp))
                                Text("Search the current and previous HQ month data", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text(
                                    "Search covers the current and previous HQ monthly snapshots. Device Monitor is only peeked at to enrich matching devices with newer information; it does not expand the search scope.",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(10.dp))
                                TextField(
                                    value = monthToMonthSearchQuery,
                                    onValueChange = { monthToMonthSearchQuery = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    label = { Text("Search device, partner or staff") },
                                    placeholder = { Text("Device ID, partner name/code or staff name") }
                                )
                                if (monthToMonthSearchLoading) {
                                    Spacer(Modifier.height(10.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                        Text("Searching Month-to-Month data…", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                if (!monthToMonthSearchLoading && monthToMonthSearchQuery.trim().length >= 2) {
                                    Spacer(Modifier.height(10.dp))
                                    if (monthToMonthSearchHits.isEmpty()) {
                                        Text("No matching device, partner or staff member was found in the current/previous HQ month data.", style = MaterialTheme.typography.bodySmall)
                                    } else {
                                        monthToMonthSearchHits.forEach { hit ->
                                            AuroraListRow(
                                                title = hit.label,
                                                subtitle = "${hit.type} • ${hit.detail}",
                                                accent = AuroraViolet,
                                                onClick = { openMonthToMonthSearchDetail(hit) },
                                                trailing = { Text("Open", style = MaterialTheme.typography.labelSmall, color = AuroraViolet, fontWeight = FontWeight.Bold) }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (comparison == null) {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                CircularProgressIndicator()
                                Spacer(Modifier.height(10.dp))
                                Text("Calculating month-on-month performance…", fontWeight = FontWeight.SemiBold)
                            }
                        } else {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                Text("YOUR PERFORMANCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(8.dp))
                                Text("As of ${comparison.asOf}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(8.dp))
                                DevMonitorOutlinedButton(
                                    onClick = { refreshMonthToMonthComparison() },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !refreshingMonthToMonthComparison
                                ) {
                                    if (refreshingMonthToMonthComparison) {
                                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Refreshing…")
                                    } else {
                                        Text("Refresh Comparison")
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("This month to date: ${comparison.currentTotal}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                                Text("Same period last month: ${comparison.previousTotal}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                val activeTargetProfile = profiles.firstOrNull { it.id == activeProfileId }
                                val monthlyTarget = activeTargetProfile?.let { if (it.userType.equals("AGENT", true)) 150 else it.monthlyTarget } ?: 0
                                if (monthlyTarget > 0) {
                                    val daysInMonth = comparison.asOf.lengthOfMonth().coerceAtLeast(1)
                                    val expectedToDate = kotlin.math.ceil(monthlyTarget.toDouble() * comparison.asOf.dayOfMonth / daysInMonth).toInt()
                                    val achievementPercent = if (expectedToDate > 0) comparison.currentTotal * 100.0 / expectedToDate else 0.0
                                    val fullMonthPercent = comparison.currentTotal * 100.0 / monthlyTarget
                                    Spacer(Modifier.height(12.dp))
                                    HorizontalDivider()
                                    Spacer(Modifier.height(8.dp))
                                    Text("MONTHLY TARGET", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                    Text("${comparison.currentTotal} / $monthlyTarget activations", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                    LinearProgressIndicator(progress = { (achievementPercent / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                                    Text("Achievement against expected-to-date: ${String.format(Locale.US, "%.1f", achievementPercent)}%", fontWeight = FontWeight.SemiBold)
                                    Text("Expected by day ${comparison.asOf.dayOfMonth}: $expectedToDate • Actual: ${comparison.currentTotal}", style = MaterialTheme.typography.bodySmall)
                                    Text("Full-month target progress: ${String.format(Locale.US, "%.1f", fullMonthPercent)}%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(
                                    "Change: ${if (comparison.delta > 0) "+" else ""}${comparison.delta}" +
                                        (comparison.percentChange?.let { " (${if (it > 0) "+" else ""}${String.format(Locale.US, "%.1f", it)}%)" } ?: ""),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Comparison uses the current and previous HQ monthly snapshots. This month's cutoff comes from the newest loaded-report data or newer Device Monitor data; last month uses the same day-of-month in the previous-month snapshot.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Show the device drill-down whenever this profile has saved devices.
                        // The loader scopes the comparison to that saved list.
                        val canShowDeviceBreakdown = savedMyDevices().isNotEmpty()
                        if (canShowDeviceBreakdown && monthToMonthDeviceComparisons.isEmpty()) {
                            DevMonitorButton(
                                onClick = { loadMonthToMonthDeviceComparisons() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !monthToMonthDeviceLoading
                            ) {
                                if (monthToMonthDeviceLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("View Month-on-Month by Device")
                            }
                        }

                        if (monthToMonthDeviceLoading) {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                    Text("Calculating device month-on-month performance…", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }

                        if (monthToMonthDeviceComparisons.isNotEmpty()) {
                            Text("DEVICE PERFORMANCE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                            monthToMonthDeviceComparisons.forEach { device ->
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                    Text(device.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                    Text("${device.comparison.currentTotal} vs ${device.comparison.previousTotal}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                                    Text(
                                        "Change: ${if (device.comparison.delta > 0) "+" else ""}${device.comparison.delta}" +
                                            (device.comparison.percentChange?.let { " (${if (it > 0) "+" else ""}${String.format(Locale.US, "%.1f", it)}%)" } ?: ""),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        if (canShowChildren && (currentStaffLevel == "CLUSTER HEAD" || currentStaffLevel == "REGIONAL MANAGER") && monthToMonthChildComparisons.isEmpty() && monthToMonthChildLevel.isBlank()) {
                            val buttonText = when (currentStaffLevel) {
                                "CLUSTER HEAD" -> "View Regional Manager Month-on-Month"
                                "REGIONAL MANAGER" -> "View Cluster Manager Month-on-Month"
                                else -> ""
                            }
                            DevMonitorButton(
                                onClick = { loadMonthToMonthChildren() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !monthToMonthChildLoading
                            ) {
                                if (monthToMonthChildLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text(buttonText)
                            }
                        }

                        if (monthToMonthChildLoading) {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                    Text("Calculating ${if (monthToMonthSelectedParent.isBlank()) "hierarchy" else "lower-level"} month-on-month performance…", fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }

                        if (monthToMonthChildComparisons.isNotEmpty()) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${monthToMonthChildLevel.replaceFirstChar { it.uppercase() }} PERFORMANCE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                    Text("Calculated only when requested.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                            }
                            monthToMonthChildComparisons.forEach { child ->
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                    Text(child.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                    Text("${child.comparison.currentTotal} vs ${child.comparison.previousTotal}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                                    Text(
                                        "Change: ${if (child.comparison.delta > 0) "+" else ""}${child.comparison.delta}" +
                                            (child.comparison.percentChange?.let { " (${if (it > 0) "+" else ""}${String.format(Locale.US, "%.1f", it)}%)" } ?: ""),
                                        fontWeight = FontWeight.SemiBold
                                    )

                                }
                            }
                        }
                    }
                } else AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        (fadeIn(tween(260)) + slideInHorizontally(tween(320)) { it / 8 }) togetherWith
                            (fadeOut(tween(180)) + slideOutHorizontally(tween(220)) { -it / 12 })
                    },
                    label = "page-transition"
                ) { page ->
                when (page) {
                    0 -> LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding),
                        state = dashboardListState,
                        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 28.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            AuroraHero(
                                title = "Today's Operations",
                                value = liveDashboard.todayTotal.toString(),
                                subtitle = "SIM registrations today",
                                meta = "${liveDashboard.date}  •  ${liveDashboard.deviceCount} monitored devices",
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        activeProfileId?.let { id -> profiles.firstOrNull { it.id == id } }?.let { activeProfile ->
                            item {
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraEmerald) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Box(Modifier.size(46.dp).clip(CircleShape).background(AuroraEmerald.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                                            Text(activeProfile.name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "D", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = AuroraEmerald)
                                        }
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Text("WELCOME BACK", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold, color = AuroraEmerald)
                                            Text(activeProfile.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                            Text("${activeProfile.userType.lowercase().replaceFirstChar { it.uppercase() }} profile", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        TextButton(onClick = { profileEditorNew = false; profileEditorId = activeProfile.id; showMyDevicesProfile = true }) { Text("Edit") }
                                    }
                                }
                            }
                        }
                        if (profiles.isEmpty()) {
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Column(Modifier.weight(1f)) {
                                        Text("YOUR PROFILE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraBlue)
                                        Text(if (profiles.isEmpty()) "Build your profile first" else "Profile ready", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                        Text(
                                            if (profiles.isEmpty()) "Use the built-in Company Directory — no activation report is required to identify your devices." else "Manage your profile and My Devices scope.",
                                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    DevMonitorButton(onClick = {
                                        profileEditorNew = profiles.isEmpty()
                                        profileEditorId = if (profiles.isEmpty()) null else activeProfileId
                                                                                showMyDevicesProfile = true
                                        showBuildProfileHint = false
                                        store.setSetting("build_profile_hint_seen", "true")
                                    }) { Text("BUILD PROFILE") }
                                }
                            }
                        }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (dashboardRefreshing) "Updating dashboard…" else if (liveDashboard.deviceCount == 0) "Dashboard not yet calculated" else "Last calculated ${liveDashboard.date}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                                DevMonitorOutlinedButton(onClick = { refreshDashboard() }, enabled = !dashboardRefreshing) {
                                    Text(if (dashboardRefreshing) "Updating…" else "↻ Refresh")
                                }
                            }
                        }
                        if (monthEndReminderVisible) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            "Month-end review reminder",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            "This payment cycle closes on the 20th. When you are ready, refresh the dashboard and payment progression to review the latest figures. DevMonitor will not run these operations automatically.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            DevMonitorOutlinedButton(
                                                onClick = { refreshDashboard() },
                                                enabled = !dashboardRefreshing,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text(if (dashboardRefreshing) "Updating…" else "↻ Refresh dashboard")
                                            }
                                            DevMonitorOutlinedButton(
                                                onClick = { selectedTab = 3 },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Open Payments")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            TextField(
                                value = dashboardSearchQuery,
                                onValueChange = { dashboardSearchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(18.dp),
                                label = { Text("Search DevMonitor") },
                                placeholder = { Text("Device, code, partner or alert") },
                                leadingIcon = { Text("⌕", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
                                trailingIcon = {
                                    if (dashboardSearchQuery.isNotBlank()) {
                                        TextButton(onClick = { dashboardSearchQuery = "" }) { Text("Clear") }
                                    }
                                }
                            )
                            if (dashboardSearchQuery.isNotBlank()) {
                                val query = dashboardSearchQuery.trim().uppercase(Locale.US)
                                val flagMatches = liveDashboard.flags.filter {
                                    it.code.contains(query, ignoreCase = true) || it.reason.contains(query, ignoreCase = true)
                                }.take(4)
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                    Text("SEARCH RESULTS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraCyan)
                                    Text(
                                        "Available payment results are shown by source. Newer data appears first.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (dashboardPaymentSearchLoading) {
                                        Spacer(Modifier.height(6.dp))
                                        Text("Checking available sources…", style = MaterialTheme.typography.bodySmall)
                                    } else {
                                        val paymentResults = dashboardPaymentSearchResults
                                        if (paymentResults.isEmpty() && flagMatches.isEmpty()) {
                                            Spacer(Modifier.height(6.dp))
                                            DevMonitorEmptyState(
                                                title = "No matches",
                                                message = "No device, payment source or alert matches that search. Try a device code or alert text."
                                            )
                                        } else {
                                            paymentResults.forEach { result ->
                                                val progression = result.progression
                                                val estimate = result.estimate
                                                val freshness = result.freshnessDate?.let { "Data through $it" } ?: "No usable date"
                                                val status = when {
                                                    estimate != null -> "Payment progression: ${estimate.activations} activations • $freshness"
                                                    progression?.warning != null -> progression.warning!!
                                                    else -> "Payment estimate unavailable from this source"
                                                }
                                                AuroraListRow(
                                                    title = result.deviceId,
                                                    subtitle = "${result.source} • $status",
                                                    accent = if (result.source == "Device Monitor") AuroraBlue else AuroraCyan,
                                                    onClick = if (result.selectable) ({
                                                        dashboardSearchQuery = ""
                                                        dashboardSearchSelectedSource = result.source
                                                        if (result.source == "Loaded Report") {
                                                            // Preserve the selected search source: a Loaded Report result
                                                            // must open the Loaded Report context, not Device Monitor.
                                                            openLoadedReportViewer(result.deviceId)
                                                        } else {
                                                            selectedTab = 1
                                                            openDeviceMonitorPaymentCard(result.deviceId)
                                                        }
                                                    }) else null,
                                                    trailing = {
                                                        Text(
                                                            if (result.selectable) "Open" else "Unavailable",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = if (result.selectable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                )
                                            }
                                            flagMatches.filter { hit -> paymentResults.none { it.deviceId.equals(hit.code, ignoreCase = true) } }.forEach { flag ->
                                                AuroraListRow(
                                                    title = flag.code,
                                                    subtitle = flag.reason,
                                                    accent = MaterialTheme.colorScheme.error,
                                                    onClick = { dashboardSearchQuery = ""; showFlags = true },
                                                    trailing = { Text("Alert", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(
                                    Triple("SMS CHECKER", "Check current standing through SMS", { selectedTab = 1 }),
                                                                        Triple("MY DEVICES", "View and manage your saved devices", { openCheckMyDevices() }),
                                    Triple("LOAD REPORT", "Import and review HQ/SIMReg reports", { openLoadedReportViewer() }),
                                    Triple("EARNING PROGRESS", "Track your progress toward earnings", { selectedTab = 3 })
                                ).chunked(2).forEach { row ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        row.forEach { (title, subtitle, action) ->
                                            val accent = when (title) {
                                                "MY DEVICES" -> AuroraEmerald
                                                "EARNING PROGRESS" -> AuroraGreen
                                                "LOAD REPORT" -> AuroraViolet
                                                else -> AuroraBlue
                                            }
                                            val dashboardKey = when (title) {
                                                "SMS CHECKER" -> "sms"
                                                "MY DEVICES" -> "my_devices"
                                                "LOAD REPORT" -> "load_report"
                                                "EARNING PROGRESS" -> "earning"
                                                else -> title.lowercase(Locale.US)
                                            }
                                            AuroraGlassCard(Modifier.weight(1f).clickable { action() }, accent) {
                                                Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, maxLines = 2)
                                                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // Payment Cycle is an Agent/Partner dashboard feature. Staff profiles
                        // do not need payment-cycle monitoring, so the entire card is hidden.
                        val activeDashboardProfileForPayment = activeProfileId?.let { id -> profiles.firstOrNull { it.id == id } }
                        val dashboardPaymentUserType = (activeDashboardProfileForPayment?.userType
                            ?: store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty())
                            .uppercase(Locale.US)
                        val showPaymentCycle = dashboardPaymentUserType == "AGENT" || dashboardPaymentUserType == "PARTNER"
                        if (showPaymentCycle) {
                        item {
                            val estimate = dashboardCycleEstimate
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraEmerald) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("PAYMENT CYCLE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraEmerald)
                                        Text(PaymentRules.paymentCycleLabel(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    AuroraStatusPill(if (dashboardCycleLoading) "Updating" else if (estimate == null) "Not calculated" else "Ready", if (dashboardCycleLoading) AuroraBlue else if (estimate == null) AuroraEmerald else AuroraGreen)
                                }
                                Spacer(Modifier.height(10.dp))
                                if (estimate != null) {
                                    Text("${estimate.activations}", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold)
                                    Text("Current Activation Achieved", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    if (estimate.nextThreshold != null) {
                                        Spacer(Modifier.height(8.dp))
                                        LinearProgressIndicator(
                                            progress = { (estimate.activations.toFloat() / estimate.nextThreshold!!.toFloat()).coerceIn(0f, 1f) },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(Modifier.height(5.dp))
                                        Text("${estimate.activationsToNext} to ${estimate.nextThreshold} activation tier", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    } else {
                                        Text("Highest configured activation tier reached.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                } else {
                                    Text("Payment progression has not been calculated for this profile yet.", style = MaterialTheme.typography.bodyMedium)
                                }
                                Spacer(Modifier.height(10.dp))
                                Text("Cycle evidence is calculated by the unified payment engine; this card does not create a second payment calculation.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(8.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DevMonitorOutlinedButton(
                                        onClick = {
                                            if (!dashboardCycleLoading) {
                                                dashboardCycleLoading = true
                                                scope.launch {
                                                    val codesSnapshot = codes.toList()
                                                    val asOf = PaymentRules.currentAwareDate()
                                                    val total = withContext(Dispatchers.IO) {
                                                        codesSnapshot.sumOf { code ->
                                                            PaymentEngine.DeviceMonitor.calculate(
                                                                deviceId = code,
                                                                asOfRequested = asOf,
                                                                deviceStore = database,
                                                                companyStore = companyActivations
                                                            ).activations ?: 0
                                                        }
                                                    }
                                                    dashboardCycleTotal = total
                                                    dashboardCycleEstimate = PaymentRules.estimate(total, 0)
                                                    dashboardCycleLoading = false
                                                    feedback.success()
                                                }
                                            }
                                        },
                                        enabled = !dashboardCycleLoading,
                                        modifier = Modifier.weight(1f)
                                    ) { Text(if (dashboardCycleLoading) "Updating…" else "↻ Refresh Progression") }
                                    DevMonitorOutlinedButton(onClick = { selectedTab = 3 }, modifier = Modifier.weight(1f)) { Text("Open Payment Intelligence") }
                                }
                            }
                        }
                        }
                        // ACTION CENTRE is relevant to Agent/Partner device monitoring only.
                        // Staff profiles must never see this dashboard card. Read the active
                        // profile first so the rule follows profile switching immediately,
                        // with the profile store setting retained as the fallback.
                        val activeDashboardProfile = activeProfileId?.let { id -> profiles.firstOrNull { it.id == id } }
                        val dashboardUserType = (activeDashboardProfile?.userType
                            ?: store.getSetting(SETTING_MY_DEVICES_USER_TYPE).orEmpty())
                            .uppercase(Locale.US)
                        val showActionCentre = dashboardUserType == "AGENT" || dashboardUserType == "PARTNER"
                        if (showActionCentre) {
                            item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), if (liveDashboard.flags.isEmpty()) AuroraGreen else MaterialTheme.colorScheme.error) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    AuroraIconBadge(if (liveDashboard.flags.isEmpty()) AuroraGreen else MaterialTheme.colorScheme.error) {
                                        Text(if (liveDashboard.flags.isEmpty()) "✓" else liveDashboard.flags.size.toString(), fontWeight = FontWeight.ExtraBold)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("ACTION CENTRE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = if (liveDashboard.flags.isEmpty()) AuroraGreen else MaterialTheme.colorScheme.error)
                                        Text(if (liveDashboard.flags.isEmpty()) "Nothing needs your attention" else "${liveDashboard.flags.size} item${if (liveDashboard.flags.size == 1) "" else "s"} need attention", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                        Text(if (liveDashboard.flags.isEmpty()) "Your monitored devices are currently clear." else "Company priority: $companyFlags  •  Partner: $partnerFlags", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                if (liveDashboard.flags.isNotEmpty()) {
                                    Spacer(Modifier.height(10.dp))
                                    liveDashboard.flags.take(3).forEach { flag ->
                                        AuroraListRow(
                                            title = flag.code,
                                            subtitle = flag.reason,
                                            accent = MaterialTheme.colorScheme.error,
                                            onClick = { openDeviceMonitorPaymentCard(flag.code) },
                                            trailing = { Text("View", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
                                        )
                                        Spacer(Modifier.height(6.dp))
                                    }
                                    DevMonitorOutlinedButton(onClick = { showFlags = true }, modifier = Modifier.fillMaxWidth()) { Text("Open All Alerts") }
                                }
                            }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                AuroraMetricCard("MTD SALES", liveDashboard.mtdTotal.toString(), Modifier.weight(1f), AuroraBlue)
                                AuroraMetricCard("ACTIVE", liveDashboard.activeTotal.toString(), Modifier.weight(1f), AuroraEmerald)
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                AuroraMetricCard("COMPANY", liveDashboard.companyMtd.toString(), Modifier.weight(1f), AuroraViolet, "MTD")
                                AuroraMetricCard("PARTNER", liveDashboard.partnerMtd.toString(), Modifier.weight(1f), AuroraGreen, "MTD")
                            }
                        }
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraEmerald) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("VISUAL TRENDS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraEmerald)
                                        Spacer(Modifier.height(4.dp))
                                        Text("Month-on-month performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                        Text(
                                            if (trendPoints.isEmpty()) "Refresh when you want to inspect performance movement." else "Latest trend data: ${trendPoints.last().date}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    DevMonitorOutlinedButton(onClick = { showVisualTrends = true }) { Text("Open") }
                                }
                            }
                        }
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), if (liveDashboard.flags.isEmpty()) AuroraCyan else MaterialTheme.colorScheme.error) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("ATTENTION CENTRE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                        Spacer(Modifier.height(4.dp))
                                        Text(if (liveDashboard.flags.isEmpty()) "Everything is clear" else "${liveDashboard.flags.size} items need attention", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                        Text(if (liveDashboard.flags.isEmpty()) "All monitored devices are currently clear." else "Company priority: $companyFlags  •  Partner: $partnerFlags", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Box(Modifier.size(44.dp).background(if (liveDashboard.flags.isEmpty()) AuroraCyan.copy(alpha=.13f) else MaterialTheme.colorScheme.errorContainer, CircleShape), contentAlignment = Alignment.Center) {
                                        Text(if (liveDashboard.flags.isEmpty()) "✓" else liveDashboard.flags.size.toString(), fontWeight = FontWeight.ExtraBold, color = if (liveDashboard.flags.isEmpty()) AuroraCyan else MaterialTheme.colorScheme.error)
                                    }
                                }
                                if (liveDashboard.flags.isNotEmpty()) {
                                    Spacer(Modifier.height(12.dp))
                                    DevMonitorButton(onClick = { showFlags = true }, Modifier.fillMaxWidth()) { Text("Open Flags Centre") }
                                }
                            }
                        }
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("BATCH CONTROL", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                        Spacer(Modifier.height(4.dp))
                                        Text(if (permissionOk) "SMS access ready" else "SMS permission required", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                        Text("Destination $destination", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Box(Modifier.size(42.dp).background(AuroraBlue.copy(alpha=.10f), CircleShape), contentAlignment = Alignment.Center) {
                                        Text("→", color = AuroraBlue, fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                                Spacer(Modifier.height(14.dp))
                                DevMonitorButton(
                                    onClick = {
                                        selectedTab = 1

                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Open Device Monitor") }
                            }
                        }
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                Text("MY DEVICES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(4.dp))
                                Text("Check My Devices", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                                Text(
                                    if (savedMyDevices().isEmpty()) "Set up your profile once, then check your devices from here." else "${savedMyDevices().size} saved device${if (savedMyDevices().size == 1) "" else "s"} ready to check.",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(12.dp))
                                DevMonitorButton(onClick = { openCheckMyDevices() }, modifier = Modifier.fillMaxWidth(), enabled = !checkingMyDevices) {
                                    if (checkingMyDevices) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Check My Devices")
                                }
                            }
                        }

                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                                Text("HQ REPORT INTELLIGENCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.height(4.dp))
                                Text("SIMReg Headquarters Report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("Read SIM Reg or Activations as-at reports for monitoring, hierarchy, performance and payment estimates.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(12.dp))
                                DevMonitorOutlinedButton(onClick = { openLoadedReportViewer() }, Modifier.fillMaxWidth()) { Text("Open SIMReg Report") }
                            }
                        }
                        if (showMyPartnersCard) {
                            item {
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                                    Text(
                                        "MY PARTNERS",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = AuroraViolet
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        "Partner code checks and saved history",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        "Independent workspace with its own saved data",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    DevMonitorButton(
                                        onClick = { deviceMonitorPaymentCode = null; selectedTab = 6 },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text("Open My Partners") }
                                }
                            }
                        }
                        item {
                            val comparison = monthToMonthComparison
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                Text(
                                    "MONTH-ON-MONTH COMPARISON",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Current performance vs the same period last month",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                if (comparison == null) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        if (refreshingMonthToMonthComparison) "Updating your available comparison…" else "No Month-on-Month result is loaded yet.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    Spacer(Modifier.height(10.dp))
                                    Text("As of ${comparison.asOf}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(Modifier.height(6.dp))
                                    Text("This month to date: ${comparison.currentTotal}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                                    Text("Same period last month: ${comparison.previousTotal}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Change: ${if (comparison.delta > 0) "+" else ""}${comparison.delta}" +
                                            (comparison.percentChange?.let { " (${if (it > 0) "+" else ""}${String.format(Locale.US, "%.1f", it)}%)" } ?: ""),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(Modifier.height(12.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DevMonitorOutlinedButton(
                                        onClick = { refreshMonthToMonthComparison(openPage = false) },
                                        modifier = Modifier.weight(1f),
                                        enabled = !refreshingMonthToMonthComparison
                                    ) {
                                        if (refreshingMonthToMonthComparison) {
                                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                            Spacer(Modifier.width(8.dp))
                                            Text("Refreshing…")
                                        } else {
                                            Text("Refresh")
                                        }
                                    }
                                    DevMonitorButton(
                                        onClick = { openMonthToMonthComparison() },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Open Full Comparison")
                                    }
                                }
                            }
                        }
                    }
                    1, 6 -> if (deviceMonitorPaymentCode != null) {
                        val paymentCode = deviceMonitorPaymentCode!!
                        val paymentRecord = records[paymentCode]
                        DevMonitorLogger.screen(
                            "Rendering Device Monitor payment card for $paymentCode; result=${paymentRecord?.result != null}; status=${paymentRecord?.status}"
                        )
                        DevicePaymentCardScreen(
                            row = importedSimRegReport?.rows?.firstOrNull {
                                canonicalDeviceCode(it.deviceId) == canonicalDeviceCode(paymentCode)
                            },
                            localRecord = paymentRecord,
                            reportIsActivation = importedSimRegReport?.isActivationReport == true,
                            reportMonth = importedSimRegReport?.coverageEnd?.let(YearMonth::from),
                            reportCutoffDay = importedSimRegReport?.cutoffDay,
                            companyActivations = companyActivations,
                            myDevicesStore = myDevicesDatabase,
                            deviceMonitorStore = database,
                            deviceMonitorMode = true,
                            paymentDataRevision = paymentDataRevision,
                            profileDisplayName = activeProfileId?.let { id -> profiles.firstOrNull { it.id == id }?.name }.orEmpty(),
                            onBack = {
                                DevMonitorLogger.screen("Returning from Device Monitor payment card for $paymentCode")
                                deviceMonitorPaymentCode = null
                            }
                        )
                    } else LazyColumn(
                        state = monitorListState,
                        modifier = Modifier.fillMaxSize().padding(padding),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column { Text(if (selectedTab == 6) "My Partners" else "Device Monitor", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Text("${codes.size} codes loaded • ${if (selectedTab == 6) "separate database" else "primary database"}") }
                                        // Flags Centre is accessed from the global app-bar icon only; avoid a duplicate Flags control in SMS Checker and My Partners.
                                    }
                                    AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("SMS SIM", style = MaterialTheme.typography.labelMedium)
                                                Text(simLabel(activeSims, selectedSubId), fontWeight = FontWeight.Bold)
                                            }
                                            DevMonitorButton(
                                                onClick = { requestPhoneStatePermission(); refreshSims(); showSimMenu = true },
                                                enabled = !running,
                                                modifier = Modifier
                                            ) { Text("Select SIM") }
                                        }
                                    }
                                    if (selectedTab == 6) {
                                        TextField(
                                            value = partnerReportSearchQuery,
                                            onValueChange = { partnerReportSearchQuery = it },
                                            modifier = Modifier.fillMaxWidth(),
                                            label = { Text("Find partner in loaded report") },
                                            placeholder = { Text("Search partner name or Trade Code") },
                                            singleLine = true,
                                            leadingIcon = { Text("⌕", fontSize = 20.sp, fontWeight = FontWeight.Bold) },
                                            trailingIcon = {
                                                if (partnerReportSearchQuery.isNotBlank()) TextButton(onClick = { partnerReportSearchQuery = "" }) { Text("Clear") }
                                            }
                                        )
                                        val partnerQuery = partnerReportSearchQuery.trim()
                                        val partnerMatches = if (partnerQuery.isBlank()) emptyList() else partnerSearchMatches
                                        if (partnerQuery.isNotBlank()) {
                                            if (partnerMatches.isEmpty()) {
                                                Text("No matching partner in the loaded report. You can still enter a Trade Code manually.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            } else {
                                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    partnerMatches.forEach { partner ->
                                                        Surface(
                                                            modifier = Modifier.fillMaxWidth().clickable {
                                                                val code = partner.tradeCode.trim()
                                                                // Keep the selected, freshly queried metadata available to the result card
                                                                // even if the HQ report was refreshed after My Partners was opened.
                                                                partnerDirectoryRows = partnerDirectoryRows.filterNot {
                                                                    it.tradeCode.trim().equals(code, ignoreCase = true)
                                                                } + partner
                                                                input = (normalizedList(input) + code).distinctBy { it.uppercase(Locale.US) }.joinToString("\n")
                                                                partnerReportSearchQuery = ""
                                                                // Keep the separate SMS Checker partner-code filter untouched.
                                                                // Selecting a partner here adds it to My Partners only; it must not filter the existing code list.
                                                            },
                                                            shape = RoundedCornerShape(12.dp),
                                                            color = AuroraViolet.copy(alpha = 0.08f),
                                                            border = BorderStroke(1.dp, AuroraViolet.copy(alpha = 0.22f))
                                                        ) {
                                                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                                Text(partner.partnerName.ifBlank { "Unnamed partner" }, fontWeight = FontWeight.Bold)
                                                                Text("Trade Code: ${partner.tradeCode}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                                                                Text(listOf(partner.cluster, partner.region, partner.territory).filter { it.isNotBlank() }.joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                                Text("Tap to add", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else if (partnerDirectoryRows.isEmpty()) {
                                            Text("Load a company report to search partner names.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    TextField(
                                        value = input,
                                        onValueChange = {
                                            input = it
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth(),
                                        label = { Text(if (selectedTab == 6) "Paste or type partner codes here" else "Paste or type your Device/Partner codes here") },
                                        placeholder = {
                                            Text(
                                                if (selectedTab == 6) "e.g. PT-001, TRADE-2048 or one per line"
                                                else "e.g. GLO-GD-255D, GLO-GD-256D or paste from Excel"
                                            )
                                        },
                                        supportingText = {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(if (selectedTab == 6) "Partner Trade Codes only • duplicates removed" else "One code per line, comma, semicolon or Excel paste • duplicates removed", style = MaterialTheme.typography.bodySmall)
                                                Text(
                                                    if (selectedTab == 6) "Add list saves; Quick Check checks without saving."
                                                    else if (showZeroDevicesButton) "Add list saves; Quick Check checks without saving. Zero Devices checks zero-current-month-sales devices only."
                                                    else "Add list saves; Quick Check checks without saving.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                if (selectedTab != 6) Text("SMS uses the Device short code.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        },
                                        minLines = if (selectedTab == 6) 2 else 3,
                                        maxLines = if (selectedTab == 6) 5 else 8
                                    )
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        DevMonitorButton(
                                            onClick = {
                                                addCodes(normalizedList(input))
                                                input = ""
                                            },
                                            enabled = !running && input.isNotBlank(),
                                            modifier = Modifier
                                                .weight(1f)
                                        ) { Text("Add list") }
                                        DevMonitorOutlinedButton(onClick = { codes = normalizedList(input); records = emptyMap(); input = ""; persist() }, enabled = !running && input.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Replace") }
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        DevMonitorButton(
                                            onClick = {
                                                val enquiryCodes = normalizedList(input)
                                                if (enquiryCodes.isNotEmpty()) {
                                                    oneOffCodes = enquiryCodes
                                                    oneOffRunRequested = true
                                                    input = ""
                                                    message = if (selectedTab == 6) {
                                                        "Checking ${enquiryCodes.size} partner code${if (enquiryCodes.size == 1) "" else "s"} without changing the saved My Partners list…"
                                                    } else {
                                                        "Checking ${enquiryCodes.size} new device${if (enquiryCodes.size == 1) "" else "s"} without changing My Devices…"
                                                    }
                                                    if (!permissionOk) requestSmsPermissions(enquiryCodes, false) else beginRun(enquiryCodes, false)
                                                }
                                            },
                                            enabled = !running && input.isNotBlank(),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(18.dp)
                                        ) { Text("Quick Check", fontWeight = FontWeight.Bold) }
                                        if (selectedTab != 6 && showZeroDevicesButton) {
                                            DevMonitorOutlinedButton(
                                                onClick = { if (selectedTab != 6) loadZeroDevicesForSmsChecker() },
                                                enabled = !running && !zeroDevicesLoading,
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(18.dp)
                                            ) { Text(if (zeroDevicesLoading) "Finding…" else "Zero Devices", fontWeight = FontWeight.Bold) }
                                        }
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        DevMonitorOutlinedButton(onClick = { importLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }, enabled = !running, modifier = Modifier.weight(1f)) { Text("Load Excel") }
                                        DevMonitorOutlinedButton(
                                            onClick = { showSaveDialog = true },
                                            enabled = !running && codes.isNotEmpty(),
                                            modifier = Modifier
                                                .weight(1f)
                                                .then(if (saveHintActive) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp)) else Modifier)
                                        ) { Text("Save list") }
                                    }
                                    if (saveHintActive) {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { showSaveHelp = true },
                                            shape = RoundedCornerShape(16.dp),
                                            color = AuroraViolet.copy(alpha = .08f),
                                            border = BorderStroke(1.dp, AuroraViolet.copy(alpha = .16f))
                                        ) {
                                            Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Text("💡 Save your code list for reuse", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                                                Text("Tap to learn", style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        DevMonitorOutlinedButton(
                                            onClick = { showSavedLists = true },
                                            enabled = !running,
                                            modifier = Modifier
                                                .weight(1f)
                                                .then(if (saveHintActive) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp)) else Modifier)
                                        ) { Text("Saved") }
                                        DevMonitorOutlinedButton(onClick = { showArchived = true }, enabled = !running, modifier = Modifier.weight(1f)) { Text("Archived") }
                                        DevMonitorOutlinedButton(onClick = { codes = emptyList(); records = emptyMap(); persist() }, enabled = !running && codes.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Clear") }
                                    }
                                }
                            }
                        }
                        item {
                            if (running) {
                                AuroraGlassCard(
                                    Modifier
                                        .fillMaxWidth(),
                                    AuroraBlue
                                ) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Processing ${currentIndex + 1} / ${if (oneOffCodes.isNotEmpty() && oneOffCodes.contains(waitingCode)) oneOffCodes.size else codes.size}", fontWeight = FontWeight.Bold)
                                        Text(waitingCode ?: "")
                                        LinearProgressIndicator(Modifier.fillMaxWidth())
                                        Text("Waiting ${secondsLeft / 60}:${(secondsLeft % 60).toString().padStart(2, '0')}")
                                        DevMonitorButton(onClick = { stopRun() }, Modifier.fillMaxWidth()) { Text("Stop Batch") }
                                    }
                                }
                            } else {
                                val checkedTodayCodes = codes.filter { records[it]?.result != null }
                                val unresolvedCodes = codes.filter { records[it]?.result == null }
                                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    DevMonitorButton(
                                        onClick = { if (!permissionOk) requestSmsPermissions(codes, false) else beginRun(codes, false) },
                                        enabled = codes.isNotEmpty(),
                                        modifier = Modifier
                                            .fillMaxWidth(),
                                        shape = RoundedCornerShape(18.dp)
                                    ) {
                                        Text("▶  Start / Refresh All", fontWeight = FontWeight.Bold)
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                        DevMonitorOutlinedButton(
                                            onClick = { if (!permissionOk) requestSmsPermissions(checkedTodayCodes, false) else beginRun(checkedTodayCodes, false) },
                                            enabled = checkedTodayCodes.isNotEmpty(),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(18.dp)
                                        ) { Text("↻ Recheck (${checkedTodayCodes.size})", fontWeight = FontWeight.SemiBold) }
                                        DevMonitorOutlinedButton(
                                            onClick = { if (!permissionOk) requestSmsPermissions(unresolvedCodes, true) else beginRun(unresolvedCodes, true) },
                                            enabled = unresolvedCodes.isNotEmpty(),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(18.dp)
                                        ) { Text("Continue (${unresolvedCodes.size})", fontWeight = FontWeight.SemiBold) }
                                    }
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                        DevMonitorOutlinedButton(
                                            onClick = { requestSmsRecoveryPermission() },
                                            enabled = codes.isNotEmpty() && !running,
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(18.dp)
                                        ) { Text(if (smsRecoveryPermissionOk) "Recover SMS" else "Enable recovery", fontWeight = FontWeight.SemiBold) }
                                        DevMonitorOutlinedButton(
                                            onClick = { if (!permissionOk) requestSmsPermissions(retryCodes, true) else beginRun(retryCodes, true) },
                                            enabled = retryCodes.isNotEmpty(),
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(18.dp)
                                        ) { Text("Retry (${retryCodes.size})", fontWeight = FontWeight.SemiBold) }
                                    }
                                }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricCard("Success", successful.toString(), Modifier.weight(1f))
                                MetricCard("Timeout", timeouts.toString(), Modifier.weight(1f))
                                MetricCard("Failed", sendFailed.toString(), Modifier.weight(1f))
                            }
                        }
                        if (oneOffCodes.isNotEmpty()) {
                            item {
                                Text("One-off Enquiry", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(
                                    "Checked directly from the enquiry box. These codes are not added to My Devices.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            items(oneOffCodes, key = { "oneoff-$it" }) { code ->
                                val record = records[code]
                                val flag = liveDashboard.flags.firstOrNull { it.code == code }
                                AuroraGlassCard(
                                    Modifier.fillMaxWidth(),
                                    if (flag != null) MaterialTheme.colorScheme.error else AuroraCyan
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Column(Modifier.weight(1f)) {
                                                Text(code, fontWeight = FontWeight.Bold)
                                                Text(if (selectedTab == 6) "ONE-OFF PARTNER CHECK" else "ONE-OFF ENQUIRY", style = MaterialTheme.typography.labelSmall)
                                            }
                                            if (flag != null) AssistChip(onClick = { showFlags = true }, label = { Text(flag.severity) })
                                        }
                                        Text("${record?.status ?: AttemptStatus.QUEUED} • Sent ${record?.repetitionsSent ?: 0}×")
                                        record?.result?.let { result -> Text("Today ${result.today ?: "-"}  •  MTD ${result.mtd ?: "-"}  •  B48 ${result.bar48 ?: "-"}  •  B96 ${result.bar96 ?: "-"}") }
                                        record?.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                                        if (!running && record?.result != null) {
                                            if (selectedTab != 6) {
                                                DevMonitorOutlinedButton(
                                                    onClick = { openDeviceMonitorPaymentCard(code) },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) { Text("Open Payment Estimate") }
                                            }
                                            TextButton(onClick = { if (!permissionOk) requestSmsPermissions(listOf(code), false) else beginRun(listOf(code), false) }) { Text(if (selectedTab == 6) "Recheck partner code" else "Recheck this code") }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            TextField(
                                value = smsListSearchQuery,
                                onValueChange = { smsListSearchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(if (selectedTab == 6) "Find a partner code" else "Find a device") },
                                placeholder = { Text(if (selectedTab == 6) "Search partner codes" else "Search device code") },
                                singleLine = true,
                                leadingIcon = { Text("⌕", fontSize = 20.sp, fontWeight = FontWeight.Bold) },
                                trailingIcon = {
                                    if (smsListSearchQuery.isNotBlank()) {
                                        TextButton(onClick = { smsListSearchQuery = "" }) { Text("Clear") }
                                    }
                                }
                            )
                        }
                        item {
                            val shownCount = codes.count { it.contains(smsListSearchQuery.trim(), ignoreCase = true) }
                            Text(
                                if (smsListSearchQuery.isBlank()) {
                                    if (selectedTab == 6) "My Partners Result" else "My Devices Results"
                                } else {
                                    if (selectedTab == 6) "Matching Partner Codes ($shownCount)" else "Matching Devices ($shownCount)"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (selectedTab != 6 && checkingMyDevices) {
                            item { DevMonitorLoadingState("Checking My Devices…", "Waiting for the current Device Monitor pass to finish.") }
                        } else if (codes.isEmpty()) {
                            item {
                                if (selectedTab == 6) {
                                    DevMonitorEmptyState(
                                        title = "No partner codes saved",
                                        message = "Add partner Trade Codes above, or load a saved partner-code list to begin checking."
                                    )
                                } else {
                                    DevMonitorEmptyState(
                                        title = "No devices in this profile",
                                        message = "Set up or update the My Devices profile from the latest Loaded Report before starting a check.",
                                        actionLabel = "Open My Devices setup",
                                        onAction = { if (selectedTab != 6) showMyDevicesProfile = true }
                                    )
                                }
                            }
                        }
                        val visibleCodes = codes.filter { it.contains(smsListSearchQuery.trim(), ignoreCase = true) }
                        itemsIndexed(visibleCodes, key = { _, code -> code }) { index, code ->
                            val record = records[code]
                            val flag = liveDashboard.flags.firstOrNull { it.code == code }
                            val result = record?.result
                            val ownershipLabel = if (Ownership.from(code) == Ownership.COMPANY) "COMPANY" else "PARTNER"
                            val statusLabel = record?.status?.name ?: AttemptStatus.QUEUED.name
                            val cardAccent = if (flag != null) {
                                MaterialTheme.colorScheme.error
                            } else {
                                when (index % 3) {
                                    0 -> AuroraBlue
                                    1 -> AuroraEmerald
                                    else -> AuroraViolet
                                }
                            }
                            AuroraGlassCard(
                                Modifier.fillMaxWidth(),
                                cardAccent
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                            val partnerDetail = if (selectedTab == 6) partnerDirectoryRows.firstOrNull { it.tradeCode.trim().equals(code.trim(), ignoreCase = true) } else null
                                            if (partnerDetail?.partnerName?.isNotBlank() == true) {
                                                Text(partnerDetail.partnerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                                Text("Trade Code: ${partnerDetail.tradeCode}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                                val locationDetails = listOf(partnerDetail.cluster, partnerDetail.region, partnerDetail.territory).filter { it.isNotBlank() }.joinToString(" • ")
                                                if (locationDetails.isNotBlank()) Text(locationDetails, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            } else Text(if (selectedTab == 6) "Trade Code: $code" else code, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                if (selectedTab != 6) AssistChip(onClick = {}, label = { Text(ownershipLabel) }, enabled = false)
                                                Text(statusLabel, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        if (flag != null) {
                                            AssistChip(onClick = { showFlags = true }, label = { Text(flag.severity) })
                                        }
                                    }

                                    if (selectedTab == 6) {
                                        val fork3 = fork3PartnerPerformance[code.trim().uppercase(Locale.US)]
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(14.dp),
                                            color = AuroraEmerald.copy(alpha = 0.07f),
                                            border = BorderStroke(1.dp, AuroraEmerald.copy(alpha = 0.24f))
                                        ) {
                                            Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("ACTIVATION PERFORMANCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraEmerald)
                                                Text("Device activation estimates", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                when {
                                                    fork3PerformanceLoading -> Text("Calculating from available device records…", style = MaterialTheme.typography.bodySmall)
                                                    fork3 == null -> Text("No partner activation calculation is available yet.", style = MaterialTheme.typography.bodySmall)
                                                    fork3.deviceCount == 0 -> Text("No devices are currently mapped to this Trade Code in the retained HQ report.", style = MaterialTheme.typography.bodySmall)
                                                    else -> {
                                                        Text("Cycle: ${fork3.cycleStart} – ${fork3.cycleEnd}  •  ${fork3.deviceCount} mapped device${if (fork3.deviceCount == 1) "" else "s"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                                val metric = fork3.deviceMonitor
                                                                Text("DEVICE MONITOR", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                                                Text(metric.total?.toString() ?: "Not available", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                                                Text(
                                                                    when {
                                                                        metric.mappedDevices == 0 -> "No mapped devices"
                                                                        metric.total == null -> "0/${metric.mappedDevices} devices with values"
                                                                        metric.complete -> "${metric.devicesWithValue}/${metric.mappedDevices} devices • complete"
                                                                        else -> "Subtotal • ${metric.devicesWithValue}/${metric.mappedDevices} devices; ${metric.unavailableDevices} unavailable"
                                                                    },
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                                )
                                                                metric.through?.let { Text("Known through $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                                            }
                                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                                val metric = fork3.loadedReport
                                                                Text("LOADED REPORT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                                                Text(metric.total?.toString() ?: "Not available", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                                                Text(
                                                                    when {
                                                                        metric.mappedDevices == 0 -> "No mapped devices"
                                                                        metric.total == null -> "0/${metric.mappedDevices} devices with values"
                                                                        metric.complete -> "${metric.devicesWithValue}/${metric.mappedDevices} devices • complete"
                                                                        else -> "Subtotal • ${metric.devicesWithValue}/${metric.mappedDevices} devices; ${metric.unavailableDevices} unavailable"
                                                                    },
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                                )
                                                                metric.through?.let { Text("Known through $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                                            }
                                                        }
                                                        if (!fork3.deviceMonitor.complete || !fork3.loadedReport.complete) Text("Partial totals exclude devices without valid values.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (result != null) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                            listOf(
                                                "Today" to (result.today ?: "-").toString(),
                                                "MTD" to (result.mtd ?: "-").toString(),
                                                "B48" to (result.bar48 ?: "-").toString(),
                                                "B96" to (result.bar96 ?: "-").toString()
                                            ).forEach { (label, value) ->
                                                Surface(
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = cardAccent.copy(alpha = 0.07f),
                                                    border = BorderStroke(1.dp, cardAccent.copy(alpha = 0.14f))
                                                ) {
                                                    Column(
                                                        Modifier.padding(horizontal = 6.dp, vertical = 7.dp),
                                                        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                                                    ) {
                                                        Text(
                                                            label,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            fontWeight = FontWeight.Bold,
                                                            maxLines = 1
                                                        )
                                                        Text(
                                                            value,
                                                            style = MaterialTheme.typography.titleMedium,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            maxLines = 1
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                        if (selectedTab == 6) {
                                            DevMonitorOutlinedButton(
                                                onClick = {
                                                    // Use the same retained HQ partner directory that populates the visible partner name above.
                                                    val detail = partnerDirectoryRows.firstOrNull { it.tradeCode.trim().equals(code.trim(), ignoreCase = true) }
                                                    val fork3 = fork3PartnerPerformance[code.trim().uppercase(Locale.US)]
                                                    val fork3Text = fork3?.let {
                                                        "\nActivation Performance (Fork 3)\nDevice Monitor: ${it.deviceMonitor.total?.toString() ?: "Not available"}${if (it.deviceMonitor.total != null && !it.deviceMonitor.complete) " subtotal" else ""} (${it.deviceMonitor.devicesWithValue}/${it.deviceMonitor.mappedDevices} devices)\nLoaded Report: ${it.loadedReport.total?.toString() ?: "Not available"}${if (it.loadedReport.total != null && !it.loadedReport.complete) " subtotal" else ""} (${it.loadedReport.devicesWithValue}/${it.loadedReport.mappedDevices} devices)"
                                                    }.orEmpty()
                                                    val metrics = (if (result != null) "Today: ${result.today ?: "-"}   MTD: ${result.mtd ?: "-"}\nB48: ${result.bar48 ?: "-"}   B96: ${result.bar96 ?: "-"}" else "Status: $statusLabel\nNo successful result available yet") + fork3Text
                                                    ReportExportPack.sharePartnerResultCardAsync(
                                                        context, detail?.partnerName.orEmpty(), code,
                                                        detail?.cluster.orEmpty(), detail?.region.orEmpty(), detail?.territory.orEmpty(), metrics
                                                    ) { ok ->
                                                        if (!ok) android.widget.Toast.makeText(context, "Could not create the partner result image", android.widget.Toast.LENGTH_LONG).show()
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                                enabled = !running
                                            ) { Text("Share partner result as image") }
                                        }
                                    } else {
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(14.dp),
                                            color = AuroraCyan.copy(alpha = 0.08f),
                                            border = BorderStroke(1.dp, AuroraCyan.copy(alpha = 0.18f))
                                        ) {
                                            Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text("WAITING FOR RESULT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold)
                                                Text(if (selectedTab == 6) "Run or recheck this partner code to populate its result." else "Run or recheck this device to populate its performance and payment pathway.", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }

                                    flag?.let {
                                        Text(it.reason, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    }
                                    record?.error?.let {
                                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                    }

                                    if (!running && result != null) {
                                        if (selectedTab == 6) {
                                            DevMonitorOutlinedButton(
                                                onClick = { if (!permissionOk) requestSmsPermissions(listOf(code), false) else beginRun(listOf(code), false) },
                                                modifier = Modifier.fillMaxWidth()
                                            ) { Text("Recheck partner code") }
                                        } else {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                DevMonitorButton(
                                                    onClick = {
                                                        DevMonitorLogger.screen(
                                                            "Device Monitor EARNING PROGRESS button tapped: code=$code; hasResult=${record?.result != null}"
                                                        )
                                                        openDeviceMonitorPaymentCard(code)
                                                    },
                                                    modifier = Modifier.weight(1f)
                                                ) { Text("EARNING PROGRESS") }
                                                DevMonitorOutlinedButton(
                                                    onClick = { if (!permissionOk) requestSmsPermissions(listOf(code), false) else beginRun(listOf(code), false) },
                                                    modifier = Modifier.weight(1f)
                                                ) { Text("Recheck") }
                                            }
                                        }
                                        if (selectedTab != 6) AnimatedVisibility(
                                            visible = paymentGateMessageCode == canonicalDeviceCode(code) && paymentGateMessage != null,
                                            enter = fadeIn(animationSpec = tween(450)),
                                            exit = fadeOut(animationSpec = tween(650))
                                        ) {
                                            AuroraGlassCard(Modifier.fillMaxWidth(), MaterialTheme.colorScheme.error) {
                                                Text("Payment history needed", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                                                Spacer(Modifier.height(4.dp))
                                                Text(
                                                    paymentGateMessage.orEmpty(),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                                Spacer(Modifier.height(8.dp))
                                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    DevMonitorButton(
                                                        onClick = {
                                                            paymentGateMessage = null
                                                            paymentGateMessageCode = null
                                                            showSimRegReport = true
                                                            selectedTab = 5
                                                        },
                                                        modifier = Modifier.weight(1f)
                                                    ) { Text("Load Company Report") }
                                                    DevMonitorOutlinedButton(
                                                        onClick = {
                                                            paymentGateMessage = null
                                                            paymentGateMessageCode = null
                                                            if (!permissionOk) requestSmsPermissions(listOf(code), false) else beginRun(listOf(code), false)
                                                        },
                                                        modifier = Modifier.weight(1f)
                                                    ) { Text("Recheck Device") }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DevMonitorOutlinedButton(
                                    onClick = { showExportMenu = true },
                                    enabled = records.isNotEmpty(),
                                    modifier = Modifier
                                        .weight(1f)
                                ) { Text("Export Excel") }
                                DevMonitorOutlinedButton(
                                    onClick = { showDashboard = true },
                                    modifier = Modifier
                                        .weight(1f)
                                ) { Text("Summary") }
                            }
                        }
                        item {
                            DevMonitorOutlinedButton(onClick = { showSnapshotMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("Share Daily Snapshot") }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DevMonitorOutlinedButton(onClick = { showDatabase = true }, modifier = Modifier.weight(1f)) { Text("Database") }
                                DevMonitorOutlinedButton(onClick = { showHistory = true }, modifier = Modifier.weight(1f)) { Text("History") }
                            }
                        }
                    }
                    5 -> SimRegReportScreen(
                        modifier = Modifier.fillMaxSize().padding(padding),
                        report = importedSimRegReport,
                        loading = importingSimReg,
                        resolvingSavedReport = loadingSavedReport,
                        localRecords = records,
                        companyActivations = companyActivations,
                        deviceMonitorStore = database,
                        myDevicesStore = myDevicesDatabase,
                        priorityStaffName = profiles.firstOrNull { it.id == activeProfileId }?.staffName.orEmpty(),
                        priorityRegion = profiles.firstOrNull { it.id == activeProfileId }?.region.orEmpty(),
                        priorityDivision = profiles.firstOrNull { it.id == activeProfileId }?.division.orEmpty(),
                        onUpdateMyDevices = { refreshMyDevicesFromProfile(startDeviceMonitor = false) },
                        partnerThreshold = partnerActivationTarget,
                        onPartnerThresholdChanged = { value ->
                            partnerActivationTarget = value.coerceAtLeast(1)
                            store.setSetting(SETTING_PARTNER_TARGET, partnerActivationTarget.toString())
                        },
                        onImport = { simRegReportLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) },
                        onReportTableReady = {
                            if (importingSimReg) {
                                simRegLoadingTitle = "Report ready"
                                simRegLoadingProgress = 1f
                                importingSimReg = false
                                simRegImportMessage = ""
                            }
                        },
                        onOnlineImport = {
                            if (NetworkUtils.hasActiveInternet(this@MainActivity)) showOnlineReports = true
                            else message = "Online Company Reports require an active Internet connection."
                        },
                        onClose = { showSimRegReport = false; selectedTab = 0; if (userScopedNoticePending) userScopedNoticeBusy = false }
                    )
                    2 -> LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                Text("AGENTS & PARTNERS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.tertiary)
                                Spacer(Modifier.height(4.dp))
                                Text("People, partners & devices", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                                Text("Saved agents are shown here automatically. Open a person to manage contact details and linked devices.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(12.dp))
                                DevMonitorButton(onClick = { showAgents = true }, Modifier.fillMaxWidth()) { Text("Add agent or partner") }
                            }
                        }
                        items(database.agents().also { agentRefreshToken }, key = { it.id }) { agent ->
                            Card(Modifier.fillMaxWidth().clickable { showAgents = true }) {
                                Row(
                                    Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    val agentPhoto = agent.photoPath
                                        ?.takeIf { it.isNotBlank() }
                                        ?.let { File(it) }
                                        ?.takeIf { it.exists() && it.isFile && it.length() > 0L }
                                    if (agentPhoto != null) {
                                        AsyncImage(
                                            model = agentPhoto,
                                            contentDescription = "${agent.name} photo",
                                            modifier = Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("👤", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(agent.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        if (agent.address.isNotBlank()) Text(agent.address, style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "Linked devices: ${database.devicesForAgent(agent.id).joinToString().ifBlank { "None yet" }}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text("Tap to manage details and device links", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                        if (database.agents().isEmpty()) item { Text("No saved agents or partners yet. Use Add agent or partner to import a contact or enter details.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    3 -> Box(Modifier.fillMaxSize().padding(padding)) {
                        PaymentLandingScreen(
                            report = importedSimRegReport,
                            localRecords = records,
                            agents = database.agents(),
                            companyActivations = companyActivations,
                            myDevicesStore = myDevicesDatabase,
                            deviceMonitorStore = database,
                            paymentDataRevision = paymentDataRevision
                        )

                    }
                    else -> LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("SETTINGS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.tertiary)
                                Text("Control centre", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                                Text("Customize DevMonitor and manage the parts of the app that affect everyday use.")

                                Text("General", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                        Text("Theme", fontWeight = FontWeight.SemiBold)
                                        Text(when (themePreference) { "light" -> "Light"; "dark" -> "Dark"; else -> "System default" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilterChip(selected = themePreference == "system", onClick = { themePreference = "system"; store.setSetting(SETTING_THEME, "system") }, label = { Text("System") }, modifier = Modifier.weight(1f))
                                            FilterChip(selected = themePreference == "light", onClick = { themePreference = "light"; store.setSetting(SETTING_THEME, "light") }, label = { Text("Light") }, modifier = Modifier.weight(1f))
                                            FilterChip(selected = themePreference == "dark", onClick = { themePreference = "dark"; store.setSetting(SETTING_THEME, "dark") }, label = { Text("Dark") }, modifier = Modifier.weight(1f))
                                        }
                                        Text("Use System to follow your phone's appearance automatically.", style = MaterialTheme.typography.bodySmall)
                                    }

                                Text("Monitor", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                        Text("Device Monitor", fontWeight = FontWeight.SemiBold)
                                        Text("SMS destinations: ${destinations.size} configured • Retention: $retention months", style = MaterialTheme.typography.bodySmall)
                                        DevMonitorButton(onClick = { showSettings = true }, Modifier.fillMaxWidth()) { Text("Open Monitor Settings") }
                                    }

                                Text("My Devices", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    "Save your identity and device scope once so Check My Devices can filter the Loaded Report automatically.",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                DevMonitorOutlinedButton(onClick = { profileEditorNew = false; profileEditorId = activeProfileId; showMyDevicesProfile = true }, Modifier.fillMaxWidth()) {
                                    Text(if (store.getSetting(SETTING_MY_DEVICES_SETUP) == "true") "Manage My Devices Profile" else "Set Up My Devices Profile")
                                }
                                Text("Account & Cloud Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                                        Text("DevMonitor Account", fontWeight = FontWeight.SemiBold)
                                        Text("Google account", fontWeight = FontWeight.SemiBold)
                                        if (!googleEmail.isNullOrBlank()) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                AsyncImage(
                                                    model = googlePhotoUrl,
                                                    contentDescription = "Google profile picture",
                                                    modifier = Modifier.size(48.dp).clip(CircleShape),
                                                    contentScale = ContentScale.Crop
                                                )
                                                Column(Modifier.weight(1f)) {
                                                    Text(googleName?.takeIf { it.isNotBlank() } ?: "Google user", fontWeight = FontWeight.SemiBold)
                                                    Text(googleEmail.orEmpty(), style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                        } else {
                                            Text("Not connected", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            if (googleEmail == null) {
                                                DevMonitorButton(onClick = {
                                                    if (NetworkUtils.hasActiveInternet(this@MainActivity)) {
                                                        googleSignInLauncher.launch(GoogleSignIn.getClient(this@MainActivity, googleOptions).signInIntent)
                                                    } else {
                                                        message = NetworkUtils.OFFLINE_MESSAGE
                                                    }
                                                }, Modifier.weight(1f), enabled = !cloudBusy) { Text("Sign in") }
                                            } else {
                                                DevMonitorOutlinedButton(onClick = {
                                                    GoogleSignIn.getClient(this@MainActivity, googleOptions).signOut().addOnCompleteListener {
                                                         FirebaseAuth.getInstance().signOut()
                                                         googleEmail = null
                                                         googleName = null
                                                         googlePhotoUrl = null
                                                         store.setSetting(SETTING_GOOGLE_EMAIL, "")
                                                         store.setSetting(SETTING_GOOGLE_NAME, "")
                                                         store.setSetting(SETTING_GOOGLE_PHOTO, "")
                                                         message = "Google/Firebase account disconnected"
                                                     }
                                                }, Modifier.weight(1f), enabled = !cloudBusy) { Text("Sign out") }
                                            }
                                        }
                                        if (googleEmail.isNullOrBlank()) {
                                            Text("Connect your Google account to enable backup and restore.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            DevMonitorButton(onClick = {
                                                if (!NetworkUtils.hasActiveInternet(this@MainActivity)) {
                                                    message = "Cloud backup requires an active Internet connection."
                                                } else {
                                                    val account = GoogleSignIn.getLastSignedInAccount(this@MainActivity)
                                                    if (account == null) message = "Sign in to Google first" else {
                                                        cloudBusy = true
                                                    scope.launch {
                                                        runCatching {
                                                            database.checkpointForBackup()
                                                            GoogleDriveBackup.backup(this@MainActivity, account, database.databaseFile())
                                                        }.onSuccess { message = it }.onFailure { message = "Backup failed: ${it.message ?: "unknown error"}" }
                                                        cloudBusy = false
                                                    }
                                                    }
                                                }
                                            }, Modifier.weight(1f), enabled = googleEmail != null && !cloudBusy) { Text(if (cloudBusy) "Working…" else "Backup") }
                                            DevMonitorOutlinedButton(onClick = {
                                                if (!NetworkUtils.hasActiveInternet(this@MainActivity)) {
                                                    message = "Cloud restore requires an active Internet connection."
                                                } else {
                                                    val account = GoogleSignIn.getLastSignedInAccount(this@MainActivity)
                                                    if (account == null) message = "Sign in to Google first" else {
                                                        cloudBusy = true
                                                    scope.launch {
                                                        val temp = File(cacheDir, "fieldpulse-cloud-restore.db")
                                                        runCatching { GoogleDriveBackup.restore(this@MainActivity, account, temp); installRestoredDatabase(temp) }
                                                            .onSuccess { message = "Cloud backup restored. Reloading DevMonitor…"; cloudBusy = false; window.decorView.postDelayed({ recreate() }, 250) }
                                                            .onFailure { temp.delete(); message = "Restore failed: ${it.message ?: "unknown error"}"; cloudBusy = false }
                                                    }
                                                    }
                                                }
                                            }, Modifier.weight(1f), enabled = googleEmail != null && !cloudBusy) { Text("Restore") }
                                        }
                                    }

                                Text("Data & Storage", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraGreen) {
                                        Text("Local app data", fontWeight = FontWeight.SemiBold)
                                        Text("${store.countCodes()} codes • ${store.countRecords()} current records • ${store.countHistory()} history records", style = MaterialTheme.typography.bodySmall)
                                        Text("DevMonitor keeps its operational database on this device unless you deliberately back it up or share a file.", style = MaterialTheme.typography.bodySmall)
                                    }

                                if (BuildConfig.MONETIZED_BUILD) {
                                    Text("Premium", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    if (!adsRemoved) DevMonitorOutlinedButton(onClick = { showBilling = true }, Modifier.fillMaxWidth()) { Text("Premium — Remove Ads") }
                                    else Text("Premium is active — ads and export limits are removed.", fontWeight = FontWeight.SemiBold)
                                }

                                HorizontalDivider()
                                Text("App version", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                    Text("DevMonitor ${BuildConfig.VERSION_NAME}", fontWeight = FontWeight.SemiBold)
                                    Text("Version code ${BuildConfig.VERSION_CODE}", style = MaterialTheme.typography.bodySmall)
                                }
                                DevMonitorOutlinedButton(onClick = {
                                    scope.launch {
                                        val update = withContext(Dispatchers.IO) { appVersionManager.checkUpdateAvailable() }
                                        if (update != null) {
                                            versionUpdateReason = update.reason
                                            versionUpdateInfo = update
                                            DevMonitorAnalytics.log(this@MainActivity, "update_prompt_shown", mapOf("prompt_type" to "manual_check"))
                                        } else {
                                            addNotification("DevMonitor is up to date", "No newer version is currently configured.", "info")
                                            DevMonitorAnalytics.log(this@MainActivity, "update_check_complete", mapOf("result" to "up_to_date"))
                                        }
                                    }
                                }, Modifier.fillMaxWidth()) { Text("Check for updates") }

                                val canManageBroadcasts = broadcastReleaseManager.isCurrentUserBroadcastAdmin()
                                if (canManageBroadcasts) {
                                    DevMonitorOutlinedButton(onClick = {
                                        showBroadcastCentre = true
                                        broadcastDraft = activeBroadcast?.message.orEmpty()
                                        broadcastPlacement = activeBroadcast?.placement ?: "TOP"
                                        broadcastStatus = ""
                                    }, Modifier.fillMaxWidth()) { Text("Broadcast Centre") }
                                }
                                if (canManageBroadcasts) {
                                    AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                                        Text("Broadcast connection check", fontWeight = FontWeight.SemiBold)
                                        Text(broadcastDiagnostic, style = MaterialTheme.typography.bodySmall)
                                        DevMonitorOutlinedButton(onClick = {
                                            scope.launch {
                                                broadcastDiagnostic = "Checking Firestore server…"
                                                val check = withContext(Dispatchers.IO) { broadcastReleaseManager.checkBroadcastFromServer() }
                                                activeBroadcast = check.broadcast
                                                broadcastDiagnostic = check.status
                                            }
                                        }, Modifier.fillMaxWidth()) { Text("Retry broadcast check") }
                                    }
                                }
                                DevMonitorOutlinedButton(onClick = {
                                    scope.launch {
                                        val generated = broadcastReleaseManager.bundledReleaseNotes()
                                        val remote = withContext(Dispatchers.IO) { broadcastReleaseManager.remoteReleaseNotes(BuildConfig.VERSION_CODE.toLong()) }
                                        whatsNewHighlights = remote.ifEmpty { generated }
                                        if (whatsNewHighlights.isNotEmpty()) showWhatsNew = true
                                        else addNotification("What's New", "No release highlights are bundled for this version yet.", "info")
                                    }
                                }, Modifier.fillMaxWidth()) { Text("What's New in this version") }
                                Text("More", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                DevMonitorOutlinedButton(onClick = { showFiles = true }, Modifier.fillMaxWidth()) { Text("Files & Analysis") }
                                DevMonitorOutlinedButton(onClick = { showAbout = true }, Modifier.fillMaxWidth()) { Text("About the App") }
                                DevMonitorOutlinedButton(onClick = { showFeedback = true }, Modifier.fillMaxWidth()) { Text("Feedback & Suggestions") }
                            } }
                        }
                    }
                }
                }
            }
            }
            activeBroadcast?.let { broadcast ->
                var showScheduledBroadcast by remember(broadcast.updatedAtMillis) { mutableStateOf(false) }
                LaunchedEffect(broadcast.updatedAtMillis, broadcast.expiresAtMillis) {
                    // Show for 15 seconds at the start of each 5-minute interval; never after 48 hours.
                    while (true) {
                        val now = System.currentTimeMillis()
                        val start = if (broadcast.updatedAtMillis > 0L) broadcast.updatedAtMillis else now
                        val elapsed = (now - start).coerceAtLeast(0L)
                        val withinTwoDays = elapsed < 48L * 60L * 60L * 1000L &&
                            (broadcast.expiresAtMillis <= 0L || now < broadcast.expiresAtMillis)
                        showScheduledBroadcast = withinTwoDays && (elapsed % (5L * 60L * 1000L)) < 15_000L
                        if (!withinTwoDays) break
                        delay(1000L)
                    }
                    showScheduledBroadcast = false
                }
                if (showScheduledBroadcast) {
                    val tickerTransition = rememberInfiniteTransition(label = "broadcastTicker")
                    val tickerOffset by tickerTransition.animateFloat(
                        initialValue = 1f, targetValue = -1f,
                        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), repeatMode = RepeatMode.Restart),
                        label = "broadcastTickerOffset"
                    )
                    Box(
                        modifier = Modifier.align(if (broadcast.placement == "BOTTOM") Alignment.BottomCenter else Alignment.TopCenter)
                            .fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp)).background(AuroraGreen.copy(alpha = 0.97f))
                            .heightIn(min = 38.dp).padding(horizontal = 12.dp, vertical = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = "📣  ${broadcast.message}     •     ",
                            color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1,
                            modifier = Modifier.fillMaxWidth().graphicsLayer { translationX = tickerOffset * 280.dp.toPx() }
                        )
                    }
                }
            }

            }
        }

        val floatingBusy = importingSimReg || companySkeletonLoading || checkingMyDevices || onlineReportLoading || partnerSummaryLoading ||
            dashboardCycleLoading || dashboardRefreshing || refreshingMonthToMonthComparison || monthToMonthChildLoading ||
            monthToMonthDeviceLoading || monthToMonthSearchLoading || monthToMonthDetailLoading
        if (floatingBusy) {
            val floatingTitle: String
            val floatingStep: String
            val floatingProgress: Float
            val floatingDetail: String
            when {
                companySkeletonLoading -> {
                    floatingTitle = companySkeletonLoadingTitle
                    floatingStep = companySkeletonLoadingMessage.ifBlank { "Building lightweight company identity data…" }
                    floatingProgress = companySkeletonLoadingProgress
                    floatingDetail = "Company Directory"
                }
                importingSimReg -> {
                    floatingTitle = simRegLoadingTitle
                    floatingStep = simRegImportMessage.ifBlank { "Working through the report…" }
                    floatingProgress = simRegLoadingProgress
                    floatingDetail = "HQ report import"
                }
                checkingMyDevices -> {
                    floatingTitle = "Checking My Devices…"
                    floatingStep = "Checking the requested device records"
                    floatingProgress = 0.60f
                    floatingDetail = "Device lookup"
                }
                onlineReportLoading -> {
                    floatingTitle = "Loading online report…"
                    floatingStep = "Downloading the selected HQ workbook"
                    floatingProgress = 0.30f
                    floatingDetail = "Online report"
                }
                partnerSummaryLoading -> {
                    floatingTitle = "Getting partner summary…"
                    floatingStep = "Preparing the requested summary"
                    floatingProgress = 0.65f
                    floatingDetail = "Partner summary"
                }
                monthToMonthDetailLoading -> {
                    floatingTitle = "Opening MOM result…"
                    floatingStep = "Preparing the selected comparison"
                    floatingProgress = 0.90f
                    floatingDetail = "Month-on-Month"
                }
                monthToMonthSearchLoading -> {
                    floatingTitle = "Searching MOM data…"
                    floatingStep = "Searching the two monthly HQ stores"
                    floatingProgress = 0.55f
                    floatingDetail = "Month-on-Month"
                }
                refreshingMonthToMonthComparison -> {
                    floatingTitle = "Refreshing MOM comparison…"
                    floatingStep = "Refreshing the selected comparison"
                    floatingProgress = 0.75f
                    floatingDetail = "Month-on-Month"
                }
                monthToMonthChildLoading -> {
                    floatingTitle = "Building MOM team comparison…"
                    floatingStep = "Preparing the selected team view"
                    floatingProgress = 0.70f
                    floatingDetail = "Month-on-Month"
                }
                monthToMonthDeviceLoading -> {
                    floatingTitle = "Building device comparison…"
                    floatingStep = "Preparing the selected device view"
                    floatingProgress = 0.70f
                    floatingDetail = "Month-on-Month"
                }
                dashboardCycleLoading -> {
                    floatingTitle = "Updating payment progression…"
                    floatingStep = "Refreshing the requested progression view"
                    floatingProgress = 0.80f
                    floatingDetail = "Earning Progress"
                }
                dashboardRefreshing -> {
                    floatingTitle = "Refreshing dashboard…"
                    floatingStep = "Updating the requested dashboard view"
                    floatingProgress = 0.75f
                    floatingDetail = "Dashboard refresh"
                }
                else -> {
                    floatingTitle = "Working…"
                    floatingStep = "Completing the requested operation"
                    floatingProgress = 0.50f
                    floatingDetail = "DevMonitor"
                }
            }
            DevMonitorFloatingLoader(floatingTitle, floatingStep, floatingProgress, floatingDetail)
        }

        if (showBilling) {
            val monthlyPrice = monthlyProduct?.subscriptionOfferDetails
                ?.firstOrNull()?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice
            val yearlyPrice = yearlyProduct?.subscriptionOfferDetails
                ?.firstOrNull()?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice
            AlertDialog(
                onDismissRequest = { showBilling = false },
                title = { Text("Remove all ads") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Choose a Premium plan to remove banner, interstitial and rewarded ads.")
                        Text("Monthly subscription" + (monthlyPrice?.let { " • $it/month" } ?: " • ₦2,000/month"))
                        Text("Yearly subscription" + (yearlyPrice?.let { " • $it/year" } ?: " • ₦20,000/year"))
                        Text(
                            "Purchases are handled securely through Xiaomi GetApps. Your Premium entitlement is checked again when DevMonitor reconnects to GetApps."
                        )
                        if (adsRemoved) {
                            Text("Premium is active. Ads and export limits are removed.", fontWeight = FontWeight.Bold)
                            DevMonitorOutlinedButton(onClick = {
                                    if (NetworkUtils.hasActiveInternet(this@MainActivity)) billingManager.manageSubscriptions(this@MainActivity)
                                    else message = "Premium management requires an active Internet connection."
                                }) {
                                Text("Manage Subscription")
                            }
                        } else {
                            DevMonitorOutlinedButton(onClick = {
                                if (NetworkUtils.hasActiveInternet(this@MainActivity)) billingManager.restorePremium()
                                else message = "Restoring Premium requires an active Internet connection."
                            }) {
                                Text("Restore Premium")
                            }
                        }
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DevMonitorOutlinedButton(
                            onClick = {
                                if (NetworkUtils.hasActiveInternet(this@MainActivity)) billingManager.launchMonthly(this@MainActivity)
                                else message = "Premium purchase requires an active Internet connection."
                            },
                            enabled = monthlyProduct != null
                        ) { Text("Monthly") }
                        DevMonitorButton(
                            onClick = {
                                if (NetworkUtils.hasActiveInternet(this@MainActivity)) billingManager.launchYearly(this@MainActivity)
                                else message = "Premium purchase requires an active Internet connection."
                            },
                            enabled = yearlyProduct != null
                        ) { Text("Yearly") }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showBilling = false }) { Text("Close") }
                }
            )
        }

        if (showFeedback) {
            FeedbackSuggestionDialog(
                adsRemoved = adsRemoved,
                onPremium = { showFeedback = false; showBilling = true },
                onDismiss = { showFeedback = false },
                onSubmit = { feedbackType, feedbackMessage, contact ->
                    if (!NetworkUtils.hasActiveInternet(this@MainActivity)) {
                        NetworkUtils.OFFLINE_MESSAGE
                    } else {
                        submitFeedbackToCloud(
                            feedbackType = feedbackType,
                            message = feedbackMessage,
                            contact = contact,
                            appVersion = BuildConfig.VERSION_NAME,
                            device = "${Build.MANUFACTURER} ${Build.MODEL}",
                            androidVersion = Build.VERSION.RELEASE,
                            premium = adsRemoved
                        )
                    }
                }
            )
        }

        if (showWelcome) {
            WelcomeWizard(
                guided = false,
                onClose = {
                    persistWelcomeSeen(this@MainActivity, store)
                    store.setSetting(SETTING_USER_SCOPED_NOTICE_ELIGIBLE, "true")
                    showWelcome = false
                },
                onStartGuidedTour = {
                    // The former SMS CHECKER guided tour has been removed. Keep the welcome
                    // action as a simple dismissal so it never launches an SMS workflow tour.
                    persistWelcomeSeen(this@MainActivity, store)
                    store.setSetting(SETTING_USER_SCOPED_NOTICE_ELIGIBLE, "true")
                    showWelcome = false
                },
                onBuildProfile = {
                    profileEditorNew = true
                    profileEditorId = null
                                        showMyDevicesProfile = true
                    showBuildProfileHint = false
                    store.setSetting("build_profile_hint_seen", "true")
                },
                onNavigate = { target ->
                    selectedTab = when (target) {
                        0 -> 1
                        2 -> 2
                        3 -> 0
                        else -> selectedTab
                    }
                    if (target == 1) showFlags = true
                }
            )
        }

        if (showPermissionSetup && !showWelcome) {
            val setupTitle: String
            val setupDescription: String
            val setupPermissions: List<String>
            when (permissionSetupStep) {
                0 -> {
                    setupTitle = "SMS device monitoring"
                    setupDescription = "Allows DevMonitor to send the 3030 monitoring queries you start, receive their replies, and optionally reconcile relevant SMS already in your inbox after interruptions. SMS inbox access is used only for monitoring recovery."
                    setupPermissions = listOf(
                        Manifest.permission.SEND_SMS,
                        Manifest.permission.RECEIVE_SMS,
                        Manifest.permission.READ_SMS
                    )
                }
                1 -> {
                    setupTitle = "Phone and SIM information"
                    setupDescription = "Allows DevMonitor to discover active SIM subscriptions and let you choose the SIM used for SMS monitoring. Without it, SIM selection and related controls may be unavailable."
                    setupPermissions = listOf(Manifest.permission.READ_PHONE_STATE)
                }
                else -> {
                    setupTitle = "Android notifications"
                    setupDescription = "Allows DevMonitor alerts to appear in Android's notification shade. The in-app notification inbox remains available if you decline."
                    setupPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        listOf(Manifest.permission.POST_NOTIFICATIONS)
                    } else emptyList()
                }
            }
            val setupMissingPermissions = setupPermissions.filterNot(::hasPermission)
            val setupGrantedCount = setupPermissions.size - setupMissingPermissions.size
            AlertDialog(
                onDismissRequest = {
                    store.setSetting(SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN, "true")
                    showPermissionSetup = false
                },
                title = { Text("Set up DevMonitor permissions (${permissionSetupStep + 1} of 3)") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(setupTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(setupDescription)
                        Text(
                            when {
                                setupPermissions.isEmpty() -> "This Android version does not require a runtime notification permission."
                                setupMissingPermissions.isEmpty() -> "Status: allowed"
                                setupGrantedCount > 0 -> "Status: partially allowed ($setupGrantedCount of ${setupPermissions.size})"
                                else -> "Status: not allowed yet"
                            },
                            color = if (setupMissingPermissions.isEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "You can skip any step. Declining a permission does not block opening DevMonitor; only features that need it will be limited. You can change permissions later in Android Settings.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (setupMissingPermissions.isNotEmpty()) {
                            TextButton(onClick = {
                                runCatching {
                                    startActivity(
                                        Intent(
                                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.fromParts("package", packageName, null)
                                        )
                                    )
                                }.onFailure { message = "Could not open Android app settings: ${it.message ?: it.javaClass.simpleName}" }
                            }) { Text("Open Android app settings") }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (setupMissingPermissions.isNotEmpty()) {
                            firstLaunchPermissionLauncher.launch(setupMissingPermissions.toTypedArray())
                        } else if (permissionSetupStep < 2) {
                            permissionSetupStep++
                        } else {
                            store.setSetting(SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN, "true")
                            showPermissionSetup = false
                        }
                    }) {
                        Text(if (setupMissingPermissions.isNotEmpty()) "Allow requested access" else if (permissionSetupStep < 2) "Next" else "Finish setup")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        if (permissionSetupStep < 2) {
                            permissionSetupStep++
                        } else {
                            store.setSetting(SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN, "true")
                            showPermissionSetup = false
                        }
                    }) { Text(if (permissionSetupStep < 2) "Skip this" else "Finish") }
                }
            )
        }

        if (showBuildProfileHint && !showWelcome && profiles.isEmpty()) {
            BuildProfileSpotlight(
                onBuildProfile = {
                    showBuildProfileHint = false
                    store.setSetting("build_profile_hint_seen", "true")
                    profileEditorNew = true
                    profileEditorId = null
                                        showMyDevicesProfile = true
                },
                onSkip = {
                    showBuildProfileHint = false
                    store.setSetting("build_profile_hint_seen", "true")
                }
            )
        }

        if (saveHintActive && !showSaveHelp && selectedTab == 1) {
            // Persistent first-week hint is rendered beside the Save/Saved controls below.
        }

        if (workflowRecoveryReason != null) {
            val reason = workflowRecoveryReason
            val title = if (reason == "MOM_PROFILE") "Set up your profile first" else "Build the history needed"
            val body = if (reason == "MOM_PROFILE") {
                "Month-on-Month uses your saved My Devices ownership profile. Create or complete your profile first, then return here."
            } else {
                "Month-on-Month needs imported historical activation data. Load the company SIMReg/Activations report for the relevant month(s), then return here and refresh the comparison."
            }
            AlertDialog(
                onDismissRequest = { workflowRecoveryReason = null },
                title = { Text(title) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(body)
                        Text(
                            if (reason == "MOM_PROFILE") "Next step: Profile → save your details and device list." else "Next step: Loaded Report → Load SIMReg Report File. The imported data is then stored in the Month-on-Month databases at import time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    DevMonitorButton(onClick = {
                        workflowRecoveryReason = null
                        if (reason == "MOM_PROFILE") {
                            profileEditorNew = profiles.isEmpty()
                            profileEditorId = activeProfileId
                            selectedTab = 4
                            showMyDevicesProfile = true
                        } else {
                            selectedTab = 5
                            showSimRegReport = true
                        }
                    }) { Text(if (reason == "MOM_PROFILE") "Open Profile" else "Open Loaded Report") }
                },
                dismissButton = {
                    TextButton(onClick = { workflowRecoveryReason = null }) { Text("Not now") }
                }
            )
        }

        if (showSaveHelp) {
            AlertDialog(
                onDismissRequest = { showSaveHelp = false },
                title = { Text("Save and reuse your code lists") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("You can keep a code list on this phone so you do not have to paste the same codes again.")
                        Text("Save list", fontWeight = FontWeight.Bold)
                        Text("Stores the current list under a name. Later, you can load it again for another operation.")
                        Text("Saved", fontWeight = FontWeight.Bold)
                        Text("Opens the lists you have already saved, so you can select one and reuse it.")
                    }
                },
                confirmButton = { DevMonitorButton(onClick = { showSaveHelp = false; showSavedLists = true }) { Text("Show Saved Lists") } },
                dismissButton = { TextButton(onClick = { showSaveHelp = false; showSaveDialog = true }) { Text("Save a List") } }
            )
        }

        if (showFlags) {
            val flags = store.dashboard().flags
            AlertDialog(
                onDismissRequest = { showFlags = false },
                title = { Text("Flags Centre") },
                text = {
                    LazyColumn(Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (flags.isEmpty()) item { Text("No active flags. All monitored devices are clear.") }
                        items(flags, key = { "${it.code}|${it.reason}" }) { flag ->
                            Card(colors = CardDefaults.cardColors(containerColor = if (flag.ownership == Ownership.COMPANY) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(flag.code, fontWeight = FontWeight.Bold)
                                        Text(flag.severity, fontWeight = FontWeight.Bold)
                                    }
                                    Text(if (flag.ownership == Ownership.COMPANY) "COMPANY PRIORITY" else "PARTNER")
                                    Text(flag.reason)
                                }
                            }
                        }
                    }
                },
                confirmButton = { DevMonitorButton(onClick = { showFlags = false }) { Text("Done") } }
            )
        }
    }

    @Composable
    private fun MetricCard(title: String, value: String, modifier: Modifier, subtitle: String = "") {
        AuroraMetricCard(title, value, modifier, AuroraBlue, subtitle)
    }

    private fun simLabel(sims: List<SubscriptionInfo>, subId: Int): String {
        val sim = sims.firstOrNull { it.subscriptionId == subId } ?: return "Not selected"
        val carrier = sim.carrierName?.toString()?.takeIf { it.isNotBlank() } ?: "SIM"
        return "SIM ${sim.simSlotIndex + 1} • $carrier"
    }

    private fun readCodesFromExcel(uri: Uri): List<String> = XlsxUtil.readCodes(this, uri)

    private fun writeResultsToExcel(
        uri: Uri,
        codes: List<String>,
        records: Map<String, QueryRecord>,
        dashboard: DashboardSummary,
        mode: ReportExportMode = ReportExportMode.DETAILED
    ): Boolean = XlsxUtil.writeReport(this, uri, codes, records, dashboard, database, companyActivations, mode)

    private fun formatTime(ms: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    private fun formatDate(ms: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms))

    private fun loadAttachedFiles(raw: String?): List<String> {
        val array = runCatching { if (raw.isNullOrBlank()) null else JSONArray(raw) }.getOrNull() ?: return emptyList()
        return buildList { for (i in 0 until array.length()) array.optString(i).takeIf { it.isNotBlank() }?.let(::add) }.distinct()
    }

    private fun loadDestinations(raw: String?): List<String> {
        val array = runCatching {
            if (raw.isNullOrBlank()) null else JSONArray(raw)
        }.getOrNull()

        if (array == null || array.length() == 0) return listOf(DEFAULT_SMS_DESTINATION)

        val result = buildList {
            for (i in 0 until array.length()) {
                array.optString(i)
                    .filter { it.isDigit() }
                    .takeIf { it.length >= 3 }
                    ?.let { add(it) }
            }
        }.distinct()

        return result.ifEmpty { listOf(DEFAULT_SMS_DESTINATION) }
    }
}


@Composable
private fun FeedbackSuggestionDialog(
    adsRemoved: Boolean,
    onPremium: () -> Unit,
    onDismiss: () -> Unit,
    onSubmit: suspend (String, String, String) -> String
) {
    var feedbackType by remember { mutableStateOf("Suggestion") }
    var message by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var submitting by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = { if (!submitting) onDismiss() },
        title = { Text("Feedback & Suggestions", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Help improve DevMonitor. Your feedback will be sent directly to the developer feedback table.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Suggestion", "Bug", "Other").forEach { type ->
                        FilterChip(
                            selected = feedbackType == type,
                            onClick = { feedbackType = type },
                            label = { Text(type) }
                        )
                    }
                }
                TextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Your feedback") },
                    placeholder = { Text("What should we improve?") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                    minLines = 4,
                    enabled = !submitting
                )
                TextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Contact (optional)") },
                    placeholder = { Text("Email or phone number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !submitting
                )
                Text(
                    "DevMonitor automatically includes the app version, device model, Android version and Premium status to help diagnose problems.",
                    style = MaterialTheme.typography.bodySmall
                )
                resultMessage?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (BuildConfig.MONETIZED_BUILD) {
                    DevMonitorOutlinedButton(
                        onClick = onPremium,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !submitting
                    ) {
                        Text(if (adsRemoved) "Premium Active" else "⭐ Go Premium — Remove Ads")
                    }
                }
            }
        },
        confirmButton = {
            DevMonitorButton(
                enabled = message.isNotBlank() && !submitting,
                onClick = {
                    submitting = true
                    resultMessage = null
                    coroutineScope.launch {
                        val result = onSubmit(feedbackType, message.trim(), contact.trim())
                        submitting = false
                        resultMessage = result
                        if (result.startsWith("Feedback sent")) {
                            message = ""
                            contact = ""
                        }
                    }
                }
            ) { Text(if (submitting) "Sending…" else "Send Feedback") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !submitting) { Text("Cancel") }
        }
    )
}

private suspend fun submitFeedbackToCloud(
    feedbackType: String,
    message: String,
    contact: String,
    appVersion: String,
    device: String,
    androidVersion: String,
    premium: Boolean
): String = withContext(Dispatchers.IO) {
    // Set FEEDBACK_WEB_APP_URL in gradle.properties when your Google Apps Script
    // web app has been deployed. The app stays buildable before the URL is supplied.
    val endpoint = BuildConfig.FEEDBACK_WEB_APP_URL.trim()
    if (endpoint.isBlank()) {
        return@withContext "Feedback service is not configured yet. Add the Google Apps Script web-app URL to FEEDBACK_WEB_APP_URL."
    }
    return@withContext runCatching {
        val data = listOf(
            "type" to feedbackType,
            "message" to message,
            "contact" to contact,
            "appVersion" to appVersion,
            "device" to device,
            "androidVersion" to androidVersion,
            "premium" to premium.toString()
        ).joinToString("&") { (key, value) ->
            "${URLEncoder.encode(key, "UTF-8")}=${URLEncoder.encode(value, "UTF-8")}"
        }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 15_000
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        }
        connection.outputStream.use { it.write(data.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        connection.disconnect()
        if (code in 200..299) "Feedback sent successfully. Thank you!"
        else "Feedback could not be sent right now. Please try again later. (HTTP $code)"
    }.getOrElse {
        "Feedback could not be sent right now. Please check your internet connection and try again."
    }
}

@Composable
private fun VisualTrendsDialog(
    points: List<TrendPoint>,
    monthlyTarget: Int,
    refreshing: Boolean,
    lastUpdated: String?,
    onRefresh: () -> Unit,
    onDismiss: () -> Unit
) {
    val delivered = points.sumOf { it.sales }
    val asOfDay = points.lastOrNull()?.date?.substringAfterLast("-")?.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val monthDays = runCatching { java.time.YearMonth.parse(lastUpdated?.substring(0, 7) ?: java.time.YearMonth.now().toString()).lengthOfMonth() }.getOrDefault(30)
    val projected = if (points.isNotEmpty()) kotlin.math.round(delivered.toDouble() * monthDays / asOfDay).toInt() else 0
    val achievement = if (monthlyTarget > 0) delivered * 100.0 / monthlyTarget else null
    val remaining = if (monthlyTarget > 0) (monthlyTarget - delivered).coerceAtLeast(0) else null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Monthly Target & Delivery", fontWeight = FontWeight.ExtraBold) },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 620.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "Current-month delivery and a simple month-end projection based on the observed daily rate. Only this month is shown; the app's two-month retention remains unchanged.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        DevMonitorOutlinedButton(onClick = onRefresh, enabled = !refreshing) {
                            Text(if (refreshing) "Updating…" else "↻ Refresh")
                        }
                    }
                    if (lastUpdated != null) {
                        Spacer(Modifier.height(4.dp))
                        Text("Last refreshed: $lastUpdated", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (points.isEmpty() && refreshing) {
                    item { DevMonitorLoadingState("Updating monthly delivery…", "Reading current-month observations.") }
                } else if (points.isEmpty()) {
                    item { DevMonitorEmptyState("No current-month observations", "Run Device Monitor or import the current report, then refresh to see monthly delivery figures.", "Refresh", onRefresh) }
                } else {
                    item {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                            Text("CURRENT-MONTH DELIVERY", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = AuroraBlue)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("Monthly target", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(if (monthlyTarget > 0) monthlyTarget.toString() else "Not set", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Delivered so far", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(delivered.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("Projected month-end", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(projected.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Target achieved", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(achievement?.let { String.format(Locale.US, "%.1f%%", it) } ?: "—", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                            if (remaining != null) {
                                Spacer(Modifier.height(8.dp))
                                Text("Remaining target balance: $remaining", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            }
                            if (monthlyTarget > 0) {
                                Spacer(Modifier.height(8.dp))
                                LinearProgressIndicator(progress = { (achievement!! / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                    item { TrendChartCard("DAILY SALES THIS MONTH", points, { it.sales }, AuroraBlue) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun DevMonitorFloatingLoader(
    title: String,
    step: String,
    progress: Float,
    operation: String
) {
    val transition = rememberInfiniteTransition(label = "floating-loader")
    val pulse by transition.animateFloat(
        initialValue = 0.82f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val shimmer by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmer"
    )
    val percent = (progress.coerceIn(0f, 1f) * 100f).toInt()
    Box(
        Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 64.dp)
                .graphicsLayer { alpha = 0.98f },
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF071426).copy(alpha = .97f),
            tonalElevation = 8.dp,
            shadowElevation = 12.dp
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.size((34f * pulse).dp).clip(CircleShape).background(Brush.linearGradient(listOf(AuroraBlue, AuroraCyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(operation.uppercase(Locale.US), color = Color.White.copy(alpha = .58f), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Text("$percent%", color = Color.White, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(10.dp))
                Text(step, color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = progress.coerceIn(0f, 1f),
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(99.dp)),
                    color = AuroraCyan,
                    trackColor = Color.White.copy(alpha = .14f)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (shimmer < .5f) "Please wait — DevMonitor is working…" else "Almost there…",
                    color = Color.White.copy(alpha = .58f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun TrendChartCard(
    title: String,
    points: List<TrendPoint>,
    value: (TrendPoint) -> Int,
    accent: Color
) {
    val values = points.map { value(it) }
    val maxValue = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    AuroraGlassCard(Modifier.fillMaxWidth(), accent) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = accent, modifier = Modifier.weight(1f))
            Text("Peak $maxValue", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = .16f)
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            if (points.size >= 2) {
                val left = 12f
                val right = size.width - 12f
                val top = 12f
                val bottom = size.height - 12f
                val step = (right - left) / (points.size - 1).coerceAtLeast(1)
                for (i in 0 until 4) {
                    val y = top + (bottom - top) * i / 3f
                    drawLine(gridColor, androidx.compose.ui.geometry.Offset(left, y), androidx.compose.ui.geometry.Offset(right, y), 1f)
                }
                for (i in 0 until points.lastIndex) {
                    val a = value(points[i]).toFloat()
                    val b = value(points[i + 1]).toFloat()
                    val x1 = left + step * i
                    val x2 = left + step * (i + 1)
                    val y1 = bottom - (bottom - top) * (a / maxValue.toFloat())
                    val y2 = bottom - (bottom - top) * (b / maxValue.toFloat())
                    drawLine(accent, androidx.compose.ui.geometry.Offset(x1, y1), androidx.compose.ui.geometry.Offset(x2, y2), 4f, StrokeCap.Round)
                    drawCircle(accent, 4.5f, androidx.compose.ui.geometry.Offset(x1, y1))
                }
                val lastX = left + step * points.lastIndex
                val lastY = bottom - (bottom - top) * (value(points.last()).toFloat() / maxValue.toFloat())
                drawCircle(accent, 4.5f, androidx.compose.ui.geometry.Offset(lastX, lastY))
            } else if (points.size == 1) {
                val y = size.height - 12f - (size.height - 24f) * (value(points[0]).toFloat() / maxValue.toFloat())
                drawCircle(accent, 6f, androidx.compose.ui.geometry.Offset(size.width / 2f, y))
            }
        }
        if (points.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(points.first().date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(points.last().date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(4.dp))
            val latest = value(points.last())
            Text("Latest: $latest  •  Observed devices: ${points.last().observedDevices}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
