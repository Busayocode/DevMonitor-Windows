# FieldPulse 4.3.4.8 — Firebase Authentication Configuration

## Purpose
This correction incorporates the refreshed Firebase `google-services.json` after registering the Android debug signing certificate for Google Sign-In.

## Firebase configuration now present
- Firebase project: `fieldpulse-b3eb3`
- Android package: `com.aziitech.simregmonitor`
- Android OAuth client (`client_type: 1`) is present.
- Android OAuth certificate hash matches the debug SHA-1:
  `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- Web OAuth client (`client_type: 3`) remains present.

## Build environment
- Android Code Studio on Android phone
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- JDK 17
- compileSdk / targetSdk 36
- ARM-compatible AAPT2 override through `build-phone.sh`

## Versioning
Authentication corrections remain within the `4.3.4.x` family. This correction is `4.3.4.8`.

## Verification status
The source ZIP has been updated with the refreshed Firebase configuration. A local build could not be performed in this environment because the Android Code Studio ARM-compatible AAPT2 binary is not available here. Build and install on the established phone environment before treating this version as verified.
