# FieldPulse 2.2.4

- Added a remote update checker for Google Drive/off-Play distribution.
- On startup, the app checks a publisher-controlled JSON manifest for a newer versionCode.
- Users are prompted to update when a newer version is detected.
- Non-forced updates can be postponed; the same version is not prompted repeatedly within 24 hours.
- The Update button opens the configured APK/share URL so the user can download/install the new build.
- Added `UPDATE_MANIFEST_URL` build property and `FIELD_PULSE_UPDATE_MANIFEST_TEMPLATE.json`.
- Update checking is disabled when `UPDATE_MANIFEST_URL` is blank.
