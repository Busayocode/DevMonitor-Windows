# FieldPulse 4.3.4.22 — SIMReg Scroll + Report Loading Experience

Targeted UI hotfix based on 4.3.4.21-Aurora-Touch-Feedback-Fix-v3.

## Changes
- Fixed SIMReg expanded Device Payment card content being hidden behind the fixed bottom navigation/banner area by applying Scaffold content insets to the SIMReg report screen.
- Added extra bottom scroll space to the SIMReg report list so the final warning/details cards can be fully brought above the bottom navigation.
- Replaced the plain SIMReg report loading spinner with a lightweight animated open-book/report illustration.
- Added a determinate percentage and staged loading messages during workbook opening, reading, parsing, and saving.
- Preserved the working dark Aurora UI, gradient buttons, ripple/touch feedback, authentication, payment logic, parser, and all existing business logic.
- No new dependencies added.
