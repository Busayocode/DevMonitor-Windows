# DevMonitor 4.6.0-NEXT v188 — Dashboard Search Scope Fix

## Purpose
Correct the Loaded Report startup-performance change so the dashboard search remains global while the Loaded Report table remains My Devices-first.

## Required behavior
1. Loaded Report/table view starts with the active profile's My Devices working set only.
2. Opening Loaded Report does not materialize the complete HQ database.
3. Dashboard device search checks My Devices first.
4. If no My Devices device matches the query, dashboard search falls back to the complete retained HQ device database.
5. The fallback is lookup-only; it does not change My Devices membership, table scope, or payment logic.
6. Selecting a Loaded Report search result continues to open a targeted single-device Loaded Report result.

## Implementation
- Added `CompanyActivationStore.searchWholeDatabaseDeviceCodes()` using the retained monthly HQ SQLite snapshots.
- Dashboard search now uses profile `codes` first and invokes the whole-database lookup only when the My Devices search returns no matches.
- VersionCode advanced from 187 to 188.
- PaymentEngine and payment-cycle formulas were not changed.
