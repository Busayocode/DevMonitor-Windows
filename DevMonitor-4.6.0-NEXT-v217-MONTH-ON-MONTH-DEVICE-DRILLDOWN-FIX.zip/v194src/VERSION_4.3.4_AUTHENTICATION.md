# FieldPulse 4.3.4 Authentication

## Purpose
4.3.4 establishes the authentication/authorization foundation for protected Payment Intelligence information while preserving the existing monitoring, parser, payment-estimation, SMS and local SQLite implementation.

## Implemented
- FieldPulse Account ID separate from Google email.
- Existing Google Sign-In is reused as the identity anchor.
- Main Nigerian phone and optional alternate phone profile.
- Nigerian phone normalization and validation.
- `0805557xxxx` is treated as a Glo staff-candidate classification signal, not proof of authorization.
- Other Nigerian numbers are classified as agent/partner candidates and require Device Manager authorization.
- Payment Intelligence is blocked unless the account has `AUTHORIZED` state.
- Authorization request IDs are generated and recorded.
- Authorization request events are stored in an append-oriented local audit table.
- Request text can be shared through WhatsApp without embedding payment/customer data.
- Authentication state and audit schema are designed around an account rather than an Android installation, so Web and PC clients can use the same future account/authorization contract.
- SQLite schema upgraded from version 7 to version 8 without replacing the existing database.

## Authorization states
- `SIGNED_OUT`
- `PHONE_REQUIRED`
- `AUTHORIZATION_REQUIRED`
- `AUTHORIZED`
- `REVOKED`

## Important security boundary
The current Android build uses the configured staff-line pattern as an eligibility filter, then uses Firebase OTP verification of that line as the staff-account verification event. Because the operating model treats verified staff accounts as full-access accounts, no second central authorization step is required for staff access. The pattern itself is not an authoritative staff registry.

## Multi-client contract
Authentication belongs to the FieldPulse account. Android, Web and PC are clients/sessions of that account. Staff authentication is attached to the FieldPulse account rather than merely the Android installation. A successfully verified staff account receives full FieldPulse access.

## Preserved
- Existing payment calculations and parser behavior.
- Existing SQLite data model, migrated forward rather than replaced.
- Existing Google Drive backup functionality.
- Existing Android Code Studio / phone build environment.
- Existing 4.3 payment-intelligence work.
