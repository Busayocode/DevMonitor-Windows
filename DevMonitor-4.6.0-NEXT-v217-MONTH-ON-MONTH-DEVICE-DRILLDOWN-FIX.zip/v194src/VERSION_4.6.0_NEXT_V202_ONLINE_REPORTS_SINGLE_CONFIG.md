# DevMonitor 4.6.0-NEXT v202 — Online Reports Single Configuration

Base: v198.

## Scope
This build returns the Online Reports configuration to the simple path that previously worked: `gradle.properties` is the authoritative local configuration file.

Set these two properties in `gradle.properties`:

- `DRIVE_REPORT_FOLDER_ID`
- `DRIVE_REPORT_API_KEY`

`app/build.gradle.kts` transfers those project properties into `BuildConfig`, and `OnlineReports.kt` consumes `BuildConfig`.

`build-phone.sh` no longer prompts for or overrides the Drive values. The GitHub workflow writes the API key secret into the same `gradle.properties` file before building and no longer passes competing `-PDRIVE_REPORT_*` command-line overrides.

## Online Reports diagnostics
The improved direct Google Drive listing remains: shared-drive flags, pagination, bounded request/coroutine timeouts, and detailed HTTP/API error text. No separate folder-validation request is used.

## Protected areas
MOM source and payment logic are carried forward unchanged from v198.
