# DevMonitor v216 — SMS Checker Agent Button Visibility

- Based on v215.
- Hides the Zero Devices button for the AGENT user type because an agent profile is limited to one device.
- Keeps Zero Devices available for PARTNER and STAFF profiles.
- Uses the active profile type first, falling back to the saved My Devices user type.
- Hides the Zero Devices explanatory text for agents as well.
- No changes to SMS result storage, MOM, payment logic, or database architecture.
