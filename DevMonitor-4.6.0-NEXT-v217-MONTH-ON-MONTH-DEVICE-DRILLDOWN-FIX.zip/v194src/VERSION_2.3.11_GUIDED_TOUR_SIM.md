# FieldPulse 2.3.11 — Guided Tour SIM Selection

## Guided tour
- When Device Monitor is opened during the guided tour and multiple active SIMs are present, the tour now inserts an explicit **Select SIM for SMS** step before code entry.
- The tour highlights the real **Select SIM** control and waits for the user to choose a SIM.
- The phone's default SMS subscription is preselected when Android exposes it; otherwise FieldPulse uses the first active SIM as its safe fallback and stores the selected subscription.
- After the user explicitly chooses a SIM, the tour continues immediately to code entry.
- Devices with only one active SIM continue directly to code entry without an unnecessary selection step.

## Reliability
- This makes the SIM-selection state explicit in the first-operation workflow, reducing runs that reach SMS sending with a user-facing **SIM not selected** state.
- Existing flexible device/partner code input and SMS short-code normalization remain unchanged.
