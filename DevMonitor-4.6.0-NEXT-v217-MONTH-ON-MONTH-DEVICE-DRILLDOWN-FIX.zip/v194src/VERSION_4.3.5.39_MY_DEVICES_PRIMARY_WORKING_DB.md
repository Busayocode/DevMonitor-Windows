# DevMonitor 4.3.5.39 — My Devices Primary Working Database

- My Devices is now the primary everyday working table.
- The existing `my_devices.db` is materialized from the normalized company database for only the saved My Devices codes.
- Normal daily working window: 21st of the previous calendar month through the end of the current calendar month.
- Example on 2026-09-24: 2026-08-21 through 2026-09-30. On 2026-10-01 it rolls to 2026-09-21 through 2026-10-31.
- The full company database remains stored and is loaded only when the user explicitly selects **Show All Devices**.
- Payment-cycle loaded-report reads use My Devices first and fall back to the company database when the requested data is not present in the working set.
- `Update My Devices` rebuilds the primary working set from the normalized company database without materializing every company device.
