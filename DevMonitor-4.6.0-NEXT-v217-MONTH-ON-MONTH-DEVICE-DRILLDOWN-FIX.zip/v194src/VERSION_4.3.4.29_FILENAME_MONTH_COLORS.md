# DevMonitor 4.3.4.29

- Expanded report filename month recognition: full/short month names, mixed capitalization, month/year order variations, numeric month/year forms, ISO dates, common numeric full dates, textual dates, and common date ranges.
- A filename month remains authoritative even when workbook metadata contains unrelated dates. If the filename omits the year, the workbook may supply the year without changing the filename month.
- Added subtle month-group table tinting with separate light/dark shades for readability.
- Version name updated to 4.3.4.29.
