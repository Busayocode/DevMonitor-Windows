# FieldPulse 4.3.4.6 — Payment Landing / Partner Access

## Access model
1. **Staff Login** — Google account + qualifying staff-line OTP. Successful verification unlocks all FieldPulse areas.
2. **Partner Login** — partner enters phone number and Trade Code. The request is sent to a designated staff member for approval. Partner payment details remain locked until approval.

## Current implementation
- Payment tab is now a landing page rather than a hard block.
- Staff can enter the existing authentication gate.
- Partner login opens a dedicated form.
- Approval request is generated with a unique request ID and shared through WhatsApp.
- Existing staff-only payment search remains available after staff authentication.

## Important
The current build does not pretend that a WhatsApp message itself constitutes an authenticated approval. The request is explicitly shown as pending until a future/shared approval mechanism records the staff decision.

### 4.3.4.7.1 — Debug Authentication Fingerprint / Build Environment
- Debug signing report verified successfully with `sh gradlew signingReport`.
- Debug keystore: `/data/user/0/com.tom.rv2ide/files/home/.android/debug.keystore`
- Debug alias: `AndroidDebugKey`
- Debug SHA-1: `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- Debug SHA-256: `1D:BE:EE:61:64:A2:FC:97:55:C3:BD:8A:7B:54:02:4A:68:22:64:69:0E:55:91:15:6D:4D:86:AE:B6:C8:AA:AA`
- Build environment: Android Code Studio on Android phone; Gradle 8.7; AGP 8.6.1; Kotlin 2.0.21; JDK 17; compileSdk/targetSdk 36; ARM-compatible AAPT2 override via `build-phone.sh`.
- Version naming for this authentication workstream remains the `4.3.4.x` family; corrections stay within that family.
- This fingerprint is the debug certificate used by the current phone development build. It must be added to the Firebase Android app configuration before retesting Google sign-in.
