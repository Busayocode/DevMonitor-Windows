# DevMonitor 4.5.2 — NEXT LEVEL Notification & Inbox

## Purpose
Introduce a lightweight in-app attention stream without creating background operational work.

## Included
- Profile-scoped Notifications & Inbox.
- Unread badge in the top bar.
- Drawer entry for the inbox.
- Local persistence with a capped history.
- Individual read and mark-all-read controls.
- Notifications for monitoring completion/failure, report imports, exports, and the existing payment-cycle reminder.

## Performance boundary
Notifications are written only as natural results of user actions or the already-approved month-end reminder. The inbox does not monitor SMS, calculate payments, refresh dashboards, sync files, or run heavy work in the background.

## Protected functionality
Payment-cycle rules, profile isolation, Device Monitor/SIMReg logic, reporting, My Devices and user-initiated performance policy are unchanged.
