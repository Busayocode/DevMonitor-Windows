# DevMonitor 4.3.5.29 — Partner Check My Devices compile fix

- Bumped versionCode to 114 and versionName to 4.3.5.29.
- Fixed the Kotlin compile error in `MainActivity.kt` by importing Compose `verticalScroll` and `rememberScrollState`.
- No partner Check My Devices behavior was changed.
