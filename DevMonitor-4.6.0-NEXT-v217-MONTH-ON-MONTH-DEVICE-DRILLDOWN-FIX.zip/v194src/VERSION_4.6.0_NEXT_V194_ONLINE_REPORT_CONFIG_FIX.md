# DevMonitor 4.6.0-NEXT v194 — Online Reports Release Configuration Fix

## Problem addressed

A release APK could report:

> Online report not configured. Set Google Drive folder ID and API key.

The Online Reports implementation remains intact. v194 makes the private API key injection explicit on the release `assembleRelease` command and adds a release-build verification step.

## Preserved configuration

- Google Drive report folder: `1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI`
- API key remains private and is never stored in the ZIP/source.
- GitHub Actions secret: `DRIVE_REPORT_API_KEY`

## Protected areas

- v193 Month-on-Month device-card bulk calculation fix retained.
- Loaded Report My Devices-first incremental rendering retained.
- PaymentEngine/payment-cycle logic unchanged.
