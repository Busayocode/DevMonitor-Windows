# DevMonitor 4.3.5.44 — My Month-on-Month Performance

- Adds the dashboard **MY MONTH-ON-MONTH PERFORMANCE** card for Staff, Partner and Agent profiles.
- Calculation is strictly on-demand: it runs only when the user taps **Check My Month-on-Month Performance**.
- Current month uses the user’s currently assigned devices. For each device, the newer applicable Device Monitor Active snapshot or normalized loaded-report data is used.
- Previous month is attributed historically from the ownership recorded in the loaded report snapshot, so device transfers do not rewrite past performance.
- Shows current MTD, same-period-last-month total, absolute delta, and percentage change.
- Does not run automatically on profile save, report import, SMS reception, dashboard opening, or app startup.
