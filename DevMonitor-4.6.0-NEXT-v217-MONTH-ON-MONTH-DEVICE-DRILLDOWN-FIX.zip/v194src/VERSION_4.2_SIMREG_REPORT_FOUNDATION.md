# FieldPulse 4.2 Development Foundation — SIMReg Report Intelligence

This is a development foundation built on the FieldPulse 4.1 Premium/GetApps production source.

## What is included
- Headquarters workbook importer accepting SIM Reg as-at or Activations as-at reports.
- Structure-aware detailed-sheet selection.
- Case-insensitive search across Device ID, Staff Name, Region, Cluster, Territory, Channel Partner Name and Trade Code.
- Report coverage/cutoff extraction.
- MTD through the effective report cutoff.
- Shared monitoring-only incentive calculator.
- Prominent company-authority/payment warning.
- Dashboard entry point: Open SIMReg Report.

## 4.2.3 — Customizable SIMReg working view

The report workspace now supports temporary Excel-like view customization.

- Individual columns can be hidden/restored.
- Device ID is visible by default.
- Daily columns, report-month MTD, Total, and hierarchy/partner columns are independently configurable.
- Rows can be filtered to all rows, rows with activity, or zero-activity rows.
- Customization changes presentation only; the original imported workbook remains complete and unchanged.
- Reset View restores the complete default table.

## 4.2.1 — SIMReg report workspace persistence and table usability
- Current report MTD is explicitly labeled with the report month, e.g. **August MTD**.
- Excel-style table supports pinch zoom plus visible +/- zoom controls from 60% to 200%.
- Device row focus and daily/MTD/TOTAL column focus are preserved.
- Every imported SIMReg/Activations workbook is automatically stored inside FieldPulse as the complete original `.xlsx`, not only parsed rows.
- Saved SIMREG Reports library lets the user reopen previously imported workbooks.
- Current-period retention keeps the three most recent reports.
- Full-month archive retention keeps the three most recent full-month reports.
- Retention classification uses report coverage dates rather than the filename.
- Excel import runs off the UI thread and shows a visible importing/busy state while the complete workbook is read, parsed and saved.

## What is not yet complete
- Full in-app navigation of every original workbook sheet beyond the detailed report view.
- Private cross-month missing-device analysis.
- Private Find Device investigation across the entire current workbook.
- Full HQ ↔ Device Monitor reconciliation screen.
- Complete role-specific manager/partner workflows.

## Verification status
- PaymentRules.kt standalone Kotlin syntax checked successfully in the available build container.
- The full Android build was attempted with `sh build-phone.sh assembleDebug --console=plain` but this environment does not contain the ARM-compatible AAPT2 binary expected by the project's phone build script. Therefore this ZIP is **not claimed as a phone-verified APK**.
- On the user's Android Code Studio phone, use the existing `build-phone.sh` workflow so its ARM-compatible AAPT2 is used.
