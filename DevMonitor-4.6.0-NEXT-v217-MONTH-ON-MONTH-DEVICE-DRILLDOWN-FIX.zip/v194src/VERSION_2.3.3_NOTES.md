# FieldPulse 2.3.3 — SMS Input Normalization & Open Partner Codes

## Changes

- User-entered device codes may be lowercase, uppercase, or mixed case.
- Every SMS query is normalized to uppercase immediately before transmission.
- This applies to the normal SMS send path and the delivery-monitored SMS path.
- The existing GLO 3030 short-form conversion remains active; its final transmitted value is also uppercase.
- Partner codes are now completely open with respect to format: no hard-coded length or alphanumeric-only regex is used.
- Any non-blank partner code is accepted, trimmed, uppercased, stored, and sent. The company/server response determines whether the code is valid.
- Excel import accepts open partner-code formats and ignores only common header labels.
- Existing short/long GLO device identity normalization and same-day recheck behavior from 2.3.2 are preserved.

## Example

User enters:
`glo-gd-66d`

SMS sent:
`GLO-GD-66D`

User enters partner code:
`ab-12_x9`

SMS sent:
`AB-12_X9`

No local format validation rejects the partner code.

## Build environment

- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Kotlin 2.0.21
- JDK 17
- compileSdk 36 / targetSdk 36
