# DevMonitor 4.3.5.37 — Check My Devices SIM Flow

## Changes

1. Check My Devices now checks the existing persisted `SETTING_SMS_SUB_ID` selection against the currently active SIMs before showing the SIM selector.
2. If the persisted default SIM is active, Check My Devices proceeds without reopening the SIM-selection dialog.
3. If no persisted default SIM is available/active, the existing SIM-selection flow remains available.
4. The fresh-install Check My Devices path keeps its pending SMS run through the Android SMS permission flow so it can resume automatically after permission is granted.
5. Compile correction: `beginRun` is declared as a local function variable before the permission/Check My Devices callbacks that reference it, then assigned its full implementation later in the composition. This resolves Kotlin's `Unresolved reference 'beginRun'` errors at the earlier callback sites without changing the normal Device Monitor flow.

## Build note

The source was statically corrected from the reported 4.3.5.37 Kotlin errors. This environment does not contain the project's Gradle wrapper, so a local Gradle compile could not be executed here. Build on the Android development environment with `sh ./gradlew :app:assembleDebug`.
