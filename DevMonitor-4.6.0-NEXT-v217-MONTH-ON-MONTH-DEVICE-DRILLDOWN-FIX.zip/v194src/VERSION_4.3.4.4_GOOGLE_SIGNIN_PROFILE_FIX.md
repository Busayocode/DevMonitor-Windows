# FieldPulse 4.3.4.4 — Google Sign-In & Profile Fix

## Purpose
Fix the silent-looking Google sign-in flow and visibly confirm the current Google identity inside FieldPulse.

## Changes
- Reports Google Sign-In API result codes instead of silently doing nothing.
- Reports missing Google ID token explicitly.
- Reports Firebase credential failures explicitly.
- Reads the Firebase current user and keeps the UI synchronized.
- Stores Google display name and profile photo URL locally alongside the email.
- Shows the Google profile picture and name in the FieldPulse Monitor top bar after successful sign-in.
- Shows the same profile in Settings → Account & Cloud Backup.
- Clears stored Google profile data on sign-out.

## Firebase configuration requirement
Firebase's current Android Google sign-in documentation requires Google as an enabled Firebase Authentication provider and the Android app's SHA-1/SHA-256 configuration to be correct. The supplied google-services.json contains the web OAuth client used for the Firebase ID-token exchange; if the installed debug build still returns a Google sign-in API error, the exact status code now shown in the app should be used to correct the Firebase/Google OAuth configuration.
