# FieldPulse 4.3.4.6 — Debug Firebase Fingerprint

## Verified debug signing identity

`sh gradlew signingReport` completed successfully.

- Store: `/data/user/0/com.tom.rv2ide/files/home/.android/debug.keystore`
- Alias: `AndroidDebugKey`
- SHA-1: `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- SHA-256: `1D:BE:EE:61:64:A2:FC:97:55:C3:BD:8A:7B:54:02:4A:68:22:64:69:0E:55:91:15:6D:4D:86:AE:B6:C8:AA:AA`

## Build environment

- Android Code Studio on Android phone
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- JDK 17
- compileSdk 36
- targetSdk 36
- ARM-compatible AAPT2 override through `build-phone.sh`

## Versioning

Authentication corrections remain in the `4.3.4.x` version family.

## Firebase action

Add the above SHA-1 and SHA-256 to Firebase project `fieldpulse-b3eb3`, Android app package `com.aziitech.simregmonitor`, then download the refreshed `google-services.json`.

Do not treat this source ZIP as a verified build until the debug APK has been rebuilt and installed successfully.
