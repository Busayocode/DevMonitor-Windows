# DevMonitor — GitHub Cloud Build

## Purpose
This project is prepared for a GitHub Actions cloud build so Android compilation does not depend on the phone's local Gradle environment.

## Build configuration
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle wrapper: 8.7
- Java: 17
- Build task: `assembleDebug`
- APK artifact: `app/build/outputs/apk/debug/*.apk`

## Phone-only workflow
1. Extract this project so `app/`, `gradle/`, `gradlew`, `settings.gradle.kts`, and `build.gradle.kts` are at the repository root.
2. Upload the extracted project files to the GitHub repository, not just the ZIP file.
3. Open **Actions** in the repository.
4. Select **DevMonitor Android Cloud Build**.
5. Tap **Run workflow** and choose the `main` branch.
6. Wait for the job to finish.
7. Open the completed workflow run.
8. Under **Artifacts**, download `DevMonitor-debug-apk`.
9. Extract the artifact and install the APK on the phone.

## Important
The GitHub workflow performs the actual Gradle compilation. Do not run another long local build on the phone just to test whether the source compiles.

## 4.5.2 compile correction
The Notification & Inbox implementation had nullable profile-ID arguments that Kotlin rejected when passed to `NotificationStore`, plus one Compose `Text()` call whose `Modifier` was supplied positionally after a named argument. These have been corrected safely without changing notification behavior.
