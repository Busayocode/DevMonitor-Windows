# FieldPulse 3.0 — Saved List Membership Management

## Change log
- Added **Manage** to Saved Lists.
- Add one or multiple normalized codes to an existing saved list.
- Select and remove one or multiple codes from a saved list.
- Duplicate additions are ignored.
- Existing GLO canonicalization is preserved.
- Saved-list changes do not delete or alter main device/history data.
- Existing Load/Delete actions remain available.

## Build environment
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- Kotlin: 2.0.21
- Java/JVM: 17
- compileSdk / targetSdk: 36
- Gradle workers: 1
- Parallel Gradle execution: disabled
- Android Code Studio / ARM64 phone build; use `sh build-phone.sh assembleRelease` for the phone-safe AAPT2 path.

## Version
- versionCode: 52
- versionName: 3.0
- applicationId: `com.aziitech.simregmonitor`


## 3.0 release designation
- This release is designated **3.0** by project decision.
- Saved List Membership Management is retained as the 3.0 feature baseline.


# FieldPulse 4.0 — Google Account, Cloud Backup & File Sharing

## Change log
- Added optional Google Sign-In from Settings.
- Added explicit Google Drive private app-data Backup and Restore.
- Local SQLite remains the primary operational database; cloud upload occurs only after the user chooses Backup.
- Restore replaces the local database only after the user chooses Restore and then reloads the app.
- Added Android Share-sheet support for the last attached file and last Excel report.
- Existing Excel export/Open behavior is preserved.
- Existing SMS transmission, recovery/recheck, GLO normalization, daily snapshot, history, guided tour, and Saved List Membership behavior are preserved.

## Version
- versionCode: 53
- versionName: 4.0
- applicationId: `com.aziitech.simregmonitor`

## Google setup requirement
- The app requires a Google Cloud project with an Android OAuth client matching package `com.aziitech.simregmonitor` and the production signing certificate.
- Enable Google Drive API.
- The app requests only the private Drive app-data scope (`drive.appdata`).
- No client secret or service-account credential is embedded in the APK.
