# DevMonitor 4.3.5.10 — Current Payment-Cycle Report Authority

## Fix
- Normalized Loaded Reports are authoritative for an exact device/date in the active 21st–20th payment cycle.
- Device Monitor SMS Active can no longer overwrite an imported activation value for the same date.
- Previous-cycle and historical bridge data cannot advance the new cycle.
- SMS deltas may fill dates after the newest imported report only when a same-date SMS Active baseline exists; otherwise the app avoids guessing.

## Rollover validation
For device `655D` on 2026-09-21, a normalized report row of 14 resolves to 14.
September 1–20 and August values are outside the active 2026-09-21 through 2026-10-20 cycle.
