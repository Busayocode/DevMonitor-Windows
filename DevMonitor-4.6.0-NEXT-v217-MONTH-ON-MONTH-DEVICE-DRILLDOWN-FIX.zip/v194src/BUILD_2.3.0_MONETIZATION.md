# 2.3.0 Monetization Configuration

Before public release:

1. Create the AdMob app and banner/interstitial/rewarded ad units.
2. Replace the Google test IDs in `gradle.properties`:
   - `ADMOB_APP_ID`
   - `ADMOB_BANNER_AD_UNIT_ID`
   - `ADMOB_INTERSTITIAL_AD_UNIT_ID`
   - `ADMOB_REWARDED_AD_UNIT_ID`
3. In Google Play Console, create:
   - a monthly subscription with product ID `fieldpulse_remove_ads_monthly`
   - a recurring yearly subscription with product ID `fieldpulse_remove_ads_yearly`
4. Keep those IDs exactly the same in `gradle.properties`, or change the properties to match the Play Console IDs.
5. Test purchases with a Play license tester before production.
6. The public build uses Google Play Billing. If publishing the same monetized package to Samsung Galaxy Store, use the store's supported IAP implementation instead of assuming Google Play Billing is available there.
