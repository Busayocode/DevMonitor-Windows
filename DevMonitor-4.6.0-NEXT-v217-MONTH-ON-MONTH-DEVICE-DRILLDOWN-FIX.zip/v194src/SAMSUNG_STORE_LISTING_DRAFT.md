# Samsung Galaxy Store listing draft — FieldPulse

## App name
FieldPulse

## Short description
SMS automation, device monitoring and reporting for field operations.

## Full description
FieldPulse is an SMS-based field monitoring and reporting tool designed to help authorized field teams query devices, track responses, review operational trends and maintain structured reports.

Key features:
- Paste device codes and start a batch immediately.
- Send SMS queries using the selected SIM.
- Monitor SMS delivery and responses.
- Track device/partner records and ownership.
- Review history, dashboards and operational flags.
- Maintain agent/partner information.
- Generate and manage reports.
- Provide feedback and suggestions from inside the app.

FieldPulse uses SMS permissions only for its core monitoring and reporting workflow. SMS content is not used for advertising or marketing.

The app may display advertisements through Google AdMob.

## Category suggestion
Business / Productivity (choose the closest category offered by Seller Portal).

## Review note
FieldPulse is an SMS automation and reporting utility. SMS permissions are essential to the core workflow: the app sends authorized device queries and receives/parses response SMS for monitoring and reporting. Please test the paste-codes workflow and the SMS query workflow during review.
