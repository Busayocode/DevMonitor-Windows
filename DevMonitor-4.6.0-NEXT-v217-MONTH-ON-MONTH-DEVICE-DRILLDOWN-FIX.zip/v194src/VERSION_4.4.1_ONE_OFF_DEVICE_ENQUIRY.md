# DevMonitor 4.4.1 — One-off Device Enquiry

## Purpose

My Devices remains the default persistent working group, but Device Monitor must also support an immediate enquiry for a random/new device without forcing the user to rerun the entire My Devices batch.

## Behavior

- **Add list** continues to add entered codes to the My Devices/working queue.
- **Replace** continues to replace the current Device Monitor working list.
- **Check Now — don't add to My Devices** parses the entered code(s), starts the SMS operation directly, and does not modify the My Devices queue.
- One-off results are shown in a dedicated **One-off Enquiry** section.
- The persistent **My Devices Results** section remains the saved working group.
- One-off enquiries use the same SMS permissions, selected SIM, timeout, response parsing, observation recording, payment estimate/progression access, and recheck behavior as normal Device Monitor enquiries.
- A one-off code is not added to the My Devices working database merely because it was checked.

## Protected areas

This change does not alter payment calculation rules, the 21st–20th payment cycle, Month-to-Month databases, loaded-report processing, or the My Devices profile/working-set architecture.
