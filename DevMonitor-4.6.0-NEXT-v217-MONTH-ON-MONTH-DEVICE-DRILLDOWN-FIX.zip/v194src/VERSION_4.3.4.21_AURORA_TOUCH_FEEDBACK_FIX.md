# FieldPulse 4.3.4.21 — Aurora Touch Feedback Fix

- Uses the 4.3.4.20 Aurora Gradient Buttons build as the exact baseline.
- Adds explicit Compose ripple indication to reusable primary and outlined Aurora buttons.
- Reuses supplied interaction sources when callers provide them.
- Creates stable interaction sources for buttons that do not supply one.
- Keeps disabled controls non-interactive and visually disabled.
- No changes to SMS, authentication, Firebase, SIMReg, reporting, backup, navigation, or business logic.
- No dependency or build-system changes.
- Version code: 78.
