#!/system/bin/sh
# DevMonitor phone-safe Gradle build helper.
#
# Release usage:
#   sh build-phone.sh assembleRelease --console=plain
#
# Release signing is supplied interactively through environment-backed Gradle
# properties. Passwords are never written to gradle.properties or this script.

set -eu

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$PROJECT_DIR"

if [ ! -f "./gradlew" ]; then
  echo "ERROR: ./gradlew was not found in $PROJECT_DIR" >&2
  exit 1
fi

# Android Code Studio / ARM64 AAPT2 locations used by the established phone build.
AAPT2=""
for candidate in \
  "${AAPT2_PATH:-}" \
  "$HOME/.androidide/aapt2" \
  "${PREFIX:-}/bin/aapt2" \
  "/data/data/com.tom.rv2ide/files/usr/bin/aapt2" \
  "/data/data/com.tom.rv2ide/files/home/.androidide/aapt2" \
  "/data/user/0/com.tom.rv2ide/files/usr/bin/aapt2" \
  "/data/user/0/com.tom.rv2ide/files/home/.androidide/aapt2"
do
  if [ -n "$candidate" ] && [ -x "$candidate" ]; then
    AAPT2="$candidate"
    break
  fi
done

if [ -z "$AAPT2" ]; then
  echo "ERROR: ARM-compatible AAPT2 was not found." >&2
  echo "Checked the standard Android Code Studio/phone locations." >&2
  echo "If necessary, set AAPT2_PATH to the ARM-compatible aapt2 binary." >&2
  exit 1
fi

IS_RELEASE=0
for arg in "$@"; do
  case "$arg" in
    assembleRelease|bundleRelease|:app:assembleRelease|:app:bundleRelease|*Release*)
      IS_RELEASE=1
      ;;
  esac
done

# Known release identity. The keystore itself was inspected and confirmed to be
# JKS with alias fieldpulse-release.
RELEASE_STORE_FILE="${RELEASE_STORE_FILE:-/storage/emulated/0/Download/1app/fieldpulse-release.jks}"
RELEASE_KEY_ALIAS="${RELEASE_KEY_ALIAS:-fieldpulse-release}"

if [ "$IS_RELEASE" -eq 1 ]; then
  if [ ! -f "$RELEASE_STORE_FILE" ]; then
    echo "ERROR: Release keystore not found:" >&2
    echo "  $RELEASE_STORE_FILE" >&2
    exit 1
  fi

  # Ask for the two release passwords only if they were not already supplied by
  # the caller. read -s prevents either password from being echoed on screen.
  if [ -z "${ORG_GRADLE_PROJECT_RELEASE_STORE_PASSWORD:-}" ]; then
    printf "Enter keystore password: "
    stty -echo 2>/dev/null || true
    IFS= read -r RELEASE_STORE_PASSWORD
    stty echo 2>/dev/null || true
    printf "\n"
    export ORG_GRADLE_PROJECT_RELEASE_STORE_PASSWORD="$RELEASE_STORE_PASSWORD"
    unset RELEASE_STORE_PASSWORD
  fi

  if [ -z "${ORG_GRADLE_PROJECT_RELEASE_KEY_PASSWORD:-}" ]; then
    printf "Enter key password: "
    stty -echo 2>/dev/null || true
    IFS= read -r RELEASE_KEY_PASSWORD
    stty echo 2>/dev/null || true
    printf "\n"
    export ORG_GRADLE_PROJECT_RELEASE_KEY_PASSWORD="$RELEASE_KEY_PASSWORD"
    unset RELEASE_KEY_PASSWORD
  fi

  export ORG_GRADLE_PROJECT_RELEASE_STORE_FILE="$RELEASE_STORE_FILE"
  export ORG_GRADLE_PROJECT_RELEASE_KEY_ALIAS="$RELEASE_KEY_ALIAS"

  # Online Reports configuration is read from gradle.properties.
  # Do not inject/override DRIVE_REPORT_FOLDER_ID or DRIVE_REPORT_API_KEY here.
fi

# Pass the ARM-compatible AAPT2 to Gradle. All remaining arguments are forwarded
# unchanged so the established command continues to work exactly as before.
exec sh ./gradlew "-Pandroid.aapt2FromMavenOverride=$AAPT2" "$@"
