# DevMonitor 4.3.5.58 — Superseded Month-to-Month Search Draft

4.3.5.58 introduced a staff-only Month-to-Month search field, but its search source was the full company device/hierarchy database. That scope was later rejected.

**Superseded by 4.3.5.59.** The final implementation searches only the four dedicated Month-to-Month databases and permits only a read-only Device Monitor peek for enrichment.

No payment calculation/resolver/progression/pathway changes were part of the 4.3.5.58 search work.
