# FieldPulse 4.3.4.25 — SIMReg navigation & performance refinement

Based on 4.3.4.24.

## Changes
- Fixed the Device Payment card's inner LazyColumn sizing by using `weight(1f)` so it receives the actual remaining viewport height.
- Added generous bottom content padding to keep the complete Payment / Incentive Warning reachable above the fixed navigation area.
- After a successful SIMReg import or opening a saved report, the report screen automatically animates to the workbook table/header so the newly loaded sheet is immediately visible.
- Memoized the expensive cycle activation total calculation to avoid repeating report-wide day summations during normal recomposition.
- Preserved the opening-book loading animation, progress display, Aurora dark UI, ripple feedback, authentication, parser, SMS, payment and reporting logic.
- No new dependencies.
