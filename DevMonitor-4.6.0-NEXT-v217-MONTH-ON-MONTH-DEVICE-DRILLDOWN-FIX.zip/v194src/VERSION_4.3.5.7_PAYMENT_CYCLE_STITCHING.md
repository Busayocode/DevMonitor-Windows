# DevMonitor 4.3.5.7 — Payment Cycle Source Stitching

This revision replaces the previous simple historical bridge/current-cycle calculation with a date-aware payment-cycle reconstruction layer.

## Rules
- The live payment cycle is always 21st → 20th using the real current date.
- Future Loaded Reports rows never advance the live cycle.
- Loaded Reports provide historical daily activation values where report coverage exists.
- Device Monitor SMS `Active` is treated as a cumulative calendar-month counter, not a 21st → 20th counter.
- A same-month SMS snapshot before the payment-cycle boundary is the strongest Active baseline.
- If that SMS baseline is unavailable, a fully covered Loaded Report calendar-month history can establish the Active baseline.
- If neither baseline exists, the app starts accumulating from the first available Device Monitor observation using its `Today` value and marks the cycle incomplete rather than inventing missing history.
- Subsequent SMS Active snapshots contribute only the increase since the previous SMS snapshot, preventing calendar-month cumulative values from being double-counted.
- When a report covers the beginning of a cycle and Device Monitor starts later, report dates and SMS-derived dates are stitched into one cycle.
- A live SMS observation for today overrides the corresponding Loaded Report/test value for today.
- Previous-month historical bridge data is reference-only and is never directly added to the current cycle total.
- The Payment Card displays the first known date and whether full cycle coverage is available.

## Example
Loaded Report: Sep 21–27. Device Monitor starts Sep 28.
- Sep 21–27 = Loaded Reports
- Sep 28 onward = Device Monitor SMS-derived contribution
- October = October SMS Active segment, with the calendar-month reset naturally handled by the October baseline of zero.

## Build
`sh ./gradlew :app:assembleDebug`

The source was not compiled in this environment because Gradle distribution download is unavailable here.
