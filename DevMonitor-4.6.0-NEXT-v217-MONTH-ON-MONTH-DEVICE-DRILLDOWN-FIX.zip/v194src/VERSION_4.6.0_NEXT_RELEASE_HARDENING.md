# 4.6.0-NEXT Release Hardening / Import Performance

## Changes in v152

### Release configuration
- Locked application ID to `com.aziitech.simregmonitor`.
- Locked release alias to `fieldpulse-release`.
- Recorded the release SHA-1 `8A:C3:1B:96:52:7D:F8:96:83:D5:84:A6:D5:99:10:0D:88:5D:F5:36`.
- Kept `fieldpulse-release.jks` out of source control.
- Cloud CI now injects the keystore and Drive API key from GitHub secrets.
- Cloud CI builds a signed release APK and verifies its actual certificate SHA-1 before publishing the artifact.
- Google Drive report folder remains `1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI`.

### Profile-save crash protection
- Fixed the Month-on-Month Current My Devices snapshot refresh so large staff/cluster scopes are processed in batches of 500 device IDs instead of one oversized SQLite `IN (...)` parameter list.
- Profile persistence is committed before the heavy working-set rebuild.
- Profile rebuild exceptions are caught and reported in-app instead of escaping the coroutine and crashing the process.

### SIMReg / Loaded Report performance direction
- The existing XLSX parser already avoids unrelated workbook entries and previews sheets before fully parsing the selected detailed sheet.
- The import pipeline continues to keep heavy parsing/database work off the main thread.
- The expensive Month-on-Month refresh now uses bounded SQL batches, reducing both SQLite variable-limit failures and large temporary argument arrays on phones.

## Known Firebase prerequisite

The checked-in `google-services.json` still contains the older debug Android certificate hash. The Firebase Android app must register the release SHA-1 above and then provide a refreshed Firebase-generated `google-services.json`. The release workflow deliberately does not fabricate this OAuth configuration.
