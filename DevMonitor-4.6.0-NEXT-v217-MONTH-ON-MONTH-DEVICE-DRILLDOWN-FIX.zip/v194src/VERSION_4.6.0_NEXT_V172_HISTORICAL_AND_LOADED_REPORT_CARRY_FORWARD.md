# DevMonitor 4.6.0-NEXT v172 — Historical Fixes + Loaded Report Carry-Forward

## Purpose

v172 is based on the v171 Loaded Report correction and explicitly carries forward the non-conflicting documented fixes from the historical development line.

## Carried-forward fixes

- Profile Builder remains vertically scrollable on shorter screens.
- Delete Profile remains available with confirmation and profile-owned data cleanup.
- Month-on-Month search/detail workflow remains available.
- Device Monitor payment evidence freshness/gating remains protected against stale Loaded Report data.
- The single floating processing/waiting window remains the app-wide processing presentation.
- Payment search remains targeted and separate from the protected PaymentEngine rules.
- Dashboard search now preserves the selected source: Device Monitor results open Device Monitor; Loaded Report results open the Loaded Report context.
- Payment-page presentation no longer displays the large technical authorization/confidentiality paragraph or unnecessary “Partner not available / Agent not available” placeholders.

## Loaded Report setup

- Validated imports remain calculation-isolated: they save the authoritative HQ snapshot without automatically refreshing downstream calculations.
- The exact validated report is displayed immediately after import.
- Open Loaded Report retrieves the latest stored report directly rather than reconstructing it through current-month filtering.
- The report table remains the supplied-report context and retains the established automatic table positioning.
- The floating processing window stays at 100% until the visible table is ready.

## Protected

- PaymentEngine and payment formulas.
- Device Monitor/SMS business logic.
- Two-month HQ snapshot architecture.
- Same-coverage-date replacement and older-report rejection.
- Current/previous month import ordering.
- Phone/cloud/PC build paths.

Build identity: versionCode 172 / versionName 4.6.0-NEXT.
