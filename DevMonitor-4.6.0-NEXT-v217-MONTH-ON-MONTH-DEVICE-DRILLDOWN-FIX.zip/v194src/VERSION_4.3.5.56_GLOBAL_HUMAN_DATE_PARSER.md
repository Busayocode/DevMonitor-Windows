# DevMonitor 4.3.5.56 — Global Human Date Parser

## Purpose
Prevent report/date interpretation bugs caused by human-written date variations. The parser is global so new import/report features should reuse it instead of adding one-off date regexes.

## Evidence for the design
Unicode CLDR documents date patterns with numeric, abbreviated and wide month forms and explicitly notes that input can differ substantially from normal locale formatting. ISO 8601 defines canonical machine-readable date representations, while common human conventions vary by element order, separators, leading zeros, year width, month names and ordinals.

## Supported input families
- ISO/YMD: `2026-09-25`, `2026/09/25`, `20260925`.
- Numeric DMY/MDY: `25/09/2026`, `09/25/2026`, dotted/dashed variants and optional leading zeros. Ambiguous numeric forms use DevMonitor's established DMY convention.
- Textual: `25 September 2026`, `September 25, 2026`, `2026 September 25`.
- Abbreviations: `25 Sep 2026`, `Sep 25 2026`, `Sept 25, 2026`.
- Ordinals: `1st`, `2nd`, `3rd`, `4th`, plus common locale ordinal suffixes.
- Roman month notation: `25.IX.2026`.
- Month/year: `September 2026`, `2026 September`, `09/2026`, `2026-09`.
- Ranges: `September 1-23rd`, `1st-23rd September`, `Sep 1st - 23rd September 2026`, `2026-09-01 - 2026/09/23`.
- Range endpoints may use different formats.
- Locale month names are harvested from platform locale data where unambiguous, with English report names explicitly supported.

## Canonical storage rule
All database/internal comparison dates remain `LocalDate` / ISO `yyyy-MM-dd`. Human formatting is presentation only.

## Ambiguity rule
There is no mathematically universal interpretation of an ambiguous string such as `03/04/2026`. DevMonitor keeps the established day/month report convention. If one numeric component exceeds 12, the parser uses the only valid interpretation.

## Specific bug prevented
`aaaaaaa DAILY SIM-REG REPORT SEPT 1-23RD.xlsx` is now parsed as coverage September 1–23, not September 1–30.

## Protected areas
This change does not modify payment calculation/resolver logic and does not modify the paused Month-on-Month calculation.
