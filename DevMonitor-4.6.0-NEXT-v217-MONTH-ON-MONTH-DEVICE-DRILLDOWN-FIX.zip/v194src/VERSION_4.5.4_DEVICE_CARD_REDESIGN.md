# DevMonitor 4.5.4 — Device-card redesign

## Milestone
`NL-P1-08` — Device-card redesign.

## Scope
The Device Monitor **My Devices Results** cards were redesigned for clearer field use:
- device code and ownership are immediately visible;
- monitoring status is separated from performance values;
- Today, MTD, Bar 48 and Bar 96 are shown as compact metrics;
- payment progression has a dedicated visual entry point;
- flags and errors remain visible;
- Payment Estimate and Recheck are the primary actions.

## Protected payment boundary
This milestone is display/integration work only. The existing payment calculator, payment-cycle rules, `PaymentCycleResolver`, progression thresholds, and payment data pathways were not changed.

## Build
- Version name: `4.5.4`
- Version code: `138`
