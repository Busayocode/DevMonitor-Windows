# DevMonitor 4.6.0-NEXT v170 — Cloud Build

## Purpose
This recovery build is a normal Android project that can be compiled from GitHub Actions or a PC, while retaining the established Android Code Studio/ARM64 phone build path.

## Cloud build target
```sh
./gradlew :app:assembleDebug --no-daemon --console=plain
```

The GitHub Actions workflow uses Java 17 and the Gradle 8.7 wrapper. The workflow can compile the Android project without relying on the phone's local Gradle environment.

## Current recovery scope
- Recovery code base: v162.1.
- Approved post-v162.1 UI work retained, especially the single informative floating waiting window.
- HQ storage uses two physical monthly stores: current calendar month and immediately previous calendar month.
- Older coverage-date imports are rejected.
- Newer coverage-date imports replace the complete monthly snapshot.
- **Same coverage-date imports are accepted as complete replacements**, allowing different complete HQ exports with the same coverage end date to arrive at different times.
- Current and previous month imports are independently addressable; import order does not matter.
- HQ import remains storage-only and does not silently trigger downstream heavy calculations.
- PaymentEngine, payment formulas/progression, Device Monitor/SMS logic, Profile Builder and release identity remain protected.

## Build environments
- **PC:** use `BUILD_FOR_PC.md` and the standard desktop Android SDK/AAPT2 toolchain.
- **Android phone:** use `BUILD_ON_PHONE.md` / `build-phone.sh` and its ARM-compatible AAPT2 override.
- **GitHub Actions:** use the repository workflow for authoritative cloud compilation when the source is pushed to GitHub.

The PC and phone paths build the same Android application; the phone helper must not be copied into the desktop build path.
