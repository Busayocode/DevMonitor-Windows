# DevMonitor 4.6.0-NEXT v153 — MOM Profile Scope & Profile Builder Fix

## Fixed
- When a previous-month Loaded Report is imported before a My Devices profile exists, the historical Previous Month Full database is no longer stranded from the user's later profile scope. Saving/updating the profile explicitly rebuilds Previous Month My Devices from the already imported historical snapshot.
- Current Month My Devices continues to follow the active profile.
- The four physical Month-on-Month SQLite databases remain separate.
- Payment calculation rules and PaymentEngine were not modified.
- Profile Builder is now vertically scrollable so all controls remain reachable on shorter screens.

## Regression intent
Test both report orders on a fresh install:
1. Current month -> SMS -> previous month -> MOM/payment.
2. Previous month -> current month -> SMS -> MOM/payment.

The expected result is that previous-month data remains visible to MOM when the active profile has matching devices, regardless of report import order.
