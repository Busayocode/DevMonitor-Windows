# FieldPulse 4.3.4.7 — Authentication Build Fix

This correction build fixes the Compose compilation errors introduced in the 4.3.4.6 payment landing screen.

## Source fixes
- Capture `LocalContext.current` in the composable and reuse the captured context from the click callback.
- Correct Material 3 `Card` argument ordering by passing `onClick` and `modifier` by name.
- No authentication model change.
- No database reset.
- No parser or existing FieldPulse functionality removed.

## Debug Firebase fingerprint
- SHA-1: `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- SHA-256: `1D:BE:EE:61:64:A2:FC:97:55:C3:BD:8A:7B:54:02:4A:68:22:64:69:0E:55:91:15:6D:4D:86:AE:B6:C8:AA:AA`

## Build environment
- Android Code Studio on Android phone
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- JDK 17
- compileSdk 36
- targetSdk 36
- ARM-compatible AAPT2 override via `build-phone.sh`

## Version naming
The authentication workstream uses the `4.3.4.x` family. This correction is `4.3.4.7`; subsequent corrections remain in that family.

## Firebase
The debug fingerprint above must be added to Firebase project `fieldpulse-b3eb3` for Android package `com.aziitech.simregmonitor`. After adding SHA-1/SHA-256, download the refreshed `google-services.json`.
