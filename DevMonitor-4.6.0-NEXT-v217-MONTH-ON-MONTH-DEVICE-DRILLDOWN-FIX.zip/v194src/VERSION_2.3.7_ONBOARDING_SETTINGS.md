# FieldPulse 2.3.7 — Introduction & Guided Tour UX

## Changes
- The first-launch introduction remains the normal entry point and is no longer bypassed by a primary “Explore First” action.
- Introduction content is vertically scrollable so longer messages can be read completely on smaller screens.
- “Next” is now the primary action on the introduction; “Explore First” is the secondary escape action.
- The Guided Tour is no longer offered as a primary action inside the initial introduction.
- Selecting the Devices / Device Monitor menu now invokes the guided workflow for users who have completed the introduction but have not completed the tour.
- The same behavior is applied to the drawer’s Open Device Monitor quick action and the dashboard’s Open Device Monitor button.
- Existing manual Guided Tour access remains available for users who deliberately choose it.
