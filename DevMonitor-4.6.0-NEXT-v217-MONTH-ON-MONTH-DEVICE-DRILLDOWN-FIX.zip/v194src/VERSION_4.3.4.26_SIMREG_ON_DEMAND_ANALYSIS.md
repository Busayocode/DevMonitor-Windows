# FieldPulse 4.3.4.26 — SIMReg on-demand analysis

## Purpose
Reduce post-import sluggishness on common and lower-powered Android phones by making SIMReg report opening a lightweight data-view operation.

## Behavior change
- Opening/importing an Excel report loads and displays the workbook only.
- No report-wide summaries are calculated during normal opening.
- No cycle activation total is calculated during normal opening.
- No incentive/payment estimate is calculated during normal opening.
- No partner portfolio calculation is calculated during normal opening.
- No HQ ↔ Device Monitor comparison is calculated during normal opening.
- Previous-report comparison files are loaded only when Private HQ Analysis is explicitly opened.
- Hierarchy totals are calculated only when Hierarchy is explicitly opened.
- Selecting a normal table row no longer produces an incentive estimate card.
- Opening a specific Device ID still enters the device payment card, where device-specific analysis is appropriate.
- The workbook auto-advance/scroll behavior from 4.3.4.25 is preserved.
- The Aurora UI and authentication/business logic are otherwise preserved.

## Performance detail
The previous implementation loaded up to six saved report workbooks in the background whenever the SIMReg screen opened and derived several report-wide values during composition. 4.3.4.26 removes that eager historical-report loading and report-wide calculations from the normal workbook path.

## Build
- versionName: 4.3.4.26
- versionCode: 83
- Baseline: FieldPulse 4.3.4.25
