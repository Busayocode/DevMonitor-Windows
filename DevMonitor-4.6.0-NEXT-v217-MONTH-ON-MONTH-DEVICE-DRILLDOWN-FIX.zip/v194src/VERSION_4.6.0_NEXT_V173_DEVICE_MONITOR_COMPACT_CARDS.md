# DevMonitor 4.6.0-NEXT v173 — Device Monitor Compact Cards

## Purpose

Reduce the vertical size and scrolling burden of Device Monitor / My Devices result cards while preserving existing data and behavior.

## Changes

- Result cards use tighter internal spacing.
- Today, MTD, B48 and B96 are shown in one compact metric row when available.
- Successive unflagged cards alternate subtle Aurora accents (blue, emerald, violet).
- Flagged cards continue to use the error accent.
- The duplicate in-card payment progression viewer was removed.
- The remaining payment navigation action is named **EARNING PROGRESS**.
- Recheck remains separate and unchanged.

## Protected

- PaymentEngine and all payment formulas.
- Payment-cycle and progression thresholds.
- Device Monitor/SMS query behavior.
- Loaded Report and HQ snapshot architecture.
- Payment data freshness/gating.
- Existing result fields and error handling.

## Build identity

`versionCode = 173` / `versionName = 4.6.0-NEXT`
