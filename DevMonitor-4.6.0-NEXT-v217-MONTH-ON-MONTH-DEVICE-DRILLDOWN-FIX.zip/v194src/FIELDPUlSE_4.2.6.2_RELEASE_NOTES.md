# FieldPulse 4.2.6.2

Focused correction: saved Company SIMReg workbook reopening.

- Validates saved workbook existence and non-zero size before parsing.
- Uses buffered file reading for persisted workbooks.
- Adds a diagnostic load path so the UI reports the actual saved-workbook failure instead of hiding it.
- Preserves the original workbook and existing retention rules.
- Preserves SIMReg/Activations intelligence, table behavior, pinch-to-zoom, drawer isolation, and ads.
- Does not change the Android versionCode/versionName in this maintenance build; 4.2.6.x is the project release naming convention until the next major milestone.
