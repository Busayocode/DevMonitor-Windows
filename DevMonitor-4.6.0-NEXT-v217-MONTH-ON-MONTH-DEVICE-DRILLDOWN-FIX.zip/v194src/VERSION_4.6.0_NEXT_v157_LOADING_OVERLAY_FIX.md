# DevMonitor 4.6.0-NEXT v157 — Unified Floating Loading Overlay

## Purpose
Remove the obsolete embedded SIMReg loading panel now that DevMonitor has a unified floating activity indicator.

## Changes
- Removed the old SIMReg-specific animated loading card from `SimRegReportScreen`.
- Removed its dedicated book/page animation and progress presentation.
- Retained the existing import/loading state logic so the operation itself is unchanged.
- Retained the unified `DevMonitorFloatingLoader`.
- Repositioned the unified loader from the bottom of the screen to a top overlay with safe spacing below the app chrome.
- The floating loader remains visible above the current screen content and does not consume layout space.

## Protected
- PaymentEngine/payment rules unchanged.
- MOM four-database architecture unchanged.
- Device Monitor payment integration unchanged.
- Profile deletion and MOM result detail changes from v155/v156 retained.

## Version
- versionName: `4.6.0-NEXT`
- versionCode: `157`
