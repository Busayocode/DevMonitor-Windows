# DevMonitor 4.5.15 Change Log

- Fixed Device Monitor payment progression around the 20th/21st payment-cycle boundary.
- Device Monitor now finds the latest Active observation on or before the 20th instead of requiring an exact 20th SMS.
- Loaded Report baseline is accepted when its coverage explicitly reaches the 20th and the device exists in that report; daily rows are not incorrectly required for every zero-activation day.
- Post-20th Device Monitor Active is selected first and compared with the Loaded Report import timestamp before choosing current-cycle evidence.
- A newer Loaded Report can provide current-cycle contribution only after the historical baseline is established.
- If neither baseline source exists, the Device Monitor payment card remains unavailable with an actionable historical-data warning.
- MTD remains excluded from payment progression.
- Existing payment cycle and payment tiers are unchanged.
- Version: 4.5.15 / versionCode 149.
