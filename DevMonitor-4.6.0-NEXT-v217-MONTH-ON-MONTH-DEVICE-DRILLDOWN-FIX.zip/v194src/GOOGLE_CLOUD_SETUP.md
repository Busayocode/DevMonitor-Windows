# FieldPulse 4.0 — Google Account & Cloud Backup Setup

1. Open Google Cloud Console and create/select the project used for FieldPulse.
2. Enable **Google Drive API**.
3. Configure the OAuth consent screen for the FieldPulse application.
4. Create an **Android OAuth client** with package name `com.aziitech.simregmonitor`.
5. Add the SHA-1 certificate fingerprint for the signing key used by the installed build. For the production key, verify the fingerprint against the known production certificate before publishing.
6. The app requests the Google account email and the private Drive app-data scope only.
7. Build and install FieldPulse 4.0, choose **Settings → Account & Cloud Backup → Sign in**, then test **Backup** and **Restore**.

The app does not embed a Google client secret. Backup files are stored in the user's private Drive app-data area rather than the normal visible Drive root.
