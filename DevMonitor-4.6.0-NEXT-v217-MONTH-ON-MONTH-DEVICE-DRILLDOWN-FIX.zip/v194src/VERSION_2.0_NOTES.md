# FieldPulse 2.0.0

SMS Automation & Reporting App

## Major UI upgrade
- Professional green operations dashboard
- Bottom navigation: Dashboard, Devices, Agents, Payments, Settings
- Dedicated Flags Centre with Company-priority ordering
- Visible flag badges on dashboard and device cards
- Company and Partner MTD summary cards
- Batch progress card and clearer start/retry actions
- Professional FieldPulse branding and adaptive Android icon

## Existing functionality retained
- SMS batch automation with 1x default and optional repeat counts
- Multi-SIM selection
- 2-minute response timeout
- Daily/MTD analytics and month-on-month history
- Company/Partner ownership rules
- Conversion Lost and increasing Conversion Lost flags
- Agent/Partner database, phone/contact linking and locations
- 21st-to-20th payment tracking
- Excel reporting
- Single-worker Gradle configuration for mobile IDE stability


## v2.0.1 update
- Restored visible SIM selector for dual/multi-SIM phones.
- SMS is sent through Android SmsManager SMS APIs only; no RCS fallback is used.
- Optional sent/delivered SMS delivery reports are monitored when the carrier/device provides them. Negative delivery reports trigger up to two immediate retries before the next query, with a visible warning while the batch continues.
- Company devices crossing the day-15 MTD <10 checkpoint remain flagged until MTD reaches 10+.
- No-sales flag threshold increased from 2 to 4 consecutive recorded days.
