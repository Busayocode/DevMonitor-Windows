# FieldPulse 4.3.4.15 — Aurora UI Composition Redesign

## Purpose
This build addresses the screenshot finding that the earlier Aurora work still looked like the old Material UI with a blue palette. The redesign therefore changes screen composition and visual hierarchy, not just colors.

## Visible changes
- Aurora dark hero on Dashboard with live-monitor identity.
- Compact live metric cards with blue/cyan/violet/mint accents.
- Attention Centre and Batch Control use glass-panel surfaces and stronger information hierarchy.
- HQ report access is presented as a dedicated intelligence card.
- Bottom navigation uses custom-drawn FieldPulse icons instead of Unicode symbols.
- Top app bar and bottom navigation use the deep-navy FieldPulse identity.
- Device Monitor, Agents, Settings and Payment Intelligence landing surfaces receive the Aurora glass-panel treatment.
- Primary buttons retain restrained 3D elevation; disabled actions do not receive large grey shadows.

## Preservation
No intentional changes were made to authentication rules, Firebase configuration, Firestore partner authorization, SQLite migration behavior, SIMReg parsing, August historical seed, SMS automation/recovery/recheck, payment calculations, backup, or existing navigation actions.

## Build
`sh build-phone.sh assembleDebug --console=plain`
