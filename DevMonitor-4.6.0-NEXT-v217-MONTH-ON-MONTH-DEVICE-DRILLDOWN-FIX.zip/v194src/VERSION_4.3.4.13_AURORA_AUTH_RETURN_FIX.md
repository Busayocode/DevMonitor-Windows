# FieldPulse 4.3.4.13 — Aurora Authentication Return Fix

## Fix
Corrected four invalid `return@Button` labels in `Authentication.kt`. The dialog now uses the custom `FieldPulseButton`, so the early returns are labeled `return@FieldPulseButton`.

## Scope
- No authentication flow redesign.
- No Firebase configuration changes.
- No database reset or migration changes.
- No UI redesign changes.
- Preserves the 4.3.4.12 Aurora UI baseline.

## Build
Version code: 71
Version name: 4.3.4.13
