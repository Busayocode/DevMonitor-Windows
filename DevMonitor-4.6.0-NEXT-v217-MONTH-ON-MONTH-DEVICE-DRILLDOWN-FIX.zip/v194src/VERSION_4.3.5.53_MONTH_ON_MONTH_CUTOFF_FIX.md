# DevMonitor 4.3.5.53 — Month-on-Month Cutoff Integrity Fix

## Root cause found

The Month-on-Month calculator was using the normalized `activation_days` table to determine the latest available report date, but the XLSX importer was persisting daily cells beyond the report's declared coverage window.

For example, a report explicitly covering **September 1–23** can still contain zero/empty columns for September 24–31. Those cells are not available report data, but the importer could store them and allow the normalized frontier to move beyond September 23. The Month-on-Month calculator could then use an incorrect cutoff and compare August through too many days.

## Fix

- During normalization, daily values are now filtered to the report's declared `coverageStart..coverageEnd`.
- Future/placeholder XLSX columns no longer become normalized dates.
- Normalized report selection now joins report metadata and refuses to let dates after a report's declared `coverage_end` define that report's effective data end.
- Device Monitor remains eligible to extend the current-month cutoff only when a real newer observation exists.
- Current and previous populations remain independently determined from their respective monthly report data.
- Month-on-Month remains strictly calendar-month/report-data based, not payment-cycle based.

## Verified against the supplied test reports

For territory **AIYETORO / OYEGUNWA OLUWABUSAYO** using the supplied September 1–23 and August data:

- September 1–23 = **1,204**
- August 1–23 = **1,058**
- Expected change = **+146 (+13.8%)**
- Expected comparison cutoff = **2026-09-23** when no newer Device Monitor observation exists.

The previous displayed 1,155 value corresponds to August 1–25, which is not the required same-period cutoff for a September 1–23 comparison.

## Protected

- No payment calculation/resolver/progression logic was changed.
- My Devices architecture was not changed.
- Historical device-ownership transfer handling remains deferred to Fork 001.
