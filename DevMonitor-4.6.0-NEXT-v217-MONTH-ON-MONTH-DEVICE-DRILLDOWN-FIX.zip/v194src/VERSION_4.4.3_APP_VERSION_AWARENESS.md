# DevMonitor 4.4.3 — App Version Awareness

## Included
- Settings now explicitly shows the installed DevMonitor version and Android version code.
- Central `AppVersionManager` checks Firebase Firestore for the minimum/latest DevMonitor version.
- Feature-specific version gates can be attached to resources/features by key.
- The Month-on-Month Performance entry point is version-aware.
- If a required version is newer than the installed version, DevMonitor presents an update dialog with the required/latest version and an Update action instead of silently failing.
- Network/config lookup failures are non-blocking; existing functionality is preserved when no version policy can be retrieved.

## Firestore configuration
Create/update the document:

`app_config/devmonitor_version`

Example fields:

```json
{
  "latestVersionName": "4.4.3",
  "latestVersionCode": 134,
  "minimumVersionName": "4.4.3",
  "minimumVersionCode": 134,
  "updateUrl": "https://play.google.com/store/apps/details?id=com.aziitech.simregmonitor",
  "reason": "A newer DevMonitor version is required for the latest features.",
  "features": {
    "month_on_month": {
      "minimumVersionName": "4.4.3",
      "minimumVersionCode": 134,
      "reason": "Month-on-Month Performance requires DevMonitor 4.4.3 or newer."
    }
  }
}
```

For a future release, update `latestVersionName`/`latestVersionCode` and set the feature's `minimumVersionCode` to the release that first supports it. Older installed clients will then prompt the user before entering that feature.
