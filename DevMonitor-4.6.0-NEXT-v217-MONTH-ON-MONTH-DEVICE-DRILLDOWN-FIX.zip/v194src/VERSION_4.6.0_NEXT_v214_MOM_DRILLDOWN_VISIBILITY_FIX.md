DevMonitor 4.6.0-NEXT v214 — MOM drill-down visibility fix

Based on v213. Normalizes saved My Devices user type and staff level by trimming whitespace before uppercasing, so valid PARTNER/STAFF role checks do not hide the Month-on-Month by Device or hierarchy drill-down buttons because of stray surrounding whitespace. No MOM calculation, database, payment, report import, or Zero Devices logic changed.
Version code: 214.
