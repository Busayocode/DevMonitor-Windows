# DevMonitor 4.3.4.30 — Continuous Loaded Reports and Safe Re-imports

- Loaded report activation data remains one continuous normalized dataset keyed by Device ID + date.
- Exact duplicate imports reuse the existing inventory record instead of creating a duplicate.
- Re-importing a report updates/replaces only the matching Device ID/date values.
- Deleting an inventory record removes report metadata only; it does not erase normalized activation dates.
- Report view now defaults to the continuous normalized rolling dataset.
- Device metadata is merged by Device ID and the latest available metadata is shown.
- Continuous dates are displayed across the full retained range with month-aware light/dark tints.
- Added additional database/screen/import logging around the continuous view and duplicate handling.
