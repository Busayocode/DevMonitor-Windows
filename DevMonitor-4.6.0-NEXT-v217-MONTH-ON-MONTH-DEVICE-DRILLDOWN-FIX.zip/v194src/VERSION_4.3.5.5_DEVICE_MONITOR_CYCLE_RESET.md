# DevMonitor 4.3.5.5 — Device Monitor Payment-Cycle Reset

Device Monitor payment cards now use the live 21st→20th payment cycle directly from daily SMS observations.

- At the start of a new cycle, the card starts at 0 when no sales have been recorded in the new cycle.
- Previous-cycle historical bridge data is displayed only as reference and is never added to the new-cycle progression.
- Future-dated observations are ignored.
- The current cycle is explicitly displayed (for example, Sep 21 → Oct 20, the October payment cycle).
- Loaded Reports date-aware payment intelligence remains unchanged.
- Existing Device Monitor historical bridge, SMS, billing, onboarding, and other functionality is preserved.
