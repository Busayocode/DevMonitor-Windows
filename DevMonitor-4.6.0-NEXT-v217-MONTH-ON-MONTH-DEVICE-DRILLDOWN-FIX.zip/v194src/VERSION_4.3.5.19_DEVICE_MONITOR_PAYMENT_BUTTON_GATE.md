# Version 4.3.5.19 — Device Monitor Payment Button Gate

Based directly on the 4.3.5.10 baseline.

- The payment-card reveal is gated at the **Open Payment Estimate** button.
- Tapping the result card itself no longer reveals the payment card.
- Before the 21st, the button reveals the card normally.
- From the 21st onward, the button reveals the card if either:
  - the latest imported company report covers through the prior-cycle cutoff (the 20th), or
  - this device already has an earlier Device Monitor observation in the current payment cycle.
- Therefore Device Monitor can build its own history from the 21st onward; missing pre-21st history does not permanently block progression.
- On the first Device Monitor observation of a new cycle, with no qualifying report baseline, the card remains hidden and the agreed warning fades in/out.
- PaymentCycleResolver calculation logic is unchanged from 4.3.5.10.
