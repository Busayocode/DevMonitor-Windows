# DevMonitor 4.6.0-NEXT v161 — Two-Month HQ Architecture

## Purpose
Move HQ activation storage from the former continuous rolling three-month database to exactly two physical monthly SQLite databases: the current calendar month and the immediately previous calendar month.

## Import policy
- One HQ report belongs to one calendar month.
- HQ reports are authoritative exports of the company database.
- Import is Replace All for that month. Missing devices are meaningful and must not survive a newer snapshot.
- August may be imported after September; month routing is independent.
- Older same-month reports are rejected. Same coverage-end reports are duplicates and rejected. Newer same-month reports replace the stored snapshot atomically.
- Reports outside current/previous month are rejected.
- Import performs no downstream refresh/calculation.

## Calculation policy
Loaded Report payment progression, historical baselines, cycle totals, Device Monitor payment bridges, Month-on-Month comparison and search retrieve their data from the month-specific HQ store. Existing payment formulas and thresholds are unchanged.

## Month-on-Month
Month-on-Month is now a calculation/search layer over the two authoritative HQ month stores. The previous four duplicate `devmonitor_mom_*` databases are obsolete. Device Monitor remains a read-only freshness/enrichment source where the established feature requires it.

## Migration
Existing `fieldpulse_company_activations.db` data is migrated once for the current and previous months. The final normalized monthly state is carried forward, after which the legacy company database and obsolete Month-on-Month caches are removed.

## Build
- versionName: `4.6.0-NEXT`
- versionCode: `161`
- Existing `.github/workflows/android-build.yml` remains the build workflow.
- Payment logic is explicitly protected from this architecture change.
