# DevMonitor 4.5.3 — Visual Trends

## Purpose
Complete NEXT LEVEL Phase 1 item `NL-P1-07` by adding a compact visual history layer without introducing background calculations or changing established business logic.

## Included
- 7-day and 30-day trend ranges for the active profile.
- SIMReg sales trend.
- Active-device trend.
- Bar 48 / Conversion Lost trend.
- Company versus Partner sales mix.
- Dashboard and drawer entry points.
- Explicit Refresh action and range controls.
- Profile-scoped SQLite range query.

## Data semantics
- Data comes from the existing `daily_observations` table.
- Missing observation days are not treated as zero sales.
- Active totals are the sum of observed device Active values for each date.
- Bar 48 is displayed as the existing Conversion Lost-related metric; no new payment or conversion formula is introduced.

## Performance boundary
- Opening Visual Trends does not calculate anything.
- Refresh and range selection are the user-authorized calculation triggers.
- No background monitoring, sync, report processing, payment estimation or automatic trend refresh was introduced.

## Protected functionality
Payment-cycle rules, Device Monitor/SMS logic, profile isolation, report authority, My Devices, Month-to-Month and monetization behavior remain unchanged.
