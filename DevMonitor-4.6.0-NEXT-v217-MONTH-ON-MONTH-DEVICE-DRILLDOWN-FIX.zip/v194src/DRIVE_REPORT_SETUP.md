# Online Company Reports setup

Version 4.3.5.23 adds an Online Company Reports option to the existing SIMReg/Activations report loader.

The app reads Excel files from one **public/read-only Google Drive folder** using the Google Drive REST API. It does not give users write access to the folder and it does not retain the downloaded workbook after import.

## Build configuration

Set these Gradle properties before building:

```properties
DRIVE_REPORT_FOLDER_ID=your_google_drive_folder_id
DRIVE_REPORT_API_KEY=your_google_cloud_api_key
```

The app converts these into `BuildConfig.DRIVE_REPORT_FOLDER_ID` and `BuildConfig.DRIVE_REPORT_API_KEY`.

The API key is an application identifier, not a secret. Restrict it in Google Cloud to the Drive API and the intended application/API usage. The Drive folder and its Excel files must be readable without user authentication.

## Runtime flow

1. User opens **SIMReg Report**.
2. User can choose **Download Report Online**.
3. The app lists `.xlsx` files from the configured folder, newest modified file first and marked **LATEST • Recommended**.
4. User may choose any listed file.
5. The selected workbook is downloaded to temporary cache storage.
6. The existing parser and normalized `CompanyActivationStore.importReport()` pipeline process it.
7. Payment/progression analytics are still deferred until the user requests them.
8. The temporary workbook is deleted after successful or failed import.

If a selected report ends before the current normalized database frontier, the report is retained as report inventory metadata but its older daily values are not allowed to roll the normalized database backward.
