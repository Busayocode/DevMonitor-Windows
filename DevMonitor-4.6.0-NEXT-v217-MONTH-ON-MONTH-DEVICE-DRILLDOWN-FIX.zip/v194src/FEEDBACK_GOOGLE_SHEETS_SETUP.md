# FieldPulse in-app feedback → Google Sheets

The app now submits feedback directly to a Google Apps Script web app. The script appends each submission to a Google Sheet.

## 1. Create the Sheet
Create a Google Sheet named `FieldPulse Feedback`. Create a tab named `Feedback`. The script will create the header row automatically if the sheet is empty.

## 2. Create the Apps Script
In the Sheet, open **Extensions → Apps Script** and replace the editor contents with:

```javascript
const SHEET_NAME = 'Feedback';

function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME)
    || SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      'Timestamp', 'Type', 'Message', 'Contact', 'App Version',
      'Device', 'Android Version', 'Premium'
    ]);
  }

  const p = e.parameter || {};
  sheet.appendRow([
    new Date(),
    p.type || '',
    p.message || '',
    p.contact || '',
    p.appVersion || '',
    p.device || '',
    p.androidVersion || '',
    p.premium || ''
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ok: true}))
    .setMimeType(ContentService.MimeType.JSON);
}
```

## 3. Deploy
Choose **Deploy → New deployment → Web app**.

Use:
- **Execute as:** Me
- **Who has access:** Anyone

Copy the resulting `https://script.google.com/macros/s/.../exec` URL.

## 4. Put the URL into the Android build
In `gradle.properties`, add:

`FEEDBACK_WEB_APP_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec`

Then rebuild the app.

## What gets recorded
Each feedback submission records the timestamp, feedback type, message, optional contact, FieldPulse version, device model, Android version, and Premium status.
