# FieldPulse 2.2.5

- Added direct APK download for in-app updates.
- Added Android FileProvider for secure APK sharing.
- Added handling for Android's "install unknown apps" permission.
- Update button now downloads the APK, then launches Android's package installer.
- Retained Google Drive update-manifest support.
- Version code: 32.
