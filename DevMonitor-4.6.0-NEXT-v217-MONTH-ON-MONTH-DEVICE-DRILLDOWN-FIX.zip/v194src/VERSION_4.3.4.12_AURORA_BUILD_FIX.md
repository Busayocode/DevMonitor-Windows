# FieldPulse 4.3.4.12 — Aurora UI Build Fix

## Purpose
Correction build for 4.3.4.11. The Aurora UI redesign introduced an over-broad source replacement that changed native Compose control names such as `TextButton` and `IconButton` and produced invalid `OutlinedButton` color types.

## Corrections
- Restored native `TextButton` and `IconButton` call sites.
- Corrected accidental `FieldPulseFieldPulseOutlinedButton` names to `FieldPulseOutlinedButton`.
- Kept intentional `FieldPulseButton` and `FieldPulseOutlinedButton` replacements for filled/outlined primary controls.
- Updated the custom outlined-button wrapper to use Material 3 `ButtonColors` and `ButtonDefaults.outlinedButtonColors()`.
- Preserved all Aurora colors, transitions, shadows, icon redesign, authentication, Firestore partner authorization, SIMReg, August historical seed, SQLite, SMS and payment logic.
- No destructive database migration or reset.

## Build environment
- AGP 8.6.1
- Gradle 8.7
- Kotlin 2.0.21
- JDK 17
- compileSdk/targetSdk 36
- Android Code Studio phone build with ARM-compatible AAPT2 override.

## Phone build
`sh build-phone.sh assembleDebug --console=plain`
