# DevMonitor 4.5.15 — Device Monitor Payment Boundary Fix

## Purpose
Correct Device Monitor payment progression without introducing another database.

## Rule
Device Monitor `Active` is cumulative from calendar day 1. The payment cycle starts on day 21.

For a date after the 20th:

`Device Monitor progression = latest qualifying Active after the 20th - Active baseline through the 20th`

The baseline is established from:
1. the latest Device Monitor Active observation available on/before the 20th; or
2. a Loaded Report that explicitly covers the device through the 20th.

If neither exists, the Device Monitor payment card remains unavailable and displays the historical-data warning.

## Current-value source
If a post-20th Device Monitor Active observation is newer than the Loaded Report snapshot, that Active value is authoritative.
If a newer Loaded Report provides current-cycle dates after the 20th, its current-cycle contribution may be used only after the baseline is established.

MTD is never substituted for Active.

## Important
The Loaded Report calculator remains separate and retains its own payment rules, including Sunday qualification. Device Monitor does not use Sunday bonuses.
