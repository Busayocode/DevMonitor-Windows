# v217 — Month-on-Month device drill-down button restored

## Change
Restore access to **View Month-on-Month by Device** for profiles with a saved My Devices list.

Previously, the button and loader were restricted to exact profile labels (`PARTNER` or `STAFF` with staff level exactly `STAFF`). That could hide the device comparison even when the profile had saved devices, for example when role labels differ slightly.

The button is now shown whenever the saved My Devices list is non-empty. The comparison remains scoped to those saved device codes; this does not broaden HQ report search scope or change comparison formulas, cutoffs, payment calculations, or import behavior.

## Version
- versionCode: 217
- versionName: 4.6.0-NEXT

## Verification
- Confirmed the UI visibility condition and loader use the saved device list as the scope.
- Android compilation still needs to be verified by the project's GitHub Actions build.
