# FieldPulse 4.3.4.2 — Authentication Hardening

## Purpose
Harden the 4.3.4 authentication foundation against arbitrary phone-number OTP requests while moving Google identity into Firebase Authentication.

## Changes
- Firebase Authentication added.
- Google ID token exchanged for Firebase credential.
- Firebase UID stored against the FieldPulse account.
- Firebase Phone Authentication added for the staff-line verification step.
- OTP requests restricted to `0805557xxxx`.
- 10-minute resend cooldown added.
- Successful OTP links the phone credential to the authenticated Google/Firebase account.
- Phone verification timestamp persisted.
- A successfully OTP-verified qualifying staff account receives full FieldPulse access, including Payment Intelligence.
- Database migrated from version 8 to 9.
- Android display name changed to FieldPulse Monitor to avoid exact-name collision on Google Play.

## Not claimed
- The `0805557xxxx` pattern is not an authoritative staff registry.
- For the current FieldPulse operating model, successful OTP verification of a qualifying staff line is the staff-account authorization event.
- The build is not phone-verified until Android Code Studio compilation and physical-device testing succeed.
