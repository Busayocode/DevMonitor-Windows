# FieldPulse Privacy Policy — draft

Last updated: 27 August 2026

FieldPulse is an SMS automation and reporting application.

## Information processed
Depending on the features used, FieldPulse may process:
- Device/partner codes entered by the user.
- SMS messages required for the monitoring/reporting workflow.
- SMS delivery status where the Android device/carrier provides it.
- Agent/partner information entered by the user, such as names, phone numbers, addresses and linked codes.
- Location information when the user explicitly uses the location feature to save/verify a field location.
- Local app settings, history and report data stored on the device.

## How the information is used
The information is used to perform the app's monitoring, SMS automation, reporting, history, database and operational-analysis functions requested by the user.

SMS information is not used for advertising or marketing.

## Advertising
FieldPulse may use Google AdMob to display advertisements. AdMob may process advertising-related information under Google's applicable privacy terms and settings.

## Sharing
FieldPulse does not sell users' SMS content or operational records. Third-party services may process information as necessary to provide services integrated into the app, including advertising services.

## User control
Users control what device codes, agent records, messages and location information they enter into the application. Android permission prompts allow users to control access to protected device features.

## Data retention and deletion
Local FieldPulse records remain on the device until the user removes them or uninstalls the application, subject to Android/device behavior and backups.

## Contact
Developer/support email: [REPLACE WITH YOUR SUPPORT EMAIL]

## Important
Replace the contact email and publish this policy at a stable HTTPS URL before submitting FieldPulse to Samsung Galaxy Store.
