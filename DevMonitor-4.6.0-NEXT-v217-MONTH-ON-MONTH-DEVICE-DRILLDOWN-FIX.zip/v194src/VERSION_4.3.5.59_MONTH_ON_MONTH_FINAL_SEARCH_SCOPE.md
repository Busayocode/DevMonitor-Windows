# DevMonitor 4.3.5.59 — Final Month-to-Month Search Scope & Staff Classification

## Final behavior

### Search scope
The Month-to-Month search is available only to installations classified as STAFF by the one-time first-run phone check. The search reads only these four dedicated databases:

1. Previous Month
2. Previous Month My Devices
3. This Month
4. This Month My Devices

It supports the established search protocol for:
- Device ID (canonical/raw, case-insensitive contains)
- Partner name or trade code
- Staff name

The full company database is **not** a search source for Month-to-Month.

### Device Monitor peek
Device Monitor remains a permitted fifth **read-only peek**, not a Month-to-Month search database. When a search result already exists in one or more of the four Month-to-Month databases, Device Monitor may be checked to enrich that result with its latest matching observation and Active value, including whether that observation is newer than the current loaded-report snapshot. Device Monitor cannot create a search result by itself.

### One-time staff classification
On the first Month-to-Month run after installation, the raw saved profile phone is checked exactly as stored:
- exactly 11 characters;
- every character is a digit;
- starts with `0805557`;
- the final four digits may be any digits.

No formatting normalization, stripping, or conversion is performed.

The result is persisted as `STAFF` or `NON_STAFF` and is not re-evaluated until a fresh install/app-data reset. A failing check is silent: no alert and no search field.

### Month-to-Month freshness
If a Device Monitor observation is genuinely newer than the current loaded-report snapshot, Month-to-Month uses the observation's **Active** value. The Device Monitor `mtd` field is not used for this comparison.

## Protected areas
- Payment calculation
- Payment resolver/pathway
- Payment progression logic
- Payment-cycle logic

No payment code was changed by 4.3.5.59.

## Verification
The source ZIP was checked for archive integrity after packaging. A local Gradle build was attempted, but this environment could not download Gradle 8.7 because network/DNS access to `services.gradle.org` was unavailable. Therefore the ZIP is source-verified and packaged, but a successful local Gradle compile is not claimed.
