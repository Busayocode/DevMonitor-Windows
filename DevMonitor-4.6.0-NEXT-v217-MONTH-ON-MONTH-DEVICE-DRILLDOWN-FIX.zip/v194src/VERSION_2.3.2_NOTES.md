# FieldPulse 2.3.2 — Daily Recheck and Device Identity Fix

- A device can now be monitored repeatedly during the same calendar day. A later successful SMS response refreshes the same daily observation instead of being skipped because an earlier check already succeeded.
- GLO device codes now have a stable canonical identity for monitoring/reporting. Long forms such as `GLO-GD-OGN-da3-3GOGN047-666D` normalize to `GLO-GD-666D`.
- Adding a long GLO device code that corresponds to an existing short code no longer creates a second device entry.
- Daily observations use the canonical device code, so morning and evening checks update the same `device + date` record.
- Existing databases are migrated to merge long/short GLO observations by device/date, retaining the latest received observation.
- Excel exports normalize GLO device codes and collapse legacy long/short duplicates, using the latest completed result.
- Agent/device links also use the canonical device identity.
- Non-GLO partner codes are intentionally unchanged.
- Existing SMS transmission behavior is preserved: 3030 receives the short device form, while other destinations receive the entered code.

## Intended daily workflow

Example:

5:00 AM — `GLO-GD-666D` returns Today=4.

5:00 PM — the same device is checked again, using a long form such as `GLO-GD-12-4-3GO3-666D`.

FieldPulse recognizes one device, stores one observation for that calendar date, and replaces the earlier snapshot with the later/cumulative response. The export contains one row: `GLO-GD-666D`.

## Build environment

- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Kotlin 2.0.21
- JDK 17
- compileSdk 36 / targetSdk 36
- Native Android + Kotlin + Jetpack Compose
- SQLite local database
- Gradle workers limited to 1
- Parallel execution disabled

Final Gradle build verification must be performed in the user's Android Code Studio environment because the present packaging environment cannot download the Gradle 8.7 distribution.


## 2.3.2 follow-up input rule — SMS normalization and open partner codes

- Device and partner code input is case-insensitive for the user. Before any SMS query is transmitted, the complete SMS code is converted to uppercase.
- This applies to both the normal SMS send path and the delivery-monitored SMS send path.
- The existing short-form conversion for destination 3030 remains in place, and the final transmitted value is uppercase.
- Partner codes are no longer constrained by a hard-coded length or character-pattern validation. Any non-blank partner code is accepted as entered, trimmed and uppercased; the remote company service determines whether the code is valid.
- Excel import follows the same open partner-code rule, while ignoring only common header labels.
