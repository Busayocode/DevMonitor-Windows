# FieldPulse 2.3.9 — Guided Tour Fixes

## Guided Tour target behavior
- The active input/control remains visible in the foreground while the user types.
- The next actionable control is visually emphasized with a gentle pulse during the guided tour.

## Guided Tour skip persistence
- Selecting **Skip** immediately ends the current tour and persists `guided_tour_dismissed=true`.
- Automatic Device Monitor tour prompts now require BOTH:
  - no completed tour timestamp, and
  - no guided-tour dismissal flag.
- This prevents a skipped tour from returning after closing/restarting the app.
- The user can deliberately restart it from Settings → **Take the Guided Tour Again**, which clears the dismissal flag.
