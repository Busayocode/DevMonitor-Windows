package com.aziitech.simregmonitor

import android.content.Context
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/**
 * Month-on-Month calculation/search layer.
 *
 * It intentionally owns no activation database. The only physical HQ data stores are
 * the current and previous monthly CompanyActivationStore databases. Refreshing
 * Month-on-Month reads those stores; importing a report does not duplicate data here.
 */
class MonthOnMonthStore(private val context: Context) {
    private var deviceMonitorStore: DatabaseStore? = null

    fun setDeviceMonitorStore(store: DatabaseStore) { deviceMonitorStore = store }

    data class Comparison(
        val asOf: LocalDate,
        val currentTotal: Int,
        val previousTotal: Int,
        val delta: Int,
        val percentChange: Double?
    )

    data class SearchHit(
        val type: String,
        val label: String,
        val detail: String,
        val deviceIds: List<String> = emptyList(),
        val sources: List<String> = emptyList(),
        val monitorLatestDate: LocalDate? = null,
        val monitorActive: Int? = null,
        val monitorIsNewer: Boolean = false
    )

    fun compare(company: CompanyActivationStore, codes: List<String>, asOf: LocalDate = LocalDate.now()): Comparison? {
        val myCodes = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        if (myCodes.isEmpty()) return null

        val live = PaymentRules.currentAwareDate(asOf)
        val currentMonth = YearMonth.from(live)
        val previousMonth = currentMonth.minusMonths(1)
        val currentStart = currentMonth.atDay(1)
        val currentRows = myCodes.associateWith { code -> company.dailyCoverageForDevice(code,currentStart,live) }
        val previousStart = previousMonth.atDay(1)
        val previousRows = myCodes.associateWith { code -> company.dailyCoverageForDevice(code,previousStart,previousMonth.atEndOfMonth()) }

        val currentReportEnd = company.latestReportForMonth(currentMonth.year,currentMonth.monthValue)?.coverageEnd
            ?.coerceAtMost(live)
        val previousReport = company.latestReportForMonth(previousMonth.year,previousMonth.monthValue)
        val previousReportEnd = previousReport?.coverageEnd ?: previousMonth.atEndOfMonth()

        val monitor = deviceMonitorStore ?: DatabaseStore(context)
        val ownedMonitor = deviceMonitorStore == null
        try {
            val importedAt = company.latestReportImportedAtCovering(live)
            val monitorRows = mutableMapOf<String,Pair<LocalDate,Int>>()
            for (code in myCodes) {
                val newest = monitor.observationsForCode(code,90).mapNotNull { obs ->
                    val date=runCatching{LocalDate.parse(obs.date)}.getOrNull() ?: return@mapNotNull null
                    if(YearMonth.from(date)!=currentMonth || date.isAfter(live)) return@mapNotNull null
                    val active=obs.active ?: return@mapNotNull null
                    val received=parseReceivedAt(obs.receivedAt) ?: return@mapNotNull null
                    if(importedAt!=null && received<=importedAt)return@mapNotNull null
                    Triple(date,active,received)
                }.maxByOrNull{it.third}
                if(newest!=null)monitorRows[code]=newest.first to newest.second
            }

            val effectiveAsOf = listOfNotNull(currentReportEnd,monitorRows.values.maxOfOrNull{it.first}).maxOrNull()?.coerceAtMost(live)
                ?: return null
            val previousCutoff = previousMonth.atDay(minOf(effectiveAsOf.dayOfMonth,previousMonth.lengthOfMonth()))

            val currentTotal = myCodes.sumOf { code ->
                val reportValues=currentRows[code].orEmpty().filterKeys{!it.isBefore(currentStart)&&!it.isAfter(effectiveAsOf)}
                val reportTotal=reportValues.values.sumOf{it.coerceAtLeast(0)}
                val reportLatest=reportValues.keys.maxOrNull()
                val monitorValue=monitorRows[code]
                when { monitorValue!=null && (reportLatest==null || !monitorValue.first.isBefore(reportLatest)) -> monitorValue.second.coerceAtLeast(0); else -> reportTotal }
            }
            val previousTotal=myCodes.sumOf{code->previousRows[code].orEmpty().filterKeys{!it.isAfter(previousCutoff)&&!it.isAfter(previousReportEnd)}.values.sumOf{it.coerceAtLeast(0)}}
            val delta=currentTotal-previousTotal
            val percent=if(previousTotal==0) null else delta.toDouble()*100.0/previousTotal.toDouble()
            DevMonitorLogger.db("Month-on-Month refresh currentMonth=$currentMonth previousMonth=$previousMonth asOf=$effectiveAsOf current=$currentTotal previous=$previousTotal monitorFresh=${monitorRows.size}")
            return Comparison(effectiveAsOf,currentTotal,previousTotal,delta,percent)
        } finally { if(ownedMonitor)monitor.close() }
    }

    /** Bulk device comparison used by the MOM device-card view. It preserves the same
     * comparison rules as compare(), but loads the two monthly HQ snapshots once rather
     * than repeating the database work for every device card. */
    fun compareMany(company: CompanyActivationStore, codes: List<String>, asOf: LocalDate = LocalDate.now()): Map<String, Comparison> {
        val myCodes = codes.map(::canonicalDeviceCode).filter { it.isNotBlank() }.distinct()
        if (myCodes.isEmpty()) return emptyMap()

        val live = PaymentRules.currentAwareDate(asOf)
        val currentMonth = YearMonth.from(live)
        val previousMonth = currentMonth.minusMonths(1)
        val currentStart = currentMonth.atDay(1)
        val previousStart = previousMonth.atDay(1)
        val currentRows = company.dailyCoverageForDevices(myCodes, currentStart, live)
        val previousRows = company.dailyCoverageForDevices(myCodes, previousStart, previousMonth.atEndOfMonth())
        val currentReportEnd = company.latestReportCoverageEndForMonth(currentMonth.year, currentMonth.monthValue)?.coerceAtMost(live)
        val previousReportEnd = company.latestReportCoverageEndForMonth(previousMonth.year, previousMonth.monthValue) ?: previousMonth.atEndOfMonth()

        val monitor = deviceMonitorStore ?: DatabaseStore(context)
        val ownedMonitor = deviceMonitorStore == null
        try {
            val importedAt = company.latestReportImportedAtCovering(live)
            val monitorRows = mutableMapOf<String, Pair<LocalDate, Int>>()
            for (code in myCodes) {
                val newest = monitor.observationsForCode(code, 90).mapNotNull { obs ->
                    val date = runCatching { LocalDate.parse(obs.date) }.getOrNull() ?: return@mapNotNull null
                    if (YearMonth.from(date) != currentMonth || date.isAfter(live)) return@mapNotNull null
                    val active = obs.active ?: return@mapNotNull null
                    val received = parseReceivedAt(obs.receivedAt) ?: return@mapNotNull null
                    if (importedAt != null && received <= importedAt) return@mapNotNull null
                    Triple(date, active, received)
                }.maxByOrNull { it.third }
                if (newest != null) monitorRows[code] = newest.first to newest.second
            }

            val effectiveAsOf = listOfNotNull(currentReportEnd, monitorRows.values.maxOfOrNull { it.first })
                .maxOrNull()?.coerceAtMost(live) ?: return emptyMap()
            val previousCutoff = previousMonth.atDay(minOf(effectiveAsOf.dayOfMonth, previousMonth.lengthOfMonth()))

            return myCodes.mapNotNull { code ->
                val currentValues = currentRows[code].orEmpty().filterKeys { !it.isBefore(currentStart) && !it.isAfter(effectiveAsOf) }
                val reportTotal = currentValues.values.sumOf { it.coerceAtLeast(0) }
                val reportLatest = currentValues.keys.maxOrNull()
                val monitorValue = monitorRows[code]
                val currentTotal = when {
                    monitorValue != null && (reportLatest == null || !monitorValue.first.isBefore(reportLatest)) -> monitorValue.second.coerceAtLeast(0)
                    else -> reportTotal
                }
                val previousTotal = previousRows[code].orEmpty()
                    .filterKeys { !it.isAfter(previousCutoff) && !it.isAfter(previousReportEnd) }
                    .values.sumOf { it.coerceAtLeast(0) }
                val delta = currentTotal - previousTotal
                val percent = if (previousTotal == 0) null else delta.toDouble() * 100.0 / previousTotal.toDouble()
                code to Comparison(effectiveAsOf, currentTotal, previousTotal, delta, percent)
            }.toMap()
        } finally {
            if (ownedMonitor) monitor.close()
        }
    }

    fun search(company: CompanyActivationStore, query: String, asOf: LocalDate = LocalDate.now(), limit: Int = 100): List<SearchHit> {
        val normalized=query.trim(); if(normalized.length<2)return emptyList(); val upper=normalized.uppercase(Locale.US)
        data class Raw(val type:String,val label:String,val detail:String,val code:String)
        val raw=mutableListOf<Raw>()
        company.latestDeviceScopeRows().forEach { row ->
            val device=canonicalDeviceCode(row.deviceId);val trade=row.tradeCode;val partner=row.partnerName;val cluster=row.cluster;val region=row.region;val territory=row.territory;val staff=row.staffName
            if(device.uppercase(Locale.US).contains(upper))raw+=Raw("DEVICE",device,listOf(partner,staff).filter{it.isNotBlank()}.joinToString(" • "),device)
            if(partner.contains(normalized,true)||trade.contains(normalized,true)){val label=partner.ifBlank{trade}.trim();if(label.isNotBlank())raw+=Raw("PARTNER",label,listOf(trade,region,territory).filter{it.isNotBlank()}.joinToString(" • "),device)}
            if(staff.contains(normalized,true)){val label=staff.trim();if(label.isNotBlank())raw+=Raw("STAFF",label,listOf(region,territory).filter{it.isNotBlank()}.joinToString(" • "),device)}
            if(cluster.contains(normalized,true)){val label=cluster.trim();if(label.isNotBlank())raw+=Raw("CLUSTER",label,region,device)}
            if(region.contains(normalized,true)){val label=region.trim();if(label.isNotBlank())raw+=Raw("REGION",label,territory,device)}
        }
        val grouped=raw.groupBy{"${it.type}|${it.label.uppercase(Locale.US)}"}
        val monitor=deviceMonitorStore?:DatabaseStore(context);val owned=deviceMonitorStore==null
        return try {
            grouped.values.map{group->
                val first=group.first();val ids=group.map{it.code}.filter{it.isNotBlank()}.distinct().take(50);val sources=listOf("Current Month","Previous Month")
                val candidate=ids.flatMap{code->monitor.observationsForCode(code,90).mapNotNull{obs->val d=runCatching{LocalDate.parse(obs.date)}.getOrNull()?:return@mapNotNull null;if(d.isAfter(asOf)||YearMonth.from(d)!=YearMonth.from(asOf))return@mapNotNull null;val active=obs.active?:return@mapNotNull null;val received=parseReceivedAt(obs.receivedAt)?:return@mapNotNull null;Triple(d,active,received)}}.maxByOrNull{it.third}
                val imported=company.latestReportImportedAtCovering(PaymentRules.currentAwareDate(asOf));val newer=candidate!=null&&(imported==null||candidate.third>imported)
                val detail=buildString{if(first.detail.isNotBlank())append(first.detail);if(isNotEmpty())append(" • ");append("Month-to-Month: ").append(sources.joinToString(", "));if(candidate!=null){append(" • Device Monitor: ${candidate.first} Active ${candidate.second}");if(newer)append(" (newer)")}}
                SearchHit(first.type,first.label,detail,ids,sources,candidate?.first,candidate?.second,newer)
            }.sortedWith(compareBy<SearchHit>{it.type}.thenBy{it.label.uppercase(Locale.US)}).take(limit)
        } finally { if(owned)monitor.close() }
    }

    fun close() { deviceMonitorStore=null }

    private fun parseReceivedAt(value:String):Long?=runCatching{java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).parse(value)?.time}.getOrNull()
}
