package com.aziitech.simregmonitor

import java.text.DateFormatSymbols
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale
import java.util.regex.Pattern

/**
 * One global, deliberately liberal date parser for human-entered/report text.
 *
 * External text may use numeric, alphabetic, alphanumeric, ordinal, ISO, Roman-
 * numeral-month, abbreviated/full month names, different separators, or mixed
 * forms on the two sides of a range. Internal app storage remains ISO-8601
 * yyyy-MM-dd so database comparisons never depend on presentation format.
 */
object HumanDateParser {
    data class DateRange(val start: LocalDate?, val end: LocalDate?)

    private val monthNumbers = linkedMapOf<String, Int>().apply {
        val english = arrayOf(
            "january" to 1, "jan" to 1,
            "february" to 2, "feb" to 2,
            "march" to 3, "mar" to 3,
            "april" to 4, "apr" to 4,
            "may" to 5,
            "june" to 6, "jun" to 6,
            "july" to 7, "jul" to 7,
            "august" to 8, "aug" to 8,
            "september" to 9, "sep" to 9, "sept" to 9,
            "october" to 10, "oct" to 10,
            "november" to 11, "nov" to 11,
            "december" to 12, "dec" to 12
        )
        english.forEach { (name, month) -> put(name, month) }
        // Roman-numeral month notation, e.g. 25.III.2026.
        arrayOf("i" to 1, "ii" to 2, "iii" to 3, "iv" to 4, "v" to 5,
            "vi" to 6, "vii" to 7, "viii" to 8, "ix" to 9, "x" to 10,
            "xi" to 11, "xii" to 12).forEach { (name, month) -> put(name, month) }
    }

    private val monthPattern: String by lazy {
        val localeMonths = linkedMapOf<String, Int>()
        // Prefer the device/default locale and English when an alias is unique.
        val preferred = listOf(Locale.getDefault(), Locale.US, Locale.UK)
        preferred.forEach { addLocaleMonths(localeMonths, it) }
        // Also harvest installed CLDR locale names. Ambiguous aliases are kept
        // out rather than silently mapping one language's month to another month.
        Locale.getAvailableLocales().forEach { addLocaleMonths(localeMonths, it) }
        monthNumbers.forEach { (k, v) -> localeMonths.putIfAbsent(k, v) }
        localeMonths.keys.sortedByDescending { it.length }
            .joinToString("|") { Pattern.quote(it) }
    }

    private val weekdayPattern: String by lazy {
        val names = linkedSetOf<String>()
        Locale.getAvailableLocales().forEach { locale ->
            val dfs = runCatching { DateFormatSymbols.getInstance(locale) }.getOrNull() ?: return@forEach
            dfs.weekdays.forEach { if (it.isNotBlank()) names.add(it.trim()) }
            dfs.shortWeekdays.forEach { if (it.isNotBlank()) names.add(it.trim()) }
        }
        listOf("Sunday", "Sun", "Monday", "Mon", "Tuesday", "Tue", "Wednesday", "Wed", "Thursday", "Thu", "Friday", "Fri", "Saturday", "Sat").forEach(names::add)
        names.sortedByDescending { it.length }.joinToString("|") { Pattern.quote(it) }
    }

    private val monthAliases: Map<String, Int> by lazy {
        val out = linkedMapOf<String, Int>()
        fun add(name: String, month: Int) {
            val key = normalizeWord(name)
            if (key.isBlank()) return
            val existing = out[key]
            if (existing == null || existing == month) out[key] = month
            else out.remove(key) // ambiguous across locales: do not guess
        }
        monthNumbers.forEach { (name, month) -> add(name, month) }
        Locale.getAvailableLocales().forEach { locale ->
            val dfs = runCatching { DateFormatSymbols.getInstance(locale) }.getOrNull() ?: return@forEach
            dfs.months.forEachIndexed { i, name -> if (i < 12) add(name, i + 1) }
            dfs.shortMonths.forEachIndexed { i, name -> if (i < 12) add(name, i + 1) }
        }
        // Reassert the English aliases because they are the dominant report language.
        monthNumbers.forEach { (name, month) -> out[name] = month }
        out
    }

    private fun addLocaleMonths(target: MutableMap<String, Int>, locale: Locale) {
        val dfs = runCatching { DateFormatSymbols.getInstance(locale) }.getOrNull() ?: return
        dfs.months.forEachIndexed { i, name -> if (i < 12 && name.isNotBlank()) target.putIfAbsent(normalizeWord(name), i + 1) }
        dfs.shortMonths.forEachIndexed { i, name -> if (i < 12 && name.isNotBlank()) target.putIfAbsent(normalizeWord(name), i + 1) }
    }

    private fun normalizeWord(value: String): String = value.trim()
        .lowercase(Locale.ROOT)
        .replace("’", "'")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun clean(value: String): String = value
        .replace('–', '-')
        .replace('—', '-')
        .replace('‑', '-')
        .replace('−', '-')
        .replace('’', '\'')
        .replace(Regex("(?i)(?<=\\d)(st|nd|rd|th|er|re|e|ème|º|°)(?=\\b)"), "")
        .replace(Regex("(?<=\\p{L})\\.(?=\\s|,|-|$)"), "")
        .replace(Regex("[_,]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .replace(Regex("^($weekdayPattern)\\s*,?\\s+", RegexOption.IGNORE_CASE), "")

    private fun year(value: String?): Int? {
        if (value.isNullOrBlank()) return null
        val n = value.toIntOrNull() ?: return null
        return when {
            n in 0..68 -> 2000 + n
            n in 69..99 -> 1900 + n
            n in 1900..2200 -> n
            else -> null
        }
    }

    private fun valid(year: Int?, month: Int?, day: Int?): LocalDate? {
        if (year == null || month == null || day == null) return null
        return runCatching { LocalDate.of(year, month, day) }.getOrNull()
    }

    private fun month(token: String): Int? = monthAliases[normalizeWord(token)]

    /** Parse one complete date, or a day/month date when defaultYear is supplied. */
    fun parseDate(text: String, defaultYear: Int? = null, defaultMonth: Int? = null): LocalDate? {
        val s = clean(text)
        if (s.isBlank()) return null

        // ISO and compact ISO: 2026-09-25, 2026/09/25, 20260925.
        Regex("^\\s*(\\d{4})\\s*[-/.]\\s*(\\d{1,2})\\s*[-/.]\\s*(\\d{1,2})\\s*$").matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[1]), m.groupValues[2].toIntOrNull(), m.groupValues[3].toIntOrNull())
        }
        Regex("^\\s*(\\d{4})(\\d{2})(\\d{2})\\s*$").matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[1]), m.groupValues[2].toIntOrNull(), m.groupValues[3].toIntOrNull())
        }
        // Day-of-year ISO form, e.g. 2026-268 or 2026268.
        Regex("^\\s*(\\d{4})[-/.]?(\\d{3})\\s*$").matchEntire(s)?.let { m ->
            val y = year(m.groupValues[1]) ?: return null
            return runCatching { LocalDate.ofYearDay(y, m.groupValues[2].toInt()) }.getOrNull()
        }

        // Full textual dates: month day year, day month year, year month day.
        Regex("^\\s*($monthPattern)\\s+(\\d{1,2})\\s*,?\\s*(\\d{2,4})\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[3]), month(m.groupValues[1]), m.groupValues[2].toIntOrNull())
        }
        Regex("^\\s*(\\d{1,2})\\s+($monthPattern)\\s*,?\\s*(\\d{2,4})\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[3]), month(m.groupValues[2]), m.groupValues[1].toIntOrNull())
        }
        Regex("^\\s*(\\d{2,4})\\s+($monthPattern)\\s+(\\d{1,2})\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[1]), month(m.groupValues[2]), m.groupValues[3].toIntOrNull())
        }

        // Roman numeral month dates.
        Regex("^\\s*(\\d{1,2})[. /-]+(i{1,3}|iv|v|vi{0,2}|ix|x|xi|xii)[. /-]+(\\d{2,4})\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[3]), month(m.groupValues[2]), m.groupValues[1].toIntOrNull())
        }

        // Numeric dates. Ambiguous numeric dates deliberately use DMY, the app's
        // established report convention; impossible cases are resolved by the values.
        Regex("^\\s*(\\d{1,2})\\s*[-/.]\\s*(\\d{1,2})\\s*[-/.]\\s*(\\d{2,4})\\s*$").matchEntire(s)?.let { m ->
            val a = m.groupValues[1].toInt(); val b = m.groupValues[2].toInt(); val y = year(m.groupValues[3])
            val monthFirst = when {
                a > 12 && b in 1..12 -> false
                b > 12 && a in 1..12 -> true
                else -> false
            }
            return if (monthFirst) valid(y, a, b) else valid(y, b, a)
        }
        // YMD with spaces or other nonstandard separators.
        Regex("^\\s*(\\d{4})\\s*[-/. ]\\s*(\\d{1,2})\\s*[-/. ]\\s*(\\d{1,2})\\s*$").matchEntire(s)?.let { m ->
            return valid(year(m.groupValues[1]), m.groupValues[2].toIntOrNull(), m.groupValues[3].toIntOrNull())
        }

        // Month/day or day/month without a year, using the supplied report year.
        Regex("^\\s*($monthPattern)\\s+(\\d{1,2})\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            return valid(year(defaultYear?.toString()), month(m.groupValues[1]), m.groupValues[2].toIntOrNull())
        }
        Regex("^\\s*(\\d{1,2})\\s+($monthPattern)\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            return valid(year(defaultYear?.toString()), month(m.groupValues[2]), m.groupValues[1].toIntOrNull())
        }
        // A bare day is only meaningful when both month and year are supplied by context.
        if (defaultMonth != null && defaultYear != null) {
            Regex("^\\s*(\\d{1,2})\\s*$").matchEntire(s)?.let { m ->
                return valid(defaultYear, defaultMonth, m.groupValues[1].toIntOrNull())
            }
        }
        return null
    }

    /** Parse a month/year period such as "September 2026", "09/2026", or "2026-09". */
    fun parseMonthYear(text: String, defaultYear: Int? = null): YearMonth? {
        val s = clean(text)
        Regex("^\\s*($monthPattern)\\s*,?\\s*(\\d{2,4})\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            val y = year(m.groupValues[2]); val mo = month(m.groupValues[1]);
            if (y != null && mo != null) return runCatching { YearMonth.of(y, mo) }.getOrNull()
        }
        Regex("^\\s*(\\d{2,4})\\s+($monthPattern)\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            val y = year(m.groupValues[1]); val mo = month(m.groupValues[2]);
            if (y != null && mo != null) return runCatching { YearMonth.of(y, mo) }.getOrNull()
        }
        Regex("^\\s*(\\d{4})[-/.](\\d{1,2})\\s*$").matchEntire(s)?.let { m ->
            return runCatching { YearMonth.of(m.groupValues[1].toInt(), m.groupValues[2].toInt()) }.getOrNull()
        }
        Regex("^\\s*(\\d{1,2})[-/.](\\d{4})\\s*$").matchEntire(s)?.let { m ->
            return runCatching { YearMonth.of(m.groupValues[2].toInt(), m.groupValues[1].toInt()) }.getOrNull()
        }
        Regex("^\\s*($monthPattern)\\s*$", RegexOption.IGNORE_CASE).matchEntire(s)?.let { m ->
            val y = defaultYear ?: return null
            return runCatching { YearMonth.of(y, month(m.groupValues[1]) ?: return null) }.getOrNull()
        }
        return null
    }

    /**
     * Parse a human date range. Each side is parsed independently, so the two
     * sides may use different formats, e.g. "Sep 1st - 23rd September 2026".
     */
    fun parseRange(text: String, defaultYear: Int? = null): DateRange {
        val s = clean(text)

        // Explicit mixed-format month endpoints, including cross-month ranges.
        Regex("($monthPattern)\\s+(\\d{1,2})\\s*-\\s*($monthPattern)\\s+(\\d{1,2})(?:\\s*,?\\s*(\\d{2,4}))?", RegexOption.IGNORE_CASE).find(s)?.let { m ->
            val y = year(m.groupValues[5]).takeIf { m.groupValues[5].isNotBlank() } ?: defaultYear
            val a = valid(y, month(m.groupValues[1]), m.groupValues[2].toIntOrNull())
            val b = valid(y, month(m.groupValues[3]), m.groupValues[4].toIntOrNull())
            if (a != null && b != null) return DateRange(a, b)
        }
        Regex("(\\d{1,2})\\s+($monthPattern)\\s*-\\s*(\\d{1,2})\\s+($monthPattern)(?:\\s*,?\\s*(\\d{2,4}))?", RegexOption.IGNORE_CASE).find(s)?.let { m ->
            val y = year(m.groupValues[5]).takeIf { m.groupValues[5].isNotBlank() } ?: defaultYear
            val a = valid(y, month(m.groupValues[2]), m.groupValues[1].toIntOrNull())
            val b = valid(y, month(m.groupValues[4]), m.groupValues[3].toIntOrNull())
            if (a != null && b != null) return DateRange(a, b)
        }

        // Compact same-month ranges, including ordinal days.
        Regex("($monthPattern)\\s+(\\d{1,2})\\s*-\\s*(\\d{1,2})(?:\\s*,?\\s*(\\d{2,4}))?", RegexOption.IGNORE_CASE).find(s)?.let { m ->
            val y = year(m.groupValues[4]).takeIf { m.groupValues[4].isNotBlank() } ?: defaultYear
            val mo = month(m.groupValues[1])
            val a = valid(y, mo, m.groupValues[2].toIntOrNull())
            val b = valid(y, mo, m.groupValues[3].toIntOrNull())
            if (a != null && b != null) return DateRange(a, b)
        }
        Regex("(\\d{1,2})\\s*-\\s*(\\d{1,2})\\s+($monthPattern)(?:\\s*,?\\s*(\\d{2,4}))?", RegexOption.IGNORE_CASE).find(s)?.let { m ->
            val y = year(m.groupValues[4]).takeIf { m.groupValues[4].isNotBlank() } ?: defaultYear
            val mo = month(m.groupValues[3])
            val a = valid(y, mo, m.groupValues[1].toIntOrNull())
            val b = valid(y, mo, m.groupValues[2].toIntOrNull())
            if (a != null && b != null) return DateRange(a, b)
        }
        Regex("($monthPattern)\\s+(\\d{2,4})\\s+(\\d{1,2})\\s*-\\s*(\\d{1,2})", RegexOption.IGNORE_CASE).find(s)?.let { m ->
            val y = year(m.groupValues[2]); val mo = month(m.groupValues[1])
            val a = valid(y, mo, m.groupValues[3].toIntOrNull())
            val b = valid(y, mo, m.groupValues[4].toIntOrNull())
            if (a != null && b != null) return DateRange(a, b)
        }

        // Two complete dates separated by a range dash, including ISO forms.
        Regex("^\\s*(\\d{4}\\s*[-/.]\\s*\\d{1,2}\\s*[-/.]\\s*\\d{1,2})\\s*-\\s*(\\d{4}\\s*[-/.]\\s*\\d{1,2}\\s*[-/.]\\s*\\d{1,2})\\s*$").matchEntire(s)?.let { m ->
            val a = parseDate(m.groupValues[1], defaultYear)
            val b = parseDate(m.groupValues[2], defaultYear)
            if (a != null && b != null) return DateRange(a, b)
        }

        // First try explicit textual/numeric connectors. The two sides are parsed
        // independently, so mixed forms are legal: "Sep 1st to 23 September 2026".
        Regex("(?i)(.+?)\\s+(?:to|through|thru|until|till|upto|up to)\\s+(.+)").find(s)?.let { range ->
            val left = range.groupValues[1].trim()
            val right = range.groupValues[2].trim()
            val rightFull = parseDate(right, defaultYear)
            val leftFull = parseDate(left, rightFull?.year ?: defaultYear)
            if (leftFull != null && rightFull != null) return DateRange(leftFull, rightFull)
        }

        // Month/year alone is a calendar period, not a single day.
        parseMonthYear(s, defaultYear)?.let { ym -> return DateRange(ym.atDay(1), ym.atEndOfMonth()) }

        // Hyphenated ranges are attempted only after complete-date parsing. This
        // avoids treating ISO 2026-09-25 as a range separator.
        parseDate(s, defaultYear)?.let { return DateRange(it, it) }
        val hyphen = Regex("^(.+?)\\s+-\\s+(.+)$").find(s)
        if (hyphen != null) {
            val left = hyphen.groupValues[1].trim()
            val right = hyphen.groupValues[2].trim()
            val rightFull = parseDate(right, defaultYear)
            val leftFull = parseDate(left, rightFull?.year ?: defaultYear)
            if (leftFull != null && rightFull != null) return DateRange(leftFull, rightFull)

            // "September 1 - 23rd 2026" / "1st September - 23 September 2026".
            val monthDay = Regex("^($monthPattern)\\s+(\\d{1,2})$", RegexOption.IGNORE_CASE).find(left)
            val dayMonth = Regex("^(\\d{1,2})\\s+($monthPattern)$", RegexOption.IGNORE_CASE).find(left)
            val rightDay = Regex("^(?:the\\s+)?(\\d{1,2})$", RegexOption.IGNORE_CASE).find(right)
            if (rightDay != null) {
                val inferred = when {
                    monthDay != null -> parseDate("${monthDay.groupValues[1]} ${monthDay.groupValues[2]}", defaultYear)
                    dayMonth != null -> parseDate("${dayMonth.groupValues[1]} ${dayMonth.groupValues[2]}", defaultYear)
                    else -> null
                }
                if (inferred != null) {
                    val end = valid(rightFull?.year ?: defaultYear ?: inferred.year, inferred.monthValue, rightDay.groupValues[1].toIntOrNull())
                    if (end != null) return DateRange(inferred, end)
                }
            }
        }
        return DateRange(null, null)
    }

    /** Extract all recognizable full dates from free-form workbook text. */
    fun extractDates(text: String, defaultYear: Int? = null): List<LocalDate> {
        val out = linkedSetOf<LocalDate>()
        val cleaned = clean(text)
        val inferredYear = defaultYear ?: Regex("\\b(19\\d{2}|20\\d{2}|21\\d{2})\\b")
            .find(cleaned)?.groupValues?.get(1)?.toIntOrNull()
        val patterns = listOf(
            Regex("\\b\\d{4}[-/.]\\d{1,2}[-/.]\\d{1,2}\\b"),
            Regex("\\b\\d{1,2}[-/.]\\d{1,2}[-/.]\\d{2,4}\\b"),
            Regex("\\b(?:\\d{1,2}\\s+)?(?:$monthPattern)(?:\\s+\\d{1,2}(?:st|nd|rd|th|er|re)?)?(?:\\s*,?\\s*\\d{2,4})?\\b", RegexOption.IGNORE_CASE),
            Regex("\\b\\d{1,2}(?:st|nd|rd|th|er|re)?\\s+(?:$monthPattern)(?:\\s*,?\\s*\\d{2,4})?\\b", RegexOption.IGNORE_CASE)
        )
        patterns.forEach { p ->
            p.findAll(cleaned).forEach { match -> parseDate(match.value, inferredYear)?.let(out::add) }
        }
        return out.sorted()
    }

    fun toIso(date: LocalDate): String = date.toString()
    fun toDisplay(date: LocalDate, locale: Locale = Locale.getDefault()): String =
        java.time.format.DateTimeFormatter.ofPattern("d MMMM yyyy", locale).format(date)
}
