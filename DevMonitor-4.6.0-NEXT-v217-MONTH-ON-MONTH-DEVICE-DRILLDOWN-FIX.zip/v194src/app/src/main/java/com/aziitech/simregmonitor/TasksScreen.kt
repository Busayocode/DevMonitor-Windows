package com.aziitech.simregmonitor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun TasksDialog(
    store: DatabaseStore,
    deviceCodes: List<String>,
    agents: List<Agent>,
    onDismiss: () -> Unit
) {
    var tasks by remember { mutableStateOf(store.operationalTasks()) }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<OperationalTask?>(null) }
    var showCompleted by remember { mutableStateOf(true) }

    fun refresh() { tasks = store.operationalTasks(showCompleted) }

    if (showEditor) {
        TaskEditorDialog(
            task = editing,
            deviceCodes = deviceCodes,
            agents = agents,
            onDismiss = { showEditor = false },
            onSave = { task -> store.saveOperationalTask(task); showEditor = false; refresh() }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tasks & Follow-ups") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${tasks.count { !it.completed }} open", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { showCompleted = !showCompleted; refresh() }) { Text(if (showCompleted) "Hide completed" else "Show completed") }
                }
                if (tasks.isEmpty()) {
                    Text("No follow-ups yet. Create a task and optionally link it to a device, partner or staff member.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(tasks, key = { it.id }) { task ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Text(task.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        AssistChip(onClick = { store.setOperationalTaskCompleted(task.id, !task.completed); refresh() }, label = { Text(if (task.completed) "Done" else "Open") })
                                    }
                                    if (task.details.isNotBlank()) Text(task.details)
                                    val link = if (task.linkType != null && task.linkValue != null) "${task.linkType!!.lowercase().replaceFirstChar { it.uppercase() }}: ${task.linkValue}" else "General follow-up"
                                    Text(link, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Text("${task.priority.lowercase().replaceFirstChar { it.uppercase() }}${task.dueDate?.let { " • Due $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
                                        Row {
                                            TextButton(onClick = { editing = task; showEditor = true }) { Text("Edit") }
                                            TextButton(onClick = { store.deleteOperationalTask(task.id); refresh() }) { Text("Delete") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { DevMonitorButton(onClick = { editing = null; showEditor = true }) { Text("Add task") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun TaskEditorDialog(
    task: OperationalTask?,
    deviceCodes: List<String>,
    agents: List<Agent>,
    onDismiss: () -> Unit,
    onSave: (OperationalTask) -> Unit
) {
    var title by remember(task) { mutableStateOf(task?.title ?: "") }
    var details by remember(task) { mutableStateOf(task?.details ?: "") }
    var dueDate by remember(task) { mutableStateOf(task?.dueDate ?: "") }
    var priority by remember(task) { mutableStateOf(task?.priority ?: "NORMAL") }
    var linkType by remember(task) { mutableStateOf(task?.linkType ?: "NONE") }
    var linkValue by remember(task) { mutableStateOf(task?.linkValue ?: "") }
    var priorityExpanded by remember { mutableStateOf(false) }
    var linkExpanded by remember { mutableStateOf(false) }
    var valueExpanded by remember { mutableStateOf(false) }
    val linkOptions = listOf("NONE", "DEVICE", "PARTNER", "STAFF")
    val values = when (linkType) {
        "DEVICE" -> deviceCodes.filter { it.startsWith("GLO-", true) }
        "PARTNER" -> deviceCodes.filter { !it.startsWith("GLO-", true) }
        "STAFF" -> agents.map { "${it.id}|${it.name}" }
        else -> emptyList()
    }
    val dueValid = dueDate.isBlank() || runCatching { LocalDate.parse(dueDate) }.isSuccess
    val canSave = title.isNotBlank() && dueValid && (linkType == "NONE" || linkValue.isNotBlank())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (task == null) "New follow-up" else "Edit follow-up") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Task") }, placeholder = { Text("e.g. Follow up on low sales") }, singleLine = true)
                OutlinedTextField(details, { details = it }, Modifier.fillMaxWidth(), label = { Text("Details") }, minLines = 2)
                OutlinedTextField(dueDate, { dueDate = it }, Modifier.fillMaxWidth(), label = { Text("Due date (YYYY-MM-DD)") }, placeholder = { Text("Optional") }, singleLine = true, isError = !dueValid)
                Box {
                    OutlinedButton(onClick = { priorityExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Priority: ${priority.lowercase().replaceFirstChar { it.uppercase() }}") }
                    DropdownMenu(priorityExpanded, { priorityExpanded = false }) { listOf("LOW","NORMAL","HIGH").forEach { p -> DropdownMenuItem(text = { Text(p.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { priority = p; priorityExpanded = false }) } }
                }
                Box {
                    OutlinedButton(onClick = { linkExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Link: ${linkType.lowercase().replaceFirstChar { it.uppercase() }}") }
                    DropdownMenu(linkExpanded, { linkExpanded = false }) { linkOptions.forEach { t -> DropdownMenuItem(text = { Text(t.lowercase().replaceFirstChar { it.uppercase() }) }, onClick = { linkType = t; linkValue = ""; linkExpanded = false }) } }
                }
                if (linkType != "NONE") {
                    Box {
                        OutlinedButton(onClick = { valueExpanded = true }, modifier = Modifier.fillMaxWidth(), enabled = values.isNotEmpty()) { Text(if (linkValue.isBlank()) "Choose ${linkType.lowercase()}" else linkValue.substringAfter('|')) }
                        DropdownMenu(valueExpanded, { valueExpanded = false }) { values.forEach { value -> DropdownMenuItem(text = { Text(value.substringAfter('|')) }, onClick = { linkValue = value.substringBefore('|').ifBlank { value }; valueExpanded = false }) } }
                    }
                }
            }
        },
        confirmButton = { DevMonitorButton(enabled = canSave, onClick = { onSave(OperationalTask(task?.id ?: 0L, title.trim(), details.trim(), dueDate.trim().ifBlank { null }, priority, linkType.takeUnless { it == "NONE" }, linkValue.substringBefore('|').ifBlank { null }, task?.completed ?: false, task?.createdAt ?: System.currentTimeMillis(), System.currentTimeMillis())) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
