package com.aziitech.simregmonitor

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

data class IncentiveEstimate(
    val activations: Int,
    val fixedReward: Int,
    val estimatedRechargeBonus: Int,
    val sundayActivations: Int,
    val sundayBonus: Int,
    val estimatedSubtotal: Int,
    val nextThreshold: Int?,
    val activationsToNext: Int,
    val nextReward: Int?
)

/**
 * Monitoring-only agent incentive rules captured from the current company flyer.
 * DevMonitor cannot verify FDS, app downloads, or recharge values above ₦200,
 * so only the minimum ₦200 recharge qualification is estimated.
 */
object PaymentRules {
    private val tiers = listOf(
        30 to 9_000,
        50 to 22_500,
        70 to 35_000,
        100 to 65_000,
        150 to 90_000,
        200 to 110_000,
        250 to 135_000,
        300 to 150_000
    )

    const val MIN_RECHARGE_NAIRA = 200
    const val FRC_INCENTIVE_PER_QUALIFYING_ACTIVATION = 250
    const val SUNDAY_EXTRA_PER_QUALIFYING_ACTIVATION = 200
    const val SUNDAY_MIN_ACTIVATIONS = 5
    const val DEFAULT_PARTNER_MIN_ACTIVATIONS = 500

    /**
     * Estimate monthly agent earnings from activation evidence.
     * Every activation is counted exactly once in the monthly activation total.
     * The minimum ₦200 recharge is assumed, yielding the ₦250 FRC incentive.
     */
    fun estimate(activations: Int, sundayActivations: Int = 0): IncentiveEstimate {
        val n = activations.coerceAtLeast(0)
        val sunday = sundayActivations.coerceAtLeast(0).coerceAtMost(n)
        val fixed = tiers.lastOrNull { n >= it.first }?.second ?: 0
        val next = tiers.firstOrNull { n < it.first }
        val recharge = n * FRC_INCENTIVE_PER_QUALIFYING_ACTIVATION
        val qualifyingSundayActivations = if (sunday >= SUNDAY_MIN_ACTIVATIONS) sunday else 0
        val sundayBonus = qualifyingSundayActivations * SUNDAY_EXTRA_PER_QUALIFYING_ACTIVATION
        return IncentiveEstimate(
            activations = n,
            fixedReward = fixed,
            estimatedRechargeBonus = recharge,
            sundayActivations = sunday,
            sundayBonus = sundayBonus,
            estimatedSubtotal = fixed + recharge + sundayBonus,
            nextThreshold = next?.first,
            activationsToNext = next?.first?.minus(n) ?: 0,
            nextReward = next?.second
        )
    }

    /**
     * Counts qualifying Sunday activations independently for each Sunday in the
     * report month. Sundays remain part of the normal monthly activation total.
     * A Sunday only earns its extra ₦200 per activation when that particular
     * Sunday has at least five qualifying activations.
     */
    fun qualifyingSundayActivations(
        daily: Map<Int, Int>,
        month: YearMonth,
        cutoffDay: Int
    ): Int {
        val endDay = cutoffDay.coerceIn(0, month.lengthOfMonth())
        if (endDay == 0) return 0
        var qualifying = 0
        for (day in 1..endDay) {
            if (LocalDate.of(month.year, month.monthValue, day).dayOfWeek == DayOfWeek.SUNDAY) {
                val count = (daily[day] ?: 0).coerceAtLeast(0)
                if (count >= SUNDAY_MIN_ACTIVATIONS) qualifying += count
            }
        }
        return qualifying
    }

    fun paymentCycleStartYearMonth(date: LocalDate): YearMonth =
        if (date.dayOfMonth >= 21) YearMonth.of(date.year, date.monthValue)
        else YearMonth.from(date).minusMonths(1)

    /** The live payment cycle is always bounded by the real current date.
     * Future-dated imported rows must never advance payment progression. */
    fun currentAwareDate(requested: LocalDate = LocalDate.now()): LocalDate =
        if (requested.isAfter(LocalDate.now())) LocalDate.now() else requested

    fun paymentCycleForDate(date: LocalDate = LocalDate.now()): Pair<LocalDate, LocalDate> {
        val asOf = currentAwareDate(date)
        return if (asOf.dayOfMonth >= 21) {
            asOf.withDayOfMonth(21) to asOf.plusMonths(1).withDayOfMonth(20)
        } else {
            asOf.minusMonths(1).withDayOfMonth(21) to asOf.withDayOfMonth(20)
        }
    }

    fun paymentCycleLabel(date: LocalDate = LocalDate.now()): String {
        val (start, end) = paymentCycleForDate(date)
        return "${start} → ${end}"
    }

    /**
     * Primary My Devices working window.
     *
     * Days 1–20: keep the active payment-cycle history from the previous
     * month's 21st through today, because that is still the live cycle.
     *
     * Day 21 onward: discard the previous month's 21st–month-end portion from
     * the working view and keep only the current month's 1st through today.
     * The authoritative company database retains the complete history.
     *
     * Examples:
     * 2026-09-20 => 2026-08-21..2026-09-20
     * 2026-09-21 => 2026-09-01..2026-09-21
     * 2026-10-05 => 2026-09-21..2026-10-05
     */
    fun myDevicesWorkingWindow(date: LocalDate = LocalDate.now()): Pair<LocalDate, LocalDate> {
        val asOf = currentAwareDate(date)
        return if (asOf.dayOfMonth >= 21) {
            asOf.withDayOfMonth(1) to asOf
        } else {
            asOf.minusMonths(1).withDayOfMonth(21) to asOf
        }
    }
}
