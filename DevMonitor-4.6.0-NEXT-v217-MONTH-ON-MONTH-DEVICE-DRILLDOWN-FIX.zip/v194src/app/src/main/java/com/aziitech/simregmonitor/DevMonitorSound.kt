package com.aziitech.simregmonitor

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Small, local-only feedback layer for meaningful DevMonitor events.
 * No network, background playback, or long-running audio is used.
 */
class DevMonitorSound(context: Context) {
    companion object {
        private const val PREFS = "devmonitor_feedback"
        private const val SOUND_ENABLED = "sound_enabled"
        private const val HAPTIC_ENABLED = "haptic_enabled"
    }

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val soundPool: SoundPool
    private val startId: Int
    private val successId: Int
    private val warningId: Int
    private val completeId: Int
    private val vibrator: Vibrator

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(attributes)
            .build()
        startId = soundPool.load(appContext, R.raw.sound_start, 1)
        successId = soundPool.load(appContext, R.raw.sound_success, 1)
        warningId = soundPool.load(appContext, R.raw.sound_warning, 1)
        completeId = soundPool.load(appContext, R.raw.sound_complete, 1)
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = appContext.getSystemService(VibratorManager::class.java)
            manager?.defaultVibrator ?: appContext.getSystemService(Vibrator::class.java)
        } else {
            @Suppress("DEPRECATION")
            appContext.getSystemService(Vibrator::class.java)
        }
    }

    var soundEnabled: Boolean
        get() = prefs.getBoolean(SOUND_ENABLED, true)
        set(value) { prefs.edit().putBoolean(SOUND_ENABLED, value).apply() }

    var hapticEnabled: Boolean
        get() = prefs.getBoolean(HAPTIC_ENABLED, true)
        set(value) { prefs.edit().putBoolean(HAPTIC_ENABLED, value).apply() }

    fun monitoringStarted() = play(startId, 1)
    fun success() = play(successId, 1)
    fun warning() = play(warningId, 2)
    fun completed() = play(completeId, 2)

    fun hapticConfirm() {
        if (!hapticEnabled || !vibrator.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(18L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(18L)
            }
        }
    }

    private fun play(soundId: Int, haptic: Int) {
        if (soundEnabled) {
            runCatching { soundPool.play(soundId, 0.55f, 0.55f, 1, 0, 1f) }
        }
        if (haptic > 0) hapticConfirm()
    }

    fun release() {
        soundPool.release()
    }
}
