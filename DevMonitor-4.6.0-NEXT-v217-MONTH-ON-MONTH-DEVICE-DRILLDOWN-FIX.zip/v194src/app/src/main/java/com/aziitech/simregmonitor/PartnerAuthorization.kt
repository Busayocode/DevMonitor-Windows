package com.aziitech.simregmonitor

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.util.Locale
import java.util.UUID

private const val PARTNER_REQUESTS = "partner_authorization_requests"
private const val STATUS_PENDING = "PENDING"
private const val STATUS_APPROVED = "APPROVED"
private const val STATUS_REJECTED = "REJECTED"
private const val STATUS_REVOKED = "REVOKED"

/** Shared, platform-neutral partner authorization backed by Firebase Firestore.
 *  Approval is tied to Firebase account UID + Trade Code, never to one physical device.
 */
object PartnerAuthorization {
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    data class Request(
        val id: String,
        val partnerUid: String,
        val partnerPhone: String,
        val tradeCode: String,
        val staffPhone: String,
        val status: String,
        val createdAt: Long,
        val decidedAt: Long?,
        val decidedBy: String?,
        val reason: String?,
        val deviceLabel: String?
    )

    fun newRequestId(): String = "PARTNER-" + UUID.randomUUID().toString().replace("-", "").take(10).uppercase(Locale.US)

    fun submitRequest(
        partnerPhone: String,
        tradeCode: String,
        staffPhone: String,
        deviceLabel: String,
        onResult: (Result<Request>) -> Unit
    ) {
        if (!NetworkUtils.hasActiveInternet(com.google.firebase.FirebaseApp.getInstance().applicationContext)) {
            onResult(Result.failure(IllegalStateException(NetworkUtils.OFFLINE_MESSAGE)))
            return
        }
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            onResult(Result.failure(IllegalStateException("Sign in with Google before requesting partner payment access.")))
            return
        }
        val requestId = newRequestId()
        val now = System.currentTimeMillis()
        val data = hashMapOf<String, Any?>(
            "partnerUid" to user.uid,
            "partnerEmail" to (user.email ?: ""),
            "partnerPhone" to partnerPhone,
            "tradeCode" to tradeCode.trim().uppercase(Locale.US),
            "staffPhone" to staffPhone,
            "status" to STATUS_PENDING,
            "createdAt" to now,
            "decidedAt" to null,
            "decidedBy" to null,
            "reason" to null,
            "deviceLabel" to deviceLabel
        )
        db.collection(PARTNER_REQUESTS).document(requestId).set(data)
            .addOnSuccessListener {
                onResult(Result.success(Request(requestId, user.uid, partnerPhone, tradeCode.trim().uppercase(Locale.US), staffPhone, STATUS_PENDING, now, null, null, null, deviceLabel)))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun findActiveApproval(tradeCode: String, onResult: (Result<Request?>) -> Unit) {
    if (!NetworkUtils.hasActiveInternet(com.google.firebase.FirebaseApp.getInstance().applicationContext)) {
        onResult(Result.failure(IllegalStateException(NetworkUtils.OFFLINE_MESSAGE)))
        return
    }
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            onResult(Result.failure(IllegalStateException("Sign in with Google before checking partner access.")))
            return
        }
        db.collection(PARTNER_REQUESTS)
            .whereEqualTo("partnerUid", user.uid)
            .whereEqualTo("tradeCode", tradeCode.trim().uppercase(Locale.US))
            .whereEqualTo("status", STATUS_APPROVED)
            .limit(1)
            .get()
            .addOnSuccessListener { snap -> onResult(Result.success(snap.documents.firstOrNull()?.toRequest())) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun listenToRequest(requestId: String, onUpdate: (Result<Request?>) -> Unit): ListenerRegistration? {
        if (!NetworkUtils.hasActiveInternet(com.google.firebase.FirebaseApp.getInstance().applicationContext)) {
            onUpdate(Result.failure(IllegalStateException(NetworkUtils.OFFLINE_MESSAGE)))
            return null
        }
        if (FirebaseAuth.getInstance().currentUser == null) return null
        return db.collection(PARTNER_REQUESTS).document(requestId).addSnapshotListener { snap, error ->
            if (error != null) onUpdate(Result.failure(error))
            else onUpdate(Result.success(snap?.takeIf { it.exists() }?.toRequest()))
        }
    }

    fun loadPendingForStaff(onResult: (Result<List<Request>>) -> Unit) {
    if (!NetworkUtils.hasActiveInternet(com.google.firebase.FirebaseApp.getInstance().applicationContext)) {
        onResult(Result.failure(IllegalStateException(NetworkUtils.OFFLINE_MESSAGE)))
        return
    }
        db.collection(PARTNER_REQUESTS)
            .whereEqualTo("status", STATUS_PENDING)
            .limit(50)
            .get()
            .addOnSuccessListener { snap -> onResult(Result.success(snap.documents.map { it.toRequest() }.sortedByDescending { it.createdAt })) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun decide(requestId: String, approved: Boolean, reason: String?, onResult: (Result<Unit>) -> Unit) {
    if (!NetworkUtils.hasActiveInternet(com.google.firebase.FirebaseApp.getInstance().applicationContext)) {
        onResult(Result.failure(IllegalStateException(NetworkUtils.OFFLINE_MESSAGE)))
        return
    }
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            onResult(Result.failure(IllegalStateException("Staff Firebase session is not active.")))
            return
        }
        val status = if (approved) STATUS_APPROVED else STATUS_REJECTED
        val update = mapOf<String, Any?>(
            "status" to status,
            "decidedAt" to System.currentTimeMillis(),
            "decidedBy" to user.uid,
            "reason" to reason
        )
        db.collection(PARTNER_REQUESTS).document(requestId).update(update)
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun revoke(requestId: String, reason: String?, onResult: (Result<Unit>) -> Unit) {
        decideStatus(requestId, STATUS_REVOKED, reason, onResult)
    }

    private fun decideStatus(requestId: String, status: String, reason: String?, onResult: (Result<Unit>) -> Unit) {
    if (!NetworkUtils.hasActiveInternet(com.google.firebase.FirebaseApp.getInstance().applicationContext)) {
        onResult(Result.failure(IllegalStateException(NetworkUtils.OFFLINE_MESSAGE)))
        return
    }
        val user = FirebaseAuth.getInstance().currentUser ?: run {
            onResult(Result.failure(IllegalStateException("Staff Firebase session is not active.")))
            return
        }
        db.collection(PARTNER_REQUESTS).document(requestId).update(
            mapOf("status" to status, "decidedAt" to System.currentTimeMillis(), "decidedBy" to user.uid, "reason" to reason)
        ).addOnSuccessListener { onResult(Result.success(Unit)) }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    private fun DocumentSnapshot.toRequest(): Request = Request(
        id = id,
        partnerUid = getString("partnerUid").orEmpty(),
        partnerPhone = getString("partnerPhone").orEmpty(),
        tradeCode = getString("tradeCode").orEmpty(),
        staffPhone = getString("staffPhone").orEmpty(),
        status = getString("status").orEmpty(),
        createdAt = getLong("createdAt") ?: 0L,
        decidedAt = getLong("decidedAt"),
        decidedBy = getString("decidedBy"),
        reason = getString("reason"),
        deviceLabel = getString("deviceLabel")
    )
}
