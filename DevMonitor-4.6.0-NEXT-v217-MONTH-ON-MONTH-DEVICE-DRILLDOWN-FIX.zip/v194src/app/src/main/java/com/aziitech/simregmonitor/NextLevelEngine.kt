package com.aziitech.simregmonitor

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Lightweight, deterministic NEXT LEVEL analytics. All calculations are explicitly invoked by the UI. */
object NextLevelEngine {
    data class AdvancedTrend(
        val date: String,
        val sales: Int,
        val active: Int,
        val bar48: Int,
        val sevenDayAverage: Double,
        val salesDelta: Int,
        val observedDevices: Int
    )
    data class Anomaly(
        val code: String,
        val severity: String,
        val title: String,
        val detail: String,
        val date: String
    )
    data class Reconciliation(
        val date: String,
        val localObserved: Int,
        val hqObserved: Int,
        val difference: Int,
        val status: String
    )
    data class Health(
        val online: Boolean,
        val databaseRows: Int,
        val observationRows: Int,
        val smsRows: Int,
        val reportCoverage: LocalDate?,
        val lastReportImportedAt: Long?,
        val databasePath: String,
        val databaseIntegrity: String,
        val freeStorageMb: Long
    )

    fun advancedTrends(db: DatabaseStore, end: LocalDate = LocalDate.now(), days: Int = 30): List<AdvancedTrend> {
        val start = end.minusDays(days.coerceIn(7, 90) - 1L)
        val rows = db.observationsBetween(start, end)
        return (0 until ChronoUnit.DAYS.between(start, end).toInt() + 1).map { offset ->
            val date = start.plusDays(offset.toLong())
            val day = rows.filter { it.date == date.toString() }
            val sales = day.sumOf { it.today ?: 0 }
            val active = day.sumOf { it.active ?: 0 }
            val bar48 = day.sumOf { it.bar48 ?: 0 }
            val prior = rows.filter { LocalDate.parse(it.date) in date.minusDays(6)..date }.groupBy { it.date }
                .values.map { group -> group.sumOf { it.today ?: 0 } }
            val avg = if (prior.isEmpty()) 0.0 else prior.average()
            val previousDay = rows.filter { it.date == date.minusDays(1).toString() }.sumOf { it.today ?: 0 }
            AdvancedTrend(date.toString(), sales, active, bar48, avg, sales - previousDay, day.size)
        }
    }

    fun anomalies(db: DatabaseStore, end: LocalDate = LocalDate.now(), days: Int = 30): List<Anomaly> {
        val start = end.minusDays(days.coerceIn(7, 90) - 1L)
        val rows = db.observationsBetween(start, end)
        val byCode = rows.groupBy { canonicalDeviceCode(it.code) }
        val out = mutableListOf<Anomaly>()
        for ((code, history) in byCode) {
            val ordered = history.sortedBy { it.date }
            val zeroRun = ordered.takeLast(7).reversed().takeWhile { (it.today ?: 0) == 0 }.size
            if (zeroRun >= 4) out += Anomaly(code, "HIGH", "Zero-sales streak", "$zeroRun consecutive observed days with zero sales.", end.toString())
            val last = ordered.lastOrNull()
            val previous = ordered.dropLast(1).takeLast(6)
            if (last != null && previous.isNotEmpty()) {
                val baseline = previous.map { it.today ?: 0 }.average()
                val current = last.today ?: 0
                if (baseline >= 2 && current <= baseline * .35) {
                    out += Anomaly(code, "MEDIUM", "Sales drop", "Latest sales ($current) are materially below the recent average (${baseline.toInt()}).", last.date)
                }
                if ((last.bar48 ?: 0) > (previous.lastOrNull()?.bar48 ?: 0)) {
                    out += Anomaly(code, "MEDIUM", "Conversion lost increased", "Bar 48 increased from ${previous.lastOrNull()?.bar48 ?: 0} to ${last.bar48 ?: 0}.", last.date)
                }
            }
        }
        return out.sortedWith(compareBy<Anomaly> { if (it.severity == "HIGH") 0 else 1 }.thenBy { it.code })
    }

    fun reconcile(db: DatabaseStore, company: CompanyActivationStore, date: LocalDate = LocalDate.now()): List<Reconciliation> {
        val local = db.observationsBetween(date, date).groupBy { canonicalDeviceCode(it.code) }
            .mapValues { (_, v) -> v.sumOf { it.today ?: 0 } }
        val report = company.latestReportForMonth(date.year, date.monthValue) ?: return local.map { (code, value) -> Reconciliation("$date • $code", value, 0, value, "No HQ report") }
        val hq = report.rows.groupBy { canonicalDeviceCode(it.deviceId) }
            .mapValues { (_, rows) -> rows.sumOf { row -> row.valueOnDate(date) } }
        return (local.keys + hq.keys).distinct().sorted().map { code ->
            val l = local[code] ?: 0
            val h = hq[code] ?: 0
            Reconciliation("$date • $code", l, h, l - h, if (l == h) "MATCH" else "DIFFERENCE")
        }
    }

    fun health(context: Context, db: DatabaseStore, company: CompanyActivationStore): Health {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = network?.let { cm.getNetworkCapabilities(it) }
        val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val today = LocalDate.now()
        val integrity = runCatching { db.readableDatabase.rawQuery("PRAGMA integrity_check", null).use { if (it.moveToFirst()) it.getString(0) else "unknown" } }.getOrDefault("error")
        return Health(online, db.countCodes() + db.countRecords() + db.countHistory(), db.observationsBetween(today.minusDays(90), today).size, db.smsCount(), company.latestReportCoverageEnd(today), company.latestReportImportedAt(today.minusDays(90), today), db.databaseFile().absolutePath, integrity, db.databaseFile().usableSpace / (1024L * 1024L))
    }

    fun optimizeDatabase(db: DatabaseStore) {
        // Explicitly user initiated. SQLite chooses applicable indexes/statistics.
        db.writableDatabase.execSQL("PRAGMA optimize")
    }
}
