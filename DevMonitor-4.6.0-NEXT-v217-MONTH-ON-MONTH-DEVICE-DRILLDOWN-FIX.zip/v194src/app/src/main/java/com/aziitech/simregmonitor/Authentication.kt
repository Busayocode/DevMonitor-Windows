package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider

private const val GLO_STAFF_PREFIX = "0805557"
private const val OTP_COOLDOWN_MS = 10L * 60L * 1000L

enum class AuthState { SIGNED_OUT, PHONE_REQUIRED, AUTHORIZATION_REQUIRED, AUTHORIZED, REVOKED }

enum class AccountClassification { UNKNOWN, GLO_STAFF_CANDIDATE, AGENT_PARTNER }

data class DevMonitorAccount(
    val accountId: String,
    val googleEmail: String,
    val mainPhone: String,
    val alternatePhone: String?,
    val firebaseUid: String?,
    val phoneVerifiedAt: Long?,
    val classification: AccountClassification,
    val state: AuthState,
    val createdAt: Long,
    val updatedAt: Long
)

data class AuthorizationAuditEvent(
    val id: String,
    val requestId: String,
    val eventType: String,
    val grantorAccountId: String?,
    val recipientAccountId: String,
    val recipientPhone: String,
    val scope: String,
    val timestamp: Long,
    val client: String,
    val reason: String?
)

object DevMonitorAuth {
    fun normalizeNigerianPhone(input: String): String {
        val digits = input.filter(Char::isDigit)
        return when {
            digits.startsWith("234") && digits.length == 13 -> "0" + digits.drop(3)
            digits.length == 10 && digits.firstOrNull() in '7'..'9' -> "0$digits"
            else -> digits
        }
    }

    fun isValidNigerianPhone(phone: String): Boolean =
        phone.length == 11 && phone.startsWith("0") && phone.all(Char::isDigit)

    fun isStaffCandidate(phone: String): Boolean =
        phone.length == 11 && phone.startsWith(GLO_STAFF_PREFIX) && phone.all(Char::isDigit)

    fun classify(phone: String): AccountClassification =
        if (isStaffCandidate(phone)) AccountClassification.GLO_STAFF_CANDIDATE
        else AccountClassification.AGENT_PARTNER

    fun newAccountId(): String = "FP-" + UUID.randomUUID().toString().replace("-", "").take(12).uppercase(Locale.US)
    fun newRequestId(): String = "AUTH-" + UUID.randomUUID().toString().replace("-", "").take(10).uppercase(Locale.US)

    fun timestamp(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).apply { timeZone = TimeZone.getTimeZone("Africa/Lagos") }.format(Date(ms))

    fun buildAuthorizationMessage(account: DevMonitorAccount, managerPhone: String, requestId: String): String =
        "DevMonitor authorization request\n\nRequest ID: $requestId\nAccount ID: ${account.accountId}\nGoogle account: ${account.googleEmail}\nVerified main phone: ${account.mainPhone}\nAccount classification: ${account.classification.name}\nRequested scope: Payment Intelligence\nDevice Manager phone: $managerPhone\n\nPlease authorize this DevMonitor account through the DevMonitor authorization system. Do not approve based on this message alone; verify the requester and the account inside the authorization system."
}

@Composable
fun AuthenticationGate(
    account: DevMonitorAccount?,
    googleEmail: String?,
    onSaveProfile: (String, String?) -> Unit,
    onPhoneVerified: (String, String) -> Unit,
    onRequestAuthorization: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var mainPhone by remember(account) { mutableStateOf(account?.mainPhone ?: "") }
    var alternatePhone by remember(account) { mutableStateOf(account?.alternatePhone ?: "") }
    var managerPhone by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var resendToken by remember { mutableStateOf<PhoneAuthProvider.ForceResendingToken?>(null) }
    var otpSentAt by remember { mutableLongStateOf(0L) }
    var sendingOtp by remember { mutableStateOf(false) }
    var verifyingOtp by remember { mutableStateOf(false) }
    var showRequest by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var nowTick by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(verificationId) {
        if (verificationId != null) {
            while (verificationId != null) {
                nowTick = System.currentTimeMillis()
                delay(1000)
            }
        }
    }

    fun normalizedMain(): String = DevMonitorAuth.normalizeNigerianPhone(mainPhone)

    fun startPhoneVerification(forceResend: Boolean = false) {
        if (!NetworkUtils.hasActiveInternet(context)) {
            error = NetworkUtils.OFFLINE_MESSAGE
            return
        }
        val phone = normalizedMain()
        if (googleEmail.isNullOrBlank()) {
            error = "Sign in with Google first. DevMonitor will use the Google account as the identity anchor."
            return
        }
        if (!DevMonitorAuth.isValidNigerianPhone(phone)) {
            error = "Enter a valid Nigerian 11-digit main phone number."
            return
        }
        if (!DevMonitorAuth.isStaffCandidate(phone)) {
            error = "Phone verification is only available for the configured Glo staff-line pattern. Other numbers do not trigger paid OTP verification."
            return
        }
        val firebaseUser = FirebaseAuth.getInstance().currentUser
        if (firebaseUser == null) {
            error = "Google identity is not yet connected to Firebase. Sign out and sign in again, then retry."
            return
        }
        val elapsed = System.currentTimeMillis() - otpSentAt
        if (!forceResend && otpSentAt > 0L && elapsed < OTP_COOLDOWN_MS) {
            val remaining = ((OTP_COOLDOWN_MS - elapsed) / 1000L).coerceAtLeast(1L)
            error = "Please wait ${remaining / 60}:${"%02d".format(remaining % 60)} before requesting another OTP."
            return
        }
        if (activity == null) {
            error = "DevMonitor could not access the Android verification activity."
            return
        }
        error = ""
        sendingOtp = true
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                // Do not silently turn an automatic SMS retrieval into access. Link the
                // verified credential to the already authenticated Google/Firebase account.
                firebaseUser.linkWithCredential(credential)
                    .addOnSuccessListener {
                        sendingOtp = false
                        verifyingOtp = false
                        verificationId = null
                        onPhoneVerified(phone, firebaseUser.uid)
                        error = "Staff-line ownership verified successfully."
                    }
                    .addOnFailureListener {
                        sendingOtp = false
                        verifyingOtp = false
                        error = "Phone verification could not be linked to this Google/Firebase account: ${it.message ?: "unknown error"}"
                    }
            }

            override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                sendingOtp = false
                error = "OTP request failed: ${e.message ?: "Firebase rejected the verification request."}"
            }

            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                sendingOtp = false
                verificationId = id
                resendToken = token
                otpSentAt = System.currentTimeMillis()
                error = "Verification code sent to the staff line ending ${phone.takeLast(4)}."
            }
        }

        val optionsBuilder = PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance())
            .setPhoneNumber("+234" + phone.drop(1))
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
        if (forceResend && resendToken != null) optionsBuilder.setForceResendingToken(resendToken!!)
        PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    }

    fun verifyCode() {
        if (!NetworkUtils.hasActiveInternet(context)) {
            error = NetworkUtils.OFFLINE_MESSAGE
            return
        }
        val id = verificationId
        val phone = normalizedMain()
        if (id.isNullOrBlank()) {
            error = "Request a verification code first."
            return
        }
        if (otpCode.trim().length != 6) {
            error = "Enter the 6-digit verification code."
            return
        }
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            error = "Your Google/Firebase session is no longer active. Sign in again."
            return
        }
        verifyingOtp = true
        val credential = PhoneAuthProvider.getCredential(id, otpCode.trim())
        user.linkWithCredential(credential)
            .addOnSuccessListener {
                verifyingOtp = false
                verificationId = null
                onPhoneVerified(phone, user.uid)
                error = "Staff-line ownership verified successfully."
            }
            .addOnFailureListener {
                verifyingOtp = false
                error = "The verification code could not be accepted: ${it.message ?: "check the code and try again."}"
            }
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Payment access & authorization", fontWeight = FontWeight.ExtraBold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Payment and incentive information is operationally sensitive. DevMonitor estimates are not the company's official payment records.")
                }
                item {
                    if (googleEmail.isNullOrBlank()) {
                        Text("Sign in with Google first from Settings → Account.")
                    } else {
                        Text("Google account: $googleEmail")
                        Text("Google/Firebase identity is required before any phone OTP can be requested.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    OutlinedTextField(
                        mainPhone, { mainPhone = it; verificationId = null; otpCode = "" },
                        Modifier.fillMaxWidth(), label = { Text("Official main staff-line number") }, singleLine = true
                    )
                }
                item {
                    Text(
                        "Only the configured Glo staff-line pattern (0805557xxxx) can start OTP verification. This is an eligibility filter, not proof that the number belongs to staff.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                item {
                    DevMonitorButton(
                        onClick = { startPhoneVerification(false) },
                        enabled = !sendingOtp && !verifyingOtp && verificationId == null,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (sendingOtp) "Sending OTP…" else "Verify staff line") }
                }
                if (verificationId != null) {
                    item {
                        OutlinedTextField(
                            otpCode, { otpCode = it.filter(Char::isDigit).take(6) },
                            Modifier.fillMaxWidth(), label = { Text("6-digit verification code") }, singleLine = true
                        )
                    }
                    item {
                        DevMonitorButton(
                            onClick = ::verifyCode,
                            enabled = !verifyingOtp && otpCode.length == 6,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (verifyingOtp) "Verifying…" else "Confirm OTP") }
                    }
                    item {
                        val remaining = ((OTP_COOLDOWN_MS - (nowTick - otpSentAt)) / 1000L).coerceAtLeast(0L)
                        TextButton(
                            onClick = { startPhoneVerification(true) },
                            enabled = !sendingOtp && remaining == 0L
                        ) { Text(if (remaining > 0) "Resend available in ${remaining / 60}:${"%02d".format(remaining % 60)}" else "Resend OTP") }
                    }
                }
                if (account?.phoneVerifiedAt != null) {
                    item {
                        Text("Staff line verified on ${DevMonitorAuth.timestamp(account.phoneVerifiedAt)}", color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (error.isNotBlank()) item { Text(error, color = if (error.contains("successfully")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }

                val classification = DevMonitorAuth.classify(normalizedMain())
                if (classification == AccountClassification.AGENT_PARTNER) {
                    item {
                        Text("This number does not match the configured staff-line pattern. It will not trigger an SMS OTP. If you are an authorized agent/partner, use the Device Manager authorization path.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (showRequest) item {
                    OutlinedTextField(managerPhone, { managerPhone = it }, Modifier.fillMaxWidth(), label = { Text("Device Manager phone number") }, singleLine = true)
                    Spacer(Modifier.height(6.dp))
                    Text("The manager number routes the authorization request. Actual authorization must be recorded by the DevMonitor authorization system.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            DevMonitorButton(onClick = {
                val normalized = normalizedMain()
                val alt = DevMonitorAuth.normalizeNigerianPhone(alternatePhone).takeIf { it.isNotBlank() }
                if (!DevMonitorAuth.isValidNigerianPhone(normalized)) {
                    error = "Enter a valid Nigerian 11-digit main phone number."
                    return@DevMonitorButton
                }
                if (alt != null && !DevMonitorAuth.isValidNigerianPhone(alt)) {
                    error = "The alternate number is not a valid Nigerian phone number."
                    return@DevMonitorButton
                }
                if (DevMonitorAuth.isStaffCandidate(normalized)) {
                    if (account?.phoneVerifiedAt == null) {
                        error = "Verify the staff line by OTP before continuing."
                        return@DevMonitorButton
                    }
                    onSaveProfile(normalized, alt)
                    onClose()
                } else {
                    if (!showRequest) {
                        onSaveProfile(normalized, alt)
                        showRequest = true
                        error = "Manager authorization is required. Enter the Device Manager's Nigerian phone number and request authorization."
                    } else {
                        val manager = DevMonitorAuth.normalizeNigerianPhone(managerPhone)
                        if (!DevMonitorAuth.isValidNigerianPhone(manager)) {
                            error = "Enter the Device Manager's Nigerian phone number."
                            return@DevMonitorButton
                        }
                        onSaveProfile(normalized, alt)
                        onRequestAuthorization(manager)
                        showRequest = false
                    }
                }
            }) { Text(if (showRequest) "Request authorization" else "Save profile") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

fun shareAuthorizationRequest(context: Context, message: String, whatsapp: Boolean) {
    if (!NetworkUtils.hasActiveInternet(context)) return
    val uri = if (whatsapp) Uri.parse("https://wa.me/?text=" + Uri.encode(message)) else null
    val intent = if (uri != null) Intent(Intent.ACTION_VIEW, uri) else Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message)
    }
    context.startActivity(Intent.createChooser(intent, "Share DevMonitor authorization request"))
}
