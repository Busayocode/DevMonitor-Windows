package com.aziitech.simregmonitor

import java.time.LocalDate
import java.time.YearMonth

/**
 * Unified payment-progression engine with two deliberately separate calculators.
 *
 * Loaded Report progression is calculated only from the month-aware normalized
 * Loaded Reports databases (current and previous calendar month). Device Monitor progression is calculated from SMS
 * Active data and may consult Loaded Reports only to reconstruct the historical
 * calendar-month baseline needed to turn a cumulative Active counter into a
 * 21st-to-20th payment-cycle value.
 */
object PaymentEngine {
    data class Progression(
        val cycleStart: LocalDate,
        val cycleEnd: LocalDate,
        val asOf: LocalDate,
        val activations: Int?,
        val availableThrough: LocalDate?,
        val complete: Boolean,
        val source: String,
        val baselineDate: LocalDate? = null,
        val baselineActive: Int? = null,
        val warning: String? = null
    ) {
        val estimate: IncentiveEstimate? get() = activations?.let { PaymentRules.estimate(it, 0) }
    }

    object LoadedReports {
        fun calculate(
            deviceId: String,
            asOfRequested: LocalDate = LocalDate.now(),
            companyStore: CompanyActivationStore
        ): Progression {
            val asOf = PaymentRules.currentAwareDate(asOfRequested)
            val (cycleStart, cycleEnd) = PaymentRules.paymentCycleForDate(asOf)
            val values = companyStore.dailyCoverageForDevice(deviceId, cycleStart, asOf)
            val through = values.keys.maxOrNull()
            val total = if (values.isNotEmpty()) values.values.sumOf { it.coerceAtLeast(0) } else null
            val complete = through != null && through >= asOf
            val warning = when {
                values.isEmpty() -> "No Loaded Report data is available for this device in the current payment cycle."
                !complete -> "Loaded Report progression is available through $through; later cycle dates have not been loaded yet."
                else -> null
            }
            return Progression(
                cycleStart = cycleStart,
                cycleEnd = cycleEnd,
                asOf = asOf,
                activations = total,
                availableThrough = through,
                complete = complete,
                source = "Loaded Reports continuous database",
                warning = warning
            )
        }
    }

    object DeviceMonitor {
        fun calculate(
            deviceId: String,
            asOfRequested: LocalDate = LocalDate.now(),
            deviceStore: DatabaseStore,
            companyStore: CompanyActivationStore?
        ): Progression {
            val asOf = PaymentRules.currentAwareDate(asOfRequested)
            val (cycleStart, cycleEnd) = PaymentRules.paymentCycleForDate(asOf)
            val code = canonicalDeviceCode(deviceId)
            val currentMonth = YearMonth.from(asOf)
            val previousMonth = currentMonth.minusMonths(1)

            // Device Monitor and Loaded Reports have separate calculators. The only
            // shared point here is evidence selection: a Loaded Report can establish
            // a historical baseline when the cumulative SMS Active baseline is absent.
            val previousPortionStart = cycleStart
            val previousPortionEnd = minOf(asOf, previousMonth.atEndOfMonth())
            val previousPortion = if (previousPortionStart <= previousPortionEnd && companyStore != null) {
                companyStore.dailyCoverageForDevice(code, previousPortionStart, previousPortionEnd)
            } else emptyMap()
            var total = previousPortion.values.sumOf { it.coerceAtLeast(0) }
            var availableThrough = previousPortion.keys.maxOrNull()
            val sources = mutableListOf<String>()
            if (previousPortion.isNotEmpty()) sources += "Loaded Reports ${previousPortionStart}..${previousPortionEnd}"

            val monthStart = currentMonth.atDay(1)
            val boundary = cycleStart.minusDays(1)
            val allSms = deviceStore.observationsBetween(code, monthStart, asOf)
                .filter { it.active != null }
                .sortedBy { it.date }
            val latestSms = allSms.lastOrNull()
            val boundarySms = if (asOf.dayOfMonth >= 21) {
                allSms.filter { LocalDate.parse(it.date) <= boundary }.lastOrNull()
            } else null
            val reportImportedAt = companyStore?.latestReportImportedAtCovering(asOf)

            if (asOf.dayOfMonth >= 21) {
                // The payment cycle begins on the 21st, but SMS Active is cumulative
                // from the 1st of the calendar month. Therefore the only correct
                // current-cycle calculation is:
                //
                //     latest Active after the 20th - Active at the 20th
                //
                // The baseline may come from the latest Device Monitor Active known
                // by the 20th, or from a Loaded Report that covers the calendar month
                // through the 20th. Never substitute MTD or zero.
                val baselineFromReports = if (boundarySms == null && companyStore != null) {
                    companyStore.paymentBaselineActiveFromLoadedReport(code, monthStart, boundary)
                } else null
                val baseline = boundarySms?.active ?: baselineFromReports
                val baselineDate = boundarySms?.let { LocalDate.parse(it.date) } ?: if (baselineFromReports != null) boundary else null

                if (latestSms == null) {
                    return Progression(
                        cycleStart, cycleEnd, asOf, null, availableThrough, false,
                        sources.joinToString(" + ").ifBlank { "Device Monitor" },
                        baselineDate, baseline,
                        if (baseline == null) {
                            "Insufficient historical data: establish the activation value through $boundary from Device Monitor or a Loaded Report, then refresh Device Monitor."
                        } else {
                            "No current Device Monitor Active observation is available after the 20th."
                        }
                    )
                }

                // If the current SMS was received after the report snapshot, it is the
                // authoritative live calendar-month Active value. If the report is newer,
                // the Loaded Report may remain the current evidence source rather than
                // incorrectly presenting an older SMS as fresher.
                val latestSmsReceivedAt = parseReceivedAt(latestSms.receivedAt)
                val smsIsNewerThanReport = reportImportedAt == null ||
                    latestSmsReceivedAt == null || latestSmsReceivedAt > reportImportedAt
                DevMonitorLogger.payment(
                    "Device Monitor live Active freshness device=$code asOf=$asOf " +
                        "smsReceived=$latestSmsReceivedAt reportCoveringAsOfImportedAt=$reportImportedAt " +
                        "smsIsNewer=$smsIsNewerThanReport"
                )

                val currentActive = if (smsIsNewerThanReport) latestSms.active else null
                if (currentActive != null) {
                    val progression = (currentActive - (baseline ?: 0)).coerceAtLeast(0)
                    total += progression
                    availableThrough = LocalDate.parse(latestSms.date)
                    sources += "Device Monitor Active ${latestSms.date} − baseline ${baselineDate ?: boundary}"
                    return Progression(
                        cycleStart, cycleEnd, asOf, total, availableThrough,
                        availableThrough?.let { date -> date.isAfter(asOf) || date == asOf } == true,
                        sources.distinct().joinToString(" + "),
                        baselineDate ?: boundary, baseline,
                        when {
                            baseline == null -> "Insufficient historical data: establish the activation value through $boundary from Device Monitor or a Loaded Report."
                            availableThrough?.let { date -> date.isBefore(asOf) } == true -> "Device Monitor progression is current through $availableThrough."
                            else -> null
                        }
                    )
                }

                // A newer Loaded Report is allowed to provide the current-cycle
                // contribution, but only after the baseline has been established.
                // This is still the Device Monitor calculator; it is not the Loaded
                // Report payment calculator and never uses Sunday bonuses.
                if (baseline != null && companyStore != null) {
                    val currentLoaded = companyStore.dailyCoverageForDevice(code, cycleStart, asOf)
                    if (currentLoaded.isNotEmpty()) {
                        val reportTotal = currentLoaded.values.sumOf { it.coerceAtLeast(0) }
                        total += reportTotal
                        availableThrough = currentLoaded.keys.maxOrNull()
                        sources += "Loaded Report current-cycle evidence"
                        return Progression(
                            cycleStart, cycleEnd, asOf, total, availableThrough,
                            availableThrough?.let { date -> date.isAfter(asOf) || date == asOf } == true,
                            sources.distinct().joinToString(" + "),
                            baselineDate ?: boundary, baseline,
                            if (availableThrough?.let { date -> date.isBefore(asOf) } == true) "Loaded Report progression is current through $availableThrough." else null
                        )
                    }
                }

                return Progression(
                    cycleStart, cycleEnd, asOf, null, availableThrough, false,
                    "Device Monitor Active",
                    baselineDate ?: boundary, baseline,
                    "A current payment-cycle value is not available yet. Keep monitoring or load a report covering the 21st onward."
                )
            }

            // Before the 21st, the payment cycle's current-month contribution is the
            // calendar-month cumulative Active value. This is still Device Monitor's
            // calculator; Loaded Reports are only a fallback when no SMS Active exists.
            if (latestSms != null) {
                total += latestSms.active!!.coerceAtLeast(0)
                availableThrough = LocalDate.parse(latestSms.date)
                sources += "Device Monitor Active ${latestSms.date}"
                return Progression(
                    cycleStart, cycleEnd, asOf, total, availableThrough,
                    availableThrough?.let { date -> date.isAfter(asOf) || date == asOf } == true,
                    sources.distinct().joinToString(" + ").ifBlank { "Device Monitor Active" },
                    null, 0,
                    if (availableThrough?.let { date -> date.isBefore(asOf) } == true) "Device Monitor progression is current through $availableThrough." else null
                )
            }

            if (companyStore != null) {
                val currentLoaded = companyStore.dailyCoverageForDevice(code, monthStart, asOf)
                if (currentLoaded.isNotEmpty()) {
                    total += currentLoaded.values.sumOf { it.coerceAtLeast(0) }
                    availableThrough = currentLoaded.keys.maxOrNull()
                    sources += "Loaded Reports current-month fallback"
                    return Progression(
                        cycleStart, cycleEnd, asOf, total, availableThrough, false,
                        sources.distinct().joinToString(" + "),
                        null, 0,
                        "No Device Monitor Active observation is available; current-month progression is report-backed only."
                    )
                }
            }

            return Progression(
                cycleStart, cycleEnd, asOf, if (previousPortion.isNotEmpty()) total else null,
                availableThrough, false,
                sources.distinct().joinToString(" + ").ifBlank { "Device Monitor" },
                null, 0,
                "No Device Monitor Active observation is available for the current month."
            )
        }

        private fun parseReceivedAt(value: String): Long? = runCatching {
            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).parse(value)?.time
        }.getOrNull()
    }

}
