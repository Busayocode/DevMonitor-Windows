package com.aziitech.simregmonitor


import android.view.ViewGroup
import android.app.Activity
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.AdListener
import android.util.Log

/**
 * DevMonitor production AdMob configuration.
 * IDs are supplied through BuildConfig and gradle.properties.
 * Keep ads out of active SMS sending/progress screens.
 */
object AdsConfig {
    const val AD_UNIT_ID = BuildConfig.ADMOB_BANNER_AD_UNIT_ID
    const val INTERSTITIAL_AD_UNIT_ID = BuildConfig.ADMOB_INTERSTITIAL_AD_UNIT_ID
    const val REWARDED_AD_UNIT_ID = BuildConfig.ADMOB_REWARDED_AD_UNIT_ID
}

@Composable
fun DevMonitorBannerAd(modifier: Modifier = Modifier) {
    if (!BuildConfig.MONETIZED_BUILD) return
    AndroidView(
        modifier = modifier,
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, 360))
                adUnitId = AdsConfig.AD_UNIT_ID
                adListener = object : AdListener() {
                    override fun onAdLoaded() { Log.d("DevMonitorAds", "Banner ad loaded successfully") }
                    override fun onAdFailedToLoad(error: com.google.android.gms.ads.LoadAdError) {
                        Log.e("DevMonitorAds", "Banner ad failed: code=${error.code}, message=${error.message}, domain=${error.domain}")
                    }
                }
                loadAd(AdRequest.Builder().build())
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        }
    )
}


/**
 * Interstitial manager. Uses the configured DevMonitor production interstitial unit.
 * The caller controls frequency and only asks to show at natural task-completion pauses.
 */
object DevMonitorInterstitialAd {
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false

    fun preload(activity: Activity) {
        if (interstitialAd != null || isLoading) return
        isLoading = true
        InterstitialAd.load(
            activity,
            AdsConfig.INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    isLoading = false
                    interstitialAd = ad
                    Log.d("DevMonitorAds", "Interstitial ad loaded successfully")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoading = false
                    interstitialAd = null
                    Log.e("DevMonitorAds", "Interstitial failed: code=${error.code}, message=${error.message}, domain=${error.domain}")
                }
            }
        )
    }

    /** Returns true when an interstitial was actually shown. */
    fun showIfReady(activity: Activity, onFinished: () -> Unit = {}) {
        val ad = interstitialAd
        if (ad == null) {
            preload(activity)
            onFinished()
            return
        }
        interstitialAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                preload(activity)
                onFinished()
            }
            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                Log.e("DevMonitorAds", "Interstitial failed to show: ${adError.message}")
                preload(activity)
                onFinished()
            }
        }
        ad.show(activity)
    }
}


/**
 * Rewarded export-credit manager.
 *
 * After the first 10 exports, one completed rewarded ad grants 3 export credits.
 * If the ad is unavailable, no export is consumed and the caller is informed.
 */
object DevMonitorRewardedAd {
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false

    fun preload(activity: Activity) {
        if (!BuildConfig.MONETIZED_BUILD || rewardedAd != null || isLoading) return
        isLoading = true
        RewardedAd.load(
            activity,
            AdsConfig.REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    isLoading = false
                    rewardedAd = ad
                    Log.d("DevMonitorAds", "Rewarded ad loaded successfully")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    isLoading = false
                    rewardedAd = null
                    Log.e("DevMonitorAds", "Rewarded failed: code=${error.code}, message=${error.message}, domain=${error.domain}")
                }
            }
        )
    }

    /**
     * Shows a rewarded ad. onRewarded is called only after the SDK confirms the reward.
     * onFinished is always called after dismissal/failure so the UI can continue safely.
     */
    fun show(activity: Activity, onRewarded: () -> Unit, onFinished: () -> Unit) {
        if (!BuildConfig.MONETIZED_BUILD) {
            onRewarded()
            onFinished()
            return
        }
        val ad = rewardedAd
        if (ad == null) {
            preload(activity)
            onFinished()
            return
        }
        rewardedAd = null
        var rewarded = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                preload(activity)
                onFinished()
            }
            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                Log.e("DevMonitorAds", "Rewarded failed to show: ${adError.message}")
                preload(activity)
                onFinished()
            }
        }
        ad.show(activity) {
            rewarded = true
            onRewarded()
        }
    }
}
