package com.aziitech.simregmonitor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

class DatabaseStore(private val context: Context, private val actualDatabaseName: String = DB_NAME) : SQLiteOpenHelper(context, actualDatabaseName, null, DB_VERSION) {
    init { if (databaseName == DB_NAME) migrateLegacyPreferences() }

    private fun migrateLegacyPreferences() {
        val prefs = context.getSharedPreferences("simreg_state", Context.MODE_PRIVATE)
        if (prefs.getBoolean("sqlite_migrated", false)) return
        runCatching {
            val raw = prefs.getString("current", null)
            if (!raw.isNullOrBlank()) {
                val root = JSONObject(raw); val codes = mutableListOf<String>(); val a = root.optJSONArray("codes") ?: JSONArray()
                for (i in 0 until a.length()) codes.add(a.optString(i))
                val records = linkedMapOf<String, QueryRecord>(); val ra = root.optJSONArray("records") ?: JSONArray()
                for (i in 0 until ra.length()) { val r = legacyJsonToRecord(ra.getJSONObject(i)); records[r.code] = r }
                saveCurrent(codes, records)
            }
            val archived = prefs.getString("archived", null)
            if (!archived.isNullOrBlank()) { val a = JSONArray(archived); for (i in 0 until a.length()) archive(a.optString(i)) }
            val lists = prefs.getString("lists", null)
            if (!lists.isNullOrBlank()) { val a = JSONArray(lists); for (i in 0 until a.length()) { val o=a.getJSONObject(i); val c=o.optJSONArray("codes") ?: JSONArray(); val list=buildList { for(j in 0 until c.length()) add(c.optString(j)) }; saveList(o.optString("name"),list) } }
            val history = prefs.getString("history", null)
            if (!history.isNullOrBlank()) { val a=JSONArray(history); for(i in 0 until a.length()){ val o=a.getJSONObject(i); val r=legacyJsonToRecord(o); writableDatabase.execSQL("INSERT INTO history(completed_at,json) VALUES(?,?)",arrayOf(o.optLong("historyAt",System.currentTimeMillis()),recordToJson(r).toString())) } }
        }
        prefs.edit().putBoolean("sqlite_migrated", true).apply()
    }

    private fun legacyJsonToRecord(o: JSONObject) = QueryRecord(
        code=o.optString("code"), type=runCatching{QueryType.valueOf(o.optString("type"))}.getOrDefault(QueryType.UNKNOWN),
        attempt=o.optInt("attempt",1), repetitionsSent=o.optInt("repetitionsSent",0), responseCount=o.optInt("responseCount",0),
        status=runCatching{AttemptStatus.valueOf(o.optString("status"))}.getOrDefault(AttemptStatus.QUEUED),
        result=o.optJSONObject("result")?.let{jsonToResult(it)}, error=o.optString("error").takeIf{it.isNotBlank()&&it!="null"},
        firstAttemptStatus=o.optString("firstAttemptStatus").takeIf{it.isNotBlank()}?.let{runCatching{AttemptStatus.valueOf(it)}.getOrNull()},
        completedAt=o.optLong("completedAt",System.currentTimeMillis()))

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE codes(code TEXT PRIMARY KEY,type TEXT NOT NULL,archived INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE records(code TEXT PRIMARY KEY,json TEXT NOT NULL)")
        db.execSQL("CREATE TABLE saved_lists(name TEXT PRIMARY KEY,codes_json TEXT NOT NULL,updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT,completed_at INTEGER NOT NULL,json TEXT NOT NULL)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
        db.execSQL("CREATE TABLE sms_inbox(id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,body TEXT NOT NULL,received_at INTEGER NOT NULL)")
        createAnalytics(db)
        createSmsRecoveryTables(db)
        createAgentPaymentTables(db)
        createAgentIndexes(db)
        createAuthenticationTables(db)
        createOperationalTaskTable(db)
    }
    private fun createSmsRecoveryTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sms_query_attempts(id INTEGER PRIMARY KEY AUTOINCREMENT,operation_id TEXT NOT NULL,code TEXT NOT NULL,destination TEXT NOT NULL,sent_at INTEGER NOT NULL,attempt INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sms_query_code ON sms_query_attempts(code,sent_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sms_query_operation ON sms_query_attempts(operation_id)")
    }
    private fun createAnalytics(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS daily_observations(code TEXT NOT NULL,obs_date TEXT NOT NULL,ownership TEXT NOT NULL,today INTEGER,mtd INTEGER,active INTEGER,bar48 INTEGER,bar96 INTEGER,duplicates INTEGER,monthly_target INTEGER,received_at TEXT,PRIMARY KEY(code,obs_date))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_obs_date ON daily_observations(obs_date)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_obs_code ON daily_observations(code)")
        db.execSQL("CREATE TABLE IF NOT EXISTS device_monitor_historical_activation_bridge(code TEXT NOT NULL,report_month TEXT NOT NULL,coverage_start TEXT NOT NULL,coverage_end TEXT NOT NULL,activation_sum INTEGER NOT NULL,source_report_id INTEGER NOT NULL,available_at INTEGER NOT NULL,PRIMARY KEY(code,report_month))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_device_hist_bridge_code ON device_monitor_historical_activation_bridge(code,report_month)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if(oldVersion<2) db.execSQL("CREATE TABLE IF NOT EXISTS sms_inbox(id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,body TEXT NOT NULL,received_at INTEGER NOT NULL)")
        if(oldVersion<3) createAnalytics(db)
        if(oldVersion<4) createAgentPaymentTables(db)
        if(oldVersion<5) createAgentIndexes(db)
        if(oldVersion<6) canonicalizeStoredDeviceCodes(db)
        if(oldVersion<7) createSmsRecoveryTables(db)
        if(oldVersion<8) createAuthenticationTables(db)
        if(oldVersion<9) upgradeAuthenticationTables(db)
        if(oldVersion<11) {
            db.execSQL("DROP TABLE IF EXISTS company_historical_activation_snapshot")
            db.execSQL("DROP INDEX IF EXISTS idx_company_hist_code")
            db.execSQL("CREATE TABLE IF NOT EXISTS device_monitor_historical_activation_bridge(code TEXT NOT NULL,report_month TEXT NOT NULL,coverage_start TEXT NOT NULL,coverage_end TEXT NOT NULL,activation_sum INTEGER NOT NULL,source_report_id INTEGER NOT NULL,available_at INTEGER NOT NULL,PRIMARY KEY(code,report_month))")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_device_hist_bridge_code ON device_monitor_historical_activation_bridge(code,report_month)")
        }
        if (oldVersion < 12) createOperationalTaskTable(db)
        if (oldVersion < 13) createOperationalNoteTable(db)
    }

    private fun createOperationalTaskTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS operational_tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,details TEXT NOT NULL DEFAULT '',due_date TEXT,priority TEXT NOT NULL DEFAULT 'NORMAL',link_type TEXT,link_value TEXT,completed INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tasks_completed_due ON operational_tasks(completed,due_date)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tasks_link ON operational_tasks(link_type,link_value)")
    }

    private fun createOperationalNoteTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS operational_notes(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT '',body TEXT NOT NULL,link_type TEXT,link_value TEXT,pinned INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_notes_pinned_updated ON operational_notes(pinned,updated_at)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_notes_link ON operational_notes(link_type,link_value)")
    }

    private fun canonicalizeStoredDeviceCodes(db: SQLiteDatabase) {
        db.beginTransaction()
        try {
            // Normalize saved code identities without touching non-GLO partner codes.
            val codeRows = mutableListOf<String>()
            db.rawQuery("SELECT code FROM codes", null).use { c -> while (c.moveToNext()) codeRows.add(c.getString(0)) }
            for (oldCode in codeRows) {
                val canonical = canonicalDeviceCode(oldCode)
                if (canonical == oldCode) continue
                val exists = db.rawQuery("SELECT 1 FROM codes WHERE code=? LIMIT 1", arrayOf(canonical)).use { it.moveToFirst() }
                if (exists) db.delete("codes", "code=?", arrayOf(oldCode))
                else db.execSQL("UPDATE codes SET code=? WHERE code=?", arrayOf(canonical, oldCode))
            }

            // Merge daily observations by stable device identity + date, retaining the
            // most recently received observation when short and long forms both exist.
            data class Obs(val code:String,val date:String,val ownership:String,val today:Int?,val mtd:Int?,val active:Int?,val bar48:Int?,val bar96:Int?,val dup:Int?,val target:Int?,val received:String)
            val merged = linkedMapOf<String, Obs>()
            db.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations", null).use { c ->
                while (c.moveToNext()) {
                    val code=canonicalDeviceCode(c.getString(0)); val o=Obs(code,c.getString(1),c.getString(2),if(c.isNull(3))null else c.getInt(3),if(c.isNull(4))null else c.getInt(4),if(c.isNull(5))null else c.getInt(5),if(c.isNull(6))null else c.getInt(6),if(c.isNull(7))null else c.getInt(7),if(c.isNull(8))null else c.getInt(8),if(c.isNull(9))null else c.getInt(9),c.getString(10)); val key=code+"|"+o.date; val prior=merged[key]; if(prior==null || o.received >= prior.received) merged[key]=o
                }
            }
            db.delete("daily_observations", null, null)
            merged.values.forEach { o -> db.execSQL("INSERT INTO daily_observations(code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)", arrayOf(o.code,o.date,o.ownership,o.today,o.mtd,o.active,o.bar48,o.bar96,o.dup,o.target,o.received)) }

            // Normalize saved lists and linked agent-device identities.
            val lists=mutableListOf<Pair<String,String>>()
            db.rawQuery("SELECT name,codes_json FROM saved_lists",null).use{c->while(c.moveToNext())lists.add(c.getString(0) to c.getString(1))}
            lists.forEach{(name,json)->runCatching{val a=JSONArray(json);val out=JSONArray();val seen=HashSet<String>();for(i in 0 until a.length()){val cc=canonicalDeviceCode(a.optString(i));if(seen.add(cc))out.put(cc)};db.execSQL("UPDATE saved_lists SET codes_json=? WHERE name=?",arrayOf(out.toString(),name))}}
            val devices=mutableListOf<Pair<Long,String>>(); db.rawQuery("SELECT agent_id,code FROM agent_devices",null).use{c->while(c.moveToNext())devices.add(c.getLong(0) to c.getString(1))}; devices.forEach{(agent,code)->val cc=canonicalDeviceCode(code);if(cc!=code){db.delete("agent_devices","agent_id=? AND code=?",arrayOf(agent.toString(),code));db.execSQL("INSERT OR IGNORE INTO agent_devices(agent_id,code) VALUES(?,?)",arrayOf(agent,cc))}}
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun createAuthenticationTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS fieldpulse_account(account_id TEXT PRIMARY KEY,google_email TEXT NOT NULL,main_phone TEXT,alternate_phone TEXT,firebase_uid TEXT,phone_verified_at INTEGER,classification TEXT NOT NULL,state TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS authorization_audit(id TEXT PRIMARY KEY,request_id TEXT NOT NULL,event_type TEXT NOT NULL,grantor_account_id TEXT,recipient_account_id TEXT NOT NULL,recipient_phone TEXT NOT NULL,scope TEXT NOT NULL,timestamp INTEGER NOT NULL,client TEXT NOT NULL,reason TEXT)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_auth_audit_recipient ON authorization_audit(recipient_account_id,timestamp)")
    }

    private fun upgradeAuthenticationTables(db: SQLiteDatabase) {
        runCatching { db.execSQL("ALTER TABLE fieldpulse_account ADD COLUMN firebase_uid TEXT") }
        runCatching { db.execSQL("ALTER TABLE fieldpulse_account ADD COLUMN phone_verified_at INTEGER") }
    }

    fun saveDevMonitorAccount(account: DevMonitorAccount) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO fieldpulse_account(account_id,google_email,main_phone,alternate_phone,firebase_uid,phone_verified_at,classification,state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)", arrayOf(account.accountId,account.googleEmail,account.mainPhone,account.alternatePhone,account.firebaseUid,account.phoneVerifiedAt,account.classification.name,account.state.name,account.createdAt,account.updatedAt))
    }
    fun fieldPulseAccount(): DevMonitorAccount? = readableDatabase.rawQuery("SELECT account_id,google_email,main_phone,alternate_phone,firebase_uid,phone_verified_at,classification,state,created_at,updated_at FROM fieldpulse_account LIMIT 1",null).use { c -> if(!c.moveToFirst()) null else DevMonitorAccount(c.getString(0),c.getString(1),c.getString(2),if(c.isNull(3)) null else c.getString(3),if(c.isNull(4)) null else c.getString(4),if(c.isNull(5)) null else c.getLong(5),runCatching{AccountClassification.valueOf(c.getString(6))}.getOrDefault(AccountClassification.UNKNOWN),runCatching{AuthState.valueOf(c.getString(7))}.getOrDefault(AuthState.SIGNED_OUT),c.getLong(8),c.getLong(9)) }
    fun addAuthorizationAudit(event: AuthorizationAuditEvent) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO authorization_audit(id,request_id,event_type,grantor_account_id,recipient_account_id,recipient_phone,scope,timestamp,client,reason) VALUES(?,?,?,?,?,?,?,?,?,?)", arrayOf(event.id,event.requestId,event.eventType,event.grantorAccountId,event.recipientAccountId,event.recipientPhone,event.scope,event.timestamp,event.client,event.reason))
    }
    fun authorizationAudit(): List<AuthorizationAuditEvent> = readableDatabase.rawQuery("SELECT id,request_id,event_type,grantor_account_id,recipient_account_id,recipient_phone,scope,timestamp,client,reason FROM authorization_audit ORDER BY timestamp DESC",null).use { c -> buildList { while(c.moveToNext()) add(AuthorizationAuditEvent(c.getString(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getLong(7),c.getString(8),if(c.isNull(9))null else c.getString(9))) } }

    private fun createAgentPaymentTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS agents(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,address TEXT NOT NULL,latitude REAL,longitude REAL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS agent_phones(id INTEGER PRIMARY KEY AUTOINCREMENT,agent_id INTEGER NOT NULL,phone TEXT NOT NULL,label TEXT NOT NULL DEFAULT '',FOREIGN KEY(agent_id) REFERENCES agents(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS agent_devices(agent_id INTEGER NOT NULL,code TEXT NOT NULL,PRIMARY KEY(agent_id,code),FOREIGN KEY(agent_id) REFERENCES agents(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS payment_cycles(id INTEGER PRIMARY KEY AUTOINCREMENT,start_date TEXT NOT NULL,end_date TEXT NOT NULL,label TEXT NOT NULL,mode TEXT NOT NULL,closed INTEGER NOT NULL DEFAULT 0,UNIQUE(start_date,end_date,mode))")
        db.execSQL("CREATE TABLE IF NOT EXISTS payment_records(id INTEGER PRIMARY KEY AUTOINCREMENT,cycle_id INTEGER NOT NULL,code TEXT NOT NULL,agent_id INTEGER,ownership TEXT NOT NULL,mtd INTEGER,today INTEGER,active INTEGER,bar48 INTEGER,bar96 INTEGER,snapshot_date TEXT NOT NULL,amount REAL,paid INTEGER NOT NULL DEFAULT 0,notes TEXT,UNIQUE(cycle_id,code),FOREIGN KEY(cycle_id) REFERENCES payment_cycles(id) ON DELETE CASCADE)")
    }
    private fun createAgentIndexes(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_agent_phone ON agent_phones(agent_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_agent_device ON agent_devices(code)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_payment_cycle ON payment_records(cycle_id)")
    }

    fun saveCurrent(codes: List<String>, records: Map<String, QueryRecord>) {
        val db=writableDatabase; db.beginTransaction(); try { val now=System.currentTimeMillis(); codes.distinct().forEach{code-> db.execSQL("INSERT OR IGNORE INTO codes(code,type,archived,created_at,updated_at) VALUES(?,?,?,?,?)",arrayOf(code,QueryType.from(code).name,0,now,now)); db.execSQL("UPDATE codes SET type=?,archived=0,updated_at=? WHERE code=?",arrayOf(QueryType.from(code).name,now,code)) }; records.values.forEach{r->db.execSQL("INSERT OR REPLACE INTO records(code,json) VALUES(?,?)",arrayOf(r.code,recordToJson(r).toString()))}; db.setTransactionSuccessful()} finally{db.endTransaction()}
    }
    fun loadCurrent(): Pair<List<String>,Map<String,QueryRecord>> { val codes=mutableListOf<String>(); readableDatabase.rawQuery("SELECT code FROM codes WHERE archived=0 ORDER BY rowid",null).use{c->while(c.moveToNext())codes.add(c.getString(0))}; val rec=linkedMapOf<String,QueryRecord>(); readableDatabase.rawQuery("SELECT json FROM records",null).use{c->while(c.moveToNext())runCatching{jsonToRecord(JSONObject(c.getString(0)))}.getOrNull()?.let{rec[it.code]=it}}; return codes to rec }
    fun saveList(name:String,codes:List<String>){if(name.trim().isBlank())return; writableDatabase.execSQL("INSERT OR REPLACE INTO saved_lists(name,codes_json,updated_at) VALUES(?,?,?)",arrayOf(name.trim(),JSONArray(codes.distinct().map(::canonicalDeviceCode)).toString(),System.currentTimeMillis()))}
    fun updateSavedListMembership(name:String, addCodes:List<String> = emptyList(), removeCodes:List<String> = emptyList()):Boolean {
        val listName=name.trim(); if(listName.isBlank()) return false
        val db=writableDatabase
        db.beginTransaction()
        return try {
            val current=mutableListOf<String>()
            db.rawQuery("SELECT codes_json FROM saved_lists WHERE name=?",arrayOf(listName)).use { c ->
                if(!c.moveToFirst()) return false
                runCatching { JSONArray(c.getString(0)) }.getOrNull()?.let { a -> for(i in 0 until a.length()) current.add(canonicalDeviceCode(a.optString(i))) }
            }
            val removeSet=removeCodes.map(::canonicalDeviceCode).filter{it.isNotBlank()}.toSet()
            val add=addCodes.map(::canonicalDeviceCode).filter{it.isNotBlank()}.distinct()
            val merged=current.filterNot{it in removeSet}.toMutableList()
            add.forEach { if(it !in merged) merged.add(it) }
            db.execSQL("UPDATE saved_lists SET codes_json=?,updated_at=? WHERE name=?",arrayOf(JSONArray(merged).toString(),System.currentTimeMillis(),listName))
            db.setTransactionSuccessful(); true
        } finally { db.endTransaction() }
    }
    fun deleteList(name:String)=writableDatabase.execSQL("DELETE FROM saved_lists WHERE name=?",arrayOf(name))
    fun loadLists():List<SavedQueryList>{val out=mutableListOf<SavedQueryList>(); readableDatabase.rawQuery("SELECT name,codes_json FROM saved_lists ORDER BY name COLLATE NOCASE",null).use{c->while(c.moveToNext()){val list=mutableListOf<String>();runCatching{JSONArray(c.getString(1))}.getOrNull()?.let{a->for(i in 0 until a.length())list.add(a.optString(i))};out.add(SavedQueryList(c.getString(0),list))}};return out}
    fun archive(code:String)=writableDatabase.execSQL("UPDATE codes SET archived=1,updated_at=? WHERE code=?",arrayOf(System.currentTimeMillis(),code))
    fun loadArchived():List<String>{val out=mutableListOf<String>();readableDatabase.rawQuery("SELECT code FROM codes WHERE archived=1 ORDER BY code",null).use{c->while(c.moveToNext())out.add(c.getString(0))};return out}
    fun restoreArchived(code:String)=writableDatabase.execSQL("UPDATE codes SET archived=0,updated_at=? WHERE code=?",arrayOf(System.currentTimeMillis(),code))
    fun deleteCode(code:String){writableDatabase.beginTransaction();try{writableDatabase.execSQL("DELETE FROM codes WHERE code=?",arrayOf(code));writableDatabase.execSQL("DELETE FROM records WHERE code=?",arrayOf(code));writableDatabase.execSQL("DELETE FROM daily_observations WHERE code=?",arrayOf(code));writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}
    fun addHistory(records:Map<String,QueryRecord>){val db=writableDatabase;db.beginTransaction();try{val stamp=System.currentTimeMillis();records.values.filter{it.status==AttemptStatus.SUCCESS||it.status==AttemptStatus.NOT_FOUND}.forEach{r->db.execSQL("INSERT INTO history(completed_at,json) VALUES(?,?)",arrayOf(stamp,recordToJson(r).toString()))};db.execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY completed_at DESC LIMIT 3000)");db.setTransactionSuccessful()}finally{db.endTransaction()}}
    fun loadHistory(limit:Int=100):List<HistoryRecord>{val out=mutableListOf<HistoryRecord>();readableDatabase.rawQuery("SELECT completed_at,json FROM history ORDER BY completed_at DESC LIMIT ?",arrayOf(limit.toString())).use{c->while(c.moveToNext())runCatching{out.add(HistoryRecord(c.getLong(0),jsonToRecord(JSONObject(c.getString(1)))))} };return out}
    fun loadHistoryForCode(code:String,limit:Int=200):List<HistoryRecord>{val target=canonicalDeviceCode(code); val out=mutableListOf<HistoryRecord>(); readableDatabase.rawQuery("SELECT completed_at,json FROM history ORDER BY completed_at DESC LIMIT 3000",null).use{c->while(c.moveToNext()){runCatching{val item=HistoryRecord(c.getLong(0),jsonToRecord(JSONObject(c.getString(1)))); if(canonicalDeviceCode(item.record.code)==target && out.size<limit) out.add(item)}}}; return out}
    fun clearHistory()=writableDatabase.delete("history",null,null)
    fun addSms(sender:String,body:String,receivedAt:Long):Long{val db=writableDatabase;val id=db.insert("sms_inbox",null,android.content.ContentValues().apply{put("sender",sender);put("body",body);put("received_at",receivedAt)});db.execSQL("DELETE FROM sms_inbox WHERE id NOT IN (SELECT id FROM sms_inbox ORDER BY id DESC LIMIT 500)");return id}
    fun smsAfter(id:Long):List<SmsInbox.ReceivedSms>{val out=mutableListOf<SmsInbox.ReceivedSms>();readableDatabase.rawQuery("SELECT id,sender,body,received_at FROM sms_inbox WHERE id>? ORDER BY id",arrayOf(id.toString())).use{c->while(c.moveToNext())out.add(SmsInbox.ReceivedSms(c.getString(1),c.getString(2),c.getLong(3),c.getLong(0)))};return out}
    fun allSms():List<SmsInbox.ReceivedSms>{val out=mutableListOf<SmsInbox.ReceivedSms>();readableDatabase.rawQuery("SELECT id,sender,body,received_at FROM sms_inbox ORDER BY id DESC",null).use{c->while(c.moveToNext())out.add(SmsInbox.ReceivedSms(c.getString(1),c.getString(2),c.getLong(3),c.getLong(0)))};return out}
    fun latestSmsId():Long=readableDatabase.rawQuery("SELECT COALESCE(MAX(id),0) FROM sms_inbox",null).use{if(it.moveToFirst())it.getLong(0) else 0L}
    fun clearSms()=writableDatabase.delete("sms_inbox",null,null)
    fun recordSmsQuery(operationId:String,code:String,destination:String,sentAt:Long,attempt:Int):Long = writableDatabase.insert("sms_query_attempts",null,ContentValues().apply{put("operation_id",operationId);put("code",canonicalDeviceCode(code));put("destination",destination);put("sent_at",sentAt);put("attempt",attempt)})
    data class SmsQueryAttempt(val id:Long,val operationId:String,val code:String,val destination:String,val sentAt:Long,val attempt:Int)
    fun smsQueryAttemptsForCodes(codes:List<String>, since:Long=0L):List<SmsQueryAttempt>{
        if(codes.isEmpty()) return emptyList()
        val placeholders=codes.joinToString(","){"?"}; val args=(codes.map(::canonicalDeviceCode)+listOf(since.toString())).toTypedArray(); val out=mutableListOf<SmsQueryAttempt>()
        readableDatabase.rawQuery("SELECT id,operation_id,code,destination,sent_at,attempt FROM sms_query_attempts WHERE code IN ($placeholders) AND sent_at>=? ORDER BY sent_at",args).use{c->while(c.moveToNext())out.add(SmsQueryAttempt(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getInt(5)))}
        return out
    }
    fun pruneSmsQueryAttempts(keepDays:Int=14){val cutoff=System.currentTimeMillis()-keepDays.coerceIn(1,90)*24L*60L*60L*1000L;writableDatabase.delete("sms_query_attempts","sent_at<?",arrayOf(cutoff.toString()))}
    fun clearSmsRecoveryData(){writableDatabase.beginTransaction();try{writableDatabase.delete("sms_query_attempts",null,null);writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}
    fun smsCount()=count("sms_inbox",null)
    fun clearAllData(){writableDatabase.beginTransaction();try{listOf("codes","records","saved_lists","history","daily_observations","sms_inbox","sms_query_attempts").forEach{writableDatabase.delete(it,null,null)};writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}
    fun checkpointForBackup(){ runCatching { writableDatabase.execSQL("PRAGMA wal_checkpoint(TRUNCATE)") } }
    fun databaseFile(): java.io.File = context.getDatabasePath(actualDatabaseName)
    fun countCodes()=count("codes","archived=0");fun countArchived()=count("codes","archived=1");fun countRecords()=count("records",null);fun countHistory()=count("history",null)
    fun getSetting(key:String):String?=readableDatabase.query("settings",arrayOf("value"),"key=?",arrayOf(key),null,null,null).use{if(it.moveToFirst())it.getString(0)else null}
    fun setSetting(key:String,value:String?){if(value==null)writableDatabase.delete("settings","key=?",arrayOf(key))else writableDatabase.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",arrayOf(key,value))}
    fun databaseCodes(search:String="",includeArchived:Boolean=true):List<DatabaseCode>{val out=mutableListOf<DatabaseCode>();val where=StringBuilder("1=1");val args=mutableListOf<String>();if(!includeArchived)where.append(" AND archived=0");if(search.isNotBlank()){where.append(" AND code LIKE ?");args.add("%${search.trim()}%")} ;readableDatabase.rawQuery("SELECT code,type,archived,updated_at FROM codes WHERE $where ORDER BY code",args.toTypedArray()).use{c->while(c.moveToNext())out.add(DatabaseCode(c.getString(0),c.getString(1),c.getInt(2)!=0,c.getLong(3)))};return out}

    fun recordObservation(r:SimRegResult,date:String=LocalDate.now().toString()){
        val canonical = canonicalDeviceCode(r.code)
        writableDatabase.execSQL("INSERT OR REPLACE INTO daily_observations(code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",arrayOf(canonical,date,Ownership.from(canonical).name,r.today,r.mtd,r.active,r.bar48,r.bar96,r.duplicates,r.monthlyTarget,r.receivedAt))
        pruneObservations()
    }
    fun observation(code:String,date:String=LocalDate.now().toString()):DailyObservation?=readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE code=? AND obs_date=?",arrayOf(code,date)).use{if(it.moveToFirst())rowObs(it)else null}
    fun observationsBetween(code:String, start:LocalDate, end:LocalDate):List<DailyObservation>{
        val out=mutableListOf<DailyObservation>()
        if(start.isAfter(end)) return out
        readableDatabase.rawQuery(
            "SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE code=? AND obs_date BETWEEN ? AND ? ORDER BY obs_date",
            arrayOf(canonicalDeviceCode(code),start.toString(),end.toString())
        ).use{c->while(c.moveToNext())out.add(rowObs(c))}
        return out
    }


    /**
     * Device Monitor payment-cycle progress is based only on daily SMS observations
     * inside the live 21st-to-20th payment cycle. Previous-cycle history is never
     * carried into the new cycle, and future-dated observations are ignored.
     */
    fun currentPaymentCycleActivations(code:String, requestedDate:LocalDate=LocalDate.now()):Int {
        val asOf = PaymentRules.currentAwareDate(requestedDate)
        val cycle = PaymentRules.paymentCycleForDate(asOf)
        val start = cycle.first
        val canonical = canonicalDeviceCode(code)
        val total = readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(COALESCE(today,0)),0) FROM daily_observations WHERE code=? AND obs_date BETWEEN ? AND ? AND obs_date<=?",
            arrayOf(canonical, start.toString(), cycle.second.toString(), asOf.toString())
        ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        DevMonitorLogger.payment(
            "device-monitor live cycle code=$canonical cycle=${cycle.first}..${cycle.second} asOf=$asOf total=$total"
        )
        return total
    }

    /**
     * Device Monitor receives only the compact historical bridge: one activation sum per
     * device and reporting month for the 21st through month-end. Company daily rows stay
     * exclusively in CompanyActivationStore.
     */
    fun replaceHistoricalCompanyBridge(rows: List<Triple<String, String, Int>>, sourceReportId: Long, coverageStart: String, coverageEnd: String) {
        if (rows.isEmpty()) return
        writableDatabase.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            rows.forEach { (code, month, total) ->
                writableDatabase.execSQL(
                    "INSERT OR REPLACE INTO device_monitor_historical_activation_bridge(code,report_month,coverage_start,coverage_end,activation_sum,source_report_id,available_at) VALUES(?,?,?,?,?,?,?)",
                    arrayOf(canonicalDeviceCode(code), month, coverageStart, coverageEnd, total, sourceReportId, now)
                )
            }
            writableDatabase.setTransactionSuccessful()
            DevMonitorLogger.db("device-monitor historical bridge saved devices=${rows.size} month=${rows.first().second} reportId=$sourceReportId")
        } finally { writableDatabase.endTransaction() }
    }

    fun saveHistoricalCompanyBridge(bridge: CompanyActivationStore.DeviceHistoricalBridge) {
        replaceHistoricalCompanyBridge(
            rows = listOf(Triple(bridge.deviceId, bridge.reportMonth.toString(), bridge.activationSum)),
            sourceReportId = bridge.sourceReportId,
            coverageStart = bridge.coverageStart.toString(),
            coverageEnd = bridge.coverageEnd.toString()
        )
    }

    fun historicalCompanyActivation(code: String, date: LocalDate = LocalDate.now()): Int? {
        val month = YearMonth.from(date).minusMonths(1).toString()
        return readableDatabase.rawQuery(
            "SELECT activation_sum FROM device_monitor_historical_activation_bridge WHERE code=? AND report_month=?",
            arrayOf(canonicalDeviceCode(code), month)
        ).use { if (it.moveToFirst() && !it.isNull(0)) it.getInt(0) else null }
    }

    fun observationsForCode(code:String,limit:Int=60):List<DailyObservation>{val out=mutableListOf<DailyObservation>();readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE code=? ORDER BY obs_date DESC LIMIT ?",arrayOf(code,limit.toString())).use{c->while(c.moveToNext())out.add(rowObs(c))};return out}
    fun observationsForMonth(month:String):List<DailyObservation>{val out=mutableListOf<DailyObservation>();readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE substr(obs_date,1,7)=? ORDER BY obs_date,code",arrayOf(month)).use{c->while(c.moveToNext())out.add(rowObs(c))};return out}
    fun observationsBetween(start:LocalDate,end:LocalDate):List<DailyObservation>{
        val out=mutableListOf<DailyObservation>()
        if(start.isAfter(end)) return out
        readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE obs_date BETWEEN ? AND ? ORDER BY obs_date,code",arrayOf(start.toString(),end.toString())).use{c->while(c.moveToNext())out.add(rowObs(c))}
        return out
    }
    fun dashboard(date:String=LocalDate.now().toString()):DashboardSummary{
        val month=date.substring(0,7); val obs=observationsForMonth(month); val latest=obs.filter{it.date==date};
        val flags=mutableListOf<DeviceFlag>(); val day=LocalDate.parse(date).dayOfMonth
        latest.forEach{ o ->
            val prev=previousObservation(o.code,o.date); val recent=observationsForCode(o.code,14)
            if(o.ownership==Ownership.COMPANY){
                val first=readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE code=? AND obs_date=?",arrayOf(o.code,month+"-01")).use{if(it.moveToFirst())rowObs(it)else null}
                if(first?.today==0 && (o.mtd ?: 0)==0) flags.add(DeviceFlag(o.code,o.ownership,"HIGH","Company device recorded 0 sales on day 1 and has still recorded no MTD sale; flag remains until the first sale.",date))
                // Once the day-15 <10 threshold is reached, keep the flag active for the rest of the month until MTD reaches 10+.
                val underTenAfterDay15 = readableDatabase.rawQuery("SELECT COUNT(*) FROM daily_observations WHERE code=? AND substr(obs_date,1,7)=? AND CAST(substr(obs_date,9,2) AS INTEGER)>=15 AND COALESCE(mtd,0)<10",arrayOf(o.code,month)).use{if(it.moveToFirst())it.getInt(0)>0 else false}
                if(underTenAfterDay15 && (o.mtd ?: 0)<10) flags.add(DeviceFlag(o.code,o.ownership,"HIGH","Company device crossed the day-15 checkpoint below 10 total SIM sales (current MTD ${o.mtd ?: 0}). Flag remains until MTD reaches 10 or more.",date))
            }
            // Flag only after four recorded consecutive zero-sales days. Missing observation days do not count as zero.
            val lastFour=observationsForCode(o.code,4).sortedBy{it.date}
            if(lastFour.size==4 && lastFour.all{(it.today ?: 0)==0} && lastFour.zipWithNext().all{(a,b)->LocalDate.parse(a.date).plusDays(1)==LocalDate.parse(b.date)}) {
                flags.add(DeviceFlag(o.code,o.ownership,"HIGH","No SIM sales for 4 consecutive recorded days.",date))
            }
            if(prev?.bar48!=null && o.bar48!=null && o.bar48>prev.bar48) flags.add(DeviceFlag(o.code,o.ownership,"MEDIUM","Conversion Lost: Bar 48 increased from ${prev.bar48} to ${o.bar48} (+${o.bar48-prev.bar48}).",date))
            val ordered=recent.sortedBy{it.date}
            val conversionEvents=ordered.zipWithNext().count{(a,b)->a.bar48!=null && b.bar48!=null && b.bar48>a.bar48}
            val mid=ordered.size/2
            if(ordered.size>=6){
                val early=ordered.take(mid).zipWithNext().count{(a,b)->a.bar48!=null && b.bar48!=null && b.bar48>a.bar48}
                val late=ordered.drop(mid).zipWithNext().count{(a,b)->a.bar48!=null && b.bar48!=null && b.bar48>a.bar48}
                if(late>early && late>0) flags.add(DeviceFlag(o.code,o.ownership,"HIGH","Increasing Conversion Lost: $late recent Conversion Lost events versus $early in the earlier comparison period.",date))
            }
            val prior=recent.drop(1).mapNotNull{it.today}.take(7)
            if(prior.size>=3){val avg=prior.average();val today=o.today?:0;if(avg>=4 && (today<=avg*0.5 || today>=avg*1.5+2)) flags.add(DeviceFlag(o.code,o.ownership,"MEDIUM","Marked deviation from its recent pattern: today $today vs 7-day average ${"%.1f".format(avg)}.",date))}
        }
        val severityRank=mapOf("HIGH" to 0,"MEDIUM" to 1,"LOW" to 2)
        val dedup=flags.distinctBy{it.code+"|"+it.reason}.sortedWith(compareBy<DeviceFlag>{if(it.ownership==Ownership.COMPANY)0 else 1}.thenBy{severityRank[it.severity]?:9}.thenBy{it.code})
        fun sum(f:(DailyObservation)->Int?)=latest.sumOf{f(it)?:0};
        return DashboardSummary(date,month,latest.size,sum{it.today},sum{it.mtd},sum{it.active},sum{it.bar48},sum{it.bar96},latest.filter{it.ownership==Ownership.COMPANY}.sumOf{it.today?:0},latest.filter{it.ownership==Ownership.COMPANY}.sumOf{it.mtd?:0},latest.filter{it.ownership==Ownership.PARTNER}.sumOf{it.today?:0},latest.filter{it.ownership==Ownership.PARTNER}.sumOf{it.mtd?:0},dedup)
    }
    private fun previousObservation(code:String,date:String):DailyObservation?=readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE code=? AND obs_date<? ORDER BY obs_date DESC LIMIT 1",arrayOf(code,date)).use{if(it.moveToFirst())rowObs(it)else null}
    private fun rowObs(c:android.database.Cursor)=DailyObservation(c.getString(0),c.getString(1),runCatching{Ownership.valueOf(c.getString(2))}.getOrDefault(Ownership.UNKNOWN),opt(c,3),opt(c,4),opt(c,5),opt(c,6),opt(c,7),opt(c,8),opt(c,9),c.getString(10))
    private fun opt(c:android.database.Cursor,i:Int):Int?=if(c.isNull(i))null else c.getInt(i)
    private fun pruneObservations(){val months=(getSetting(SETTING_RETENTION_MONTHS)?.toIntOrNull()?:60).coerceIn(1,60);val cutoff=LocalDate.now().minusMonths(months.toLong()).toString();writableDatabase.delete("daily_observations","obs_date<?",arrayOf(cutoff))}
    fun setRetentionMonths(months:Int){setSetting(SETTING_RETENTION_MONTHS,months.coerceIn(1,60).toString());pruneObservations()}

    fun saveAgent(agent: Agent): Long {
        val now=System.currentTimeMillis()
        if(agent.id==0L){
            val v=ContentValues().apply{put("name",agent.name.trim());put("address",agent.address.trim());put("latitude",agent.latitude);put("longitude",agent.longitude);put("created_at",now);put("updated_at",now)}
            return writableDatabase.insert("agents",null,v)
        }
        val v=ContentValues().apply{put("name",agent.name.trim());put("address",agent.address.trim());put("latitude",agent.latitude);put("longitude",agent.longitude);put("updated_at",now)}
        writableDatabase.update("agents",v,"id=?",arrayOf(agent.id.toString())); return agent.id
    }
    fun deleteAgent(id:Long){ writableDatabase.delete("agents","id=?",arrayOf(id.toString())) }
    fun agents(search:String=""):List<Agent>{
        val out=mutableListOf<Agent>(); val where=if(search.isBlank())"1=1" else "name LIKE ? OR address LIKE ?"; val args=if(search.isBlank()) emptyArray() else arrayOf("%$search%","%$search%")
        readableDatabase.rawQuery("SELECT id,name,address,latitude,longitude,created_at,updated_at FROM agents WHERE $where ORDER BY name COLLATE NOCASE",args).use{c->while(c.moveToNext())out.add(Agent(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getDouble(3),if(c.isNull(4))null else c.getDouble(4),c.getLong(5),c.getLong(6)))}; return out
    }
    fun addAgentPhone(agentId:Long,phone:String,label:String=""){ if(phone.isBlank())return; writableDatabase.execSQL("INSERT INTO agent_phones(agent_id,phone,label) VALUES(?,?,?)",arrayOf(agentId,phone,label)) }
    fun phonesForAgent(agentId:Long):List<AgentPhone>{val out=mutableListOf<AgentPhone>();readableDatabase.rawQuery("SELECT id,agent_id,phone,label FROM agent_phones WHERE agent_id=? ORDER BY id",arrayOf(agentId.toString())).use{c->while(c.moveToNext())out.add(AgentPhone(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3)))};return out}
    fun deleteAgentPhone(id:Long)=writableDatabase.delete("agent_phones","id=?",arrayOf(id.toString()))
    fun linkDeviceToAgent(agentId:Long,code:String){writableDatabase.execSQL("INSERT OR IGNORE INTO agent_devices(agent_id,code) VALUES(?,?)",arrayOf(agentId,canonicalDeviceCode(code)))}
    fun unlinkDeviceFromAgent(agentId:Long,code:String){writableDatabase.delete("agent_devices","agent_id=? AND code=?",arrayOf(agentId.toString(),canonicalDeviceCode(code)))}
    fun agentForCode(code:String):Long?=readableDatabase.rawQuery("SELECT agent_id FROM agent_devices WHERE code=? LIMIT 1",arrayOf(canonicalDeviceCode(code))).use{if(it.moveToFirst())it.getLong(0)else null}


    fun operationalTasks(includeCompleted:Boolean=true):List<OperationalTask>{
        val out=mutableListOf<OperationalTask>(); val where=if(includeCompleted) "1=1" else "completed=0"
        readableDatabase.rawQuery("SELECT id,title,details,due_date,priority,link_type,link_value,completed,created_at,updated_at FROM operational_tasks WHERE $where ORDER BY completed ASC, CASE WHEN due_date IS NULL OR due_date='' THEN 1 ELSE 0 END, due_date ASC, updated_at DESC",null).use{c->while(c.moveToNext()) out.add(OperationalTask(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),if(c.isNull(5))null else c.getString(5),if(c.isNull(6))null else c.getString(6),c.getInt(7)!=0,c.getLong(8),c.getLong(9)))}
        return out
    }
    fun saveOperationalTask(task:OperationalTask):Long{
        val now=System.currentTimeMillis(); val v=ContentValues().apply{put("title",task.title.trim());put("details",task.details.trim());put("due_date",task.dueDate?.trim().orEmpty().ifBlank{null});put("priority",task.priority);put("link_type",task.linkType);put("link_value",task.linkValue);put("completed",if(task.completed)1 else 0);put("created_at",if(task.id==0L)now else task.createdAt);put("updated_at",now)}
        return if(task.id==0L) writableDatabase.insert("operational_tasks",null,v) else {writableDatabase.update("operational_tasks",v,"id=?",arrayOf(task.id.toString()));task.id}
    }
    fun setOperationalTaskCompleted(id:Long,completed:Boolean){writableDatabase.execSQL("UPDATE operational_tasks SET completed=?,updated_at=? WHERE id=?",arrayOf(if(completed)1 else 0,System.currentTimeMillis(),id))}
    fun deleteOperationalTask(id:Long){writableDatabase.delete("operational_tasks","id=?",arrayOf(id.toString()))}

    fun operationalNotes(includePinnedFirst:Boolean=true):List<OperationalNote>{
        val order = if(includePinnedFirst) "pinned DESC, updated_at DESC" else "updated_at DESC"
        val out=mutableListOf<OperationalNote>()
        readableDatabase.rawQuery("SELECT id,title,body,link_type,link_value,pinned,created_at,updated_at FROM operational_notes ORDER BY $order",null).use{c->
            while(c.moveToNext()) out.add(OperationalNote(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),if(c.isNull(4))null else c.getString(4),c.getInt(5)!=0,c.getLong(6),c.getLong(7)))
        }
        return out
    }
    fun saveOperationalNote(note:OperationalNote):Long{
        val now=System.currentTimeMillis()
        val v=ContentValues().apply{
            put("title",note.title.trim())
            put("body",note.body.trim())
            put("link_type",note.linkType)
            put("link_value",note.linkValue)
            put("pinned",if(note.pinned)1 else 0)
            put("created_at",if(note.id==0L)now else note.createdAt)
            put("updated_at",now)
        }
        return if(note.id==0L) writableDatabase.insert("operational_notes",null,v) else { writableDatabase.update("operational_notes",v,"id=?",arrayOf(note.id.toString())); note.id }
    }
    fun setOperationalNotePinned(id:Long,pinned:Boolean){writableDatabase.execSQL("UPDATE operational_notes SET pinned=?,updated_at=? WHERE id=?",arrayOf(if(pinned)1 else 0,System.currentTimeMillis(),id))}
    fun deleteOperationalNote(id:Long){writableDatabase.delete("operational_notes","id=?",arrayOf(id.toString()))}

    fun paymentMode():String=getSetting("payment_calendar_mode") ?: "CIRCLE_21_20"
    fun setPaymentMode(mode:String)=setSetting("payment_calendar_mode",mode)
    fun paymentCycleFor(date:LocalDate=LocalDate.now(),mode:String=paymentMode()):PaymentCycle{
        val normal=mode=="CALENDAR"
        val start=if(normal)date.withDayOfMonth(1) else if(date.dayOfMonth>=21)date.withDayOfMonth(21) else date.minusMonths(1).withDayOfMonth(21)
        val end=if(normal)date.withDayOfMonth(date.lengthOfMonth()) else start.plusMonths(1).withDayOfMonth(20)
        val label=if(normal)HumanDateParser.toDisplay(start).replace(Regex("\\s+\\d{1,2}$"), "") else HumanDateParser.toDisplay(end).replace(Regex("\\s+\\d{1,2}$"), "")
        val db=writableDatabase; db.execSQL("INSERT OR IGNORE INTO payment_cycles(start_date,end_date,label,mode,closed) VALUES(?,?,?,?,0)",arrayOf(start.toString(),end.toString(),label,mode));
        val id=db.rawQuery("SELECT id FROM payment_cycles WHERE start_date=? AND end_date=? AND mode=?",arrayOf(start.toString(),end.toString(),mode)).use{if(it.moveToFirst())it.getLong(0)else 0L}
        return PaymentCycle(id,start.toString(),end.toString(),label,mode,false)
    }
    fun capturePaymentSnapshot(date:LocalDate=LocalDate.now(),mode:String=paymentMode()):Int{
        val cycle=paymentCycleFor(date,mode); val latest=readableDatabase.rawQuery("SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations WHERE obs_date<=? ORDER BY code,obs_date DESC",arrayOf(date.toString()));
        val seen=HashSet<String>(); var count=0; latest.use{c->while(c.moveToNext()){val code=c.getString(0);if(!seen.add(code))continue; val obs=rowObs(c); val agent=agentForCode(code); writableDatabase.execSQL("INSERT OR REPLACE INTO payment_records(cycle_id,code,agent_id,ownership,mtd,today,active,bar48,bar96,snapshot_date,amount,paid,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",arrayOf(cycle.id,code,agent,obs.ownership.name,obs.mtd,obs.today,obs.active,obs.bar48,obs.bar96,date.toString(),null,0,null));count++}}; writableDatabase.execSQL("UPDATE payment_cycles SET closed=1 WHERE id=?",arrayOf(cycle.id)); return count
    }
    fun paymentCycles():List<PaymentCycle>{val out=mutableListOf<PaymentCycle>();readableDatabase.rawQuery("SELECT id,start_date,end_date,label,mode,closed FROM payment_cycles ORDER BY start_date DESC",null).use{c->while(c.moveToNext())out.add(PaymentCycle(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getInt(5)!=0))};return out}
    fun paymentRecords(cycleId:Long):List<PaymentRecord>{val out=mutableListOf<PaymentRecord>();readableDatabase.rawQuery("SELECT id,cycle_id,code,agent_id,ownership,mtd,today,active,bar48,bar96,snapshot_date,amount,paid,notes FROM payment_records WHERE cycle_id=? ORDER BY ownership,code",arrayOf(cycleId.toString())).use{c->while(c.moveToNext())out.add(PaymentRecord(c.getLong(0),c.getLong(1),c.getString(2),if(c.isNull(3))null else c.getLong(3),runCatching{Ownership.valueOf(c.getString(4))}.getOrDefault(Ownership.UNKNOWN),if(c.isNull(5))null else c.getInt(5),if(c.isNull(6))null else c.getInt(6),if(c.isNull(7))null else c.getInt(7),if(c.isNull(8))null else c.getInt(8),if(c.isNull(9))null else c.getInt(9),c.getString(10),if(c.isNull(11))null else c.getDouble(11),c.getInt(12)!=0,c.getString(13)))};return out}
    fun updatePayment(id:Long,amount:Double?,paid:Boolean,notes:String?){writableDatabase.execSQL("UPDATE payment_records SET amount=?,paid=?,notes=? WHERE id=?",arrayOf(amount,if(paid)1 else 0,notes,id))}

    private fun count(table:String,where:String?):Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM $table${if(where!=null)" WHERE $where" else ""}",null).use{if(it.moveToFirst())it.getInt(0)else 0}
    private fun resultToJson(r:SimRegResult)=JSONObject().put("code",r.code).put("type",r.type.name).put("receivedAt",r.receivedAt).put("today",r.today).put("mtd",r.mtd).put("active",r.active).put("bar48",r.bar48).put("bar96",r.bar96).put("duplicates",r.duplicates).put("monthlyTarget",r.monthlyTarget).put("status",r.status.name).put("raw",r.raw)
    private fun jsonToResult(o:JSONObject)=SimRegResult(o.optString("code"),runCatching{QueryType.valueOf(o.optString("type"))}.getOrDefault(QueryType.UNKNOWN),o.optString("receivedAt"),optInt(o,"today"),optInt(o,"mtd"),optInt(o,"active"),optInt(o,"bar48"),optInt(o,"bar96"),optInt(o,"duplicates"),optInt(o,"monthlyTarget"),runCatching{AttemptStatus.valueOf(o.optString("status"))}.getOrDefault(AttemptStatus.UNRECOGNIZED),o.optString("raw"))
    private fun recordToJson(r:QueryRecord)=JSONObject().put("code",r.code).put("type",r.type.name).put("attempt",r.attempt).put("repetitionsSent",r.repetitionsSent).put("responseCount",r.responseCount).put("status",r.status.name).put("error",r.error).put("firstAttemptStatus",r.firstAttemptStatus?.name).put("completedAt",r.completedAt).put("result",r.result?.let{resultToJson(it)})
    private fun jsonToRecord(o:JSONObject)=QueryRecord(o.optString("code"),runCatching{QueryType.valueOf(o.optString("type"))}.getOrDefault(QueryType.UNKNOWN),o.optInt("attempt",1),o.optInt("repetitionsSent",0),o.optInt("responseCount",0),runCatching{AttemptStatus.valueOf(o.optString("status"))}.getOrDefault(AttemptStatus.QUEUED),o.optJSONObject("result")?.let{jsonToResult(it)},o.optString("error").takeIf{it.isNotBlank()&&it!="null"},o.optString("firstAttemptStatus").takeIf{it.isNotBlank()}?.let{runCatching{AttemptStatus.valueOf(it)}.getOrNull()},o.optLong("completedAt",System.currentTimeMillis()))
    private fun optInt(o:JSONObject,key:String):Int?=if(o.isNull(key))null else o.optInt(key)
    companion object{private const val DB_NAME="simreg_monitor.db";private const val DB_VERSION=13;const val SETTING_RETENTION_MONTHS="retention_months"}
}
data class DatabaseCode(val code:String,val type:String,val archived:Boolean,val updatedAt:Long)
