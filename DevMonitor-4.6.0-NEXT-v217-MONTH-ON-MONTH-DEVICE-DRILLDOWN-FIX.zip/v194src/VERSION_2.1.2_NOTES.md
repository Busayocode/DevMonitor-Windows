# FieldPulse v2.1.2

- Removed Glo/Globacom branding from user-facing identity and About page.
- Kept GLO device-code handling because those codes are part of the SMS protocol.
- Main action renamed to **Start Sending SMS**.
- Added the three supplied Busayo portrait photos to the app resources; the first is now the primary guide image.
- Updated launcher icon to a clean green SMS/monitoring pulse mark.
- Kept the existing green theme, guided-tour-first behavior, Day-7 zero-sales rule, flags, database, payment cycle, and SMS short-code conversion.
- Version: 2.1.2 (version code 24).
