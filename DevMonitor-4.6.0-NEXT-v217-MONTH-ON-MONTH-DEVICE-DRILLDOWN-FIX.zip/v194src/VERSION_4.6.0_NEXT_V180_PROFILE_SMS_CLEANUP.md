# DevMonitor 4.6.0-NEXT v180 — Profile + SMS CHECKER Cleanup

**Status: IMPLEMENTED**

## Changes

1. **SMS CHECKER guided tour removed completely**
   - No automatic SMS CHECKER tour.
   - No drawer/Device Monitor tour launch.
   - No Settings "Take the Guided Tour Again" entry for SMS CHECKER.
   - SMS operation and protocol are unchanged.

2. **Dashboard tour target correction**
   - LOAD REPORT and EARNING PROGRESS remain mapped to their real dashboard action cards.
   - Tour scrolling now keeps that action-card row visible instead of scrolling to unrelated Company/Partner content.

3. **Profile Builder**
   - BUILD PROFILE dashboard card is visible only when no profile exists.
   - Manage Current Profile is available once profiles exist, keeping Delete Profile discoverable.
   - Profile verification warning added before save.
   - Agent profiles use exactly one selected device.

4. **User-facing terminology**
   - Company Skeleton is an internal engineering term only.
   - User-facing language uses Company Directory/company data.

5. **Report / Device Monitor table presentation**
   - My Devices is the fresh-session default.
   - Broader data is expanded by explicit user action.
   - Full indexed data remains available for general search.

## Protected

Payment logic, payment progression, payment-cycle rules, HQ report authority, two-month HQ architecture, SMS protocol, profile isolation and explicit-refresh performance rules are unchanged.
