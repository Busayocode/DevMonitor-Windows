# DevMonitor 4.3.5.49 — Device Month-on-Month Expansion

Based on the known-good 4.3.5.48 fork.

- Adds an on-demand **View Month-on-Month by Device** button for Cluster Managers (the lowest displayed staff hierarchy) and Partners.
- Device calculations are performed only after the button is invoked.
- Each current device is compared against its own historical previous-month activation total.
- Existing Regional Manager/Cluster Head hierarchy drill-down remains unchanged.
- Territory remains in the database and underlying data model but is not exposed as a Month-on-Month drill-down view.
- No database migration or deletion was made.
- Device Monitor and other existing functionality are retained.
