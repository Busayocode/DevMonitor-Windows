# DevMonitor 4.5.11 — Payment Engine & Rolling Three-Month Report Database

## Payment architecture

- Replaced the previous mixed `PaymentCycleResolver` path with `PaymentEngine`.
- Loaded Report progression and Device Monitor progression are separate calculators.
- Loaded Report calculator reads only the continuous normalized Loaded Report database and reconstructs the 21st→20th cycle from available daily report data.
- Device Monitor calculator uses SMS `Active` as the live cumulative calendar-month source. It may consult Loaded Reports only to establish the historical calendar-month baseline required to convert cumulative Active into the live 21st→20th cycle.
- `MTD` is never used as the Device Monitor payment source.
- Device Monitor estimates do not apply Loaded Report Sunday bonuses.
- If the required Active baseline is unavailable, the Device Monitor calculator reports insufficient historical data rather than substituting an unrelated value.
- Device Monitor and Loaded Report payment cards remain independently visible in the Payments flow.

## Rolling report database

- `CompanyActivationStore.activation_days` remains the continuous normalized date-addressable database.
- Imports are now accepted out of chronological order. An August report imported after September fills August dates instead of being rejected because September already exists.
- For overlapping dates, a report with a later coverage end is protected from rollback by an older, less-complete report.
- Retention is current month plus the two preceding calendar months (three calendar months total).
- The table viewer defaults to the current calendar month while historical dates remain available to the database and payment engine.
- Late historical imports no longer replace the current-month viewer.
- Latest hierarchy metadata follows report coverage chronology rather than raw import ID order.

## Version

- versionCode: 145
- versionName: 4.5.11
