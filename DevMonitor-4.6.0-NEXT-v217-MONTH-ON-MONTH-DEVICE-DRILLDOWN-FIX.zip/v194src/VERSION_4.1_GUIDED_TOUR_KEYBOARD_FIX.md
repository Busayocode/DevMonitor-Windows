# FieldPulse 4.1 — Guided Tour Keyboard Fix

## Fix
During Guided Tour Step 5 (Start sending SMS), the on-screen keyboard could remain visible after the user added a code list. This could cover the highlighted Start Sending SMS control and make the next action unclear to a first-time user.

## Change
When the tour advances to stage 3 / Step 5, FieldPulse now:
- clears focus from the code-entry field;
- explicitly hides the software keyboard;
- then leaves the Start Sending SMS control available for the user to tap.

No SMS workflow, AdMob configuration, Xiaomi Billing implementation, or other tour stages were changed.
