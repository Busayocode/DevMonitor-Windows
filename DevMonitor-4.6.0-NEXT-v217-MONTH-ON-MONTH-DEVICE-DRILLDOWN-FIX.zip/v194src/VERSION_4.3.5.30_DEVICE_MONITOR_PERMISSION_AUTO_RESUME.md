# Version 4.3.5.30 — Device Monitor Permission Auto-Resume

When a user starts a Device Monitor batch before SMS permissions are granted, preserve that user-initiated batch while the SMS disclosure and Android permission dialogs are shown. Once SEND_SMS and RECEIVE_SMS are granted and the disclosure is completed, automatically resume the exact pending batch instead of returning to the idle Device Monitor screen.

No SMS query, parser, result, or monitoring behavior was otherwise changed.
