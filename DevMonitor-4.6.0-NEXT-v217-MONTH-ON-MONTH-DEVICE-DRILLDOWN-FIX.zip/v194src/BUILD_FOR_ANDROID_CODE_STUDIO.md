# Building SIMReg Monitor v0.7 in Android Code Studio

1. Extract `SimRegMonitor-v0.7-mobile.zip`.
2. In Android Code Studio choose **Open existing project** and select the extracted `SimRegMonitor-v0.7` folder.
3. Let Gradle sync finish. Do not add `local.properties` or a Windows/PC SDK path.
4. Use JDK 17 if Android Code Studio asks for a Gradle JDK.
5. The project is pinned to AGP 8.6.1 + Gradle 8.7 + Kotlin 2.0.21.
6. Build the debug APK and install it on the phone.

The project intentionally does not include Windows batch files or Apache POI. XLSX handling is implemented inside the app with standard Android ZIP/XML APIs.


## v2.0.1 update
- Restored visible SIM selector for dual/multi-SIM phones.
- SMS is sent through Android SmsManager SMS APIs only; no RCS fallback is used.
- Optional sent/delivered SMS delivery reports are monitored when the carrier/device provides them. Negative delivery reports trigger up to two immediate retries before the next query, with a visible warning while the batch continues.
- Company devices crossing the day-15 MTD <10 checkpoint remain flagged until MTD reaches 10+.
- No-sales flag threshold increased from 2 to 4 consecutive recorded days.
