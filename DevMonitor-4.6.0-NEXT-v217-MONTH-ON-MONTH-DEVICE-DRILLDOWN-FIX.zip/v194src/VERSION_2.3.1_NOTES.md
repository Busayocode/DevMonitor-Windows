# FieldPulse 2.3.1

- Added visible Go Premium entry points to About and Feedback.
- Monthly and yearly Premium products are treated as recurring subscriptions.
- Annual plan now queries Google Play Billing as SUBS rather than a one-time INAPP purchase.
- Premium entitlement is refreshed from active store purchases so stale local access is not permanent after expiry/cancellation.
- Feedback dialog now submits to a configurable Google Apps Script endpoint, designed to write directly to Google Sheets.
- Feedback includes type, message, optional contact, app version, device model, Android version and Premium status.
- Interstitial frequency is 1 ad every 5 qualifying events.
- Rewarded export credit is 3 exports per completed rewarded ad after the first 10 free exports.
