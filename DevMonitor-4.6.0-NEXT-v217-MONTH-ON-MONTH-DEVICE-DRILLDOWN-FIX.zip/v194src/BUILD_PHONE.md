## Build target: DevMonitor 4.5.14 / versionCode 148

# Phone build — DevMonitor 4.5.13

This package retains the established Android Code Studio / ARM build helper.

```sh
sh build-phone.sh assembleDebug --console=plain
```

For release:

```sh
sh build-phone.sh assembleRelease --console=plain
```

`build-phone.sh` automatically locates the ARM-compatible AAPT2 and preserves
the project's single-worker settings for phone stability.
