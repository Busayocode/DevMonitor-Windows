# DevMonitor PC v324 — Mobile-inspired modern interface

## Intent
Bring the Windows app closer to the mobile DevMonitor visual language so the PC edition feels like the same product, not a separate tool.

## Visual changes
- Deep navy navigation rail with high-contrast labels and a blue selected state.
- Cool, light blue-grey workspace background with cleaner white surfaces.
- Unified blue accent, calmer shadows, more consistent rounded controls, and improved spacing.
- Clearer DevMonitor brand header and a less platform-specific window title.
- Slightly roomier default window and workspace to improve desktop scanning.

## Functional safety
This is a visual-only pass on the existing v323 source. It does not intentionally change navigation routes, data storage, payment/MOM calculations, report imports, sync protocol, or Firestore paths.

## Validation
ZIP structure is retained and archive integrity should be checked after packaging. A Windows/.NET build and visual runtime review are still required; this source-only environment does not establish those results.
