# DevMonitor PC v322 — Automatic Sync Bridge

Changes from PC v321:
- Starts the local LAN sync bridge automatically when the Windows app opens.
- Reuses the existing pairing key.
- Removes the per-first-exchange Windows approval prompt; encrypted payload handling remains in place.
- Leaves manual start/stop controls available for recovery.
- Does not change sync payload scope or business/payment logic.

Pairing still needs to be established once on Android using the PC address/key or QR code. Authentication is intentionally not added in this change and can be designed separately.

Validation: source edits and ZIP integrity only; Windows compilation and device-to-device transfer have not been verified here.
