# DevMonitor Windows v327 — Offline Backup and Compact UI

- Added user-initiated offline database backup to a user-selected `.db` file.
- Added restore from a selected backup file, including SQLite integrity and DevMonitor schema validation.
- Restore creates a timestamped safety backup before replacing live database contents.
- Applied a 70% workspace layout scale to the Windows UI.
- Preserved existing payment calculations, report import flows, and sync pathways.

Validation status: source ZIP integrity checked. Windows compilation and interactive restore testing are not confirmed in this environment.
