# DevMonitor Android → Windows parity matrix (source review v217 / v204)

The bridge is now a working source-level implementation, but **the Windows app is not yet at full Android feature parity**. This matrix prevents the current release from being misrepresented as complete.

## Present in the Windows source
- Local dashboard and profile/company summary
- Device Monitor and payment estimate surfaces using the existing Windows `PaymentRules.cs`
- HQ report import and two-month snapshot database
- Month-on-Month comparison and CSV export
- My Devices list
- SMS Checker stored results/history surface (Windows does not send SMS)
- Tasks/follow-ups, notes, notifications, timeline, trends, Action Centre and export screens in the current Windows shell
- `.dmdata` import/export fallback
- New v1 phone/PC bridge for My Devices codes, operational tasks, notes and SMS inbox history

## Still requires parity implementation and tests
- Full phone query-result/history interchange and device-monitor daily observation reconciliation
- Android agents/partners and associated phone/device relationships
- Notifications/inbox and settings/profile preference synchronization
- Saved lists, SIMReg code registry, archived codes, query records, SMS attempt/recovery state
- Company activation database / report history views and full report/export parity
- Full visual/workflow parity for all Android screens, role-specific flows, guided tours and profile-scoped features
- Deletion tombstones, conflict review UI, sync audit history, resumable batches and background scheduling
- Automated cross-platform golden tests proving payment outputs and cutoff boundaries match Android

## Non-negotiable protections
- Do not sync-replace HQ monthly snapshots through the operational bridge. HQ import remains a separate authoritative replace-all operation per month, with out-of-order month imports handled by the report importer.
- Do not change `PaymentRules.cs` or Android `PaymentRules.kt` formulas/cutoffs as part of transport work.
- Do not implement cellular SMS sending on Windows.
- Treat sync as explicit and user-initiated until retries, tombstones, audit and reconciliation tests are complete.
