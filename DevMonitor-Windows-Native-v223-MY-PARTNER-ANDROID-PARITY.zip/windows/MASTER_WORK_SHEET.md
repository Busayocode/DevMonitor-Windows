## Current update — Windows v221 (2026-10-12)

- Deliverable: DevMonitor-Windows-Native-v221-EARNINGS-FLIER-REACH-MESSAGES-CONNECTION-STATUS.zip
- Scope: earnings flier visual direction, reach-step-specific encouragement copy, and PC–Android connection-status visibility/parity.
- Guardrail: payment calculations and category thresholds remain unchanged; card values must come only from the chosen source.
- Verification: ZIP integrity checked; no claim of a successful platform build.

# DevMonitor Windows Master Work Sheet

## Current package
- Windows native version: **4.6.0.223** (source package; build not yet verified).
- Android handoff baseline: **4.6.0-NEXT versionCode 227**.

## Cross-device earnings-card sharing
- Start on Windows from **Earning Progress → Share an agent card via Android** or **Share Earnings Cards**.
- Select one source for the whole batch: SMS Checker or Loaded Report. Select agent rows; every linked device with values in that source gets a separate PNG.
- Cards show source-only Today, MTD and Active values, the selected source, reporting period, as-of timestamp, and a monitoring-only warning. This PC handoff does not compute a new payment estimate or fill missing values from another source.
- Cards are queued locally as `share_queue` records, included in the existing AES-GCM encrypted sync response, then presented by Android in the native share sheet. Android sends card IDs back as acknowledgements on the next exchange. The PC removes acknowledged queue entries.
- The share-sheet handoff is not proof that WhatsApp or another recipient received a message. User selects recipient and confirms sending.
- Limits: up to 20 cards per batch; transfer uses the existing 15 MB encrypted bridge request limit; Android rejects individual PNG payloads above 2 MB.

## Protected boundaries
- No changes to `PaymentRules.cs` or the Android payment calculation paths.
- HQ snapshots and payment records remain excluded from synchronization.
- Existing five-minute standby reachability policy and bounded retry/backoff behavior are unchanged.

## Verification status
- Source archive and documentation prepared. Android Gradle compilation could not be completed in this environment because the Gradle distribution download requires network access. Windows compilation and paired Android↔PC handoff remain to be verified by GitHub Actions and a real paired-device test.


## Windows v222 connection feedback and navigation contrast (2026-10-13)
- Inactive sidebar navigation now uses higher-contrast white text and a slightly larger font.
- Header refresh still refreshes the current page and now also checks the local bridge health endpoint when the bridge is running. If stopped, it explains the exact Phone Data Exchange action needed to start it.
- A local health response is not represented as proof of a successful Android sync. Payment calculations remain unchanged.


## Windows v223 — My Partner workspace and Android v237 parity pass
- Added a dedicated My Partner navigation page. It searches imported HQ snapshots by partner name/trade code and selecting a row fills the form.
- Partner entries and history tables live in a separate `%LOCALAPPDATA%\DevMonitor\my_partner.db`, scoped to the local profile; no writes to My Devices, SMS Checker observations, HQ snapshots, or payment progression.
- Windows does not send SMS and does not fabricate partner-check outcomes. Phone-side result delivery and native desktop toast notifications remain follow-up verification/work items.
- Payment rules are unchanged.
- Validation: ZIP integrity and XAML XML validation performed; .NET/Windows compilation unavailable in this environment.
