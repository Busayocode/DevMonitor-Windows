# DevMonitor Windows 4.6.0.211 — Sync Bridge Compile Fix

- Added `using System.IO;` to `SyncBridgeServer.cs` for `StreamReader` and `InvalidDataException`.
- Retains the v210 build-hardening and earlier sync changes.
- ZIP integrity can be checked locally; a full .NET build must still be confirmed by GitHub Actions.
