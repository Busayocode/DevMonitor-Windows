using System.IO;
using System.Net.NetworkInformation;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DevMonitor.Windows;

/// <summary>Local LAN endpoint. Only encrypted AES-GCM envelopes are accepted.</summary>
public sealed class SyncBridgeServer : IDisposable
{
    private readonly HttpListener _listener = new();
    private readonly string _token;
    private readonly Func<string,string> _exchange;
    private CancellationTokenSource? _stop;
    public bool IsRunning => _listener.IsListening;
    public int Port { get; }
    public SyncBridgeServer(string token, Func<string,string> exchange, int port=43827)
    {
        if (string.IsNullOrWhiteSpace(token) || token.Length < 16) throw new ArgumentException("Pairing key must contain at least 16 characters.", nameof(token));
        _token=token; _exchange=exchange; Port=port;
        _listener.Prefixes.Add($"http://+:{port}/");
    }
    public void Start(){ if(IsRunning)return; _stop=new CancellationTokenSource(); _listener.Start(); _=Serve(_stop.Token); }
    public void Stop(){try{_stop?.Cancel();_listener.Stop();}catch{} }
    private async Task Serve(CancellationToken ct)
    {
        while(!ct.IsCancellationRequested && _listener.IsListening)
        {
            HttpListenerContext ctx;
            try{ctx=await _listener.GetContextAsync().WaitAsync(ct);}catch{break;}
            _=Task.Run(()=>Handle(ctx),ct);
        }
    }
    private async Task Handle(HttpListenerContext ctx)
    {
        try
        {
            ctx.Response.Headers["Cache-Control"]="no-store";
            ctx.Response.Headers["X-Content-Type-Options"]="nosniff";
            if(ctx.Request.HttpMethod=="GET" && ctx.Request.Url?.AbsolutePath=="/health")
            { await Write(ctx,200,"{\"service\":\"DevMonitor Sync Bridge\",\"protocol\":1,\"encrypted\":true}"); return; }
            if(ctx.Request.HttpMethod!="POST" || ctx.Request.Url?.AbsolutePath!="/sync") { await Write(ctx,404,"{\"error\":\"not_found\"}");return; }
            if(ctx.Request.ContentLength64>15*1024*1024){await Write(ctx,413,"{\"error\":\"too_large\"}");return;}
            using var reader=new StreamReader(ctx.Request.InputStream,ctx.Request.ContentEncoding);
            var envelope=JsonDocument.Parse(await reader.ReadToEndAsync());
            var cipher=Convert.FromBase64String(envelope.RootElement.GetProperty("payload").GetString()??"");
            if(cipher.Length<12+16) throw new InvalidDataException("Invalid encrypted payload.");
            var key=SHA256.HashData(Encoding.UTF8.GetBytes(_token)); var nonce=cipher[..12]; var data=cipher[12..]; var plain=new byte[data.Length-16];
            using(var aes=new AesGcm(key,16)) aes.Decrypt(nonce,data.AsSpan(0,data.Length-16),data.AsSpan(data.Length-16,16),plain);
            var request=Encoding.UTF8.GetString(plain);
            var response=_exchange(request);
            var outNonce=RandomNumberGenerator.GetBytes(12); var outCipher=new byte[response.Length==0?16:Encoding.UTF8.GetByteCount(response)+16]; var outPlain=Encoding.UTF8.GetBytes(response);
            using(var aes=new AesGcm(key,16)) aes.Encrypt(outNonce,outPlain,outCipher.AsSpan(0,outPlain.Length),outCipher.AsSpan(outPlain.Length,16));
            await Write(ctx,200,JsonSerializer.Serialize(new{payload=Convert.ToBase64String(outNonce.Concat(outCipher).ToArray())}));
        }
        catch(Exception ex){try{await Write(ctx,400,JsonSerializer.Serialize(new{error="sync_failed",message=ex.Message}));}catch{}}
    }
    private static async Task Write(HttpListenerContext c,int status,string body){var bytes=Encoding.UTF8.GetBytes(body);c.Response.StatusCode=status;c.Response.ContentType="application/json; charset=utf-8";c.Response.ContentLength64=bytes.Length;await c.Response.OutputStream.WriteAsync(bytes);c.Response.Close();}
    public static string GetLanAddresses()=>string.Join(", ",NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up).SelectMany(n=>n.GetIPProperties().UnicastAddresses).Where(a=>a.Address.AddressFamily==AddressFamily.InterNetwork&&!IPAddress.IsLoopback(a.Address)).Select(a=>a.Address.ToString()).Distinct());
    public void Dispose(){Stop();_listener.Close();_stop?.Dispose();}
}
