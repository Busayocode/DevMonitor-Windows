package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight, user-triggered reporting helpers. Does not calculate or alter payment rules. */
data class PaymentCardSharePayload(
    val agentName: String, val deviceCode: String, val source: String, val period: String,
    val asOf: String, val estimate: IncentiveEstimate, val activationDetail: String = ""
)

object ReportExportPack {
    /** Shares the existing displayed estimate as a PNG; this is presentation only. */
    fun sharePaymentCard(context: Context, payload: PaymentCardSharePayload): Boolean =
        sharePaymentCards(context, listOf(payload))

    /** Render the high-resolution card off the UI thread so PNG rasterization/compression cannot freeze the screen. */
    fun sharePaymentCardAsync(context: Context, payload: PaymentCardSharePayload, onFinished: (Boolean) -> Unit = {}) {
        val appContext = context.applicationContext
        Thread({
            val prepared = runCatching {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val file = createPaymentCardImage(appContext, payload, "${stamp}_share")
                FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
            }.getOrNull()
            Handler(Looper.getMainLooper()).post {
                if (prepared == null) {
                    onFinished(false)
                    return@post
                }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, prepared)
                    putExtra(Intent.EXTRA_TEXT, "${payload.agentName} — DevMonitor estimated earnings (${payload.source})")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val launched = runCatching {
                    context.startActivity(Intent.createChooser(intent, "Share Earnings Card"))
                }.isSuccess
                onFinished(launched)
            }
        }, "DevMonitor-ShareCard-Render").apply { isDaemon = true; start() }
    }

    /** Creates one exact-source image per device and hands all images to the Android share sheet. */
    fun sharePaymentCards(context: Context, payloads: List<PaymentCardSharePayload>): Boolean {
        if (payloads.isEmpty()) return false
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val files = payloads.mapIndexed { index, payload -> createPaymentCardImage(context, payload, "${stamp}_$index") }
            val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it) })
            val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris.first()) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, if (payloads.size == 1) "${payloads.first().agentName} — DevMonitor earnings progression (${payloads.first().source})" else "DevMonitor earnings progression cards — ${payloads.size} device card(s). Please review each card's source and period.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, if (payloads.size == 1) "Share Earnings Card" else "Batch Share Earnings Cards"))
            true
        }.getOrDefault(false)
    }

    /** Opens PC-prepared PNG cards after a user-initiated sync. The PC supplies the exact figures; Android only presents them. */
    fun sharePreparedPngs(context: Context, cards: List<org.json.JSONObject>): List<String> {
        if (cards.isEmpty()) return emptyList()
        return runCatching {
            val files = cards.take(20).mapIndexedNotNull { index, item ->
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
                val encoded = item.optString("pngBase64")
                if (encoded.isBlank()) return@mapIndexedNotNull null
                val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                if (bytes.size > 2_000_000 || !bytes.take(8).toByteArray().contentEquals(byteArrayOf(0x89.toByte(),0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a))) return@mapIndexedNotNull null
                val file = File(context.cacheDir, "DevMonitor_PC_Share_${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.png")
                FileOutputStream(file).use { it.write(bytes) }
                id to file
            }
            if (files.isEmpty()) return@runCatching emptyList()
            val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it.second) })
            val caption = cards.firstOrNull()?.optString("caption")?.takeIf { it.isNotBlank() } ?: "DevMonitor earnings cards prepared on Windows"
            val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris.first()) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, if (uris.size == 1) "Share PC Earnings Card" else "Share PC Earnings Cards").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            files.map { it.first }
        }.getOrDefault(emptyList())
    }

    /** Shares partner identity and existing performance values as a flyer-style PNG; no values are calculated here. */
    fun sharePartnerResultCardAsync(
        context: Context,
        partnerName: String,
        tradeCode: String,
        cluster: String,
        region: String,
        territory: String,
        metrics: String,
        onFinished: (Boolean) -> Unit = {}
    ) {
        val appContext = context.applicationContext
        Thread({
            val prepared = runCatching {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val file = createPartnerResultImage(appContext, partnerName, tradeCode, cluster, region, territory, metrics, stamp)
                FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
            }.getOrNull()
            Handler(Looper.getMainLooper()).post {
                if (prepared == null) {
                    onFinished(false)
                    return@post
                }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, prepared)
                    putExtra(Intent.EXTRA_TEXT, "DevMonitor partner performance — ${partnerName.ifBlank { tradeCode }} ($tradeCode)")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val launched = runCatching {
                    context.startActivity(Intent.createChooser(intent, "Share Partner Performance"))
                }.isSuccess
                onFinished(launched)
            }
        }, "DevMonitor-PartnerCard-Render").apply { isDaemon = true; start() }
    }

    /** Compatibility wrapper for callers that still need a synchronous result. */
    fun sharePartnerResultCard(
        context: Context, partnerName: String, tradeCode: String, cluster: String,
        region: String, territory: String, metrics: String
    ): Boolean = runCatching {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = createPartnerResultImage(context, partnerName, tradeCode, cluster, region, territory, metrics, stamp)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "DevMonitor partner performance — ${partnerName.ifBlank { tradeCode }} ($tradeCode)")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Partner Performance"))
        true
    }.getOrDefault(false)

    private fun createPartnerResultImage(
        context: Context, partnerName: String, tradeCode: String, cluster: String,
        region: String, territory: String, metrics: String, stamp: String
    ): File {
        // Match the approved earnings flyer proportions and visual language, but keep partner
        // performance tier-free. All displayed metrics are copied from the current result.
        val width = 1080; val height = 1440
        val outputScale = 1.5f
        val bitmap = Bitmap.createBitmap((width * outputScale).toInt(), (height * outputScale).toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(outputScale, outputScale)
        val anti = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.DITHER_FLAG).apply {
            isSubpixelText = true; isLinearText = true; hinting = Paint.HINTING_ON
        }
        val background = Paint(anti).apply {
            shader = android.graphics.LinearGradient(0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFFEAF4FC.toInt(), 0xFFF9FCFF.toInt(), 0xFFE4F7EE.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), background)
        canvas.drawCircle(1030f, 70f, 230f, Paint(anti).apply { color = 0x2229C6B2 })
        canvas.drawRoundRect(28f, 28f, 1052f, (height - 28).toFloat(), 46f, 46f, Paint(anti).apply { color = 0xFFF9FCFF.toInt() })
        val hero = runCatching { android.graphics.BitmapFactory.decodeResource(context.resources, R.drawable.earnings_hero_photo) }.getOrNull()
        if (hero != null) {
            canvas.drawBitmap(hero, null, android.graphics.RectF(420f, 28f, 1052f, 610f), Paint(anti).apply { isFilterBitmap = true })
            hero.recycle()
        }
        canvas.drawRect(28f, 28f, 500f, 610f, Paint(anti).apply {
            shader = android.graphics.LinearGradient(28f, 0f, 540f, 0f,
                intArrayOf(0xFFF9FCFF.toInt(), 0xFFF9FCFF.toInt(), 0x00F9FCFF), floatArrayOf(0f, .62f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        // The bundled photo contains baked-in "Payment Received" wording and a sample amount.
        // Mask that misleading badge completely; partner cards must not imply a payment either.
        canvas.drawRoundRect(568f, 418f, 1010f, 570f, 28f, 28f, Paint(anti).apply { color = 0xFFF0F8F3.toInt() })
        canvas.drawRoundRect(568f, 418f, 1010f, 570f, 28f, 28f, Paint(anti).apply {
            color = 0xFFB9E6D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f
        })
        canvas.drawText("PARTNER ACTIVITY", 600f, 477f, Paint(anti).apply { color = 0xFF087F5B.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Results shown below", 600f, 518f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 21f })
        val navy = 0xFF0B2946.toInt()
        val white = Paint(anti).apply { color = 0xFFFFFFFF.toInt(); typeface = Typeface.DEFAULT_BOLD }
        canvas.drawRoundRect(62f, 62f, 202f, 202f, 32f, 32f, Paint(anti).apply { color = 0xFF0D9E89.toInt() })
        canvas.drawText("DM", 82f, 148f, Paint(white).apply { textSize = 50f })
        canvas.drawText("DevMonitor", 230f, 106f, Paint(anti).apply { color = navy; textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Monitor  •  Track  •  Improve", 232f, 158f, Paint(anti).apply { color = 0xFF24518A.toInt(); textSize = 22f })
        canvas.drawText("PARTNER PERFORMANCE", 64f, 250f, Paint(anti).apply { color = 0xFF5C7FB5.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Performance at", 64f, 316f, Paint(anti).apply { color = 0xFF0B1638.toInt(); textSize = 46f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("a glance", 64f, 370f, Paint(anti).apply { color = 0xFF0B1638.toInt(); textSize = 46f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Your partner activity snapshot", 64f, 420f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 24f })
        // The hero stays uncluttered; the result is presented once in the performance panel below.

        canvas.save(); canvas.translate(0f, 235f)
        canvas.drawCircle(112f, 336f, 52f, Paint(anti).apply { color = 0xFF367FE2.toInt() })
        canvas.drawCircle(112f, 320f, 17f, Paint(anti).apply { color = 0xFFFFFFFF.toInt() })
        canvas.drawOval(82f, 342f, 142f, 374f, Paint(anti).apply { color = 0xFFFFFFFF.toInt() })
        val label = Paint(anti).apply { color = 0xFF607286.toInt(); textSize = 22f }
        val namePaint = Paint(anti).apply { color = navy; textSize = 34f; typeface = Typeface.DEFAULT_BOLD }
        var name = partnerName.ifBlank { "Partner details unavailable" }
        while (namePaint.measureText(name) > 570f && name.length > 8) name = name.dropLast(2) + "…"
        canvas.drawText("CHANNEL PARTNER", 190f, 314f, Paint(label).apply { textSize = 20f; color = 0xFF7890B0.toInt() })
        canvas.drawText(name, 190f, 360f, namePaint)
        canvas.drawText("TRADE CODE  ${tradeCode.take(28)}", 192f, 397f, Paint(label).apply { textSize = 19f })
        canvas.drawRoundRect(754f, 315f, 1006f, 374f, 30f, 30f, Paint(anti).apply { color = 0xFFE4F7EC.toInt() })
        canvas.drawText("✓  PARTNER", 775f, 351f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })

        val details = listOf("CLUSTER" to cluster, "REGION" to region, "TERRITORY" to territory).filter { it.second.isNotBlank() }
        var detailY = 440f
        if (details.isNotEmpty()) {
            canvas.drawRoundRect(64f, 420f, 1016f, 420f + details.size * 48f + 28f, 22f, 22f, Paint(anti).apply { color = 0xFFF0F6FC.toInt() })
            details.forEach { (key, value) ->
                canvas.drawText(key, 88f, detailY + 30f, Paint(label).apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD })
                canvas.drawText(value.take(48), 270f, detailY + 30f, Paint(anti).apply { color = navy; textSize = 22f })
                detailY += 48f
            }
        }
        val metricsStart = if (details.isEmpty()) 440f else 420f + details.size * 48f + 60f
        val dmLine = metrics.lineSequence().firstOrNull { it.startsWith("Device Monitor:", ignoreCase = true) }
        val loadedLine = metrics.lineSequence().firstOrNull { it.startsWith("Loaded Report:", ignoreCase = true) }
        val hasFork3Metrics = dmLine != null || loadedLine != null
        canvas.drawRoundRect(64f, metricsStart, 1016f, metricsStart + (if (hasFork3Metrics) 430f else 300f), 30f, 30f, Paint(anti).apply { color = 0xFF0D9B78.toInt() })
        canvas.drawText("PERFORMANCE VALUES", 98f, metricsStart + 48f, Paint(white).apply { textSize = 25f })
        val parsed = Regex("(?i)(Today|MTD|B48|B96)\\s*:\\s*([^\\s]+)").findAll(metrics).associate { it.groupValues[1].uppercase(Locale.US) to it.groupValues[2] }
        val metricItems = listOf("TODAY" to (parsed["TODAY"] ?: "-"), "MTD" to (parsed["MTD"] ?: "-"), "B48" to (parsed["B48"] ?: "-"), "B96" to (parsed["B96"] ?: "-"))
        metricItems.forEachIndexed { index, item ->
            val col = index % 2; val row = index / 2
            val left = 98f + col * 445f; val top = metricsStart + 78f + row * 98f
            canvas.drawRoundRect(left, top, left + 410f, top + 78f, 18f, 18f, Paint(anti).apply { color = 0x22FFFFFF })
            canvas.drawText(item.first, left + 18f, top + 27f, Paint(anti).apply { color = 0xFFD8FFF1.toInt(); textSize = 17f; typeface = Typeface.DEFAULT_BOLD })
            canvas.drawText(item.second.take(18), left + 18f, top + 62f, Paint(white).apply { textSize = 30f })
        }
        if (hasFork3Metrics) {
            canvas.drawText("ACTIVATION PERFORMANCE  •  FORK 3", 98f, metricsStart + 290f, Paint(white).apply { textSize = 19f; typeface = Typeface.DEFAULT_BOLD })
            listOfNotNull(dmLine, loadedLine).forEachIndexed { index, line ->
                val left = 98f + index * 445f
                val value = line.substringAfter(':').trim().substringBefore('(').trim().replace(Regex("(?i)\\s*subtotal\\s*"), "")
                val deviceCount = Regex("\\((\\d+/\\d+ devices)\\)").find(line)?.groupValues?.get(1).orEmpty()
                val partial = line.contains("subtotal", ignoreCase = true)
                canvas.drawRoundRect(left, metricsStart + 305f, left + 410f, metricsStart + 405f, 18f, 18f, Paint(anti).apply { color = 0x22FFFFFF })
                canvas.drawText(if (line.startsWith("Device Monitor:", true)) "DEVICE MONITOR" else "LOADED REPORT", left + 16f, metricsStart + 331f, Paint(anti).apply { color = 0xFFD8FFF1.toInt(); textSize = 16f; typeface = Typeface.DEFAULT_BOLD })
                canvas.drawText((if (partial) "Subtotal " else "") + value.take(18), left + 16f, metricsStart + 366f, Paint(white).apply { textSize = 25f; typeface = Typeface.DEFAULT_BOLD })
                if (deviceCount.isNotBlank()) canvas.drawText(deviceCount, left + 16f, metricsStart + 391f, Paint(anti).apply { color = 0xFFE0FFF4.toInt(); textSize = 15f })
            }
        }
        canvas.restore()
        canvas.drawText("Generated ${SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())}", 64f, 1350f, Paint(anti).apply { color = 0xFF607286.toInt(); textSize = 20f })
        canvas.drawText("DevMonitor  •  Partner result summary", 64f, 1382f, Paint(anti).apply { color = 0xFF24518A.toInt(); textSize = 19f })
        val file = File(context.cacheDir, "DevMonitor_Partner_Result_$stamp.png")
        try { FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) } }
        finally { bitmap.recycle() }
        return file
    }

    private fun createPaymentCardImage(context: Context, d: PaymentCardSharePayload, stamp: String): File {
        // Flyer-like share card inspired by the approved reference. All monetary figures remain
        // the already-computed estimate supplied by the selected source; this function is display-only.
        val width = 1080; val height = 2040
        // Render the complete flyer at 1.5x pixel density. This keeps a useful export resolution
        // while cutting the main ARGB bitmap from 3240x5430 (~67 MiB) to 1620x2715 (~17 MiB).
        // Text, icons, borders, gradients and the photo share the same uniformly scaled canvas.
        // Keep the logical layout unchanged; payment values and source selection remain untouched.
        val outputScale = 1.5f
        val bitmap = Bitmap.createBitmap((width * outputScale).toInt(), (height * outputScale).toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(outputScale, outputScale)
        val anti = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.DITHER_FLAG).apply {
            isSubpixelText = true
            isLinearText = true
            hinting = Paint.HINTING_ON
        }
        val background = Paint(anti).apply {
            shader = android.graphics.LinearGradient(0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFFEAF4FC.toInt(), 0xFFF9FCFF.toInt(), 0xFFE4F7EE.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), background)
        canvas.drawCircle(1030f, 70f, 230f, Paint(anti).apply { color = 0x2229C6B2 })
        canvas.drawRoundRect(28f, 28f, 1052f, (height - 28).toFloat(), 46f, 46f, Paint(anti).apply { color = 0xFFF9FCFF.toInt() })

        // Photographic hero section: high-density embedded celebration photo sits to the right.
        // The drawable is stored at 3x pixel dimensions for clean downsampling on exported PNGs.
        val hero = runCatching { android.graphics.BitmapFactory.decodeResource(context.resources, R.drawable.earnings_hero_photo) }.getOrNull()
        if (hero != null) {
            val dst = android.graphics.RectF(420f, 28f, 1052f, 610f)
            canvas.drawBitmap(hero, null, dst, Paint(anti).apply { isFilterBitmap = true })
            hero.recycle()
        }
        canvas.drawRect(28f, 28f, 500f, 610f, Paint(anti).apply {
            shader = android.graphics.LinearGradient(28f, 0f, 540f, 0f,
                intArrayOf(0xFFF9FCFF.toInt(), 0xFFF9FCFF.toInt(), 0x00F9FCFF), floatArrayOf(0f, .62f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        // Explicitly cover the photo's baked-in "Payment Received" badge and sample amount.
        // The live estimate is shown separately below and is never presented as money received.
        canvas.drawRoundRect(568f, 418f, 1010f, 570f, 28f, 28f, Paint(anti).apply { color = 0xFFF0F8F3.toInt() })
        canvas.drawRoundRect(568f, 418f, 1010f, 570f, 28f, 28f, Paint(anti).apply {
            color = 0xFFB9E6D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f
        })
        canvas.drawText("PAYMENT ESTIMATE", 596f, 477f, Paint(anti).apply { color = 0xFF087F5B.toInt(); textSize = 26f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("See calculated estimate below", 596f, 518f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 19f })
        val white = Paint(anti).apply { color = 0xFFFFFFFF.toInt(); typeface = Typeface.DEFAULT_BOLD }
        canvas.drawRoundRect(62f, 62f, 202f, 202f, 32f, 32f, Paint(anti).apply { color = 0xFF0D9E89.toInt() })
        canvas.drawText("DM", 82f, 148f, Paint(white).apply { textSize = 50f })
        canvas.drawText("DevMonitor", 230f, 106f, Paint(anti).apply { color = 0xFF0B2946.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Monitor  •  Track  •  Earn", 232f, 158f, Paint(anti).apply { color = 0xFF24518A.toInt(); textSize = 22f })
        canvas.drawText("EARNINGS PROGRESSION", 64f, 250f, Paint(anti).apply { color = 0xFF5C7FB5.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Your hard work", 64f, 316f, Paint(anti).apply { color = 0xFF0B1638.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("is paying off!", 64f, 370f, Paint(anti).apply { color = 0xFF0B1638.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Another step closer", 64f, 420f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 26f })
        canvas.drawText("to your next milestone.", 64f, 456f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 26f })
        // Keep the hero uncluttered; estimated earnings appear once in the main earnings panel below.

        // Move the variable-data panel below the photographic hero. This is still only a layout
        // translation: figures and the established payment engine are untouched.
        canvas.save()
        canvas.translate(0f, 235f)
        val navy = 0xFF102944.toInt()
        val label = Paint(anti).apply { color = 0xFF607286.toInt(); textSize = 22f }
        val bold = Paint(anti).apply { color = navy; typeface = Typeface.DEFAULT_BOLD }
        // Agent identity row with avatar and a clear linked-agent treatment.
        canvas.drawCircle(112f, 336f, 52f, Paint(anti).apply { color = 0xFF367FE2.toInt() })
        canvas.drawCircle(112f, 320f, 17f, Paint(anti).apply { color = 0xFFFFFFFF.toInt() })
        canvas.drawOval(82f, 342f, 142f, 374f, Paint(anti).apply { color = 0xFFFFFFFF.toInt() })
        canvas.drawText("AGENT", 190f, 314f, Paint(label).apply { textSize = 21f; color = 0xFF7890B0.toInt() })
        val namePaint = Paint(bold).apply { textSize = 36f }
        var name = d.agentName.ifBlank { "Unlinked agent" }
        while (namePaint.measureText(name) > 570f && name.length > 8) name = name.dropLast(2) + "…"
        canvas.drawText(name, 190f, 360f, namePaint)
        canvas.drawText("DEVICE  ${d.deviceCode.take(32)}", 192f, 397f, Paint(label).apply { textSize = 19f })
        canvas.drawRoundRect(754f, 315f, 1006f, 374f, 30f, 30f, Paint(anti).apply { color = 0xFFE4F7EC.toInt() })
        canvas.drawText("✓  ${if (d.agentName.isBlank()) "Device card" else "Linked Agent"}", 775f, 351f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })

        canvas.drawRoundRect(64f, 420f, 1016f, 476f, 22f, 22f, Paint(anti).apply { color = 0xFFEAF5F2.toInt() })
        val sourceLine = "${d.period.take(28)}  •  SOURCE: ${d.source.take(22)}"
        canvas.drawText(sourceLine, 86f, 455f, Paint(anti).apply { color = 0xFF087F5B.toInt(); textSize = 21f; typeface = Typeface.DEFAULT_BOLD })

        // Prominent earnings hero: no amount is recalculated here.
        canvas.drawRoundRect(64f, 496f, 1016f, 690f, 30f, 30f, Paint(anti).apply { color = 0xFF0D9B78.toInt() })
        canvas.drawText("CURRENT PAYMENT ESTIMATE", 98f, 542f, Paint(anti).apply { color = 0xFFD8FFF1.toInt(); textSize = 23f; typeface = Typeface.DEFAULT_BOLD })
        val total = "₦${String.format(Locale.US, "%,d", d.estimate.estimatedSubtotal)}"
        var totalSize = 78f
        val totalPaint = Paint(anti).apply { color = -1; typeface = Typeface.DEFAULT_BOLD; textSize = totalSize }
        while (totalPaint.measureText(total) > 850f && totalSize > 48f) { totalSize -= 2f; totalPaint.textSize = totalSize }
        canvas.drawText(total, 98f, 628f, totalPaint)
        canvas.drawText("Monitoring estimate • official company payment remains final", 100f, 662f, Paint(anti).apply { color = 0xFFE0FFF5.toInt(); textSize = 18f })

        // Tier milestones: progress fill is proportional to the full 0–300 scale, not to the next tier.
        val tiers = listOf(30, 50, 70, 100, 150, 200, 250, 300)
        val reached = d.estimate.activations.coerceAtLeast(0)
        val nextTier = tiers.firstOrNull { reached < it }
        canvas.drawRoundRect(64f, 710f, 1016f, 948f, 28f, 28f, Paint(anti).apply { color = 0xFFF0F7F4.toInt() })
        canvas.drawText("ACTIVATION TIER PROGRESSION", 90f, 750f, Paint(bold).apply { textSize = 24f })
        canvas.drawText("${reached} activations achieved", 90f, 780f, Paint(label).apply { textSize = 18f })
        val left = 110f; val right = 970f; val trackY = 826f
        canvas.drawRoundRect(left, trackY - 6f, right, trackY + 6f, 6f, 6f, Paint(anti).apply { color = 0xFFD4DEEA.toInt() })
        val fraction = (reached.toFloat() / tiers.last().toFloat()).coerceIn(0f, 1f)
        if (fraction > 0f) canvas.drawRoundRect(left, trackY - 6f, left + (right - left) * fraction, trackY + 6f, 6f, 6f, Paint(anti).apply { color = 0xFF19A85B.toInt() })
        tiers.forEachIndexed { index, threshold ->
            val x = left + (right - left) * index / (tiers.size - 1)
            val done = reached >= threshold
            val isNext = threshold == nextTier
            val c = if (done) 0xFF19A85B.toInt() else if (isNext) 0xFF2674E8.toInt() else 0xFFB9C6D8.toInt()
            canvas.drawCircle(x, trackY, if (isNext) 17f else 13f, Paint(anti).apply { color = c })
            val p = Paint(anti).apply { color = if (done || isNext) c else 0xFF718096.toInt(); textSize = 18f; typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(threshold.toString(), x - p.measureText(threshold.toString()) / 2f, 860f, p)
        }
        val progression = when {
            nextTier == null -> "All activation tiers reached — maintain the momentum!"
            else -> "${(nextTier - reached).coerceAtLeast(0)} more activations to reach the ${nextTier}-activation tier."
        }
        canvas.drawText(progression.take(78), 90f, 914f, Paint(bold).apply { textSize = 19f; color = 0xFF24518A.toInt() })

        val rows = listOf(
            "Activations achieved" to String.format(Locale.US, "%,d", d.estimate.activations),
            "Fixed performance reward" to "₦${String.format(Locale.US, "%,d", d.estimate.fixedReward)}",
            "FRC cumulative — Progressively paid weekly" to "₦${String.format(Locale.US, "%,d", d.estimate.estimatedRechargeBonus)}",
            "Sunday bonus" to "₦${String.format(Locale.US, "%,d", d.estimate.sundayBonus)}"
        )
        var y = 986f
        rows.forEachIndexed { i, pair ->
            canvas.drawRoundRect(64f, y - 28f, 1016f, y + 28f, 16f, 16f, Paint(anti).apply { color = if (i % 2 == 0) 0xFFF0F5F9.toInt() else 0xFFFFFFFF.toInt() })
            canvas.drawText(pair.first, 88f, y + 7f, Paint(label).apply { textSize = 21f })
            val valuePaint = Paint(bold).apply { textSize = 23f }
            canvas.drawText(pair.second, 986f - valuePaint.measureText(pair.second), y + 7f, valuePaint)
            y += 62f
        }
        // Next-tier projection uses the existing configured tier reward plus only the
        // already-qualified Sunday bonus. It deliberately does not assume future Sunday bonuses,
        // and excludes the weekly-paid FRC component from both current and projected totals.
        val nextReward = d.estimate.nextReward
        val nextThresholdForReward = d.estimate.nextThreshold
        val currentMainEstimate = d.estimate.estimatedSubtotal
        val projectedMainEstimate = nextReward?.plus(d.estimate.sundayBonus)
        val additionalGain = projectedMainEstimate?.minus(currentMainEstimate)
        canvas.drawRoundRect(64f, 1240f, 1016f, 1430f, 26f, 26f, Paint(anti).apply { color = 0xFFEAF3FF.toInt() })
        canvas.drawText("WHAT YOUR NEXT TIER COULD PAY", 88f, 1277f, Paint(anti).apply { color = 0xFF24518A.toInt(); textSize = 23f; typeface = Typeface.DEFAULT_BOLD })
        if (nextThresholdForReward != null && nextReward != null && projectedMainEstimate != null && additionalGain != null) {
            val need = (nextThresholdForReward - reached).coerceAtLeast(0)
            canvas.drawText("Add $need activations to reach $nextThresholdForReward", 88f, 1315f, Paint(label).apply { textSize = 21f })
            canvas.drawText("PROJECTED MAIN ESTIMATE", 88f, 1355f, Paint(label).apply { textSize = 17f })
            canvas.drawText("₦${String.format(Locale.US, "%,d", projectedMainEstimate)}", 88f, 1397f, Paint(bold).apply { textSize = 34f; color = 0xFF087F5B.toInt() })
            val gainText = "+₦${String.format(Locale.US, "%,d", additionalGain)} more"
            val gainPaint = Paint(anti).apply { color = 0xFF087F5B.toInt(); textSize = 23f; typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(gainText, 986f - gainPaint.measureText(gainText), 1397f, gainPaint)
            canvas.drawText("Keeps current qualified Sunday bonus; future Sunday bonus not assumed. FRC excluded.", 88f, 1418f, Paint(label).apply { textSize = 14f })
        } else {
            canvas.drawText("Highest configured activation tier reached.", 88f, 1335f, Paint(bold).apply { textSize = 24f; color = 0xFF087F5B.toInt() })
            canvas.drawText("FRC remains separate; future Sunday bonus is not assumed.", 88f, 1378f, Paint(label).apply { textSize = 18f })
        }

        val reachMessage = when {
            reached >= 300 -> "TOP REACH STEP! Sustain the momentum and keep service quality high."
            reached >= 250 -> "EXCELLENT REACH! Keep building toward the 300-activation milestone."
            reached >= 200 -> "STRONG PROGRESS! Your next reach step is 250 activations."
            reached >= 150 -> "GOOD MOMENTUM! Keep moving toward the 200-activation step."
            reached >= 100 -> "YOU'RE BUILDING REACH! Aim for the 150-activation step next."
            reached >= 70 -> "NICE PROGRESS! Keep connecting toward 100 activations."
            reached >= 50 -> "YOU'RE GAINING GROUND! The 70-activation step is next."
            reached >= 30 -> "GOOD START! Grow toward the 50-activation step."
            else -> "EVERY CONNECTION COUNTS. Build toward the 30-activation step."
        }
        canvas.drawRoundRect(64f, 1460f, 1016f, 1570f, 24f, 24f, Paint(anti).apply { color = 0xFFE4F8EC.toInt() })
        canvas.drawCircle(112f, 1515f, 29f, Paint(anti).apply { color = 0xFF0D9B4D.toInt() })
        canvas.drawText("✓", 98f, 1526f, Paint(anti).apply { color = -1; textSize = 32f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Keep going!", 160f, 1507f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD })
        drawWrapped(canvas, reachMessage, 160f, 1540f, 810f, Paint(anti).apply { color = 0xFF24516B.toInt(); textSize = 19f }, 23f, 2)
        canvas.drawText("As of ${d.asOf.take(32)}", 70f, 1618f, Paint(label).apply { textSize = 18f })
        canvas.drawText("FOR MONITORING / ESTIMATION ONLY", 70f, 1658f, Paint(anti).apply { color = 0xFFB42332.toInt(); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })
        if (d.activationDetail.isNotBlank()) canvas.drawText(d.activationDetail.take(82), 70f, 1690f, Paint(label).apply { textSize = 15f })
        canvas.drawRoundRect(64f, 1708f, 1016f, 1738f, 12f, 12f, Paint(anti).apply { color = 0xFF0B2946.toInt() })
        canvas.drawText("DevMonitor   •   MONITOR  •  TRACK  •  EARN", 86f, 1729f, Paint(anti).apply { color = -1; textSize = 16f; typeface = Typeface.DEFAULT_BOLD })
        canvas.restore()

        val file = File(context.cacheDir, "DevMonitor_Earnings_Flier_${stamp}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private fun drawWrapped(canvas: Canvas, text: String, x: Float, baseline: Float, maxWidth: Float, paint: Paint, lineHeight: Float, maxLines: Int) {
        val words = text.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var current = ""
        for (word in words) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (paint.measureText(candidate) <= maxWidth || current.isEmpty()) current = candidate
            else { lines += current; current = word }
            if (lines.size >= maxLines) break
        }
        if (lines.size < maxLines && current.isNotEmpty()) lines += current
        lines.take(maxLines).forEachIndexed { i, line -> canvas.drawText(line, x, baseline + i * lineHeight, paint) }
    }
    fun shareDailySnapshot(context: Context, dashboard: DashboardSummary, format: SnapshotFormat): Boolean {
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val file = when (format) {
                SnapshotFormat.IMAGE -> createImage(context, dashboard, stamp)
                SnapshotFormat.PDF -> createPdf(context, dashboard, stamp)
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (format == SnapshotFormat.IMAGE) "image/png" else "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "DevMonitor Daily Snapshot — ${dashboard.date}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Daily Snapshot"))
            true
        }.getOrDefault(false)
    }

    private fun createImage(context: Context, d: DashboardSummary, stamp: String): File {
        val width = 1080
        val height = 1320
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFFF7FAFD.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 34f; typeface = Typeface.DEFAULT }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor", 64f, 82f, bold.apply { textSize = 48f; color = 0xFF00843D.toInt() })
        canvas.drawText("Daily Operational Snapshot", 64f, 130f, paint.apply { textSize = 30f; color = 0xFF40546A.toInt() })
        canvas.drawText(d.date, 64f, 178f, paint.apply { textSize = 26f })
        var y = 250f
        val metrics = listOf(
            "Devices observed" to d.deviceCount.toString(),
            "Today's SIMReg" to d.todayTotal.toString(),
            "MTD SIMReg" to d.mtdTotal.toString(),
            "Active" to d.activeTotal.toString(),
            "Bar 48" to d.bar48Total.toString(),
            "Bar 96" to d.bar96Total.toString(),
            "Company today / MTD" to "${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD" to "${d.partnerToday} / ${d.partnerMtd}",
            "Active flags" to d.flags.size.toString()
        )
        for ((label, value) in metrics) {
            canvas.drawRoundRect(54f, y - 34f, width - 54f, y + 28f, 18f, 18f, Paint(paint).apply { color = 0xFFFFFFFF.toInt() })
            canvas.drawText(label, 82f, y + 5f, paint.apply { textSize = 24f; color = 0xFF40546A.toInt() })
            canvas.drawText(value, 800f, y + 5f, bold.apply { textSize = 26f; color = 0xFF12233A.toInt() })
            y += 88f
        }
        y += 28f
        canvas.drawText("Exceptions", 64f, y, bold.apply { textSize = 30f; color = 0xFFD14B5B.toInt() })
        y += 48f
        val flags = d.flags.take(8)
        if (flags.isEmpty()) canvas.drawText("No active flags recorded.", 64f, y, paint.apply { textSize = 24f })
        else flags.forEach { flag ->
            val line = "• ${flag.code}: ${flag.reason}"
            canvas.drawText(line.take(78), 70f, y, paint.apply { textSize = 21f; color = 0xFF40546A.toInt() })
            y += 38f
        }
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private fun createPdf(context: Context, d: DashboardSummary, stamp: String): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(612, 792, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 14f }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor — Daily Operational Snapshot", 36f, 48f, bold.apply { textSize = 20f; color = 0xFF00843D.toInt() })
        canvas.drawText("Date: ${d.date}", 36f, 72f, paint)
        val lines = listOf(
            "Devices observed: ${d.deviceCount}", "Today's SIMReg: ${d.todayTotal}", "MTD SIMReg: ${d.mtdTotal}",
            "Active: ${d.activeTotal}", "Bar 48: ${d.bar48Total}", "Bar 96: ${d.bar96Total}",
            "Company today / MTD: ${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD: ${d.partnerToday} / ${d.partnerMtd}", "Active flags: ${d.flags.size}"
        )
        var y = 110f
        lines.forEach { canvas.drawText(it, 42f, y, paint); y += 25f }
        y += 12f
        canvas.drawText("Exceptions", 36f, y, bold.apply { textSize = 16f; color = 0xFFD14B5B.toInt() }); y += 25f
        d.flags.take(14).forEach { flag ->
            val text = "${flag.code} — ${flag.reason}"
            canvas.drawText(text.take(92), 42f, y, paint.apply { textSize = 10f; color = 0xFF40546A.toInt() }); y += 17f
            if (y > 750f) return@forEach
        }
        doc.finishPage(page)
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}

enum class SnapshotFormat { IMAGE, PDF }
