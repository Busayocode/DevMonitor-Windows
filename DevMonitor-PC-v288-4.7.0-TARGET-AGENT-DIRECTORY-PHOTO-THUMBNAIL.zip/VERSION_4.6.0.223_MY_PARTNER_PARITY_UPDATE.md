# DevMonitor Windows 4.6.0.223 — My Partner parity update

Date: 2026-10-13

## Changes
- Added a dedicated My Partner workspace to Windows navigation.
- Searches loaded monthly HQ snapshots by partner name or trade code; selecting a match fills the partner form.
- Stores saved partner entries in separate local SQLite file `%LOCALAPPDATA%\DevMonitor\my_partner.db`, scoped to the local profile.
- Kept partner workspace separate from My Devices, SMS Checker observations, HQ snapshots, and payment progression.
- Does not send SMS or manufacture partner-check results on Windows.

## Protected logic
`PaymentRules.cs` and payment calculation paths were not intentionally modified.

## Verification
ZIP integrity and XAML XML validation are checked. A Windows .NET build and native desktop toast notifications were not verified in this environment. Use the repository's Windows GitHub Actions workflow to compile the app and installer.
