# Windows v234 — Historical eligibility gate for payment progression

- PC-initiated SMS Checker share-card batches skip a device when the required historical Active baseline through the 20th is unavailable after the 21st.
- Accepts a valid dated phone Active baseline or an imported HQ report with device-level coverage spanning month start through the 20th, and requires a successful post-20th Active observation before creating a current-cycle card. Missing history is never silently treated as zero.
- Loaded Report source remains separate. Existing tier/FRC/Sunday rules and PC-to-Android share handoff are preserved.
- Project version 4.6.0.234. Static checks only; Windows compile and runtime verification pending.
