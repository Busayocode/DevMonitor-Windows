# DevMonitor Pre-rendered Voice Audio — Welcome Integration Update

Status: welcome assets and playback triggers integrated into Android v298 and Windows v283 source packages. Compilation and runtime/device playback still require verification in their target build environments.

## Bundled welcome recordings
- `dm_welcome_first_launch.wav` — Perfect F1; exact dialogue: “Welcome to DevMonitor”.
- `dm_welcome_staff_profile.wav` — Perfect M1; exact dialogue: “Welcome to DevMonitor, a collection of tools to help you monitor your devices and answer to your numbers!” The quiet tail was trimmed with a short fade-out.
- Both are bundled locally for offline playback. No Android TextToSpeech, Windows SpeechSynthesizer, or phone/PC speech engine is used.

## Trigger rules
- First-launch welcome: plays once on a fresh Android install (only if the persisted welcome/onboarding state says it has not been seen) and once on the first Windows app startup. Persistent latches prevent repeat playback.
- Staff profile welcome: Android plays after a new STAFF profile is committed; Windows plays after the first successful save of a STAFF profile. Per-profile/app latches prevent repeats. Editing an existing profile does not replay it.
- The supplied profile recording is specifically the STAFF script. No incorrect substitute is played for PARTNER or AGENT profiles; those need their own approved recordings before their distinct scripts can be spoken.
- All bundled voice clips share a playback queue to prevent overlap. Important warning/error clips jump ahead of queued welcomes; the currently playing clip is allowed to finish cleanly.
- Existing warning/error and qualifying task-completion audio behaviour is retained.

## Guardrails
- Audio playback is best-effort and must never block profile saving, notification storage, imports, report calculations, payments, MOM, or sync.
- These changes do not modify payment formulas/cycle rules, MOM snapshots/databases, HQ/report authority, report processing, or existing notification triggers.
- Audio does not initiate any business operation.

## Verification status
- Source ZIP integrity and embedded WAV assets: verified during packaging.
- Android compile/device playback: not verified in this environment.
- Windows compile/runtime playback: not verified in this environment.

- MP3 copies are excluded from the Windows source package; bundled welcome audio uses WAV only.
