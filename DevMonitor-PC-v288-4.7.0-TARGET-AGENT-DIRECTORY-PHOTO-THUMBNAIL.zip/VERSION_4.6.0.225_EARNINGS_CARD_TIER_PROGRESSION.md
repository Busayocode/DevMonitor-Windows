# Windows v225 — Earnings card tier progression

- Flyer-style PC PNG output for SMS Checker and Loaded Report source figures.
- Activation progression uses the existing configured tier thresholds and the selected source's Active value only.
- Encouragement message varies by reach step; missing Active values are explicitly unavailable.
- Does not change payment calculations, import behavior, sync rules, or source isolation.
- Partner lookup results remain separate from payment progression because lookup metrics are not payment inputs.
- Duplicate Flags menu item was not present in the Windows navigation source inspected for this build.
- Archive/source checks only; run Windows GitHub Actions and test the paired phone handoff before release.
