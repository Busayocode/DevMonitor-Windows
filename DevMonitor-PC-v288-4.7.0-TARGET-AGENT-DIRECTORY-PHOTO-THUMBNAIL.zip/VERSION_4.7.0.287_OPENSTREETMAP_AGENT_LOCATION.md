# DevMonitor Windows v287 — OpenStreetMap agent-location parity

## Change
- The Agents & Partners directory now lets the user select a synced Android agent and open its saved coordinates in OpenStreetMap.
- Coordinates are validated before opening the map. If missing or invalid, Windows explains that the pin must be set and saved on Android, followed by explicit sync.
- The Agents page documents OpenStreetMap attribution.
- Updated master/parity documentation to remove the old Google Maps API-key and billing assumption.

## Ownership and safety
- Android remains authoritative for agent records, saved coordinates, contact information, and linked devices. Windows remains read-only for these agent records.
- Postal address remains separate from latitude/longitude. Windows does not guess coordinates from an address.
- No payment formulas, MOM snapshot/database behavior, HQ snapshots, or target logic were changed.

## Verification status
- Source ZIP integrity will be checked after packaging.
- Compilation and live Windows/Android runtime behavior are not claimed as verified in this environment.
