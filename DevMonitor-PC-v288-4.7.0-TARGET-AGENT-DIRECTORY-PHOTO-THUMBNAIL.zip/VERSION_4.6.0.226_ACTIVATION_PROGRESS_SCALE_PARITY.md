# Windows v226 — Activation Progress Scale Parity

- Fixed the Windows share-card milestone bar to use the complete 0–300 activation scale, matching Android's progression semantics.
- PC cards remain source-figure cards and do not infer monetary earnings.
- Windows build and image review remain pending.
