# DevMonitor Windows v235 — Strict payment history and partner search parity

Date: 2026-10-17

## Payment-card eligibility
- SMS Checker card batches require a device-specific Active history source in the previous calendar month, a successful current-calendar-month Active result, and (from the 21st) evidence for the cumulative baseline through the 20th plus a successful post-20th Active result.
- Failure reasons identify the missing evidence. Missing history is not interpreted as zero.
- Loaded Report cards continue to use their own selected report data and are never filled from SMS Checker data.

## My Partners lookup
- Lookup uses the latest retained HQ directory only.
- Partner names and Trade Codes support case-insensitive partial matching.
- Blank Trade Codes are excluded; matches are deduplicated by canonical Trade Code and capped at 12.
- Older imported months remain available through Loaded Report.

## Preserved
- Existing payment formulas and tier thresholds, FRC weekly separation, Sunday bonus rules, next-tier projection, PC-to-Android share queue/acknowledgement, and offline data workflows.

## Verification status
Source-level changes and archive integrity can be checked here. Windows compilation, installer generation, and paired Android/PC runtime tests still require the Windows GitHub Actions workflow and a connected test device.
