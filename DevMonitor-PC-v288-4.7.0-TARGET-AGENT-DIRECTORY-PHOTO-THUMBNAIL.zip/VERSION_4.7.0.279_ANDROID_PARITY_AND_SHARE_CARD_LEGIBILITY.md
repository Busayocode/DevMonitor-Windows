# DevMonitor Windows v279 — Android parity and share-card legibility

## Base
- `DevMonitor-Windows-Native-v278-TARGET-WPF-COMPILE-FIX.zip`
- Compared against Android `DevMonitor-4.7.0-TARGET-v292-AD-FREQUENCY-CORRECTION.zip`.

## Changes
- Increased contrast for secondary text in the Windows earnings share-card renderer.
- Enlarged supporting text and used width-aware fitting for long source/period, estimate breakdown, activation status, next-tier projection, and explanatory notes.
- Advanced Windows project and installer version to `4.7.0.279`.

## Protected
- No changes to `PaymentRules.cs`, payment formula/cutoffs, source-selection, Sunday bonus qualification, FRC handling, HQ snapshot storage/import rules, Target calculations, or phone/PC sync payload rules.
- No Android-only AdMob gating was added to Windows. Android v292's rewarded-ad export credits and SMS interstitial threshold remain phone-specific because this Windows source does not contain an AdMob integration.
- Android v291 location permission changes are not applicable to the Windows desktop runtime.

## Verification
- ZIP structure, source consistency, and version references checked.
- Windows compilation and rendered-card visual review not performed here because the .NET SDK/Windows WPF runtime is unavailable.
