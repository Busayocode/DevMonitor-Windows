# Windows v227 — Photographic Earnings Flyer

- Embedded the generated photographic hero image in the native Windows share-card renderer.
- PC-prepared PNG cards remain offline-capable and use only selected-source values.
- Activation progression uses the existing Active figure and does not infer payment estimates.
- Native Windows build was not run in this environment; GitHub Actions build verification is required.
