using System;
using System.IO;
using System.Windows;
using System.Windows.Media;

namespace DevMonitor.Windows;

/// <summary>Plays bundled, pre-rendered DevMonitor AI voice clips. Never uses Windows speech synthesis.</summary>
internal static class DevMonitorVoiceNotifications
{
    private static MediaPlayer? _player;
    private static readonly object Gate = new();
    private static readonly System.Collections.Generic.LinkedList<string> WelcomeQueue = new();
    private static bool _welcomePlaying;

    public static void PlayFirstLaunchOnce(DevMonitorDb db)
    {
        if (db.GetSetting("welcome_first_launch_played") == "true") return;
        db.SetSetting("welcome_first_launch_played", "true");
        EnqueueWelcome("dm_welcome_first_launch.wav");
    }

    public static void PlayStaffProfileOnce(DevMonitorDb db)
    {
        if (db.GetSetting("welcome_staff_profile_played") == "true") return;
        db.SetSetting("welcome_staff_profile_played", "true");
        EnqueueWelcome("dm_welcome_staff_profile.wav");
    }

    private static void EnqueueWelcome(string file, bool prioritize = false)
    {
        lock (Gate)
        {
            if (prioritize) WelcomeQueue.AddFirst(file);
            else WelcomeQueue.AddLast(file);
        }
        Application.Current?.Dispatcher.BeginInvoke(new Action(PlayNextWelcome));
    }

    private static void PlayNextWelcome()
    {
        string file;
        lock (Gate)
        {
            if (_welcomePlaying || WelcomeQueue.Count == 0 || Application.Current is null) return;
            _welcomePlaying = true;
            file = WelcomeQueue.First!.Value;
            WelcomeQueue.RemoveFirst();
        }
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, "Assets", "Voice", file);
            if (!File.Exists(path)) { FinishWelcome(); return; }
            var player = new MediaPlayer { Volume = 0.85 };
            lock (Gate) _player = player;
            player.Open(new Uri(path, UriKind.Absolute));
            player.MediaEnded += (_, _) => { player.Close(); FinishWelcome(); };
            player.MediaFailed += (_, _) => { player.Close(); FinishWelcome(); };
            player.MediaOpened += (_, _) => player.Play();
        }
        catch { FinishWelcome(); /* Audio must never interrupt profile saving or app startup. */ }
    }

    private static void FinishWelcome()
    {
        lock (Gate) { _welcomePlaying = false; _player = null; }
        Application.Current?.Dispatcher.BeginInvoke(new Action(PlayNextWelcome));
    }

    public static void PlayFor(string title, string kind)
    {
        var t = (title ?? string.Empty).Trim().ToLowerInvariant();
        var k = (kind ?? string.Empty).Trim().ToLowerInvariant();
        var isAlert = k == "warning" || k == "error";
        var file = isAlert ? "dm_alert_notification.wav"
            : (k == "task" && (t.Contains("task completed") || t.Contains("task complete"))) ? "dm_complete_notification.wav"
            : null;
        if (file is null || Application.Current is null) return;
        // Use the shared queue so alerts never overlap a welcome; alerts jump ahead of queued welcomes.
        EnqueueWelcome(file, prioritize: isAlert);
    }
}
