# Windows 4.7.0.278 — Target WPF compile fix

- Removed the unsupported `FormattedText.TextRenderingMode` assignment in the earnings-card PNG renderer. WPF's default text rendering is retained.
- Kept the expected-to-date achievement calculation and removed no Target functionality.
- Target card shows achievement percentage against the expected cumulative target for the same reporting day, with no shortfall/deficit figure or behind-pace warning. Full-month progress remains a separate percentage.
- Windows project version: 4.7.0.278.
- ZIP integrity/source checks performed; compile must be confirmed by GitHub Actions.
