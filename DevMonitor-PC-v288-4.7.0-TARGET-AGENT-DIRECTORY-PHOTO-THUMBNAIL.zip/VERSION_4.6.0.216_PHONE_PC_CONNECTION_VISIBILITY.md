# DevMonitor Windows 4.6.0.216 — Phone/PC Connection Visibility

- Added last-successful-phone-exchange timestamp to Phone Data Exchange.
- Clarified that the Windows local bridge listens while DevMonitor is running and the bridge is started.
- Windows bridge continues to accept encrypted operational sync requests; Android v225 performs active-screen auto-sync with finite retries and a five-minute standby check after failure.
- The UI discloses that Android background restrictions and Windows sleep/shutdown can interrupt availability.
- No payment calculation, HQ report import, or HQ/payment data boundary changes.
- ZIP integrity can be checked locally; .NET publish and live Android/Windows pairing still require GitHub Actions and device testing.
