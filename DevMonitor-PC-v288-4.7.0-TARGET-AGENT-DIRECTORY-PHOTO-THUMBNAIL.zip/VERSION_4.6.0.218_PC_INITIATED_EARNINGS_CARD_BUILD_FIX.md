# DevMonitor Windows 4.6.0.218 — earnings-card handoff build fix

- Fixed the C# compiler error in MainWindow.xaml.cs caused by literal newlines inside a normal interpolated string. The optional skipped-card details now use escaped `\n` sequences.
- Advanced Windows assembly/file/informational version to 4.6.0.218.
- Preserved the PC-initiated earnings-card handoff feature from v217.
- No payment calculations or rules were changed.
- This is a source correction; successful compilation and Android handoff must be confirmed by GitHub Actions and paired-device testing.
