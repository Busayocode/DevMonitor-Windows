# DevMonitor Windows 4.6.0.217 — PC-initiated earnings-card handoff

- Added Share Earnings Cards page to the native Windows client.
- Select one source (SMS Checker or Loaded Report), select agents already synchronized from Android, and prepare up to 20 PNG cards per batch.
- Cards contain only source fields available in that source (Today, MTD, Active), agent/device, period and as-of timestamp. Missing source rows are skipped and reported. No new payment estimate or cross-source fill is introduced.
- Prepared PNGs are queued in the existing local operational archive and included in the encrypted PC↔Android sync response. Android opens the native sharing sheet after receiving the cards.
- Android acknowledges opened cards on the next exchange; Windows removes acknowledged queue items. Queue data is excluded from normal extended-record sync to avoid duplicating large images.
- HQ monthly snapshots and payment records remain excluded from sync. PaymentRules.cs and payment calculation paths were not modified.
- Build status: source changes packaged; a Windows build and end-to-end device handoff still require GitHub Actions / paired-device testing.
