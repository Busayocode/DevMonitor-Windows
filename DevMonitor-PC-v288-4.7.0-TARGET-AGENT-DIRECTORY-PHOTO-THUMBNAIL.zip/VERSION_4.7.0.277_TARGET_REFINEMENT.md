# DevMonitor Windows 4.7.0.277 — Target refinement

- Main achievement is actual activity divided by expected cumulative target as of the reporting cutoff.
- No numeric shortfall, deficit, or behind-pace warning is shown.
- Full-month progress is shown separately as a neutral percentage.
- Existing profile targets and payment calculations are unchanged.
