DevMonitor Windows v4.6.0.215 — Analytics IO Usings Fix

Change:
- Added an explicit System.IO using to AppTelemetry.cs for Path, Directory, File, and FileInfo.
- Advanced the Windows assembly/file/informational version to 4.6.0.215.

Scope:
- Build-compatibility fix only. No telemetry behavior, database logic, payment calculations, or sync behavior was changed.

Validation:
- ZIP integrity is checked after packaging.
- A local .NET publish was not run in this environment; GitHub Actions must confirm compilation.
