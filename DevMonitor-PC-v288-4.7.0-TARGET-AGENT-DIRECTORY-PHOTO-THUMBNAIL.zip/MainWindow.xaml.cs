using Microsoft.Win32;
using Microsoft.Data.Sqlite;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace DevMonitor.Windows;

public partial class MainWindow : Window
{
    private readonly DevMonitorDb _db=new();
    private SyncBridgeServer? _syncBridge;
    private string _page="Dashboard";
    private List<DeviceRow> _lastReport=[];
    private DateTime _reportStart,_reportEnd;
    private readonly DispatcherTimer _linkStatusTimer = new() { Interval = TimeSpan.FromSeconds(5) };

    public MainWindow()
    {
        InitializeComponent();
        AppTelemetry.Initialize(_db);
        DevMonitorVoiceNotifications.PlayFirstLaunchOnce(_db);
        // Keep the native window fully inside the usable Windows desktop area.
        // This prevents the title bar/close button being positioned off-screen
        // on smaller displays or with display scaling enabled.
        MaxWidth = SystemParameters.WorkArea.Width;
        MaxHeight = SystemParameters.WorkArea.Height;
        Width = Math.Min(Width, MaxWidth);
        Height = Math.Min(Height, MaxHeight);
        if (Width < MinWidth) MinWidth = Math.Max(800, MaxWidth);
        if (Height < MinHeight) MinHeight = Math.Max(520, MaxHeight);
        Left = Math.Max(SystemParameters.WorkArea.Left, SystemParameters.WorkArea.Left + (SystemParameters.WorkArea.Width - Width) / 2);
        Top = Math.Max(SystemParameters.WorkArea.Top, SystemParameters.WorkArea.Top + (SystemParameters.WorkArea.Height - Height) / 2);
        var myPartnerNav = NavPanel.Children.OfType<Button>().FirstOrDefault(b => Equals(b.Tag, "MyPartner"));
        if (myPartnerNav != null) myPartnerNav.Visibility = IsStaffProfile() ? Visibility.Visible : Visibility.Collapsed;
        Render("Dashboard");
        _linkStatusTimer.Tick += (_,_) => UpdateLinkStatus();
        _linkStatusTimer.Start();
        UpdateLinkStatus();
        Closed += (_,_)=>{_linkStatusTimer.Stop();_db.Dispose();};
    }

    private void UpdateLinkStatus()
    {
        var running=_syncBridge?.IsRunning==true;
        var last=_syncBridge?.LastSuccessfulExchange?.ToLocalTime();
        if(!running){LinkStatusDot.Fill=new SolidColorBrush(Color.FromRgb(220,70,70));LinkStatusText.Text="PC link: bridge stopped";}
        else if(!last.HasValue){LinkStatusDot.Fill=new SolidColorBrush(Color.FromRgb(217,119,6));LinkStatusText.Text="PC link: waiting for Android";}
        else if(DateTime.Now-last.Value>TimeSpan.FromMinutes(10)){LinkStatusDot.Fill=new SolidColorBrush(Color.FromRgb(217,119,6));LinkStatusText.Text="PC link: no recent sync";}
        else {LinkStatusDot.Fill=new SolidColorBrush(Color.FromRgb(22,163,74));LinkStatusText.Text="PC link: connected";}
        LinkStatusText.ToolTip=last.HasValue?$"Last sync {last.Value:dd MMM HH:mm:ss}":"No successful exchange yet";
    }

    private void Nav_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button b && b.Tag is string page) Render(page);
    }

    private async void Refresh_Click(object sender,RoutedEventArgs e)
    {
        // Refresh the current page and explicitly test the local sync bridge; do not silently imply
        // that refreshing page data can start a bridge that has not been configured/started.
        Render(_page);
        if (_syncBridge?.IsRunning != true)
        {
            UpdateLinkStatus();
            StatusText.Text = "Link check complete";
            MessageBox.Show(this,
                "The PC sync bridge is stopped, so Android cannot connect yet.\n\nOpen Phone Data Exchange and choose ‘Start local sync bridge’. Keep DevMonitor running and use the displayed LAN address and pairing key in Android Settings → Next Level → Health.\n\nThis check did not change or recalculate payment data.",
                "DevMonitor connection check", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        try
        {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(4) };
            var response = await client.GetAsync($"http://127.0.0.1:{_syncBridge.Port}/health");
            if (response.IsSuccessStatusCode)
            {
                StatusText.Text = "Bridge health check passed";
                UpdateLinkStatus();
                MessageBox.Show(this, "The local sync bridge is running and its health endpoint responded successfully. This confirms the PC bridge is listening; it does not by itself prove that Android has completed a sync.\n\nIf the phone still shows offline, verify both devices are on the same trusted network and check the saved PC URL and pairing key in Android → Next Level → Health.", "DevMonitor connection check", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                StatusText.Text = $"Bridge health check returned HTTP {(int)response.StatusCode}";
                UpdateLinkStatus();
                MessageBox.Show(this, StatusText.Text, "DevMonitor connection check", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        catch (Exception ex)
        {
            StatusText.Text = "Bridge health check failed";
            UpdateLinkStatus();
            MessageBox.Show(this, $"The local bridge health check failed: {ex.Message}\n\nOpen Phone Data Exchange and restart the local sync bridge if necessary.", "DevMonitor connection check", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private bool IsStaffProfile() => string.Equals(_db.GetSetting("profile_role")?.Trim(), "STAFF", StringComparison.OrdinalIgnoreCase);

    private void Render(string page)
    {
        var myPartnerNav = NavPanel.Children.OfType<Button>().FirstOrDefault(b => Equals(b.Tag, "MyPartner"));
        if (myPartnerNav != null) myPartnerNav.Visibility = IsStaffProfile() ? Visibility.Visible : Visibility.Collapsed;
        if (page == "MyPartner" && !IsStaffProfile()) page = "Dashboard";
        _page=page;
        AppTelemetry.Track("page_open", page);
        foreach (var nav in NavPanel.Children.OfType<Button>())
        {
            nav.Background = nav.Tag is string tag && tag == page ? (Brush)FindResource("SidebarSelectedBrush") : Brushes.Transparent;
            nav.Foreground = Brushes.White;
                nav.Effect = nav.Tag is string selected && selected == page ? (Effect)FindResource("ButtonShadow") : null;
        }
        PageHost.Content=page switch {
            "Dashboard"=>Dashboard(),
            "Sms"=>SmsPage(),
            "Devices"=>DevicesPage(),
            "Report"=>ReportPage(),
            "Earnings"=>EarningsPage(),
            "Monitor"=>MonitorPage(),
            "MonthOnMonth"=>MonthOnMonthPage(),
            "Agents"=>AgentsPage(),
            "MyPartner"=>MyPartnerPage(),
            "ShareCards"=>ShareCardsPage(),
            "Tasks"=>TasksPage(),
            "Notes"=>NotesPage(),
            "Activity"=>ActivityPage(),
            "Inbox"=>InboxPage(),
            "Exports"=>ExportsPage(),
            "LoadedReport"=>LoadedReportPage(),
            "Trends"=>TrendsPage(),
            "ActionCentre"=>ActionCentrePage(),
            "Profile"=>ProfilePage(),
            "Exchange"=>ExchangePage(),
            "AndroidData"=>AndroidDataPage(),
            "Settings"=>SettingsPage(),
            _=>Dashboard()
        };
        PageTitle.Text=page switch {
            "Sms"=>"SMS Checker","Devices"=>"My Devices","Report"=>"Load Report",
            "Earnings"=>"Earning Progress","Monitor"=>"Device Monitor","MonthOnMonth"=>"Month-on-Month","Agents"=>"Agents & Partners","MyPartner"=>"My Partners","ShareCards"=>"Share Earnings Cards","Tasks"=>"Tasks & Follow-ups","Notes"=>"Notes","Activity"=>"Device Activity Timeline","Inbox"=>"Notifications / Inbox","Exports"=>"Export Centre","LoadedReport"=>"Loaded Report","Trends"=>"Trends & Insights","ActionCentre"=>"Action Centre","Profile"=>"Profile & Company","Exchange"=>"Phone Data Exchange","AndroidData"=>"Android Data Archive","Settings"=>"Settings",_=>"Dashboard"
        };
        PageEyebrow.Text=page=="Dashboard"?"CONTROL CENTRE":page.ToUpperInvariant();
        FooterText.Text=$"DevMonitor Windows • Local database: {_db.FilePath}";
    }

    private Border Card(UIElement content, Brush? accent=null)
    {
        var b=new Border{Background=Brushes.White,CornerRadius=new CornerRadius(12),Padding=new Thickness(20),Margin=new Thickness(0,0,0,14),BorderBrush=(Brush)FindResource("BorderBrush"),BorderThickness=new Thickness(1),Effect=(Effect)FindResource("SoftShadow")};
        var panel=new StackPanel(); if(accent!=null) panel.Children.Add(new Border{Height=4,Background=accent,CornerRadius=new CornerRadius(4),Margin=new Thickness(0,0,0,14)});
        panel.Children.Add(content);b.Child=panel;return b;
    }
    private TextBlock H(string text,double size=20)=>new(){Text=text,FontSize=size,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("TextBrush"),Margin=new Thickness(0,0,0,7)};
    private TextBlock P(string text)=>new(){Text=text,FontSize=14,Foreground=(Brush)FindResource("MutedBrush"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)};
    private Button B(string text,RoutedEventHandler click){var b=new Button{Content=text,Style=(Style)FindResource("PrimaryButton")};b.Click+=click;return b;}
    private StackPanel Stack(params UIElement[] e)
    {
        var panel=new StackPanel();
        foreach(var item in e) panel.Children.Add(item);
        return panel;
    }

    private UIElement Dashboard()
    {
        var root=new StackPanel();
        var count=_db.MyDevices().Count;
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var (cs,ce)=PaymentRules.PaymentCycleForDate(today);
        root.Children.Add(Card(Stack(
            H("Good day — DevMonitor is ready",28),
            P("A native Windows workspace built from the current Android application's operational model. Everything here runs locally unless you explicitly connect a future sync service."),
            new WrapPanel{Children={
                B("SMS CHECKER",(_,_)=>Render("Sms")),
                B("MY DEVICES",(_,_)=>Render("Devices")),
                B("LOAD REPORT",(_,_)=>Render("Report")),
                (IsStaffProfile()?B("MY PARTNERS",(_,_)=>Render("MyPartner")):new Button{Visibility=Visibility.Collapsed}),
                B("EARNING PROGRESS",(_,_)=>Render("Earnings")),
                B("TASKS",(_,_)=>Render("Tasks")),
                B("NOTES",(_,_)=>Render("Notes")),
                B("EXPORT",(_,_)=>Render("Exports")),
                B("LOADED REPORT",(_,_)=>Render("LoadedReport")),
                B("TRENDS",(_,_)=>Render("Trends")),
                B("ACTION CENTRE",(_,_)=>Render("ActionCentre")),
                B("PHONE EXCHANGE",(_,_)=>Render("Exchange"))
            }}
        ),(Brush)FindResource("AccentBrush")));
        root.Children.Add(new UniformGrid{Columns=4,Children={
            Metric("MY DEVICES",count.ToString()),
            Metric("PAYMENT CYCLE",$"{cs:dd MMM} → {ce:dd MMM}"),
            Metric("CURRENT MONTH",today.ToString("MMMM yyyy")),
            Metric("PREVIOUS MONTH",today.AddMonths(-1).ToString("MMMM yyyy")),
            Metric("OPEN TASKS",_db.Tasks(false).Count.ToString()),
            Metric("UNREAD ALERTS",_db.UnreadNotifications().ToString()),
            Metric("PHONE RESULTS",_db.PhoneResults().Count.ToString())
        }});
        root.Children.Add(Card(Stack(
            H("Current architecture"),
            P("HQ reports are authoritative monthly snapshots. Windows keeps only the current and immediately previous calendar-month stores, imports are Replace All for a month, and import does not silently recalculate downstream screens."),
            B("Open Settings",(_,_)=>Render("Settings"))
        ),Brushes.SteelBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private Border Metric(string title,string value)
    {
        var s=Stack(new TextBlock{Text=title,FontSize=11,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("MutedBrush")},
            new TextBlock{Text=value,FontSize=21,FontWeight=FontWeights.Bold,Margin=new Thickness(0,6,0,0)});
        return new Border{Child=s,Background=Brushes.White,Padding=new Thickness(18),Margin=new Thickness(0,0,12,14),CornerRadius=new CornerRadius(12),BorderBrush=(Brush)FindResource("BorderBrush"),BorderThickness=new Thickness(1)};
    }

    private UIElement DevicesPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        root.Children.Add(Card(Stack(H("Your working device set"),P("The Windows version keeps a separate, user-scoped working set. Updating this list never deletes authoritative HQ history."),
            B("Replace My Devices",(_,_)=>EditDevices())) ,Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=480,ItemsSource=ids.Select(x=>new{Device=x}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void EditDevices()
    {
        var w=new Window{Title="Update My Devices",Width=520,Height=430,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var box=new TextBox{AcceptsReturn=true,Text=string.Join(Environment.NewLine,_db.MyDevices()),VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(15)};
        var save=new Button{Content="Save device list",Margin=new Thickness(15),Padding=new Thickness(12)};
        save.Click+=(_,_)=>{_db.ReplaceMyDevices(box.Text.Split(new[]{"\r\n","\n"},StringSplitOptions.RemoveEmptyEntries));w.DialogResult=true;w.Close();Render("Devices");};
        w.Content=new DockPanel{Children={box,save}};DockPanel.SetDock(save,Dock.Bottom);w.ShowDialog();
    }

    private UIElement ReportPage()
    {
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("HQ / SIMReg report import"),P("Choose an Excel report. The first worksheet is parsed into a normalized device/day model. Only the current calendar month or immediately previous month may be stored."),
            B("Choose Excel Report",ImportReport)),Brushes.MediumPurple));
        if(_lastReport.Count>0) root.Children.Add(Card(Stack(
            H($"Loaded report: {_lastReport.Count:N0} devices"),
            P($"Coverage: {_reportStart:yyyy-MM-dd} → {_reportEnd:yyyy-MM-dd}. This is a validated in-memory view; use Store Month to commit it to the local authoritative monthly snapshot."),
            B("Store Month Snapshot",StoreReport)),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void ImportReport(object? s,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="Excel reports|*.xlsx;*.xlsm|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            StatusText.Text="Reading report…";
            _lastReport=ReportImporter.Read(dlg.FileName,out _reportStart,out _reportEnd);
            _db.SetSetting("last_report_file",dlg.FileName);
            StatusText.Text=$"Loaded {_lastReport.Count:N0} devices";
            AppTelemetry.Track("report_import_success", "local_excel");
            Render("Report");
        }catch(Exception ex){AppTelemetry.RecordException(ex, "background_task");AppTelemetry.Track("report_import_failed", "local_excel");MessageBox.Show(this,ex.Message,"DevMonitor",MessageBoxButton.OK,MessageBoxImage.Error);StatusText.Text="Import failed";}
    }
    private void StoreReport(object? s,RoutedEventArgs e)
    {
        var month=new DateTime(_reportStart.Year,_reportStart.Month,1);
        var current=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=current.AddMonths(-1);
        if(month!=current && month!=previous){MessageBox.Show(this,"Only the current and immediately previous calendar month can be stored.","DevMonitor");return;}
        var old=_db.StoredCoverageEnd(month);
        if(old.HasValue && _reportEnd<old.Value){MessageBox.Show(this,$"Older report rejected. Stored coverage ends {old:yyyy-MM-dd}.","DevMonitor");return;}
        var source=_db.GetSetting("last_report_file")??"Imported report";
        _db.ReplaceMonthSnapshot(month,_reportStart,_reportEnd,source,_lastReport);
        _db.AddNotification("Report imported",$"{month:MMMM yyyy} snapshot stored through {_reportEnd:dd MMM yyyy}.","success");
        AppTelemetry.Track("report_snapshot_stored", "local_excel");
        MessageBox.Show(this,"Monthly snapshot stored. Downstream calculations were not automatically refreshed.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
        Render("Report");
    }

    private UIElement EarningsPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var total=snapshots.Sum(x=>x.Active);
        var sundays=0;
        var estimate=PaymentRules.Estimate(total,sundays);
        root.Children.Add(Card(Stack(H("Earning Progress"),P($"Payment cycle: {PaymentRules.PaymentCycleLabel(DateTime.Today)}"),
            new TextBlock{Text=total.ToString("N0"),FontSize=44,FontWeight=FontWeights.Bold},
            P("Current cycle activations — Active remains the payment/progression input."),
            new TextBlock{Text=$"Estimated subtotal: ₦{estimate.Subtotal:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            P($"Fixed tier: ₦{estimate.FixedReward:N0} • FRC cumulative: ₦{estimate.RechargeBonus:N0} — Progressively paid weekly • Sunday bonus: ₦{estimate.SundayBonus:N0}"),
            P(estimate.NextThreshold.HasValue?$"{estimate.ActivationsToNext:N0} activations to the next tier ({estimate.NextThreshold:N0}).":"Highest configured tier reached."),
            B("Share an agent card via Android",(_,_)=>Render("ShareCards"))
        ),Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=430,ItemsSource=snapshots.Select(x=>new{Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Status=x.Flag??"OK"}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ShareCardsPage()
    {
        var root=new StackPanel();
        string Field(JsonElement e,string key)=>e.TryGetProperty(key,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():"";
        var source=new ComboBox{ItemsSource=new[]{"SMS Checker","Loaded Report"},SelectedIndex=1,Width=220,Height=36,Margin=new Thickness(0,0,0,10)};
        var agents=_db.AndroidRecords("agents").Select(r=>ReadAndroidPayload(r)).Select(a=>new ShareAgentRow(
            Field(a,"id"),Field(a,"name"),_db.AndroidRecords("agent_devices").Select(ReadAndroidPayload).Where(d=>Field(d,"agent_id")==Field(a,"id")).Select(d=>DevMonitorDb.Canonical(Field(d,"code"))).Distinct(StringComparer.OrdinalIgnoreCase).ToList()))
            .Where(a=>!string.IsNullOrWhiteSpace(a.Id)&&!string.IsNullOrWhiteSpace(a.Name)).OrderBy(a=>a.Name).ToList();
        var grid=new DataGrid{ItemsSource=agents,AutoGenerateColumns=false,IsReadOnly=true,SelectionMode=DataGridSelectionMode.Extended,SelectionUnit=DataGridSelectionUnit.FullRow,Height=340,MinHeight=180,CanUserAddRows=false};
        grid.Columns.Add(new DataGridTextColumn{Header="Agent",Binding=new System.Windows.Data.Binding(nameof(ShareAgentRow.Name)),Width=new DataGridLength(2,DataGridLengthUnitType.Star)});
        grid.Columns.Add(new DataGridTextColumn{Header="Linked devices",Binding=new System.Windows.Data.Binding(nameof(ShareAgentRow.DeviceCount)),Width=110});
        grid.Columns.Add(new DataGridTextColumn{Header="Device codes",Binding=new System.Windows.Data.Binding(nameof(ShareAgentRow.DeviceSummary)),Width=new DataGridLength(3,DataGridLengthUnitType.Star)});
        root.Children.Add(Card(Stack(H("Prepare on PC, share from Android",22),P("Select agents and one source. DevMonitor creates a separate PNG for each linked device, carrying the existing payment estimate from that source and queues the cards for the paired Android phone. The phone opens its native share sheet after the next successful sync. Figures are never mixed between sources."),new TextBlock{Text="Figures source",Margin=new Thickness(0,0,0,5)},source,grid,
            new WrapPanel{Children={B("Select all",(_,_)=>{grid.SelectAll();}),B("Clear selection",(_,_)=>grid.UnselectAll()),B("Prepare & queue for Android",(_,_)=>QueueShareCards(source.SelectedItem?.ToString()??"Loaded Report",grid.SelectedItems.Cast<ShareAgentRow>().ToList()))}},
            P($"Agents available from the paired Android archive: {agents.Count}. Link devices in Android's Agents Database and sync first. Pending PC→Android cards: {_db.AndroidRecords("share_queue").Count}.")
        ),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private sealed record ShareAgentRow(string Id,string Name,List<string> Devices)
    {
        public int DeviceCount=>Devices.Count;
        public string DeviceSummary=>string.Join(", ",Devices.Take(4))+(Devices.Count>4?$" +{Devices.Count-4}":"");
    }

    private string? GetSmsCheckerCardEligibilityIssue(string device,DateTime asOf)
    {
        // Strict counterpart of Android v275. Eligibility is evidence-based on every
        // day of the month: never treat a missing history/baseline as zero.
        var canonical=DevMonitorDb.Canonical(device);
        var monthStart=new DateTime(asOf.Year,asOf.Month,1);
        var previousMonth=monthStart.AddMonths(-1);
        var boundary=monthStart.AddDays(19); // payment-cycle baseline cutoff: day 20
        var phoneRows=_db.PhoneResults(device);
        bool Good(PhoneQueryResult x)=>x.Status.Equals("OK",StringComparison.OrdinalIgnoreCase)&&x.Active.HasValue;

        var hasPreviousPhoneHistory=phoneRows.Any(x=>Good(x)&&x.ResultAt.Date>=previousMonth.Date&&x.ResultAt.Date<monthStart.Date);
        var previousReportStart=_db.StoredCoverageStart(previousMonth);
        var previousReportEnd=_db.StoredCoverageEnd(previousMonth);
        var previousReportRow=_db.LoadMonth(previousMonth).FirstOrDefault(x=>DevMonitorDb.Canonical(x.DeviceId)==canonical);
        var hasPreviousReportHistory=previousReportRow!=null&&previousReportRow.Daily.Any(k=>k.Key.Date>=previousMonth.Date&&k.Key.Date<monthStart.Date)
            &&previousReportStart.HasValue&&previousReportEnd.HasValue
            &&previousReportStart.Value.Date<monthStart.Date&&previousReportEnd.Value.Date>=previousMonth.Date;
        if(!hasPreviousPhoneHistory&&!hasPreviousReportHistory)
            return "no device-specific Active history from the previous calendar month";

        // SMS Checker cards must have a real current-month Active result from the phone.
        // HQ rows may establish history, but must not be substituted as SMS Checker figures.
        var hasCurrentPhoneActive=phoneRows.Any(x=>Good(x)&&x.ResultAt.Date>=monthStart.Date&&x.ResultAt.Date<=asOf.Date);
        if(!hasCurrentPhoneActive)
            return "no successful current-month Active result from SMS Checker";

        if(asOf.Day>=21){
            var hasPhoneBaseline=phoneRows.Any(x=>Good(x)&&x.ResultAt.Date>=monthStart.Date&&x.ResultAt.Date<=boundary.Date);
            var currentReportStart=_db.StoredCoverageStart(monthStart);
            var currentReportEnd=_db.StoredCoverageEnd(monthStart);
            var currentReportRow=_db.LoadMonth(monthStart).FirstOrDefault(x=>DevMonitorDb.Canonical(x.DeviceId)==canonical);
            var hasReportBaseline=currentReportRow!=null&&currentReportRow.Daily.Any(k=>k.Key.Date<=boundary.Date&&k.Key.Date>=monthStart.Date)
                &&currentReportStart.HasValue&&currentReportStart.Value.Date<=monthStart.Date
                &&currentReportEnd.HasValue&&currentReportEnd.Value.Date>=boundary.Date;
            if(!hasPhoneBaseline&&!hasReportBaseline)
                return "missing cumulative Active baseline through the 20th";

            var hasPostBoundaryPhoneActive=phoneRows.Any(x=>Good(x)&&x.ResultAt.Date>boundary.Date&&x.ResultAt.Date<=asOf.Date);
            if(!hasPostBoundaryPhoneActive)
                return "no successful post-20th Active result yet";
        }
        return null;
    }

    private void QueueShareCards(string source,List<ShareAgentRow> selected)
    {
        if(selected.Count==0){MessageBox.Show(this,"Select at least one agent.","Share earnings cards");return;}
        var cards=new List<(string Agent,string Device,int? Today,int? Mtd,int? Active,int SundayActivations,string Period,string AsOf)>();
        var skipped=new List<string>();
        foreach(var agent in selected){
            if(agent.Devices.Count==0){skipped.Add(agent.Name+" (no linked devices)");continue;}
            foreach(var device in agent.Devices){
                int? today=null,mtd=null,active=null;int sundayActivations=0;string period="Current available period",asOf="Unknown";
                if(source=="SMS Checker"){
                    var eligibilityIssue=GetSmsCheckerCardEligibilityIssue(device,DateTime.Today);
                    if(eligibilityIssue!=null){
                        skipped.Add(device+" ("+eligibilityIssue+"; no progression card created)");
                        continue;
                    }
                }
                if(source=="Loaded Report"){
                    var currentMonth=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
                    var previousMonth=currentMonth.AddMonths(-1);
                    var loadedMonth=_db.StoredCoverageEnd(currentMonth).HasValue?currentMonth:(_db.StoredCoverageEnd(previousMonth).HasValue?previousMonth:(DateTime?)null);
                    if(loadedMonth.HasValue){
                        var coverageEnd=_db.StoredCoverageEnd(loadedMonth.Value)!.Value.Date;
                        var rowExists=_db.LoadMonth(loadedMonth.Value).Any(x=>DevMonitorDb.Canonical(x.DeviceId)==DevMonitorDb.Canonical(device));
                        // Reuse the existing Device Monitor projection, but accept it only when it is truly HQ-sourced.
                        // If a newer phone/SMS value would override it, do not mix sources: skip this card instead.
                        var snap=rowExists?_db.DeviceSnapshots(new[]{device},coverageEnd).FirstOrDefault():null;
                        if(snap!=null && snap.Source.Equals("HQ",StringComparison.OrdinalIgnoreCase)){
                            today=snap.Today;mtd=snap.Mtd;active=snap.Active;
                            // Sunday bonuses are counted only from the same selected HQ report,
                            // within the active payment cycle, using the established rule threshold.
                            var sourceRow=_db.LoadMonth(loadedMonth.Value).FirstOrDefault(x=>DevMonitorDb.Canonical(x.DeviceId)==DevMonitorDb.Canonical(device));
                            if(sourceRow!=null){
                                var (cycleStart,cycleEnd)=PaymentRules.PaymentCycleForDate(coverageEnd);
                                sundayActivations=sourceRow.Daily.Where(k=>k.Key.Date>=cycleStart.Date&&k.Key.Date<=coverageEnd.Date&&k.Key.DayOfWeek==DayOfWeek.Sunday&&k.Value>=PaymentRules.SundayMinimumActivations).Sum(k=>Math.Max(0,k.Value));
                            }
                            asOf=coverageEnd.ToString("dd MMM yyyy");period=$"Loaded report • {loadedMonth.Value:MMMM yyyy} through {coverageEnd:dd MMM}";
                        }
                    }
                }else{
                    var q=_db.PhoneResults(device).OrderByDescending(x=>x.ResultAt).FirstOrDefault();
                    if(q!=null && q.Status.Equals("OK",StringComparison.OrdinalIgnoreCase)){today=q.Today;mtd=q.Mtd;active=q.Active;asOf=q.ResultAt.ToString("dd MMM yyyy HH:mm");period="SMS Checker latest result";}
                }
                if(today is null&&mtd is null&&active is null){skipped.Add(device+" (no figures in "+source+")");continue;}
                cards.Add((agent.Name,device,today,mtd,active,sundayActivations,period,asOf));
            }
        }
        if(cards.Count==0){MessageBox.Show(this,"No shareable figures were found in the selected source. No cards were queued.","Share earnings cards");return;}
        if(cards.Count>20){MessageBox.Show(this,$"This batch contains {cards.Count} cards. Select fewer agents; the safe transfer limit is 20 images per batch.","Share earnings cards");return;}
        var stamp=DateTime.Now.ToString("yyyyMMdd_HHmmss");int queued=0;
        foreach(var c in cards){
            var id=Guid.NewGuid().ToString("N");var estimate=c.Active.HasValue?PaymentRules.Estimate(c.Active.Value,c.SundayActivations):null;
            var bytes=RenderSharePng(c.Agent,c.Device,source,c.Period,c.AsOf,c.Today,c.Mtd,c.Active,estimate);
            var payload=JsonSerializer.Serialize(new{id,fileName=$"DevMonitor_{stamp}_{queued+1}.png",pngBase64=Convert.ToBase64String(bytes),caption=$"{c.Agent} — DevMonitor earnings estimate ({source}; {c.Period})",agent=c.Agent,device=c.Device,source,period=c.Period,asOf=c.AsOf,activations=c.Active,sundayActivations=c.SundayActivations,estimatedSubtotal=estimate?.Subtotal,fixedReward=estimate?.FixedReward,rechargeBonus=estimate?.RechargeBonus,sundayBonus=estimate?.SundayBonus});
            _db.MergeAndroidRecord("share_queue",id,payload);queued++;
        }
        _db.AddNotification("Earnings cards queued",$"Queued {queued} PNG card(s) for Android sharing from {source}.","share");
        var message=$"Queued {queued} card(s) for Android. Open DevMonitor on the phone and allow the next sync to complete; Android will present the native sharing sheet. Figures came only from {source}."+(skipped.Count>0?$"\n\nSkipped {skipped.Count}: {string.Join(", ",skipped.Take(8))}":"");
        MessageBox.Show(this,message,"Share earnings cards",MessageBoxButton.OK,MessageBoxImage.Information);Render("ShareCards");
    }

    private static byte[] RenderSharePng(string agent,string device,string source,string period,string asOf,int? today,int? mtd,int? active,IncentiveEstimate? estimate)
    {
        // Presentation only: this renderer consumes the estimate already selected for the payment card.
        // Do not recalculate payment figures inside the card renderer.
        const int width=1080,height=1630;var visual=new DrawingVisual();
        using(var dc=visual.RenderOpen()){
            dc.DrawRectangle(new LinearGradientBrush(Color.FromRgb(232,243,252),Color.FromRgb(236,250,242),90),null,new Rect(0,0,width,height));
            dc.DrawRoundedRectangle(Brushes.White,new Pen(new SolidColorBrush(Color.FromRgb(210,229,244)),2),new Rect(28,28,width-56,height-56),42,42);
            var header=new LinearGradientBrush();header.StartPoint=new Point(0,0);header.EndPoint=new Point(1,1);header.GradientStops.Add(new GradientStop(Color.FromRgb(7,27,54),0));header.GradientStops.Add(new GradientStop(Color.FromRgb(7,91,96),0.62));header.GradientStops.Add(new GradientStop(Color.FromRgb(13,158,120),1));
            dc.DrawRoundedRectangle(header,null,new Rect(28,28,width-56,360),42,42);dc.DrawRectangle(header,null,new Rect(28,315,width-56,73));
            // Keep the flyer-like photographic hero present on PC-created cards too. The photo is
            // an embedded app asset so exported PNGs do not depend on external network access.
            try { var heroUri=new Uri("pack://application:,,,/Assets/earnings_hero_photo.png",UriKind.Absolute); var heroImage=new BitmapImage(heroUri); dc.DrawImage(heroImage,new Rect(590,28,462,350)); } catch { /* retain branded fallback if asset loading fails */ }
            dc.DrawEllipse(new SolidColorBrush(Color.FromArgb(35,40,215,194)),null,new Point(1000,92),150,150);dc.DrawEllipse(new SolidColorBrush(Color.FromArgb(24,40,215,194)),null,new Point(950,145),92,92);
            void Text(string value,double x,double y,double size,Brush brush,bool bold=false){
                var ft=new FormattedText(value,System.Globalization.CultureInfo.InvariantCulture,FlowDirection.LeftToRight,
                    new Typeface(new FontFamily("Segoe UI"),FontStyles.Normal,bold?FontWeights.SemiBold:FontWeights.Normal,FontStretches.Normal),size,brush,1.0);
                ft.SetFontSize(size,0,value.Length);
                dc.DrawText(ft,new Point(x,y));
            }
            void FitText(string value,double x,double y,double maxWidth,double startSize,double minSize,Brush brush,bool bold=false){
                var fittedSize=startSize;
                FormattedText measured;
                do {
                    measured=new FormattedText(value,System.Globalization.CultureInfo.InvariantCulture,FlowDirection.LeftToRight,
                        new Typeface(new FontFamily("Segoe UI"),FontStyles.Normal,bold?FontWeights.SemiBold:FontWeights.Normal,FontStretches.Normal),fittedSize,brush,1.0);
                    if(measured.WidthIncludingTrailingWhitespace<=maxWidth || fittedSize<=minSize) break;
                    fittedSize-=1;
                } while(fittedSize>=minSize);
                measured.SetFontSize(fittedSize,0,value.Length);
                dc.DrawText(measured,new Point(x,y));
            }
            string Clip(string v,int n)=>v.Length>n?v[..n]:v;
            Text("DM",72,56,44,Brushes.White,true);Text("DevMonitor",154,60,42,Brushes.White,true);Text("EARNINGS GROWTH  •  PERFORMANCE",156,116,23,new SolidColorBrush(Color.FromRgb(126,243,208)),true);
            Text("YOUR PROGRESS. YOUR NEXT MILESTONE.",72,190,24,Brushes.White,true);Text(Clip(agent,28),72,245,36,Brushes.White,true);Text("DEVICE  •  "+Clip(device,34),72,298,22,new SolidColorBrush(Color.FromRgb(235,255,248)),true);
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(239,248,244)),null,new Rect(58,410,width-116,230),32,32);
            Text(estimate!=null?"CURRENT PAYMENT ESTIMATE":"ESTIMATE UNAVAILABLE",92,438,23,new SolidColorBrush(Color.FromRgb(8,127,91)),true);
            Text(estimate!=null?$"₦{estimate.Subtotal:N0}":"Active figure unavailable",88,478,66,new SolidColorBrush(Color.FromRgb(5,92,70)),true);
            FitText(estimate!=null?$"Fixed ₦{estimate.FixedReward:N0}  •  FRC ₦{estimate.RechargeBonus:N0} (Progressively paid weekly)  •  Sunday ₦{estimate.SundayBonus:N0}":"No estimate is calculated without Active",94,565,900,22,17,new SolidColorBrush(Color.FromRgb(55,76,75)),true);
            Text("Monitoring estimate • official payment remains final",94,602,20,new SolidColorBrush(Color.FromRgb(55,76,75)));
            FitText(source+"  |  "+period,72,680,920,23,18,new SolidColorBrush(Color.FromRgb(36,81,138)),true);
            var rows=new[]{("TODAY",today),("MONTH TO DATE",mtd),("ACTIVE",active)};double y=720;int idx=0;
            foreach(var row in rows){var rowBg=idx%2==0?Color.FromRgb(242,248,251):Color.FromRgb(255,255,255);dc.DrawRoundedRectangle(new SolidColorBrush(rowBg),new Pen(new SolidColorBrush(Color.FromRgb(220,234,241)),1),new Rect(62,y,width-124,66),18,18);dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(24,173,104)),null,new Rect(62,y,12,66),6,6);Text(row.Item1,98,y+20,24,new SolidColorBrush(Color.FromRgb(51,72,78)),true);FitText(row.Item2?.ToString("N0")??"Not available",700,y+18,260,30,24,new SolidColorBrush(Color.FromRgb(18,61,60)),true);y+=76;idx++;}
            // Only activation count drives this graphic. It does not infer or display a payment estimate.
            var thresholds=new[]{30,50,70,100,150,200,250,300};int reached=active??0;var next=thresholds.FirstOrDefault(t=>reached<t);bool hasNext=next>0;
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(239,247,250)),new Pen(new SolidColorBrush(Color.FromRgb(216,231,241)),1),new Rect(58,970,width-116,250),30,30);
            Text("ACTIVATION TIER PROGRESSION",88,995,25,new SolidColorBrush(Color.FromRgb(16,41,68)),true);
            FitText(active.HasValue?$"Based on {reached:N0} active activations":"Progression unavailable — Active figure missing",88,1030,900,21,18,new SolidColorBrush(Color.FromRgb(55,75,96)));
            double left=110,right=970,trackY=1090;dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(212,222,234)),null,new Rect(left,trackY-6,right-left,12),6,6);
            double fraction= !active.HasValue?0:Math.Clamp((double)reached/thresholds[^1],0,1);if(fraction>0)dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(25,168,91)),null,new Rect(left,trackY-6,(right-left)*fraction,12),6,6);
            for(int i=0;i<thresholds.Length;i++){double x=left+(right-left)*i/(thresholds.Length-1);bool done=active.HasValue&&reached>=thresholds[i];bool isNext=active.HasValue&&thresholds[i]==next;var c=done?Color.FromRgb(25,168,91):isNext?Color.FromRgb(38,116,232):Color.FromRgb(185,198,216);dc.DrawEllipse(new SolidColorBrush(c),null,new Point(x,trackY),isNext?18:14,isNext?18:14);Text(thresholds[i].ToString(),x-18,1120,18,new SolidColorBrush(done||isNext?c:Color.FromRgb(113,128,150)),true);}
            string encouragement=!active.HasValue?"Load a valid Active figure to show activation progression.":!hasNext?"TOP REACH STEP! Sustain the momentum and keep service quality high.":reached>=250?"EXCELLENT REACH! Keep building toward the 300-activation milestone.":reached>=200?"STRONG PROGRESS! Your next reach step is 250 activations.":reached>=150?"GOOD MOMENTUM! Keep moving toward the 200-activation step.":reached>=100?"YOU'RE BUILDING REACH! Aim for the 150-activation step next.":reached>=70?"NICE PROGRESS! Keep connecting toward 100 activations.":reached>=50?"YOU'RE GAINING GROUND! The 70-activation step is next.":reached>=30?"GOOD START! Grow toward the 50-activation step.":"EVERY CONNECTION COUNTS. Build toward the 30-activation step.";
            FitText(encouragement,88,1170,900,22,18,new SolidColorBrush(Color.FromRgb(8,127,91)),true);
            // Next-tier projection uses the already-calculated estimate. Keep the current qualified
            // Sunday bonus constant, do not predict unearned Sunday bonuses, and never include FRC.
            if(estimate!=null && estimate.NextThreshold.HasValue && estimate.NextReward.HasValue){
                var projected=estimate.NextReward.Value+estimate.SundayBonus;
                var gain=projected-estimate.Subtotal;
                dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(234,243,255)),new Pen(new SolidColorBrush(Color.FromRgb(202,222,245)),1),new Rect(58,1235,width-116,215),26,26);
                Text("WHAT YOUR NEXT TIER COULD PAY",88,1265,23,new SolidColorBrush(Color.FromRgb(36,81,138)),true);
                FitText($"Add {estimate.ActivationsToNext:N0} activations to reach {estimate.NextThreshold.Value:N0}",88,1298,900,22,18,new SolidColorBrush(Color.FromRgb(55,75,96)));
                Text("PROJECTED MAIN ESTIMATE",88,1333,18,new SolidColorBrush(Color.FromRgb(55,75,96)),true);
                Text($"₦{projected:N0}",88,1380,36,new SolidColorBrush(Color.FromRgb(8,127,91)),true);
                Text($"+₦{gain:N0} more",650,1380,26,new SolidColorBrush(Color.FromRgb(8,127,91)),true);
                FitText("Keeps current qualified Sunday bonus; future Sunday bonus not assumed. FRC excluded.",88,1420,900,17,14,new SolidColorBrush(Color.FromRgb(55,75,96)));
            } else if(estimate!=null){
                dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(234,243,255)),new Pen(new SolidColorBrush(Color.FromRgb(202,222,245)),1),new Rect(58,1235,width-116,215),26,26);
                Text("NEXT-TIER OPPORTUNITY",88,1275,23,new SolidColorBrush(Color.FromRgb(36,81,138)),true);
                Text("Highest configured activation tier reached.",88,1320,22,new SolidColorBrush(Color.FromRgb(8,127,91)),true);
                FitText("FRC remains separate; future Sunday bonus is not assumed.",88,1365,900,20,17,new SolidColorBrush(Color.FromRgb(55,75,96)));
            } else {
                dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(242,246,250)),new Pen(new SolidColorBrush(Color.FromRgb(216,231,241)),1),new Rect(58,1235,width-116,215),26,26);
                Text("NEXT-TIER OPPORTUNITY",88,1275,23,new SolidColorBrush(Color.FromRgb(36,81,138)),true);
                Text("Unavailable until a valid Active figure is available.",88,1320,21,new SolidColorBrush(Color.FromRgb(55,75,96)));
            }
            Text("SOURCE: "+Clip(source,42),70,1490,19,new SolidColorBrush(Color.FromRgb(20,91,73)),true);Text("PERIOD: "+Clip(period,58),70,1520,18,new SolidColorBrush(Color.FromRgb(49,90,84)));Text("SOURCE FIGURES ONLY • NO CROSS-SOURCE FILL",70,1570,18,new SolidColorBrush(Color.FromRgb(180,55,55)),true);
        }
        // Rasterize the entire visual at 3x resolution; retain vector text/shapes until final
        // rasterization so labels, milestone markers, borders and the footer are as crisp as the photo.
        var bmp=new RenderTargetBitmap(width*3,height*3,288,288,PixelFormats.Pbgra32);bmp.Render(visual);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bmp));using var ms=new MemoryStream();encoder.Save(ms);return ms.ToArray();
    }

    private UIElement MonitorPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        root.Children.Add(Card(Stack(
            H("Device Monitor"),
            P("Current device activity from the authoritative monthly HQ snapshots. Payment calculations continue to use Active, not MTD."),
            new TextBlock{Text=$"Devices: {snapshots.Count:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            B("Refresh Device Monitor",(_,_)=>Render("Monitor"))
        ),Brushes.SteelBlue));
        root.Children.Add(new DataGrid{ItemsSource=snapshots.Select(x=>new{
            Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Ownership=x.Ownership,Status=x.Flag??"OK"
        }).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=480});
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonthOnMonthPage()
    {
        var root=new StackPanel();
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var currentMonth=new DateTime(today.Year,today.Month,1);
        var previousMonth=currentMonth.AddMonths(-1);
        var currentRows=_db.LoadMonth(currentMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var previousRows=_db.LoadMonth(previousMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var ids=_db.MyDevices().Select(DevMonitorDb.Canonical).ToList();
        var currentEnd=_db.StoredCoverageEnd(currentMonth);
        var previousEnd=_db.StoredCoverageEnd(previousMonth);
        var currentCutoff=Math.Min(today.Day,currentEnd?.Day??0);
        var previousCutoff=Math.Min(currentCutoff,previousEnd?.Day??0);
        var data=new List<(string Device,int Current,int Previous,int Change)>();
        foreach(var id in ids){
            currentRows.TryGetValue(id,out var c); previousRows.TryGetValue(id,out var p);
            var cur=c?.Daily.Where(k=>k.Key.Month==today.Month&&k.Key.Year==today.Year&&k.Key.Day<=currentCutoff).Sum(k=>k.Value)??0;
            var prev=p?.Daily.Where(k=>k.Key.Month==previousMonth.Month&&k.Key.Year==previousMonth.Year&&k.Key.Day<=previousCutoff).Sum(k=>k.Value)??0;
            data.Add((id,cur,prev,cur-prev));
        }
        var grid=new DataGrid{ItemsSource=data.Select(x=>new{Device=x.Device,Current=x.Current,Previous=x.Previous,Change=x.Change,Trend=x.Change>0?"Up":x.Change<0?"Down":"Flat"}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=480};
        root.Children.Add(Card(Stack(
            H("Month-on-Month"),
            P($"User-scoped comparison through the available report cutoff. Current cutoff: day {currentCutoff}; previous-month cutoff: day {previousCutoff}. Missing historical coverage is not treated as zero. Rows: {data.Count:N0}."),
            new TextBlock{Text=$"Current: {currentMonth:MMMM yyyy}  •  Previous: {previousMonth:MMMM yyyy}",FontSize=18,FontWeight=FontWeights.Bold},
            new WrapPanel{Children={
                B("Refresh comparison",(_,_)=>Render("MonthOnMonth")),
                B("Export comparison CSV",(_,_)=>{
                    var lines=data.Select(x=>$"{Csv(x.Device)},{x.Current},{x.Previous},{x.Change},{(x.Change>0?"Up":x.Change<0?"Down":"Flat")}");
                    SaveCsv($"DevMonitor_MonthOnMonth_{currentMonth:yyyy_MM}.csv","Device,CurrentMonth,PreviousMonth,Change,Trend",lines);
                })
            }}
        ),Brushes.MediumPurple));
        var role = (_db.GetSetting("profile_role") ?? "AGENT").Trim().ToUpperInvariant();
        var target = role == "AGENT" ? 150 : int.TryParse(_db.GetSetting("profile_monthly_target"), out var configuredTarget) ? configuredTarget : 0;
        var profileName = (_db.GetSetting("profile_name") ?? "").Trim();
        var profileStaff = (_db.GetSetting("profile_staff") ?? profileName).Trim();
        var profilePartner = (_db.GetSetting("profile_partner") ?? profileName).Trim();
        var targetRows = _db.LoadMonth(currentMonth);
        IEnumerable<DeviceRow> targetScope = targetRows;
        if (role == "STAFF")
            targetScope = targetRows.Where(x => !string.IsNullOrWhiteSpace(profileStaff) && string.Equals(x.StaffName.Trim(), profileStaff, StringComparison.OrdinalIgnoreCase));
        else if (role == "PARTNER")
            targetScope = targetRows.Where(x => (!string.IsNullOrWhiteSpace(profilePartner) && string.Equals(x.PartnerName.Trim(), profilePartner, StringComparison.OrdinalIgnoreCase)) || (!string.IsNullOrWhiteSpace(profilePartner) && string.Equals(x.TradeCode.Trim(), profilePartner, StringComparison.OrdinalIgnoreCase)));
        else {
            var agentIds = _db.MyDevices().Select(DevMonitorDb.Canonical).ToHashSet(StringComparer.OrdinalIgnoreCase);
            targetScope = targetRows.Where(x => agentIds.Contains(DevMonitorDb.Canonical(x.DeviceId)));
        }
        var targetActive = targetScope.Sum(x => x.Daily.Where(k => k.Key.Year == today.Year && k.Key.Month == today.Month && k.Key.Day <= currentCutoff).Sum(k => k.Value));
        var monthDays = DateTime.DaysInMonth(today.Year, today.Month);
        var expectedDay = Math.Min(today.Day, currentCutoff > 0 ? currentCutoff : today.Day);
        var expected = target > 0 ? (int)Math.Ceiling(target * expectedDay / (double)monthDays) : 0;
        var achievement = expected > 0 ? targetActive * 100.0 / expected : 0;
        var fullMonthProgress = target > 0 ? targetActive * 100.0 / target : 0;
        root.Children.Add(Card(Stack(
            H("MONTHLY TARGET", 20),
            P(role == "AGENT" ? "Agent target is fixed at 150 activations per month." : role == "STAFF" ? "All devices assigned to this staff member contribute to the monthly target." : "All devices belonging to this partner contribute to the monthly target."),
            new TextBlock { Text = target > 0 ? $"{targetActive:N0} / {target:N0} activations" : "Set a monthly target in Profile & Company to enable target tracking.", FontSize = 25, FontWeight = FontWeights.Bold },
            target > 0 ? new ProgressBar { Minimum = 0, Maximum = 100, Value = Math.Clamp(achievement, 0, 100), Height = 14 } : new TextBlock { Text = "Target not configured", Foreground = Brushes.Gray },
            P(target > 0 ? $"Achievement against expected-to-date: {achievement:0.0}%  •  Expected by day {expectedDay}: {expected:N0}  •  Actual: {targetActive:N0}" : "Staff and Partner profiles must have a target greater than zero."),
            P(target > 0 ? $"Full-month target progress: {fullMonthProgress:0.0}%" : "")
        ), Brushes.DarkCyan));
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement SmsPage()
    {
        var root=new StackPanel();
        var code=new TextBox{Height=38,Width=220};
        var status=new ComboBox{ItemsSource=new[]{"OK","ERROR","PENDING","ZERO_DEVICES"},SelectedIndex=0,Height=38,Width=150,Margin=new Thickness(8,0,8,0),ToolTip="Use ZERO_DEVICES only when the phone workflow explicitly reports no assigned devices."};
        var today=new TextBox{Height=38,Width=90}; var mtd=new TextBox{Height=38,Width=90}; var active=new TextBox{Height=38,Width=90};
        var b48=new TextBox{Height=38,Width=90}; var b96=new TextBox{Height=38,Width=90};
        root.Children.Add(Card(Stack(
            H("SMS Checker"),
            P("Windows cannot directly receive an Android SIM's SMS. It can, however, store and use results delivered from the phone app or pasted/imported locally. No SMS is sent from Windows."),
            new WrapPanel{Children={
                new TextBlock{Text="Device",VerticalAlignment=VerticalAlignment.Center},code,
                new TextBlock{Text="Status",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(12,0,0,0)},status
            }},
            new WrapPanel{Children={
                new TextBlock{Text="Today",VerticalAlignment=VerticalAlignment.Center},today,
                new TextBlock{Text="MTD",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},mtd,
                new TextBlock{Text="Active",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},active,
                new TextBlock{Text="48h",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},b48,
                new TextBlock{Text="96h",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},b96
            }},
            B("Store phone result",(_,_)=>{
                if(string.IsNullOrWhiteSpace(code.Text)){MessageBox.Show(this,"Enter a device code.");return;}
                int? Num(string x)=>int.TryParse(x,out var n)?n:null;
                _db.SavePhoneResult(new PhoneQueryResult(DevMonitorDb.Canonical(code.Text),status.SelectedItem?.ToString()??"OK",Num(today.Text),Num(mtd.Text),Num(active.Text),Num(b48.Text),Num(b96.Text),DateTime.UtcNow,"Manual/local phone result"));
                _db.AddNotification("Phone result stored",$"Result stored for {DevMonitorDb.Canonical(code.Text)}.","sms");
                Render("Sms");
            })
        ),Brushes.SteelBlue));

        var phone=_db.PhoneResults();
        var phoneSearch=new TextBox{Width=280,Height=38,Margin=new Thickness(0,0,8,8),ToolTip="Search device code or status"};
        var phoneGrid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=420};
        var phoneCount=new TextBlock{Text=$"Stored phone results: {phone.Count:N0}",FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,8)};
        void LoadPhoneResults(){
            var q=phoneSearch.Text.Trim();
            var filtered=_db.PhoneResults().Where(x=>string.IsNullOrWhiteSpace(q)||x.DeviceId.Contains(DevMonitorDb.Canonical(q),StringComparison.OrdinalIgnoreCase)||x.Status.Contains(q,StringComparison.OrdinalIgnoreCase)).Take(500).ToList();
            phoneGrid.ItemsSource=filtered.Select(x=>new{Device=x.DeviceId,Status=x.Status,Today=x.Today,MTD=x.Mtd,Active=x.Active,Bar48=x.Bar48,Bar96=x.Bar96,Received=x.ResultAt.ToLocalTime().ToString("dd MMM yyyy HH:mm")}).ToList();
            phoneCount.Text=$"Matching phone results: {filtered.Count:N0}";
        }
        phoneSearch.TextChanged+=(_,_)=>LoadPhoneResults();
        root.Children.Add(Card(Stack(
            H("Phone results & search",18),
            P("Search by device code or status, including explicit ZERO_DEVICES results. These records remain local/offline; Device Monitor prefers a phone result only when newer than the stored HQ report."),
            new WrapPanel{Children={phoneSearch,B("Clear search",(_,_)=>phoneSearch.Clear())}},phoneCount,phoneGrid
        ),Brushes.SteelBlue));
        LoadPhoneResults();

        var sms=_db.Sms();
        root.Children.Add(Card(Stack(
            H($"Raw SMS history ({sms.Count:N0})",18),
            P("Raw SMS records are retained for audit/review. They are not required for Windows calculations once a structured phone result has been stored."),
            new DataGrid{ItemsSource=sms.Select(x=>new{Received=x.Received.ToString("yyyy-MM-dd HH:mm"),Sender=x.Sender,Body=x.Body}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=300}
        )));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement AgentsPage()
    {
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(month);
        var groups=rows.GroupBy(r=>string.IsNullOrWhiteSpace(r.PartnerName)?"Unassigned":r.PartnerName).Select(g=>new{Partner=g.Key,Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Region=string.Join(", ",g.Select(x=>x.Region).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Take(3)),Activations=g.Sum(x=>x.Daily.Where(d=>d.Key.Month==month.Month&&d.Key.Year==month.Year).Sum(d=>d.Value))}).OrderByDescending(x=>x.Activations).ToList();
        var root=new StackPanel();root.Children.Add(Card(Stack(H("Agents & Partners"),P("A working management view derived from the authoritative HQ report. Partner/device counts and current-month activity update whenever the report snapshot is refreshed."),H($"{groups.Count} partner groups",17),new WrapPanel{Children={B("Open My Devices",(_,_)=>Render("Devices")),B("Open Device Monitor",(_,_)=>Render("Monitor")),B("Create follow-up",(_,_)=>Render("Tasks"))}}),Brushes.CadetBlue));
        root.Children.Add(Card(new DataGrid{ItemsSource=groups,IsReadOnly=true,AutoGenerateColumns=true,Height=430},Brushes.CadetBlue));
        var androidAgents=_db.AndroidRecords("agents").Select(ReadAndroidPayload).ToList();
        var androidPhones=_db.AndroidRecords("agent_phones").Select(ReadAndroidPayload).ToList();
        var androidEmails=_db.AndroidRecords("agent_emails").Select(ReadAndroidPayload).ToList();
        var androidDevices=_db.AndroidRecords("agent_devices").Select(ReadAndroidPayload).ToList();
        if(androidAgents.Count>0){
            string Field(JsonElement e,string key)=>e.TryGetProperty(key,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():"";
            var linked=androidAgents.Select(a=>{var id=Field(a,"id");var name=Field(a,"name");var photoPath=Field(a,"photo_path");return new{Agent=name,PhotoImage=LoadAgentPhotoPreview(photoPath),PhotoInitials=AgentInitials(name),Address=Field(a,"address"),Latitude=Field(a,"latitude"),Longitude=Field(a,"longitude"),Phones=string.Join(", ",androidPhones.Where(p=>Field(p,"agent_id")==id).Select(p=>Field(p,"phone")+(string.IsNullOrWhiteSpace(Field(p,"label"))?"":" ("+Field(p,"label")+")"))),Emails=string.Join(", ",androidEmails.Where(e=>Field(e,"agent_id")==id).Select(e=>Field(e,"email")+(string.IsNullOrWhiteSpace(Field(e,"label"))?"":" ("+Field(e,"label")+")"))),Devices=string.Join(", ",androidDevices.Where(d=>Field(d,"agent_id")==id).Select(d=>Field(d,"code"))),PhotoStatus=string.IsNullOrWhiteSpace(photoPath)?"No photo saved":"Photo saved on Android; image bytes are not synced to PC"};}).ToList();
            var agentGrid=new DataGrid{ItemsSource=linked,IsReadOnly=true,AutoGenerateColumns=false,Height=300,SelectionMode=DataGridSelectionMode.Single,SelectionUnit=DataGridSelectionUnit.FullRow};
            agentGrid.Columns.Add(new DataGridTemplateColumn{Header="Photo",Width=64,CellTemplate=CreateAgentPhotoTemplate()});
            foreach(var column in new[]{("Agent","Agent"),("Address","Address"),("Latitude","Latitude"),("Longitude","Longitude"),("Phones","Phones"),("Emails","Emails"),("Devices","Devices"),("PhotoStatus","Photo status")}) agentGrid.Columns.Add(new DataGridTextColumn{Header=column.Item2,Binding=new System.Windows.Data.Binding(column.Item1),IsReadOnly=true});
            var openAgentMap=B("Open selected agent in OpenStreetMap",(_,_)=>{
                if(agentGrid.SelectedItem is null){MessageBox.Show(this,"Select a synced agent row first.","Agent location",MessageBoxButton.OK,MessageBoxImage.Information);return;}
                var selected=agentGrid.SelectedItem;var t=selected.GetType();
                string V(string key)=>t.GetProperty(key)?.GetValue(selected)?.ToString()??"";
                if(!double.TryParse(V("Latitude"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out var lat)||!double.TryParse(V("Longitude"),System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out var lon)||lat < -90||lat > 90||lon < -180||lon > 180){MessageBox.Show(this,"This agent has no valid saved latitude/longitude yet. Set the pin on Android, save the agent, then sync again.","No saved pin",MessageBoxButton.OK,MessageBoxImage.Information);return;}
                var url=$"https://www.openstreetmap.org/?mlat={lat.ToString(System.Globalization.CultureInfo.InvariantCulture)}&mlon={lon.ToString(System.Globalization.CultureInfo.InvariantCulture)}#map=17/{lat.ToString(System.Globalization.CultureInfo.InvariantCulture)}/{lon.ToString(System.Globalization.CultureInfo.InvariantCulture)}";
                try{System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url){UseShellExecute=true});}
                catch(Exception ex){MessageBox.Show(this,$"Could not open OpenStreetMap: {ex.Message}","Agent location",MessageBoxButton.OK,MessageBoxImage.Warning);}
            });
            root.Children.Add(Card(Stack(H("Android agent directory & assignments",18),P("Agent contacts, email addresses, saved coordinates and device assignments received from Android are shown alongside the HQ-derived company hierarchy. Android is authoritative for agent records and device links; this Windows view is read-only. Set or change a pin on Android, save the agent, then sync. Use the button below to open a saved pin on OpenStreetMap. OpenStreetMap map data © OpenStreetMap contributors. The directory includes a photo thumbnail slot with an initials placeholder; it renders an image only when an image file is accessible on this PC. Android currently syncs the photo path, not the image bytes, so phone-only photos remain placeholders until image-byte sync is implemented. Changes made on Android appear after the next successful explicit sync."),agentGrid,new WrapPanel{Children={openAgentMap,B("Refresh agent directory",(_,_)=>Render("Agents"))}}),Brushes.SteelBlue));
        }
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private static string AgentInitials(string? name)
    {
        var parts=(name??"").Split(' ',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);
        if(parts.Length==0)return "?";
        return parts.Length==1?parts[0][..1].ToUpperInvariant():(parts[0][..1]+parts[^1][..1]).ToUpperInvariant();
    }

    private static ImageSource? LoadAgentPhotoPreview(string? photoPath)
    {
        try
        {
            if(string.IsNullOrWhiteSpace(photoPath)||!File.Exists(photoPath))return null;
            var bitmap=new BitmapImage();bitmap.BeginInit();bitmap.CacheOption=BitmapCacheOption.OnLoad;bitmap.UriSource=new Uri(Path.GetFullPath(photoPath),UriKind.Absolute);bitmap.DecodePixelWidth=96;bitmap.EndInit();bitmap.Freeze();return bitmap;
        }
        catch{return null;}
    }

    private static DataTemplate CreateAgentPhotoTemplate()
    {
        var grid=new FrameworkElementFactory(typeof(Grid));
        var border=new FrameworkElementFactory(typeof(Border));border.SetValue(Border.WidthProperty,42d);border.SetValue(Border.HeightProperty,42d);border.SetValue(Border.CornerRadiusProperty,new CornerRadius(21));border.SetValue(Border.BackgroundProperty,new SolidColorBrush(Color.FromRgb(226,232,240)));border.SetValue(Border.HorizontalAlignmentProperty,HorizontalAlignment.Center);border.SetValue(Border.VerticalAlignmentProperty,VerticalAlignment.Center);
        var initials=new FrameworkElementFactory(typeof(TextBlock));initials.SetBinding(TextBlock.TextProperty,new System.Windows.Data.Binding("PhotoInitials"));initials.SetValue(TextBlock.FontWeightProperty,FontWeights.SemiBold);initials.SetValue(TextBlock.ForegroundProperty,new SolidColorBrush(Color.FromRgb(71,85,105)));initials.SetValue(TextBlock.HorizontalAlignmentProperty,HorizontalAlignment.Center);initials.SetValue(TextBlock.VerticalAlignmentProperty,VerticalAlignment.Center);border.AppendChild(initials);
        var image=new FrameworkElementFactory(typeof(Image));image.SetBinding(Image.SourceProperty,new System.Windows.Data.Binding("PhotoImage"));image.SetValue(Image.WidthProperty,42d);image.SetValue(Image.HeightProperty,42d);image.SetValue(Image.StretchProperty,Stretch.UniformToFill);image.SetValue(Image.ClipToBoundsProperty,true);image.SetValue(Image.HorizontalAlignmentProperty,HorizontalAlignment.Center);image.SetValue(Image.VerticalAlignmentProperty,VerticalAlignment.Center);
        grid.AppendChild(border);grid.AppendChild(image);return new DataTemplate{VisualTree=grid};
    }

    private static JsonElement ReadAndroidPayload(AndroidRecord record){using var doc=JsonDocument.Parse(record.PayloadJson);return doc.RootElement.Clone();}

    private UIElement MyPartnerPage()
    {
        if (!IsStaffProfile()) return Card(Stack(H("My Partners"), P("This workspace is available only to a saved Staff profile.")), Brushes.MediumPurple);
        var root=new StackPanel();
        var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"DevMonitor");
        Directory.CreateDirectory(dir);
        var path=Path.Combine(dir,"my_partner.db");
        using(var conn=new SqliteConnection($"Data Source={path}")) { conn.Open(); using var cmd=conn.CreateCommand(); cmd.CommandText="CREATE TABLE IF NOT EXISTS partner_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,profile TEXT NOT NULL,partner_name TEXT NOT NULL,trade_code TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL); CREATE TABLE IF NOT EXISTS partner_history(id INTEGER PRIMARY KEY AUTOINCREMENT,profile TEXT NOT NULL,partner_name TEXT NOT NULL,trade_code TEXT NOT NULL DEFAULT '',result TEXT NOT NULL,created_at TEXT NOT NULL);"; cmd.ExecuteNonQuery(); }
        var profile=_db.GetSetting("profile_name") ?? "default";
        var name=new TextBox{MinWidth=230,Height=38,Margin=new Thickness(0,4,8,4)};
        var code=new TextBox{MinWidth=190,Height=38,Margin=new Thickness(0,4,8,4)};
        var notes=new TextBox{MinWidth=250,Height=38,Margin=new Thickness(0,4,8,4)};
        var search=new TextBox{MinWidth=300,Height=38,Margin=new Thickness(0,4,8,4),ToolTip="Search partner name or Trade Code"};
        var matches=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=220,SelectionMode=DataGridSelectionMode.Single};
        var saved=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=210,SelectionMode=DataGridSelectionMode.Single};
        var history=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=150};
        var previewTitle=H("Select a partner to preview the result",18);
        var previewCode=P("The selected partner's full name, Trade Code and available loaded-report details will appear here.");
        var preview=new Border{Background=new SolidColorBrush(Color.FromRgb(239,248,247)),BorderBrush=new SolidColorBrush(Color.FromRgb(39,143,130)),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(22),Child=Stack(previewTitle,previewCode),MinWidth=360};
        object? selectedPartner=null;
        List<object> FindMatches(){
            // Match Android v239/v252 semantics: query the newest retained HQ directory,
            // case-insensitive partial partner-name/Trade-Code matching, unique nonblank
            // Trade Codes, and a compact capped result list. Older month snapshots remain
            // available in Loaded Report but do not pollute the current partner lookup.
            var q=search.Text.Trim();
            var latest=_db.Reports().FirstOrDefault();
            if(latest==null)return new List<object>();
            var rows=_db.LoadMonth(latest.Month)
                .Where(r=>!string.IsNullOrWhiteSpace(r.TradeCode))
                .Where(r=>q.Length==0||r.PartnerName.Contains(q,StringComparison.OrdinalIgnoreCase)||DevMonitorDb.Canonical(r.TradeCode).Contains(DevMonitorDb.Canonical(q)))
                .GroupBy(r=>DevMonitorDb.Canonical(r.TradeCode),StringComparer.OrdinalIgnoreCase)
                .Select(g=>g.First())
                .OrderBy(r=>r.PartnerName,StringComparer.OrdinalIgnoreCase)
                .Take(12)
                .Select(r=>(object)new{Partner=r.PartnerName,TradeCode=r.TradeCode,Region=r.Region,Cluster=r.Cluster,Territory=r.Territory,Staff=r.StaffName,MonthCount=1})
                .ToList();
            return rows;
        }
        void Load(){matches.ItemsSource=FindMatches();using var conn=new SqliteConnection($"Data Source={path}");conn.Open();using var cmd=conn.CreateCommand();cmd.CommandText="SELECT id AS ID,partner_name AS Partner,trade_code AS TradeCode,notes AS Notes,updated_at AS Updated FROM partner_entries WHERE profile=$p ORDER BY partner_name";cmd.Parameters.AddWithValue("$p",profile);var dt=new System.Data.DataTable();using var reader=cmd.ExecuteReader();dt.Load(reader);saved.ItemsSource=dt.DefaultView;using var h=conn.CreateCommand();h.CommandText="SELECT partner_name AS Partner,trade_code AS TradeCode,result AS Result,created_at AS Date FROM partner_history WHERE profile=$p ORDER BY id DESC LIMIT 100";h.Parameters.AddWithValue("$p",profile);var hd=new System.Data.DataTable();using var hr=h.ExecuteReader();hd.Load(hr);history.ItemsSource=hd.DefaultView;}
        void ShowPreview(string partner,string trade,string region,string cluster,string territory,string staff){selectedPartner=new {Partner=partner,TradeCode=trade,Region=region,Cluster=cluster,Territory=territory,Staff=staff};previewTitle.Text=partner;previewCode.Text=$"TRADE CODE  {trade}\nRegion: {region}\nCluster: {cluster}\nTerritory: {territory}\nStaff: {staff}\n\nPartner details from the loaded HQ report. Windows does not send SMS or invent check outcomes.";}
        matches.SelectionChanged+=(_,_)=>{if(matches.SelectedItem is not null){var t=matches.SelectedItem.GetType();string V(string k)=>t.GetProperty(k)?.GetValue(matches.SelectedItem)?.ToString()??"";name.Text=V("Partner");code.Text=V("TradeCode");ShowPreview(V("Partner"),V("TradeCode"),V("Region"),V("Cluster"),V("Territory"),V("Staff"));}};
        saved.SelectionChanged+=(_,_)=>{if(saved.SelectedItem is System.Data.DataRowView row){name.Text=row["Partner"]?.ToString()??"";code.Text=row["TradeCode"]?.ToString()??"";ShowPreview(name.Text,code.Text,"","","","");}};
        var save=B("Add partner to My Partners",(_,_)=>{if(string.IsNullOrWhiteSpace(name.Text)||string.IsNullOrWhiteSpace(code.Text)){MessageBox.Show(this,"Select a loaded-report partner or enter both the partner name and Trade Code.");return;}using var conn=new SqliteConnection($"Data Source={path}");conn.Open();using var cmd=conn.CreateCommand();cmd.CommandText="INSERT INTO partner_entries(profile,partner_name,trade_code,notes,updated_at) VALUES($p,$n,$c,$d,$t)";cmd.Parameters.AddWithValue("$p",profile);cmd.Parameters.AddWithValue("$n",name.Text.Trim());cmd.Parameters.AddWithValue("$c",code.Text.Trim());cmd.Parameters.AddWithValue("$d",notes.Text.Trim());cmd.Parameters.AddWithValue("$t",DateTime.Now.ToString("O"));cmd.ExecuteNonQuery();_db.AddNotification("My Partners entry saved",name.Text.Trim(),"partner");Load();});
        var share=B("Share result as PNG",(_,_)=>{try{preview.Measure(new Size(900,double.PositiveInfinity));preview.Arrange(new Rect(0,0,Math.Max(520,preview.DesiredSize.Width),preview.DesiredSize.Height));preview.UpdateLayout();var width=Math.Max(520,(int)Math.Ceiling(preview.ActualWidth));var height=Math.Max(220,(int)Math.Ceiling(preview.ActualHeight));var bmp=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bmp.Render(preview);var dlg=new SaveFileDialog{Filter="PNG image|*.png",FileName=$"MyPartner-{DevMonitorDb.Canonical(code.Text)}.png"};if(dlg.ShowDialog(this)!=true)return;using var fs=File.Create(dlg.FileName);var enc=new PngBitmapEncoder();enc.Frames.Add(BitmapFrame.Create(bmp));enc.Save(fs);StatusText.Text="Partner result image saved";}catch(Exception ex){MessageBox.Show(this,$"Could not create the partner result image: {ex.Message}","My Partners",MessageBoxButton.OK,MessageBoxImage.Warning);}});
        root.Children.Add(Card(Stack(H("My Partners",22),P("Staff-only partner-code workspace. Search the loaded HQ report by partner name or Trade Code, select a match to populate the official details, save it to your separate partner list, and export an individual partner result as a shareable PNG. This workspace does not change SMS Checker, device setup, payment calculations or HQ snapshots."),H("Find a partner in loaded reports",17),new WrapPanel{Children={search,B("Search partner codes",(_,_)=>matches.ItemsSource=FindMatches()),B("Clear",(_,_)=>{search.Clear();matches.ItemsSource=FindMatches();})}},matches,H("Add partner code",17),P("Examples: partner name ‘Amina Stores’ or Trade Code ‘TRD-2048’. Select a matching loaded-report row to fill the name and official Trade Code."),new WrapPanel{Children={new StackPanel{Children={new TextBlock{Text="Partner full name"},name}},new StackPanel{Children={new TextBlock{Text="Trade Code"},code}},new StackPanel{Children={new TextBlock{Text="Notes (optional)"},notes}}}},new WrapPanel{Children={save,B("Refresh",(_,_)=>Load())}}),Brushes.MediumPurple));
        root.Children.Add(Card(Stack(H("My Partners Result",18),preview,new WrapPanel{Children={share}}),Brushes.DarkCyan));
        root.Children.Add(Card(Stack(H("Saved My Partners",18),saved),Brushes.SteelBlue));
        root.Children.Add(Card(Stack(H("My Partners result history",18),P("Only actual partner-check results received from supported phone-side workflows may be recorded here. This PC screen does not send SMS or manufacture check outcomes."),history),Brushes.DarkCyan));
        Load();return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement TasksPage()
    {
        var root=new StackPanel(); var tasks=_db.Tasks();
        root.Children.Add(Card(Stack(H("Tasks & Follow-ups"),P("Create persistent operational follow-ups and optionally link them to a device, partner or staff member."),
            B("Add Task",(_,_)=>TaskEditor(null))),Brushes.MediumSeaGreen));
        var taskGrid=new DataGrid{ItemsSource=tasks,IsReadOnly=true,AutoGenerateColumns=true,Height=390,SelectionMode=DataGridSelectionMode.Single};
        root.Children.Add(Card(Stack(H($"Open: {tasks.Count(x=>!x.Completed)}  •  Completed: {tasks.Count(x=>x.Completed)}",17),taskGrid,
            new WrapPanel{Children={
                B("Edit selected",(_,_)=>{if(taskGrid.SelectedItem is OperationalTask selected)TaskEditor(selected);else MessageBox.Show(this,"Select a task first.");}),
                B("Toggle complete",(_,_)=>{if(taskGrid.SelectedItem is OperationalTask selected){_db.SetTaskCompleted(selected.Id,!selected.Completed);_db.AddNotification(selected.Completed?"Task reopened":"Task completed",selected.Title,"task");Render("Tasks");}else MessageBox.Show(this,"Select a task first.");}),
                B("Delete selected",(_,_)=>{if(taskGrid.SelectedItem is OperationalTask selected&&MessageBox.Show(this,$"Delete task '{selected.Title}'?","Confirm delete",MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes){_db.DeleteTask(selected.Id);Render("Tasks");}else if(taskGrid.SelectedItem is not OperationalTask)MessageBox.Show(this,"Select a task first.");})
            }}),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void TaskEditor(OperationalTask? existing)
    {
        var w=new Window{Title=existing==null?"New Follow-up":"Edit Follow-up",Width=560,Height=520,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var title=new TextBox{Text=existing?.Title??""}; var details=new TextBox{Text=existing?.Details??"",AcceptsReturn=true,Height=100,TextWrapping=TextWrapping.Wrap};
        var due=new TextBox{Text=existing?.DueDate??"",ToolTip="Optional: YYYY-MM-DD"}; var priority=new ComboBox{ItemsSource=new[]{"LOW","NORMAL","HIGH"},SelectedItem=existing?.Priority??"NORMAL",Margin=new Thickness(0,5,0,9),Height=40};
        var link=new TextBox{Text=existing?.LinkValue??"",ToolTip="Optional device / partner / staff reference"};
        var save=B("Save Task",(_,_)=>{if(string.IsNullOrWhiteSpace(title.Text)){MessageBox.Show(w,"Task title is required.");return;} if(!string.IsNullOrWhiteSpace(due.Text)&&!DateTime.TryParse(due.Text,out _)){MessageBox.Show(w,"Use a valid date such as 2026-10-31.");return;} _db.SaveTask(new OperationalTask(existing?.Id??0,title.Text,details.Text,string.IsNullOrWhiteSpace(due.Text)?null:due.Text,(priority.SelectedItem?.ToString()??"NORMAL"),string.IsNullOrWhiteSpace(link.Text)?null:"REFERENCE",string.IsNullOrWhiteSpace(link.Text)?null:link.Text,existing?.Completed??false,existing?.CreatedAt??DateTime.UtcNow,DateTime.UtcNow));_db.AddNotification("Task saved",title.Text,"task");w.DialogResult=true;w.Close();Render("Tasks");});
        var close=B("Cancel",(_,_)=>w.Close()); var panel=Stack(H(existing==null?"New follow-up":"Edit follow-up",22),new TextBlock{Text="Task title"},title,new TextBlock{Text="Details"},details,new TextBlock{Text="Due date"},due,new TextBlock{Text="Priority"},priority,new TextBlock{Text="Linked reference (optional)"},link,new WrapPanel{Children={save,close}});w.Content=new ScrollViewer{Content=panel};w.ShowDialog();
    }

    private UIElement NotesPage()
    {
        var notes=_db.Notes(); var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Notes"),P("Keep durable operational notes alongside your device and report work. Pin important notes so they stay at the top."),B("Add Note",(_,_)=>NoteEditor(null))),Brushes.MediumPurple));
        root.Children.Add(Card(Stack(H($"{notes.Count} saved notes",17),new DataGrid{ItemsSource=notes.Select(n=>new{Id=n.Id,Title=n.Title,Preview=n.Body.Length>100?n.Body[..100]+"…":n.Body,Pinned=n.Pinned?"Pinned":"",Updated=n.UpdatedAt.ToLocalTime().ToString("dd MMM HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=420}),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void NoteEditor(OperationalNote? existing)
    {
        var w=new Window{Title=existing==null?"New Note":"Edit Note",Width=620,Height=500,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var title=new TextBox{Text=existing?.Title??""};var body=new TextBox{Text=existing?.Body??"",AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,Height=220};var pinned=new CheckBox{Content="Pin this note",IsChecked=existing?.Pinned??false,Margin=new Thickness(0,8,0,12)};
        var save=B("Save Note",(_,_)=>{if(string.IsNullOrWhiteSpace(body.Text)){MessageBox.Show(w,"Note body is required.");return;}_db.SaveNote(new OperationalNote(existing?.Id??0,title.Text,body.Text,null,null,pinned.IsChecked==true,existing?.CreatedAt??DateTime.UtcNow,DateTime.UtcNow));w.DialogResult=true;w.Close();Render("Notes");});
        var cancel=B("Cancel",(_,_)=>w.Close());w.Content=Stack(H(existing==null?"New note":"Edit note",22),new TextBlock{Text="Title (optional)"},title,new TextBlock{Text="Note"},body,pinned,new WrapPanel{Children={save,cancel}});w.ShowDialog();
    }

    private UIElement ActivityPage()
    {
        var ids=_db.MyDevices();var selected=ids.FirstOrDefault()??"";var root=new StackPanel();
        var combo=new ComboBox{ItemsSource=ids,SelectedItem=selected,MinWidth=260,Height=40,Margin=new Thickness(0,5,8,9)};
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=500};
        void Load(){var id=combo.SelectedItem?.ToString()??"";var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(month).FirstOrDefault(x=>DevMonitorDb.Canonical(x.DeviceId)==DevMonitorDb.Canonical(id));var events=new List<object>();if(rows!=null)foreach(var d in rows.Daily.OrderByDescending(x=>x.Key))events.Add(new{Date=d.Key.ToString("dd MMM yyyy"),Type="OBSERVATION",Event="SIMReg",Details=$"Value {d.Value:N0}"});foreach(var t in _db.Tasks().Where(t=>string.Equals(t.LinkValue,id,StringComparison.OrdinalIgnoreCase)))events.Add(new{Date=t.UpdatedAt.ToLocalTime().ToString("dd MMM yyyy"),Type="TASK",Event=t.Completed?"Task completed":"Task updated",Details=t.Title});foreach(var n in _db.Notes().Where(n=>string.Equals(n.LinkValue,id,StringComparison.OrdinalIgnoreCase)))events.Add(new{Date=n.UpdatedAt.ToLocalTime().ToString("dd MMM yyyy"),Type="NOTE",Event="Note updated",Details=n.Title});grid.ItemsSource=events.OrderByDescending(x=>x.GetType().GetProperty("Date")?.GetValue(x)?.ToString()).ToList();}
        combo.SelectionChanged+=(_,_)=>Load();
        root.Children.Add(Card(Stack(H("Device Activity Timeline"),P("A chronological view combining imported HQ observations with linked operational work."),new WrapPanel{Children={new TextBlock{Text="Device",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,8,0)},combo,B("Refresh timeline",(_,_)=>Load())}}),Brushes.SteelBlue));root.Children.Add(Card(grid,Brushes.SteelBlue));Load();return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement InboxPage()
    {
        var notes=_db.Notifications();var grid=new DataGrid{ItemsSource=notes,IsReadOnly=true,AutoGenerateColumns=true,Height=520,SelectionMode=DataGridSelectionMode.Single};var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Notifications / Inbox"),P("Local operational alerts plus Android profile notifications imported during sync. Android notification read state is reconciled by source ID; HQ snapshots and payment data are not involved."),new WrapPanel{Children={B("Mark all read",(_,_)=>{_db.MarkAllNotificationsRead();foreach(var r in _db.AndroidRecords("notifications")){try{using var doc=JsonDocument.Parse(r.PayloadJson);var node=System.Text.Json.Nodes.JsonNode.Parse(r.PayloadJson) as System.Text.Json.Nodes.JsonObject;if(node!=null){node["read"]=true;_db.MergeAndroidRecord(r.Type,r.Key,node.ToJsonString());}}catch{}}Render("Inbox");}),B("Refresh",(_,_)=>Render("Inbox")),B("Open Android notification records",(_,_)=>Render("AndroidData"))}}),Brushes.Orange));
        root.Children.Add(Card(grid,Brushes.Orange));return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ExportsPage()
    {
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=Card(Stack(H("Export Centre"),P("Create user-controlled CSV files from the current local data. Export never changes calculations or the database."),
            B("Export My Devices",(_,_)=>ExportMyDevices()),B("Export Device Monitor",(_,_)=>ExportMonitor()),B("Export Current Month",(_,_)=>ExportMonth()),B("Export Partner Summary",(_,_)=>ExportPartners()),B("Export Tasks & Notes",(_,_)=>ExportOperations())),Brushes.DarkCyan)};
    }
    private void SaveCsv(string suggested,string header,IEnumerable<string> lines){var dlg=new SaveFileDialog{Filter="CSV files|*.csv",FileName=suggested};if(dlg.ShowDialog()!=true)return;System.IO.File.WriteAllText(dlg.FileName,header+Environment.NewLine+string.Join(Environment.NewLine,lines));StatusText.Text=$"Exported {System.IO.Path.GetFileName(dlg.FileName)}";}
    private static string Csv(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
    private void ExportMyDevices()=>SaveCsv("DevMonitor_MyDevices.csv","Device",_db.MyDevices().Select(Csv));
    private void ExportMonitor()=>SaveCsv("DevMonitor_DeviceMonitor.csv","Device,Today,MTD,Active,Status",_db.DeviceSnapshots(_db.MyDevices(),DateTime.Today).Select(x=>$"{Csv(x.DeviceId)},{x.Today},{x.Mtd},{x.Active},{Csv(x.Flag??"OK")}"));
    private void ExportMonth(){var m=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(m);SaveCsv($"DevMonitor_{m:yyyy_MM}.csv","Device,Date,Value,Partner,Region,Cluster,Staff",rows.SelectMany(r=>r.Daily.Select(d=>$"{Csv(r.DeviceId)},{d.Key:yyyy-MM-dd},{d.Value},{Csv(r.PartnerName)},{Csv(r.Region)},{Csv(r.Cluster)},{Csv(r.StaffName)}")));}
    private void ExportOperations(){SaveCsv("DevMonitor_Operations.csv","Type,Title,Details,DueOrUpdated,Status",_db.Tasks().Select(t=>$"TASK,{Csv(t.Title)},{Csv(t.Details)},{Csv(t.DueDate??t.UpdatedAt.ToString("yyyy-MM-dd"))},{t.Completed}").Concat(_db.Notes().Select(n=>$"NOTE,{Csv(n.Title)},{Csv(n.Body)},{n.UpdatedAt:yyyy-MM-dd},")));}
    private void ExportPartners(){
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var rows=_db.LoadMonth(month).GroupBy(r=>string.IsNullOrWhiteSpace(r.PartnerName)?"Unassigned":r.PartnerName)
            .Select(g=>new{Partner=g.Key,Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Activations=g.Sum(x=>x.Daily.Where(d=>d.Key.Year==month.Year&&d.Key.Month==month.Month).Sum(d=>d.Value)),Regions=string.Join("; ",g.Select(x=>x.Region).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct())})
            .OrderByDescending(x=>x.Activations).ToList();
        SaveCsv($"DevMonitor_PartnerSummary_{month:yyyy_MM}.csv","Partner,Devices,CurrentMonthActivations,Regions",rows.Select(x=>$"{Csv(x.Partner)},{x.Devices},{x.Activations},{Csv(x.Regions)}"));
    }


    private UIElement LoadedReportPage()
    {
        var root=new StackPanel();
        var reports=_db.Reports();
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=month.AddMonths(-1);
        var selected=reports.FirstOrDefault()?.Month ?? month;
        var combo=new ComboBox{ItemsSource=reports.Select(r=>$"{r.Month:MMMM yyyy} • {r.CoverageStart:dd MMM}–{r.CoverageEnd:dd MMM} • {r.DeviceCount:N0} devices").ToList(),SelectedIndex=0,MinWidth=420,Height=38};
        var search=new TextBox{Width=300,Height=38,Margin=new Thickness(8,0,8,0),ToolTip="Device, partner, region, staff or trade code"};
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=520};
        void Load()
        {
            var info=reports.ElementAtOrDefault(combo.SelectedIndex);
            if(info==null){grid.ItemsSource=null;return;}
            var rows=_db.SearchReport(info.Month,search.Text);
            grid.ItemsSource=rows.Select(r=>new {
                Device=r.DeviceId,TradeCode=r.TradeCode,Partner=r.PartnerName,Cluster=r.Cluster,
                Region=r.Region,Territory=r.Territory,Staff=r.StaffName,
                Days=r.Daily.Count,Total=r.Daily.Values.Sum()
            }).ToList();
            StatusText.Text=$"{rows.Count:N0} report rows";
        }
        search.KeyDown+=(o,e)=>{if(e.Key==System.Windows.Input.Key.Enter)Load();};
        combo.SelectionChanged+=(o,e)=>Load();
        root.Children.Add(Card(Stack(
            H("Loaded Report"),
            P("The complete imported monthly snapshot remains available offline. Search is local and does not require the internet. The report itself remains authoritative; presentation filtering never deletes data."),
            new WrapPanel{Children={
                new TextBlock{Text="Report",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,8,0)},
                combo,search,B("Search",(_,_)=>Load()),
                B("Show All",(_,_)=>{search.Clear();Load();})
            }},
            H("Available snapshots",17)
        ),Brushes.MediumPurple));
        root.Children.Add(Card(grid,Brushes.MediumPurple));
        Load();
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement TrendsPage()
    {
        var root = new StackPanel();
        var today = PaymentRules.CurrentAwareDate(DateTime.Today);
        var month = new DateTime(today.Year, today.Month, 1);
        var role = (_db.GetSetting("profile_role") ?? "AGENT").Trim().ToUpperInvariant();
        var target = role == "AGENT" ? 150 : int.TryParse(_db.GetSetting("profile_monthly_target"), out var configuredTarget) ? configuredTarget : 0;
        var profileName = (_db.GetSetting("profile_name") ?? "").Trim();
        var profileStaff = (_db.GetSetting("profile_staff") ?? profileName).Trim();
        var profilePartner = (_db.GetSetting("profile_partner") ?? profileName).Trim();
        var rows = _db.LoadMonth(month);
        IEnumerable<DeviceRow> scoped = rows;
        if (role == "STAFF")
            scoped = rows.Where(x => !string.IsNullOrWhiteSpace(profileStaff) && string.Equals(x.StaffName.Trim(), profileStaff, StringComparison.OrdinalIgnoreCase));
        else if (role == "PARTNER")
            scoped = rows.Where(x => (!string.IsNullOrWhiteSpace(profilePartner) && string.Equals(x.PartnerName.Trim(), profilePartner, StringComparison.OrdinalIgnoreCase)) || (!string.IsNullOrWhiteSpace(profilePartner) && string.Equals(x.TradeCode.Trim(), profilePartner, StringComparison.OrdinalIgnoreCase)));
        else
        {
            var ids = _db.MyDevices().Select(DevMonitorDb.Canonical).ToHashSet(StringComparer.OrdinalIgnoreCase);
            scoped = rows.Where(x => ids.Contains(DevMonitorDb.Canonical(x.DeviceId)));
        }
        var targetRows = scoped.ToList();
        var daily = targetRows.SelectMany(r => r.Daily.Where(d => d.Key.Year == today.Year && d.Key.Month == today.Month && d.Key.Date <= today.Date).Select(d => (Date: d.Key.Date, Sales: d.Value)))
            .GroupBy(x => x.Date).OrderBy(g => g.Key).Select(g => new { Date = g.Key, Sales = g.Sum(x => x.Sales) }).ToList();
        var delivered = daily.Sum(x => x.Sales);
        var asOfDay = daily.LastOrDefault()?.Date.Day ?? today.Day;
        var monthDays = DateTime.DaysInMonth(today.Year, today.Month);
        var projected = daily.Count > 0 && asOfDay > 0 ? (int)Math.Round(delivered * monthDays / (double)asOfDay, MidpointRounding.AwayFromZero) : 0;
        var achievement = target > 0 ? delivered * 100.0 / target : (double?)null;
        var remaining = target > 0 ? Math.Max(0, target - delivered) : (int?)null;
        root.Children.Add(Card(Stack(
            H("Monthly Target & Delivery", 22),
            P("Current-month delivery and a simple month-end projection based on the observed daily rate. Only this month is shown; the two-month data-retention model is unchanged."),
            new UniformGrid { Columns = 2, Children = {
                Metric("MONTHLY TARGET", target > 0 ? target.ToString("N0") : "Not set"),
                Metric("DELIVERED SO FAR", delivered.ToString("N0")),
                Metric("PROJECTED MONTH-END", projected.ToString("N0")),
                Metric("TARGET ACHIEVED", achievement.HasValue ? $"{achievement.Value:0.0}%" : "—")
            }},
            P(remaining.HasValue ? $"Remaining target balance: {remaining.Value:N0}" : "Set a monthly target in Profile & Company to show target percentage and remaining balance."),
            target > 0 ? new ProgressBar { Minimum = 0, Maximum = 100, Value = Math.Clamp(achievement ?? 0, 0, 100), Height = 14 } : new TextBlock { Text = "" },
            B("Refresh monthly delivery", (_, _) => Render("Trends"))
        ), Brushes.SteelBlue));
        root.Children.Add(Card(Stack(
            H("Daily sales this month", 18),
            P("Only recorded dates are listed. Missing observation days are not converted to zero sales."),
            new DataGrid { ItemsSource = daily.Select(x => new { Date = x.Date.ToString("dd MMM"), Sales = x.Sales }).ToList(), IsReadOnly = true, AutoGenerateColumns = true, Height = 300 }
        ), Brushes.MediumSeaGreen));
        return new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = root };
    }

    private UIElement ActionCentrePage()
    {
        var open=_db.Tasks(false);
        var unread=_db.Notifications().Where(x=>!x.Read).ToList();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var flagged=snapshots.Where(x=>!string.IsNullOrWhiteSpace(x.Flag)).ToList();
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Action Centre"),P("Prioritized offline actions from tasks, alerts and device/report exceptions."),
            new UniformGrid{Columns=3,Children={Metric("OPEN TASKS",open.Count.ToString()),Metric("UNREAD ALERTS",unread.Count.ToString()),Metric("FLAGGED DEVICES",flagged.Count.ToString())}}
        ),Brushes.Orange));
        if(open.Count>0) root.Children.Add(Card(Stack(H("Tasks requiring attention",18),new DataGrid{ItemsSource=open.Take(20).Select(t=>new{Task=t.Title,Priority=t.Priority,Due=t.DueDate??"—",Reference=t.LinkValue??"—"}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Tasks",(_,_)=>Render("Tasks"))),Brushes.MediumSeaGreen));
        if(unread.Count>0) root.Children.Add(Card(Stack(H("Unread notifications",18),new DataGrid{ItemsSource=unread.Take(20).Select(n=>new{When=n.Timestamp.ToLocalTime().ToString("dd MMM HH:mm"),Title=n.Title,Message=n.Message,Type=n.Kind}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Inbox",(_,_)=>Render("Inbox"))),Brushes.Orange));
        if(flagged.Count>0) root.Children.Add(Card(Stack(H("Device exceptions",18),new DataGrid{ItemsSource=flagged.Select(x=>new{Device=x.DeviceId,Status=x.Flag,Active=x.Active,MTD=x.Mtd}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Device Monitor",(_,_)=>Render("Monitor"))),Brushes.IndianRed));
        if(open.Count==0&&unread.Count==0&&flagged.Count==0) root.Children.Add(Card(Stack(H("All clear",22),P("There are no outstanding local actions or exceptions.")),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ProfilePage()
    {
        var profile=new LocalProfile(
            _db.GetSetting("profile_name")??"Windows User",
            _db.GetSetting("profile_role")??"AGENT",
            _db.GetSetting("profile_partner")??"",
            _db.GetSetting("profile_region")??"",
            _db.GetSetting("profile_territory")??"",
            _db.GetSetting("profile_staff")??"");
        var name=new TextBox{Text=profile.Name};var role=new ComboBox{ItemsSource=new[]{"AGENT","PARTNER","STAFF"},SelectedItem=profile.Role,Height=38};
        var partner=new TextBox{Text=profile.Partner};var region=new TextBox{Text=profile.Region};var territory=new TextBox{Text=profile.Territory};var staff=new TextBox{Text=profile.Staff};var monthlyTarget=new TextBox{Text=(string.Equals(role.SelectedItem?.ToString(),"AGENT",StringComparison.OrdinalIgnoreCase)?"150":(_db.GetSetting("profile_monthly_target")??"")),IsReadOnly=string.Equals(role.SelectedItem?.ToString(),"AGENT",StringComparison.OrdinalIgnoreCase)};role.SelectionChanged+=(_,_)=>{var isAgent=string.Equals(role.SelectedItem?.ToString(),"AGENT",StringComparison.OrdinalIgnoreCase);monthlyTarget.IsReadOnly=isAgent;if(isAgent)monthlyTarget.Text="150";else if(monthlyTarget.Text=="150")monthlyTarget.Text=_db.GetSetting("profile_monthly_target")??"";};
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Profile & Company"),P("The Windows edition keeps its own local profile and derives management views from the imported HQ report. Profile settings work offline."),
            new TextBlock{Text="Name"},name,new TextBlock{Text="Role"},role,new TextBlock{Text="Partner / company"},partner,new TextBlock{Text="Region"},region,new TextBlock{Text="Territory"},territory,new TextBlock{Text="Staff / manager"},staff,new TextBlock{Text="Monthly target (Staff/Partner; Agents fixed at 150)"},monthlyTarget,
            B("Save profile",(_,_)=>{var selectedRole=role.SelectedItem?.ToString()??"AGENT";var targetValue=selectedRole.Equals("AGENT",StringComparison.OrdinalIgnoreCase)?150:(int.TryParse(monthlyTarget.Text,out var enteredTarget)?enteredTarget:0);if(!selectedRole.Equals("AGENT",StringComparison.OrdinalIgnoreCase)&&targetValue<=0){MessageBox.Show(this,"Enter a monthly target greater than zero for Staff or Partner.","Target",MessageBoxButton.OK,MessageBoxImage.Warning);return;}var firstProfileSave=_db.GetSetting("profile_setup_complete")!="true";_db.SetSetting("profile_monthly_target",targetValue.ToString());_db.SetSetting("profile_name",name.Text.Trim());_db.SetSetting("profile_role",selectedRole);_db.SetSetting("profile_partner",partner.Text.Trim());_db.SetSetting("profile_region",region.Text.Trim());_db.SetSetting("profile_territory",territory.Text.Trim());_db.SetSetting("profile_staff",staff.Text.Trim());_db.SetSetting("profile_setup_complete","true");if(firstProfileSave&&selectedRole.Equals("STAFF",StringComparison.OrdinalIgnoreCase))DevMonitorVoiceNotifications.PlayStaffProfileOnce(_db);_db.AddNotification("Profile updated","Local profile changes saved.","profile");StatusText.Text="Profile saved";var mpNav=NavPanel.Children.OfType<Button>().FirstOrDefault(b=>Equals(b.Tag,"MyPartner"));if(mpNav!=null)mpNav.Visibility=IsStaffProfile()?Visibility.Visible:Visibility.Collapsed;if(!IsStaffProfile()&&_page=="MyPartner")Render("Dashboard");})
        ),Brushes.CadetBlue));
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var rows=_db.LoadMonth(month);
        var hierarchy=rows.GroupBy(x=>string.IsNullOrWhiteSpace(x.Region)?"Unassigned region":x.Region).Select(g=>new{
            Region=g.Key,Partners=g.Select(x=>x.PartnerName).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Clusters=g.Select(x=>x.Cluster).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Staff=g.Select(x=>x.StaffName).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Activations=g.Sum(x=>x.Daily.Values.Sum())
        }).OrderByDescending(x=>x.Activations).ToList();
        root.Children.Add(Card(Stack(H("Company skeleton",18),P("Region → partner → cluster → staff/device relationships are reconstructed locally from the loaded HQ snapshot."),
            new DataGrid{ItemsSource=hierarchy,IsReadOnly=true,AutoGenerateColumns=true,Height=350}
        ),Brushes.CadetBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ExchangePage()
    {
        var results=_db.PhoneResults();
        var root=new StackPanel();
        root.Children.Add(Card(Stack(
            H("Phone Data Exchange"),
            P("Pair Android and Windows on the same Wi-Fi, or use a trusted HTTPS reverse-proxy endpoint for remote sync. Sync payloads are AES-GCM encrypted with the pairing key even on local HTTP. HQ monthly snapshots and payment data are deliberately excluded from sync merges."),
            B("Start local sync bridge",StartSyncBridge),
            B("Stop local sync bridge",StopSyncBridge),
            B("Sync with HTTPS cloud relay",SyncWithCloud),
            P($"Local bridge: {(_syncBridge?.IsRunning==true ? "LISTENING" : "STOPPED")} • Port 43827 • LAN IPs: {SyncBridgeServer.GetLanAddresses()} • Last successful phone exchange: {(_syncBridge?.LastSuccessfulExchange?.ToLocalTime().ToString("dd MMM HH:mm:ss") ?? "not yet")}"),
            P("The Windows bridge remains available while DevMonitor is running. Android v225 retries finitely and checks again every 5 minutes after a failed cycle; active-screen sync repeats every 30 seconds after success. Windows sleeps/shutdowns and Android background restrictions can interrupt availability."),
            B("Import .dmdata fallback",ImportExchange),
            B("Export .dmdata fallback",ExportExchange),
            H($"Stored phone results: {results.Count:N0}",18),
            P(results.Count==0?"No phone query results have been imported yet.":"The latest phone results are retained locally and can be used while offline.")
        ),Brushes.DarkCyan));
        if(results.Count>0) root.Children.Add(Card(new DataGrid{ItemsSource=results.Take(100).Select(x=>new{Device=x.DeviceId,Status=x.Status,Today=x.Today,MTD=x.Mtd,Active=x.Active,At=x.ResultAt.ToLocalTime().ToString("dd MMM yyyy HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=400},Brushes.DarkCyan));
        var counts=_db.AndroidRecordCounts();
        root.Children.Add(Card(Stack(H("Android query & relationship archive",18),P("Imported from Android sync: saved query lists, archived/current query codes, query result records and history, daily observations, SMS attempt/recovery metadata, agents, phone contacts and device-to-agent relationships. These are retained locally for offline review/export; they never overwrite authoritative HQ snapshots or payment records."),
            H($"Archived Android records: {_db.AndroidRecords().Count:N0}",16),
            new DataGrid{ItemsSource=counts.Select(x=>new{RecordFamily=x.Key,Records=x.Value}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=210},
            B("Export Android archive JSON",ExportAndroidArchive),B("Export Android archive index CSV",ExportAndroidArchiveIndex)
        ),Brushes.SteelBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private void StartSyncBridge(object? sender,RoutedEventArgs e){
        try{
            var token=_db.GetSetting("sync_pairing_key");
            if(string.IsNullOrWhiteSpace(token)){token=Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(24)).TrimEnd('=');_db.SetSetting("sync_pairing_key",token);}
            _syncBridge?.Dispose();_syncBridge=new SyncBridgeServer(token,MergeSyncPackage);_syncBridge.Start();
            MessageBox.Show(this,$"Local bridge is running on port 43827.\n\nPairing key (enter on Android):\n{token}\n\nLAN addresses: {SyncBridgeServer.GetLanAddresses()}\n\nUse http://LAN-IP:43827/sync. Payloads are encrypted; keep the key private.","DevMonitor Sync Bridge",MessageBoxButton.OK,MessageBoxImage.Information);
            StatusText.Text="Local sync bridge running";UpdateLinkStatus();Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,"Could not start the local bridge. If Windows reports URL access denied, run the URL reservation command in the bridge README as administrator.\n\n"+ex.Message,"Sync Bridge",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void StopSyncBridge(object? sender,RoutedEventArgs e){_syncBridge?.Stop();_syncBridge?.Dispose();_syncBridge=null;StatusText.Text="Local sync bridge stopped";UpdateLinkStatus();Render("Exchange");}
    private async void SyncWithCloud(object? sender,RoutedEventArgs e){
        var endpoint=Microsoft.VisualBasic.Interaction.InputBox("HTTPS relay base URL (for example https://sync.example.com)","DevMonitor Cloud Sync",_db.GetSetting("sync_cloud_endpoint")??"").Trim();
        if(string.IsNullOrWhiteSpace(endpoint))return;
        if(!endpoint.StartsWith("https://",StringComparison.OrdinalIgnoreCase)){MessageBox.Show(this,"Cloud sync requires HTTPS with a valid certificate.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Warning);return;}
        var token=_db.GetSetting("sync_pairing_key");
        if(string.IsNullOrWhiteSpace(token)){token=Microsoft.VisualBasic.Interaction.InputBox("Create or enter the same pairing key used on Android (at least 16 characters).","DevMonitor Cloud Sync","");if(string.IsNullOrWhiteSpace(token))return;_db.SetSetting("sync_pairing_key",token);}
        try{
            _db.SetSetting("sync_cloud_endpoint",endpoint);
            var json=JsonSerializer.Serialize(BuildSyncDto(),new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
            var bytes=System.Text.Encoding.UTF8.GetBytes(json);var nonce=System.Security.Cryptography.RandomNumberGenerator.GetBytes(12);var key=System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(token));var cipher=new byte[bytes.Length+16];
            using(var aes=new System.Security.Cryptography.AesGcm(key,16))aes.Encrypt(nonce,bytes,cipher.AsSpan(0,bytes.Length),cipher.AsSpan(bytes.Length,16));
            var body=JsonSerializer.Serialize(new{payload=Convert.ToBase64String(nonce.Concat(cipher).ToArray())});
            using var client=new HttpClient{Timeout=TimeSpan.FromSeconds(25)};using var req=new HttpRequestMessage(HttpMethod.Post,endpoint.TrimEnd('/')+"/sync");req.Headers.Add("X-DevMonitor-Pairing-Key",token);req.Content=new StringContent(body,System.Text.Encoding.UTF8,"application/json");
            using var response=await client.SendAsync(req);var text=await response.Content.ReadAsStringAsync();response.EnsureSuccessStatusCode();var envelope=JsonDocument.Parse(text);var combined=Convert.FromBase64String(envelope.RootElement.GetProperty("payload").GetString()??"");var outNonce=combined[..12];var data=combined[12..];var plain=new byte[data.Length-16];using(var aes=new System.Security.Cryptography.AesGcm(key,16))aes.Decrypt(outNonce,data.AsSpan(0,data.Length-16),data.AsSpan(data.Length-16,16),plain);
            MergeSyncPackage(System.Text.Encoding.UTF8.GetString(plain));StatusText.Text="Cloud sync completed";MessageBox.Show(this,"HTTPS cloud sync completed.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,"Cloud sync failed: "+ex.Message,"DevMonitor",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private string MergeSyncPackage(string json){
        var dto=JsonSerializer.Deserialize<SyncDto>(json,new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??throw new System.IO.InvalidDataException("Invalid sync package.");
        if(dto.Protocol!=1)throw new System.IO.InvalidDataException("Unsupported sync protocol.");
        if(dto.MyDevices.Count>100000||dto.Tasks.Count>50000||dto.Notes.Count>50000||dto.Sms.Count>100000||dto.ExtendedData.Count>100000)throw new System.IO.InvalidDataException("Sync package exceeds safe limits.");
        if(dto.Tasks.Any(x=>string.IsNullOrWhiteSpace(x.Title)||x.Title.Length>1000)||dto.Notes.Any(x=>x.Title.Length>1000||x.Body.Length>200000))throw new System.IO.InvalidDataException("Sync package contains invalid task or note fields.");
        foreach(var ack in dto.ShareCardAcks.Where(x=>!string.IsNullOrWhiteSpace(x))) _db.DeleteAndroidRecord("share_queue",ack,createTombstone:false);
        ValidateAndroidRecords(dto.ExtendedData);
        var phoneResults=ParseAndroidQueryResults(dto.ExtendedData);
        foreach(var t in dto.Tasks)_db.MergeSyncedTask(t);
        foreach(var n in dto.Notes)_db.MergeSyncedNote(n);
        foreach(var sms in dto.Sms)_db.MergeSyncedSms(sms.Sender,sms.Body,sms.Received);
        foreach(var q in phoneResults)_db.MergeSyncedPhoneResult(q);
        foreach(var row in dto.ExtendedData.Where(x=>!x.Type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase))){
            if(string.IsNullOrWhiteSpace(row.Type)||string.IsNullOrWhiteSpace(row.Key)||row.Payload.ValueKind!=JsonValueKind.Object)continue;
            _db.MergeAndroidRecord(row.Type,row.Key,row.Payload.GetRawText());
            if(string.Equals(row.Type,"notifications",StringComparison.OrdinalIgnoreCase)){
                var payload=row.Payload;
                string TextField(string name,string fallback="")=>payload.TryGetProperty(name,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():fallback;
                long epoch=0;long.TryParse(TextField("timestamp"),out epoch);
                var when=epoch>0?DateTimeOffset.FromUnixTimeMilliseconds(epoch).UtcDateTime:DateTime.UtcNow;
                var read=payload.TryGetProperty("read",out var rv)&&rv.ValueKind==JsonValueKind.True;
                _db.MergeAndroidNotification(row.Key,TextField("title","Android notification"),TextField("message"),TextField("kind","info"),when,read);
            }
        }
        foreach(var row in dto.ExtendedData.Where(x=>x.Type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase))){
            _db.MergeAndroidRecord(row.Type,row.Key,row.Payload.GetRawText());
            ApplySyncTombstone(row);
        }
        _db.ReplaceMyDevices(_db.MyDevices().Concat(dto.MyDevices));
        _db.AddNotification("Phone/PC sync completed",$"Merged {dto.Tasks.Count} tasks, {dto.Notes.Count} notes, {dto.Sms.Count} SMS records and {dto.ExtendedData.Count} extended Android records. HQ snapshots and payment records were not changed.","sync");
        return JsonSerializer.Serialize(BuildSyncDto(),new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
    }
    private void ApplySyncTombstone(AndroidEntityDto row){
        if(row.Payload.ValueKind!=JsonValueKind.Object)return;
        string Read(string name)=>row.Payload.TryGetProperty(name,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():"";
        var type=Read("entityType");if(type.Length==0)type=Read("entity_type");var key=Read("entityKey");if(key.Length==0)key=Read("entity_key");
        if(string.IsNullOrWhiteSpace(type)||string.IsNullOrWhiteSpace(key))return;
        if(type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase))return;
        _db.DeleteAndroidRecord(type,key,createTombstone:false);
    }

    private static void ValidateAndroidRecords(IEnumerable<AndroidEntityDto> records){
        var allowed=new HashSet<string>(StringComparer.OrdinalIgnoreCase){"query_codes","query_records","saved_query_lists","query_history","daily_observations","sms_query_attempts","agents","agent_phones","agent_emails","agent_devices","profile_metadata","notifications","sync_tombstones","share_queue"};
        foreach(var row in records)if(!allowed.Contains(row.Type)||string.IsNullOrWhiteSpace(row.Key)||row.Key.Length>512||row.Payload.ValueKind!=JsonValueKind.Object||row.Payload.GetRawText().Length>500_000)throw new System.IO.InvalidDataException("Sync/archive includes an invalid or unsupported Android record. No records were merged.");
    }
    private static List<PhoneQueryResult> ParseAndroidQueryResults(IEnumerable<AndroidEntityDto> records)
    {
        var output=new List<PhoneQueryResult>();
        foreach(var row in records.Where(x=>x.Type.Equals("query_records",StringComparison.OrdinalIgnoreCase)))
        {
            if(!row.Payload.TryGetProperty("json",out var jsonValue)||jsonValue.ValueKind!=JsonValueKind.String)continue;
            using var recordDoc=JsonDocument.Parse(jsonValue.GetString()??"{}");var record=recordDoc.RootElement;
            var code=record.TryGetProperty("code",out var codeValue)?codeValue.GetString():null;
            if(string.IsNullOrWhiteSpace(code))throw new System.IO.InvalidDataException("An Android query result is missing its device code.");
            var recordStatus=record.TryGetProperty("status",out var statusValue)?statusValue.GetString()??"UNRECOGNIZED":"UNRECOGNIZED";
            var completed=record.TryGetProperty("completedAt",out var completedValue)&&completedValue.TryGetInt64(out var epoch)?epoch:DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            JsonElement result=default;var hasResult=record.TryGetProperty("result",out result)&&result.ValueKind==JsonValueKind.Object;
            int? Number(string name){if(!hasResult||!result.TryGetProperty(name,out var v)||v.ValueKind!=JsonValueKind.Number||!v.TryGetInt32(out var n))return null;return n;}
            var received=hasResult&&result.TryGetProperty("receivedAt",out var receivedValue)?receivedValue.GetString():null;
            var resultAt=DateTime.TryParse(received,out var parsed)?parsed:DateTimeOffset.FromUnixTimeMilliseconds(Math.Max(0,completed)).UtcDateTime;
            var status=string.Equals(recordStatus,"SUCCESS",StringComparison.OrdinalIgnoreCase)?"OK":recordStatus;
            var raw=hasResult&&result.TryGetProperty("raw",out var rawValue)?rawValue.GetString()??"":record.TryGetProperty("error",out var errorValue)?errorValue.GetString()??"":"";
            output.Add(new PhoneQueryResult(DevMonitorDb.Canonical(code),status,Number("today"),Number("mtd"),Number("active"),Number("bar48"),Number("bar96"),resultAt,raw));
        }
        return output;
    }
    private SyncDto BuildSyncDto()=>new(){MyDevices=_db.MyDevices(),Tasks=_db.Tasks(),Notes=_db.Notes(),Sms=_db.Sms().Select(x=>new SmsDto{Sender=x.Sender,Body=x.Body,Received=x.Received}).ToList(),ExtendedData=_db.AndroidRecords().Where(x=>!x.Type.Equals("share_queue",StringComparison.OrdinalIgnoreCase)).Select(x=>new AndroidEntityDto{Type=x.Type,Key=x.Key,Payload=JsonDocument.Parse(x.PayloadJson).RootElement.Clone()}).ToList(),ShareCards=_db.AndroidRecords("share_queue").Select(x=>JsonDocument.Parse(x.PayloadJson).RootElement.Clone()).ToList()};
    private sealed class SyncDto{public int Protocol{get;set;}=1;public string CreatedAt{get;set;}=DateTime.UtcNow.ToString("O");public List<string> MyDevices{get;set;}=[];public List<OperationalTask> Tasks{get;set;}=[];public List<OperationalNote> Notes{get;set;}=[];public List<SmsDto> Sms{get;set;}=[];public List<AndroidEntityDto> ExtendedData{get;set;}=[];public List<string> ShareCardAcks{get;set;}=[];public List<JsonElement> ShareCards{get;set;}=[];}
    private sealed class AndroidEntityDto{public string Type{get;set;}="";public string Key{get;set;}="";public JsonElement Payload{get;set;}}

    private sealed class ExchangeDto
    {
        public string Version {get;set;}="1";
        public string CreatedAt {get;set;}=DateTime.UtcNow.ToString("O");
        public List<string> MyDevices {get;set;}=[];
        public List<PhoneQueryResult> PhoneResults {get;set;}=[];
        public List<OperationalTask> Tasks {get;set;}=[];
        public List<OperationalNote> Notes {get;set;}=[];
        public List<AppNotification> Notifications {get;set;}=[];
        public List<SmsDto> Sms {get;set;}=[];
        public List<AndroidEntityDto> ExtendedData {get;set;}=[];
    }
    private sealed class SmsDto { public string Sender {get;set;}=""; public string Body {get;set;}=""; public DateTime Received {get;set;} }

    private void ExportExchange(object? sender,RoutedEventArgs e)
    {
        var dto=new ExchangeDto{
            MyDevices=_db.MyDevices(),PhoneResults=_db.PhoneResults(),Tasks=_db.Tasks(),Notes=_db.Notes(),Notifications=_db.Notifications(),
            Sms=_db.Sms().Select(x=>new SmsDto{Sender=x.Sender,Body=x.Body,Received=x.Received}).ToList(),
            ExtendedData=_db.AndroidRecords().Select(x=>new AndroidEntityDto{Type=x.Type,Key=x.Key,Payload=JsonDocument.Parse(x.PayloadJson).RootElement.Clone()}).ToList()
        };
        var dlg=new SaveFileDialog{Filter="DevMonitor data package|*.dmdata",FileName=$"DevMonitor-Phone-Exchange-{DateTime.Now:yyyyMMdd-HHmm}.dmdata"};
        if(dlg.ShowDialog()!=true)return;
        System.IO.File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(dto,new JsonSerializerOptions{WriteIndented=true}));
        StatusText.Text=$"Exported {System.IO.Path.GetFileName(dlg.FileName)}";
        _db.AddNotification("Data package exported",System.IO.Path.GetFileName(dlg.FileName),"exchange");
    }

    private void ImportExchange(object? sender,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="DevMonitor data package|*.dmdata;*.json|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            var dto=JsonSerializer.Deserialize<ExchangeDto>(System.IO.File.ReadAllText(dlg.FileName),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
            if(dto==null)throw new System.IO.InvalidDataException("The package could not be read.");
            if(dto.Version!="1")throw new System.IO.InvalidDataException($"Unsupported DevMonitor package version '{dto.Version}'. No data was imported.");
            if(dto.MyDevices.Count>100000||dto.PhoneResults.Count>100000||dto.Tasks.Count>50000||dto.Notes.Count>50000||dto.Notifications.Count>100000||dto.Sms.Count>100000||dto.ExtendedData.Count>100000)throw new System.IO.InvalidDataException("The package exceeds safe import limits. No data was imported.");
            if(dto.PhoneResults.Any(q=>string.IsNullOrWhiteSpace(q.DeviceId)||q.DeviceId.Length>128||new[]{q.Today,q.Mtd,q.Active,q.Bar48,q.Bar96}.Any(n=>n.HasValue&&n.Value<0)))throw new System.IO.InvalidDataException("The package contains an invalid phone result (missing device code or negative count). No data was imported.");
            ValidateAndroidRecords(dto.ExtendedData);
            var syncedPhoneResults=ParseAndroidQueryResults(dto.ExtendedData);
            if(dto.MyDevices.Count>0)_db.ReplaceMyDevices(dto.MyDevices);
            foreach(var q in dto.PhoneResults)_db.SavePhoneResult(q);
            foreach(var t in dto.Tasks)_db.SaveTask(t with {Id=0});
            foreach(var n in dto.Notes)_db.SaveNote(n with {Id=0});
            foreach(var n in dto.Notifications)_db.AddNotification(n.Title,n.Message,n.Kind);
            foreach(var sms in dto.Sms)_db.MergeSyncedSms(sms.Sender,sms.Body,sms.Received);
            foreach(var q in syncedPhoneResults)_db.MergeSyncedPhoneResult(q);
            foreach(var row in dto.ExtendedData){if(!string.IsNullOrWhiteSpace(row.Type)&&!string.IsNullOrWhiteSpace(row.Key)&&row.Payload.ValueKind==JsonValueKind.Object)_db.MergeAndroidRecord(row.Type,row.Key,row.Payload.GetRawText());}
            _db.AddNotification("Phone data imported",$"{dto.PhoneResults.Count:N0} phone results and {dto.ExtendedData.Count:N0} extended Android records imported from {System.IO.Path.GetFileName(dlg.FileName)}.","exchange");
            MessageBox.Show(this,"Phone data package imported. The data is now available offline.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
            Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"Data package import failed",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    private UIElement AndroidDataPage()
    {
        var root=new StackPanel();
        var initialTypes=new List<string>{"All families"}.Concat(_db.AndroidRecords().Select(x=>x.Type).Distinct().OrderBy(x=>x)).ToList();
        var family=new ComboBox{ItemsSource=initialTypes,SelectedIndex=0,MinWidth=220,Height=36,Margin=new Thickness(0,0,8,8)};
        var search=new TextBox{Width=280,Height=36,Margin=new Thickness(0,0,8,8),ToolTip="Search family, key or payload"};
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=520,SelectionMode=DataGridSelectionMode.Single};
        void Load(){
            var records=_db.AndroidRecords();var type=family.SelectedItem?.ToString();var q=search.Text?.Trim()??"";
            grid.ItemsSource=records.Where(x=>(type=="All families"||string.IsNullOrWhiteSpace(type)||x.Type==type)&&(q.Length==0||x.Type.Contains(q,StringComparison.OrdinalIgnoreCase)||x.Key.Contains(q,StringComparison.OrdinalIgnoreCase)||x.PayloadJson.Contains(q,StringComparison.OrdinalIgnoreCase))).Take(2000).ToList();
        }
        void EditSelected(){if(grid.SelectedItem is not AndroidRecord selected){MessageBox.Show(this,"Select an Android record first.");return;}if(new[]{"agents","agent_phones","agent_emails","agent_devices"}.Contains(selected.Type,StringComparer.OrdinalIgnoreCase)){MessageBox.Show(this,"Agent records and device links are managed on Android. Sync the phone to refresh this read-only copy.","Android is authoritative",MessageBoxButton.OK,MessageBoxImage.Information);return;}EditAndroidRecord(selected);Load();}
        family.SelectionChanged+=(_,_)=>Load();search.TextChanged+=(_,_)=>Load();
        root.Children.Add(Card(Stack(H("Android Data Archive",22),P("Manage Android-originated query lists, query codes, history, observations, SMS attempt metadata, profile metadata and notifications. Agent contacts and device assignments are displayed from Android as the authoritative source and should be changed on Android, then synced. HQ monthly snapshots and payment records are not editable here."),
            new WrapPanel{Children={family,search,B("Refresh",(_,_)=>{Load();StatusText.Text="Android archive refreshed";}),B("Add record",(_,_)=>{EditAndroidRecord(null);Load();}),B("Edit selected",(_,_)=>EditSelected()),B("Delete selected",(_,_)=>{if(grid.SelectedItem is not AndroidRecord r){MessageBox.Show(this,"Select a record first.");return;}if(new[]{"agents","agent_phones","agent_emails","agent_devices"}.Contains(r.Type,StringComparer.OrdinalIgnoreCase)){MessageBox.Show(this,"Agent records and device links are managed on Android. Sync the phone to refresh this read-only copy.","Android is authoritative",MessageBoxButton.OK,MessageBoxImage.Information);return;}if(MessageBox.Show(this,$"Delete {r.Type} / {r.Key}? This deletion will be sent to paired devices on the next sync.","Confirm delete",MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes){_db.DeleteAndroidRecord(r.Type,r.Key);Load();StatusText.Text="Record deleted; deletion marker queued for sync";}}),B("Export JSON",ExportAndroidArchive),B("Export index CSV",ExportAndroidArchiveIndex)}},
            H($"{_db.AndroidRecords().Count:N0} archived records",16),grid),Brushes.SteelBlue));
        Load();return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private void EditAndroidRecord(AndroidRecord? existing){
        var w=new Window{Title=existing==null?"Add Android archive record":"Edit Android archive record",Width=760,Height=680,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var type=new ComboBox{ItemsSource=new[]{"query_codes","query_records","saved_query_lists","query_history","daily_observations","sms_query_attempts","profile_metadata","notifications"},SelectedItem=existing?.Type??"query_codes",Height=36,IsEnabled=existing==null};
        var key=new TextBox{Text=existing?.Key??"",Height=36};
        var payload=new TextBox{Text=existing?.PayloadJson??"{\n  \"code\": \"\",\n  \"type\": \"\",\n  \"archived\": 0,\n  \"created_at\": 0,\n  \"updated_at\": 0\n}",AcceptsReturn=true,AcceptsTab=true,TextWrapping=TextWrapping.NoWrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Auto,FontFamily=new System.Windows.Media.FontFamily("Consolas"),FontSize=13};
        var save=B("Save record",(_,_)=>{try{
            var t=type.SelectedItem?.ToString()??"";var k=key.Text.Trim();if(string.IsNullOrWhiteSpace(t)||string.IsNullOrWhiteSpace(k))throw new System.IO.InvalidDataException("Family and record key are required.");
            using var doc=JsonDocument.Parse(payload.Text);if(doc.RootElement.ValueKind!=JsonValueKind.Object)throw new System.IO.InvalidDataException("Payload must be a JSON object.");if(payload.Text.Length>500000)throw new System.IO.InvalidDataException("Payload exceeds the 500 KB limit.");
            if(existing!=null&&(existing.Type!=t||existing.Key!=k))_db.DeleteAndroidRecord(existing.Type,existing.Key);
            _db.MergeAndroidRecord(t,k,doc.RootElement.GetRawText());
            if(t=="notifications"){
                string Field(string n,string d="")=>doc.RootElement.TryGetProperty(n,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():d;
                long.TryParse(Field("timestamp"),out var ms);var when=ms>0?DateTimeOffset.FromUnixTimeMilliseconds(ms).UtcDateTime:DateTime.UtcNow;
                var read=doc.RootElement.TryGetProperty("read",out var rv)&&rv.ValueKind==JsonValueKind.True;
                _db.MergeAndroidNotification(k,Field("title","Android notification"),Field("message"),Field("kind","info"),when,read);
            }
            w.DialogResult=true;w.Close();
        }catch(Exception ex){MessageBox.Show(w,ex.Message,"Cannot save Android record",MessageBoxButton.OK,MessageBoxImage.Error);}});
        w.Content=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=Stack(H(existing==null?"New archive record":"Edit archive record",22),P("This editor works on operational Android records only. Keep the payload schema valid for its selected family. It does not edit HQ report snapshots or payment records."),new TextBlock{Text="Record family"},type,new TextBlock{Text="Record key"},key,new TextBlock{Text="Payload JSON"},payload,new WrapPanel{Children={save,B("Cancel",(_,_)=>w.Close())}})};
        w.ShowDialog();
    }

    private void ExportAndroidArchive(object? sender,RoutedEventArgs e){
        var dlg=new SaveFileDialog{Filter="JSON archive|*.json",FileName=$"DevMonitor_Android_Archive_{DateTime.Now:yyyyMMdd-HHmm}.json"};if(dlg.ShowDialog()!=true)return;
        var records=_db.AndroidRecords().Select(x=>new{type=x.Type,key=x.Key,updatedAt=x.UpdatedAt,payload=JsonDocument.Parse(x.PayloadJson).RootElement.Clone()}).ToList();
        System.IO.File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(new{format="DevMonitorAndroidArchiveV1",exportedAt=DateTime.UtcNow,records},new JsonSerializerOptions{WriteIndented=true}));
        StatusText.Text=$"Exported {records.Count:N0} Android archive records";
    }
    private void ExportAndroidArchiveIndex(object? sender,RoutedEventArgs e){
        SaveCsv("DevMonitor_Android_Archive_Index.csv","RecordFamily,Key,UpdatedAt,PayloadBytes",_db.AndroidRecords().Select(x=>$"{Csv(x.Type)},{Csv(x.Key)},{Csv(x.UpdatedAt.ToString("O"))},{System.Text.Encoding.UTF8.GetByteCount(x.PayloadJson)}"));
    }

    private UIElement SettingsPage()
    {
        var telemetry = new CheckBox { Content = "Enable anonymous local usage diagnostics", IsChecked = AppTelemetry.IsEnabled, Margin = new Thickness(0, 5, 0, 8), FontSize = 14 };
        telemetry.Checked += (_, _) => AppTelemetry.SetEnabled(true);
        telemetry.Unchecked += (_, _) => AppTelemetry.SetEnabled(false);
        var openDiagnostics = B("Open diagnostics folder", (_, _) =>
        {
            try { Directory.CreateDirectory(AppTelemetry.DiagnosticsFolder); System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = AppTelemetry.DiagnosticsFolder, UseShellExecute = true }); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Diagnostics", MessageBoxButton.OK, MessageBoxImage.Information); }
        });
        return new ScrollViewer { Content = Card(Stack(
            H("Settings"), P("Desktop settings are local and offline-first. Cloud account, backup and Android/Windows synchronization are deliberately isolated from core calculations."),
            H("Usage diagnostics",17), P("Optional anonymous app-open, page-use, report workflow and technical error events are stored on this PC only. Nothing is uploaded. Device codes, staff names, phone numbers, report rows and payment values are not recorded."), telemetry, openDiagnostics,
            H("Local data",17), P($"Database: {_db.FilePath}"), H("Payment rules",17), P("Payment/progression rules are ported from the supplied Android source and remain separate from report-import UI."),
            H("Two-month HQ store",17), P("Only the current and immediately previous calendar months are accepted. Older coverage is rejected; same or newer coverage replaces the month's complete snapshot.")), Brushes.Gray) };
    }

    protected override void OnClosed(EventArgs e){_syncBridge?.Dispose();base.OnClosed(e);_db.Dispose();}
}
