# DevMonitor Windows v213 — Analytics foundation

- Added opt-in, local-only desktop usage diagnostics, aligned to the Android event categories where practical: app open, page open, report import success/failure, report snapshot stored, and technical exceptions.
- Added Windows/assembly version context to each event.
- Added Settings controls to enable/disable diagnostics and open the diagnostics folder.
- Events are stored under `%LOCALAPPDATA%\DevMonitor\diagnostics\events.jsonl`.
- No event upload/network transmission is implemented; remote centralized analytics requires an approved HTTPS collection endpoint or telemetry provider configuration.
- No device identifiers, staff names, phone numbers, report rows, raw SMS, activation records or payment values are recorded.
- Bumped Windows assembly version to 4.6.0.213.
- Preserved PaymentRules.cs, the authoritative HQ snapshot model, and the phone/PC sync bridge protocol.

Validation: source integration and ZIP integrity checked. The .NET Windows build should be confirmed by GitHub Actions.
