# DevMonitor Windows v221 — Earnings flier parity and reach-step messaging

- Carries forward the promotional earnings-card and visible PC–Android connection-status work.
- Specifies that the Android-rendered card uses the selected source's exact figures and the existing reach-step/category to select its encouragement message.
- No payment formula, category threshold, or source-selection behavior is changed by this documentation/parity update.
- Master work sheet and change log updated.
- Validation: ZIP structure checked; Windows build not run in this environment.
