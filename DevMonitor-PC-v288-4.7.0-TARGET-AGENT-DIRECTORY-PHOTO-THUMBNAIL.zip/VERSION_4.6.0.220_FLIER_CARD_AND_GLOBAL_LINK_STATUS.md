# DevMonitor Windows 4.6.0.220 — Flyer Cards and Global Link Status

- Reworked PC-prepared earnings PNGs into green/lime promotional flyers inspired by the company payment-structure graphic.
- Preserved exact selected-source values; no payment formula or cross-source filling was added.
- Added a persistent header indicator: bridge stopped, waiting for Android, connected after recent successful exchange, or no recent sync.
- Indicator refreshes every five seconds and reports last successful exchange.
- Build and paired-device behaviour still require GitHub Actions and device testing.


Version identity advance only: assembly, file and informational versions are 4.6.0.220. No feature or payment logic change intended in this version-only advance.
