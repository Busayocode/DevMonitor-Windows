# DevMonitor Windows/PC v288 — agent-directory photo thumbnail and placeholder

## Cumulative base
- Built cumulatively on Windows/PC v287, retaining the existing monthly target forecast, fixed offline notification audio, Android-authoritative agent directory, contact/email/device-link display, and OpenStreetMap location handoff.
- The Windows assembly/file/informational version is advanced to `4.7.0.288`.

## Change
- Added a dedicated photo thumbnail column to the synced Android agent directory.
- The thumbnail renders an image when the referenced photo file is actually accessible on the Windows PC.
- When it is unavailable, the row shows a neutral initials avatar rather than an empty cell. The photo-status column explains whether a photo is absent or its image bytes have not been transferred.
- The directory remains read-only for Android-originated agent records. Android remains authoritative for agent identity, contacts, coordinates and linked devices.

## Important limitation
- The current Android-to-PC archive sync carries `photo_path`, not the photo image bytes. A phone-private file path is not a transferable image, so photos stored only on Android will show the initials placeholder in this PC build. Full cross-device photo rendering requires a separately implemented, size-limited and privacy-aware image-byte sync; this version does not pretend that transfer is already available.

## Protected logic and verification
- No payment formulas, payment eligibility gates, MOM snapshots/databases, HQ authority, target calculations, monthly forecast formulas, device links, or sync ownership rules were intentionally changed.
- Source and ZIP integrity checks are possible in this environment. A Windows .NET build and runtime/UI verification are not confirmed here because the .NET SDK is unavailable.
