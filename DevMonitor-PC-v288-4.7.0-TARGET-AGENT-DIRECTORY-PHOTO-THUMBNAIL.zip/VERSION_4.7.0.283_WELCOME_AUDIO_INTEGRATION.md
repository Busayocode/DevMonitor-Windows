# Windows v283 — Welcome Audio Integration

- Added bundled offline first-launch welcome WAV recording (Perfect F1).
- Added bundled offline staff-profile welcome WAV recording (Perfect M1, trimmed tail).
- First-launch welcome is latched in the local settings database and plays on the first application startup only.
- Staff welcome is played only after the first successful save of a STAFF profile, and only once. Existing profile edits and non-STAFF profiles do not trigger this staff-specific recording.
- Welcome tracks are queued; audio failure is best-effort and must not interrupt profile saving.
- Existing warning/error and qualifying task-completion audio routing remains present.
- Payment/MOM logic and report calculations were not intentionally changed.
- Version: 4.7.0.283. Build/runtime verification remains pending.

- MP3 copies removed; WAV is the sole bundled format for these welcome tracks.
