# DevMonitor Android 4.7.0-TARGET (versionCode 276)

- Staff and Partner profiles require a positive monthly target.
- Agent target is fixed at 150.
- Target is persisted with profile metadata.
- Month-on-Month displays cumulative monthly activations vs target, target achievement percentage, expected cumulative value by day of month, and pace status.
- Existing payment calculations and report import semantics are unchanged.
- Build/runtime verification pending.
