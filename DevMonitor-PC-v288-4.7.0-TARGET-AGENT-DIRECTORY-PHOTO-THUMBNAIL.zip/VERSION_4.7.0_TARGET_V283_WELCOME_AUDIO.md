# DevMonitor Windows v283 — Welcome Audio Integration

## Included tracks
- `dm_welcome_first_launch.wav`: Track 1, “Welcome to DevMonitor”. Bundled and played once on first launch, with persistent state.
- `dm_welcome_staff_profile.wav`: Track 2, “Welcome to DevMonitor, a collection of tools to help you monitor your devices and answer to your numbers!” Bundled and played only after successful creation of a new Staff profile. Profile edits do not replay it.

Both tracks play offline from bundled WAV assets; no device TTS or network call is used. Audio errors are best-effort and do not interrupt app workflows. MP3 copies are not included.

## Scope and safety
- This change only adds bundled WAV audio assets, playback hooks, and persistent one-time markers.
- Existing warning/task audio remains unchanged.
- Payment logic, MOM databases/snapshots, report calculations, sync, and notification triggers outside these two welcome events are unchanged.
- Build and runtime/device playback still require validation in the relevant Android/Windows build environments.
