# Windows v229 — Share card estimate pass-through and full-card resolution

- Share card renderer now accepts the selected estimate object and does not calculate payment totals itself.
- Entire card exports at 2160 × 2840, 192 DPI.
- Existing source isolation is retained.
- Windows compilation remains pending in a .NET SDK environment.
