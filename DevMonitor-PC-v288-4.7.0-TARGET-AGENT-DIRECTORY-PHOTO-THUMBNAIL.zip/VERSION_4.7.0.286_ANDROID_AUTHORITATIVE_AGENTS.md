# DevMonitor Windows v286 — Android-authoritative agent directory

Windows receives and displays the agent data and linked device state synced from Android. Android remains the sole management source for agent details and associations. Windows does not provide a parallel agent CRUD workflow. The Windows archive may retain and export received rows but does not offer agents, phones, emails or agent-device links as editable archive record types.

Google Maps pin selection occurs on Android. Saved coordinates sync as part of the agent record. Android-local photo paths are not image data and are not treated as portable images on Windows.

Payment and MOM behavior is protected. Build/runtime verification pending.
