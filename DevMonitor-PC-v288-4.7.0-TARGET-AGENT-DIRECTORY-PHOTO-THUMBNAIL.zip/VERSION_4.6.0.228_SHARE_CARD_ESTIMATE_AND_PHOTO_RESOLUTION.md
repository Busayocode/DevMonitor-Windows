# Windows v228 — Share-card estimate and photo resolution

- Share-card PNG now carries the established PaymentRules estimate, including fixed reward, FRC component, and same-source Sunday bonus where loaded-report daily data is available.
- SMS Checker estimates use the existing Windows rule path and do not borrow Loaded Report Sunday data.
- If Active is missing, the card explicitly says the estimate is unavailable instead of fabricating a zero estimate.
- Queue metadata includes the estimate components for auditability.
- Embedded hero asset is 1542 × 1545 pixels for cleaner rendering.
- Build verification pending.
