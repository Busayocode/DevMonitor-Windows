# DevMonitor Windows 4.6.0.224 — My Partners lookup and share cards

- Carried the recent Android My Partners refinement into the native Windows workspace.
- My Partners navigation is visible only after a saved local profile has role `STAFF`; changing the role to Agent or Partner hides it and redirects away from the workspace.
- Loaded-report lookup searches partner names and Trade Codes and selecting a match populates the full partner name and official Trade Code.
- Lookup rows include available region, cluster, territory, staff and month-count details.
- Added a personalized My Partners Result preview and export-to-PNG action for sharing. This exports the selected partner details; it does not fabricate SMS/check results.
- Renamed the workspace and results headings to My Partners / My Partners Result. Partner-code examples replace device-specific wording.
- Preserved the separate local `my_partner.db` store and left the original SMS Checker and payment rules unchanged.
- Windows remains unable to send SMS; actual check outcomes must come from supported phone-side workflows.

Build/device validation is required after upload to GitHub Actions.
