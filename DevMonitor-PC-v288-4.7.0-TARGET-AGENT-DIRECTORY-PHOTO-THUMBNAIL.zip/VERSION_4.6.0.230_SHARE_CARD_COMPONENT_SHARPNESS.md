VERSION 4.6.0.231 — ESTIMATE LABEL CLARITY

- Verified PC share-card hero labels estimated earnings explicitly and includes monitoring-only disclaimer.
- No payment calculations or source-selection rules changed.
