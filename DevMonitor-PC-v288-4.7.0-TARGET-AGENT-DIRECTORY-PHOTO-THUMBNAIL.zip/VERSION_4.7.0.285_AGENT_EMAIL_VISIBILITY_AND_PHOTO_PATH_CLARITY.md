# Windows v285 — Agent email visibility and photo-path clarity

## Implemented
- The Agents directory includes synced email addresses alongside phone numbers, address and device assignments.
- The photo status makes clear that an Android `photo_path` is device-local metadata, not a PC-accessible image.

## Remaining work
- Native Windows agent/contact/email/photo editing.
- Transfer image bytes instead of Android-local paths and render agent photos on Windows share cards.
- Contact import preview/duplicate review/merge and reviewed contact-name application.
- Integrated saved map pin search, pin movement, confirmation, edit and clear.

Payment and MOM rules/snapshots were not intentionally changed. Build and runtime testing remain required.
