# DevMonitor Windows v222 — Connection refresh and navigation contrast

- Increased inactive sidebar navigation text contrast to white and raised font size to 14 so non-selected sections remain legible.
- Replaced the silent top-bar refresh behaviour with a current-page refresh plus explicit local bridge health check.
- When the bridge is stopped, the user receives actionable instructions to start it from Phone Data Exchange. The refresh action does not falsely claim it can reconnect a bridge that has not been started.
- When running, the refresh action requests the local `/health` endpoint and reports success/failure. A successful local health check is explicitly distinguished from a completed Android sync.
- No payment calculation changes.
- Build verification required via GitHub Actions; no local .NET SDK assumed.
