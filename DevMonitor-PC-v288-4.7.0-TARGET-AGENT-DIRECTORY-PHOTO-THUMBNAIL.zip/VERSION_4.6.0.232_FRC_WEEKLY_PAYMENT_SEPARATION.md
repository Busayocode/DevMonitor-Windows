# Windows v232 — FRC weekly payment separation

- FRC cumulative remains visible and is labelled “Progressively paid weekly”.
- FRC is excluded from the main payment estimate total. The existing fixed performance reward and qualifying Sunday bonus remain the main total.
- The same subtotal flows into the Earning Progress page, generated earnings cards, and sync payload.
- FRC calculation and all activation/payment thresholds remain unchanged.
- Compilation and paired-device verification pending.
