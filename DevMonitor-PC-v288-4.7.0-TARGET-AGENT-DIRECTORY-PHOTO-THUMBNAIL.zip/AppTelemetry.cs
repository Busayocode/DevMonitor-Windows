using System.IO;
using System.Text.Json;

namespace DevMonitor.Windows;

/// <summary>
/// Opt-in, privacy-conscious desktop diagnostics. Events are kept locally only;
/// no network transmission is performed by this module.
/// Never pass device IDs, staff names, phone numbers, report rows, or payment values.
/// </summary>
internal static class AppTelemetry
{
    private static DevMonitorDb? _db;
    private static readonly object Gate = new();
    private static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DevMonitor", "diagnostics");
    private static readonly string LogPath = Path.Combine(Folder, "events.jsonl");

    public static bool IsEnabled => string.Equals(_db?.GetSetting("desktop_analytics_enabled"), "true", StringComparison.OrdinalIgnoreCase);
    public static string DiagnosticsFolder => Folder;

    public static void Initialize(DevMonitorDb db)
    {
        _db = db;
        AppDomain.CurrentDomain.UnhandledException += (_, e) => RecordException(e.ExceptionObject as Exception, "app_domain");
        TaskScheduler.UnobservedTaskException += (_, e) => { RecordException(e.Exception, "background_task"); e.SetObserved(); };
        Track("app_open");
    }

    public static void SetEnabled(bool enabled)
    {
        _db?.SetSetting("desktop_analytics_enabled", enabled ? "true" : "false");
        if (enabled) Track("diagnostics_enabled");
    }

    public static void Track(string eventName, string? category = null)
    {
        if (!IsEnabled) return;
        var allowedEvents = new HashSet<string>(StringComparer.Ordinal)
        {
            "app_open", "page_open", "report_import_success", "report_import_failed",
            "report_snapshot_stored", "sync_bridge_started", "sync_success", "sync_failed",
            "phone_package_import_success", "phone_package_import_failed", "diagnostics_enabled",
            "app_exception", "background_exception"
        };
        if (!allowedEvents.Contains(eventName)) eventName = "other_event";
        var row = new
        {
            timestampUtc = DateTimeOffset.UtcNow,
            eventName,
            category = SafeCategory(category),
            appVersion = typeof(AppTelemetry).Assembly.GetName().Version?.ToString() ?? "unknown",
            osFamily = "Windows",
            osVersion = Environment.OSVersion.Version.ToString()
        };
        Write(row);
    }

    public static void RecordException(Exception? exception, string area)
    {
        if (!IsEnabled || exception is null) return;
        var row = new
        {
            timestampUtc = DateTimeOffset.UtcNow,
            eventName = area == "app_domain" ? "app_exception" : "background_exception",
            category = SafeCategory(area),
            exceptionType = exception.GetType().FullName ?? "Exception",
            appVersion = typeof(AppTelemetry).Assembly.GetName().Version?.ToString() ?? "unknown",
            osFamily = "Windows",
            osVersion = Environment.OSVersion.Version.ToString()
        };
        Write(row);
    }

    private static string SafeCategory(string? value)
    {
        var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "Dashboard", "Sms", "Devices", "Report", "Earnings", "Monitor", "MonthOnMonth", "Agents", "Tasks", "Notes", "Activity", "Inbox", "Exports", "LoadedReport", "Trends", "ActionCentre", "Profile", "Exchange", "AndroidData", "Settings", "local_excel", "phone_package", "lan_bridge", "app_domain", "background_task" };
        return value is not null && allowed.Contains(value) ? value : "unspecified";
    }

    private static void Write(object row)
    {
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(Folder);
                File.AppendAllText(LogPath, JsonSerializer.Serialize(row) + Environment.NewLine);
                var info = new FileInfo(LogPath);
                if (info.Length > 1_000_000)
                {
                    var archive = Path.Combine(Folder, $"events-{DateTime.UtcNow:yyyyMMdd-HHmmss}.jsonl");
                    File.Move(LogPath, archive, true);
                }
            }
        }
        catch { /* Diagnostics must never interrupt core app behavior. */ }
    }
}
