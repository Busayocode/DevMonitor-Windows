# Windows v233 — Share-card next-tier earnings opportunity

- Adds the clearly labelled current payment estimate, exact additional activations needed, projected main estimate at the next configured tier, and incremental gain to PC-generated shareable earnings cards.
- Consumes the selected source's existing `IncentiveEstimate`; retains the currently qualified Sunday bonus only and does not assume future Sunday bonus eligibility.
- Excludes weekly-paid FRC from current and projected main estimates while retaining the separate FRC breakdown.
- Source isolation and PC-to-Android PNG handoff remain unchanged.
- Validation status: static source/archive checks only; Windows build and generated-PNG visual inspection are pending.
