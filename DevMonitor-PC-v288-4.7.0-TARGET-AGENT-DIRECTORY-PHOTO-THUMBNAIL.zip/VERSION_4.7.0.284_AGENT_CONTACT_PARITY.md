# Windows/PC v284 — Agent contact parity support

- Accept and retain the additive `agent_emails` record family during phone/PC sync and JSON archive workflows.
- Existing Agents & Partners view continues to expose agent records and linked device assignments from the Android-originated operational archive; email records are retained in the archive and can be reviewed/edited through Android Data Archive.
- Android-private photo file paths are not transferred as if they were valid Windows paths. Windows-native contact/photo editing and direct photo rendering remain follow-up parity work.
- Existing share-card workflow continues to queue the selected exact-source card and linked device identifiers; no payment values or calculation logic are changed by this increment.
- Compile/runtime verification pending; source changes do not imply verified parity.
