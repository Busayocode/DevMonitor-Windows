# Android v297 — Welcome Audio Integration

- Added bundled offline first-launch welcome recording (Perfect F1).
- Added bundled offline staff-profile welcome recording (Perfect M1, trimmed tail).
- First-launch sound uses the existing persisted onboarding state plus a dedicated audio latch, so it is not replayed on ordinary launches or screen re-entry.
- Staff welcome runs only after a newly created STAFF profile is committed and is latched per profile ID. Profile edits do not replay it.
- Audio is queued and best-effort; playback failure does not interrupt profile persistence or business workflows.
- Existing payment/MOM logic and alert/task notification routing were not intentionally changed.
- Version code: 297. Build/device verification remains pending.
