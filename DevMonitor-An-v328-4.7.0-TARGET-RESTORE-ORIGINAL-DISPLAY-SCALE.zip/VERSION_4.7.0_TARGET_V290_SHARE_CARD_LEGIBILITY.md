# Android v290 — Share-card text legibility

Base: `DevMonitor-4.7.0-TARGET-v284-RESPONSIVE-COMPACT-UI.zip`

## Changes
- Improved contrast and increased the smallest text sizes in the payment share-card renderer.
- Kept the output scale at 1.5×; no resolution increase.
- Fit long projection-note and activation-detail lines to their available width.
- Advanced `versionCode` to 290.

## Protected behavior
No payment calculation, displayed estimate source, cycle logic, Target calculation, MOM/HQ storage, Drive-report configuration, or regular SMS Checker behavior was intentionally changed.

## Verification status
ZIP structure and source-level checks only. Gradle compilation, device rendering, and compression after sharing must still be tested.
