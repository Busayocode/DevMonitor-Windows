# DevMonitor Android v265 — Partner card and checker isolation fixes

- Fixed partner name/details lookup for share cards using the retained HQ partner directory already displayed in My Partners.
- Removed the duplicate mini badge/value from the hero on partner and earnings share cards; the key values remain in their primary panels.
- Reduced partner card canvas to 1080 × 1320 logical units, exported at 1.5x (1620 × 1980), and repositioned the footer to reduce bottom whitespace.
- Cancel in-flight checker work and clear pending SMS-permission resume state when navigating between SMS Checker and My Partners or leaving either route.
- No partner metrics or payment calculations changed.
- ZIP integrity/source checks only. Android compilation and physical-device/WhatsApp testing remain pending.
