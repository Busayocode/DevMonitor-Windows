# Android v271 — FRC weekly payment separation

- FRC cumulative remains visible and is described as “Progressively paid weekly”.
- Main payment estimate excludes FRC and uses the existing fixed performance reward plus qualifying Sunday bonus only.
- FRC records, activation-based cumulative calculation, tier thresholds, Sunday rules, and source isolation are preserved.
- Build/device verification pending.
