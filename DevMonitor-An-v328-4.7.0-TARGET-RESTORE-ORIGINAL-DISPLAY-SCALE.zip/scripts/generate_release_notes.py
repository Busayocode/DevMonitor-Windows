#!/usr/bin/env python3
"""Generate app/src/main/assets/release_notes.json from version/change documentation."""
from pathlib import Path
import json, re, sys
root = Path(__file__).resolve().parents[1]
gradle = root / "app/build.gradle.kts"
text = gradle.read_text(encoding="utf-8")
code_match = re.search(r'versionCode\s*=\s*(\d+)', text)
name_match = re.search(r'versionName\s*=\s*"([^"]+)"', text)
if not code_match or not name_match:
    raise SystemExit("Could not read versionCode/versionName")
code, name = int(code_match.group(1)), name_match.group(1)
# Prefer the version-specific note whose filename/version most closely matches the build name/code.
files = list(root.glob("VERSION*.md"))
ranked = []
for path in files:
    body = path.read_text(encoding="utf-8", errors="replace")
    score = 0
    if str(code) in path.name or str(code) in body[:1200]: score += 10
    if name.lower().replace('-', '_') in path.name.lower(): score += 15
    if score: ranked.append((score, path.name, body))
ranked.sort(reverse=True)
source = ranked[0][2] if ranked else ""
# If version-specific notes are absent, use the first section of CHANGE_LOG.md.
if not source:
    change = root / "CHANGE_LOG.md"
    if change.exists(): source = change.read_text(encoding="utf-8", errors="replace")
lines=[]
for line in source.splitlines():
    m=re.match(r"\s*(?:[-*•])\s+(.+)", line)
    if m:
        value=re.sub(r"[`*]", "", m.group(1)).strip()
        lowered = value.lower()
        if value and not lowered.startswith(("validation:", "verification:", "build/device", "no payment")) and "firestore rules" not in lowered and "scripts/generate_release_notes.py" not in lowered:
            lines.append(value)
    if len(lines)>=12: break
if not lines:
    lines=[f"DevMonitor {name} includes the latest improvements and fixes."]
out=root/"app/src/main/assets/release_notes.json"
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({"versionCode":code,"versionName":name,"highlights":lines},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(f"Generated {out} for {name} (versionCode {code}) with {len(lines)} highlights")
