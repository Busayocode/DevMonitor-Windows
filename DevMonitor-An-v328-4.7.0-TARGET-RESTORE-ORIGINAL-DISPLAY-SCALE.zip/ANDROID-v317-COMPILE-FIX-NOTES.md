# Android v317 compile fix

This package fixes the Kotlin compile errors reported by GitHub Actions for the v316 LAN discovery / QR pairing source.

## Root cause
`NextLevelScreen.kt` introduced pairing UI references (`onBridgeEndpointChange`, `onBridgeKeyChange`, `bridgeApproved`, `qrScanner`, `discoveryStatus`, and `discoveredPcs`) inside `HealthBody` without passing them into that composable. This caused unresolved references during `:app:compileReleaseKotlin`.

## Fixes
- Pass the pairing approval, discovery state and QR scan action into `HealthBody` explicitly.
- Update the QR scan callback to set the parent-owned endpoint and key state directly.
- Bump Android versionCode to 317 and versionName to identify this compile fix.
- Declare camera permission for the bundled ZXing QR scanner.

## Verification
The source ZIP passes ZIP integrity validation. This note does not claim that the Android release build or physical-device pairing has been tested. Run the repository's GitHub Actions build to verify compilation and subsequent integration.
