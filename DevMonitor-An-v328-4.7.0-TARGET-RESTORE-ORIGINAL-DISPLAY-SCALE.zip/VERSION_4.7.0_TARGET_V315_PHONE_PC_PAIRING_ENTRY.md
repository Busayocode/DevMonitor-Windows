# DevMonitor Android v315 — Phone/PC pairing entry point

The existing app-bar PC-link icon opens Next Level → Health. The sync bridge panel now presents “Pair with Windows PC” and gives direct setup instructions matching Windows v316.

This is a discoverability/usability update only. URL and pairing key are still entered manually; QR pairing and automatic local-network discovery are not available in this build.

Existing encrypted bridge behavior is retained. Payment logic, MOM records/snapshots, HQ activation snapshots and target calculations are not intentionally changed.

Validation: ZIP integrity/source inspection only; Gradle compile, install and live PC↔phone pairing are unverified.
