# DevMonitor v281 — Missing permission setup setting key fix

## GitHub failure diagnosed
The release build failed during `:app:compileReleaseKotlin` because `MainActivity.kt` referenced `SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN` five times without declaring the constant. This is a Kotlin source compilation error, not an Android SDK or native-library stripping failure.

## Fix
Declared:
`private const val SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN = "first_launch_permission_setup_seen"`

The existing wizard's read/write calls are unchanged, so the intended persistence behavior is preserved. Android `versionCode` is now 281.

## Feature continuity
- Retains v280 restoration of the Fork 3 partner activation-performance calculation and share-card metrics.
- Removes the visible “Fork 3” wording only; the UI section title is “ACTIVATION PERFORMANCE”.
- Retains the welcome-tour persistence safeguard and removal of the notification test-alert button.
- Does not intentionally change payment formulas, Target calculations, or HQ/MOM storage behavior.

## Verification status
The ZIP archive integrity and source edits were checked. A complete Gradle release build and GitHub Actions run have not yet confirmed success.
