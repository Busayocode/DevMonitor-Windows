# Android v300 — Agent contact review/merge and photo management

## Implemented
- Contact selection now opens a review/merge dialog before changing the agent. The user can review/edit the contact display name and postal address, preview labeled phone numbers and emails, see duplicate counts, and explicitly confirm the merge. Existing device links are preserved; duplicate phone/email values are skipped. Contact selection is one contact per session, not a multi-select batch.
- Agent editor can resolve an address/place name to a suggested coordinate. The user reviews the result and explicitly saves it; postal address and coordinates remain separate fields. Saved coordinates can be cleared.
- Agents database offers `Replace photo` using the platform image picker.
- Agents with a saved image offer `Clear photo`.
- Replacement images are copied into app-private `agent_photos` storage using a unique filename, and the agent record is updated only after a non-empty copy succeeds.
- Contact-import thumbnail behavior remains non-destructive: the imported contact thumbnail is only used when the agent has no saved photo.

## Protected behavior
No payment calculator, payment rule, payment cycle, loaded-report authority, Device Monitor calculation, or MOM database/snapshot code was changed intentionally in this increment.

## Remaining work — not represented as completed
- Multi-contact selection in one import session (current system picker is one contact per session).
- Integrated interactive map-pin workflow: tap/move a pin on an embedded map and return the selected coordinates to DevMonitor. Address geocoding and manual coordinate editing exist, but direct pin manipulation does not yet.
- Windows native agent/contact/photo editor, portable image-byte transfer, and full Windows personalized-card parity.
- Android and Windows compilation/device/runtime tests remain required.
