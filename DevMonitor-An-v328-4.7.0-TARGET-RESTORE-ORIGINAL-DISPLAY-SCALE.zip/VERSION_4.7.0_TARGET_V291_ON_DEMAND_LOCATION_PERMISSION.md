# DevMonitor Android v291 — On-demand location permission

## Scope
- Base: `DevMonitor-4.7.0-TARGET-v290-SHARE-CARD-LEGIBILITY.zip`.
- Android version code: `291`.
- Android version name: `4.7.0-TARGET-ON-DEMAND-LOCATION-PERMISSION`.

## Change
Location is no longer included in the first-launch permission walkthrough. The walkthrough now has three steps: SMS device monitoring, phone/SIM information, and Android notifications. The app retains location permissions in its manifest and keeps the existing `currentLocation()` runtime permission check, so the request is triggered by the location-dependent map-helper action rather than at launch.

The v290 share-card legibility improvements are retained. No payment calculation, Target logic, MOM/HQ storage, Drive configuration, or SMS Checker behavior was intentionally changed.

## Verification status
ZIP integrity and source-level checks only. No Gradle build or on-device permission prompt test has been run for v291.
