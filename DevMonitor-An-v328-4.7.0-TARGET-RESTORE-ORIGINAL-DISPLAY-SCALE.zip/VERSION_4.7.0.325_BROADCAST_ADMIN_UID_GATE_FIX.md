# DevMonitor Android v325 — Broadcast administrator visibility fix

## Changes
- Fixed `isCurrentUserBroadcastAdmin()` so it compares the signed-in Firebase Authentication UID directly with `ADMIN_FIREBASE_UID`. The previous v324 condition compared the configured UID against itself as a placeholder guard, which always returned false and hid all administrator controls.
- Set Android `versionCode` to 325 so this build is distinguishable from the installed v318 and can be offered as a newer Android version.
- Updated `versionName` to identify the broadcast administrator gate fix.
- Kept the configured administrator UID and broadcast document path unchanged.
- Kept the existing Settings UI gate and Firestore rules structure intact.

## Validation
- Source ZIP integrity checked after patch.
- Source inspection confirms the administrator check now returns `uid == ADMIN_FIREBASE_UID`.
- No Gradle build, APK installation, or live Firebase publish test has been performed here.
