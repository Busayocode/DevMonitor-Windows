# Android v307 — Agent contact and device workflow

## User-facing changes
- Agent list observes mutation refreshes so saved agents should appear immediately without leaving the menu.
- Contact-photo import tries the full-size photo stream and PHOTO_URI fallback. A contact provider may still have no usable image.
- Email entry sits in the main Add/Edit Agent details form before device selection. Contact import continues to allow individual phone/email choices.
- Device linking is integrated into the scrollable Add/Edit Agent form. All available My Devices codes are presented, and selected links are applied when Save is pressed.
- A contact-import-created agent reopens the details form to finish address, email and device linking rather than immediately sending the user into a separate details submenu.

## Protected logic
No intentional changes to payment formulas/cycle rules, MOM physical database snapshots, HQ activation snapshots, target rules, or report authority.

## Verification
ZIP integrity check is required before delivery. Android compilation and runtime must still be confirmed on a connected build runner/device; prior environment had no DNS access to services.gradle.org.
