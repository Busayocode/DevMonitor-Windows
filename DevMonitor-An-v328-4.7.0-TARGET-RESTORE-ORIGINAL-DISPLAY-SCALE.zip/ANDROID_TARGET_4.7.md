# DevMonitor Android 4.7 Target refinement (v277)

The Target card reports achievement against the expected cumulative target for the same day: actual activity / expected-to-date activity × 100. The card does not show shortfall amounts or behind-pace warnings. Full-month target progress is a separate neutral percentage. Staff/Partner target entry and the fixed Agent target of 150 remain unchanged. Payment logic is untouched.
