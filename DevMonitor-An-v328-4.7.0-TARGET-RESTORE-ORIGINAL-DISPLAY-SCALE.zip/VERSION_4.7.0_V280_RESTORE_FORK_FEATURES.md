# DevMonitor v280 — Restore partner activation performance

- Restored `Fork3ActivationPerformance.kt`, its calculation state and background calculation, and the partner result-card activation-performance section from the v278 source.
- Restored activation-performance values in the partner result share card and its full layout in `ReportExportPack.kt`.
- Removed only the visible `FORK 3` wording from the partner result-card section title and share-card title. The section now reads `ACTIVATION PERFORMANCE`.
- Preserved the v279 welcome-tour persistence safeguard and the removal of the notification test-alert button.
- No payment formulas or MOM/HQ storage logic intentionally changed.
- Android version code: 280.
- Build and device verification remain pending.
