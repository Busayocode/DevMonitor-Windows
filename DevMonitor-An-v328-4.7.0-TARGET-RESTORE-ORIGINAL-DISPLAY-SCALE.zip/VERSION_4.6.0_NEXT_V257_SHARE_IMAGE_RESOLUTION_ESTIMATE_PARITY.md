# v257 — Share image resolution and estimate parity

- Upscaled and sharpened the embedded earnings hero asset to 1542 × 1545 pixels for cleaner high-density export rendering. This improves resampling quality but does not recreate lost photographic detail.
- Extended the rounded card background to cover the complete 1810-pixel exported card, including the translated footer.
- Existing Android share-card payloads continue to render the exact selected source's already-computed `IncentiveEstimate`; no payment formula changed.
- Partner result cards remain lookup-result cards and do not infer payment estimates.
- Build verification is pending.
