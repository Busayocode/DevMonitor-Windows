# DevMonitor Android v267 — Fork 3 Partner Activation Performance

This build introduces an experimental, read-only partner-level aggregation. For each My Partners Trade Code, it resolves the distinct devices assigned in the latest retained HQ directory and sums each device's existing payment-cycle activation progression from the Device Monitor engine and Loaded Reports engine independently.

- Device Monitor aggregation uses `PaymentEngine.DeviceMonitor.calculate`, preserving its established current-cycle baseline, freshness and fallback rules.
- Loaded Report aggregation uses `PaymentEngine.LoadedReports.calculate` and does not reuse the Device Monitor total.
- A partial subtotal is clearly labelled with the number of devices contributing and the number unavailable. Missing data is never silently treated as zero.
- The existing payment engine, payment estimates, source stores, partner records, device records, and HQ import behavior are unchanged.
- Fork 3 is experimental; Android compilation and device-level verification are still required.
