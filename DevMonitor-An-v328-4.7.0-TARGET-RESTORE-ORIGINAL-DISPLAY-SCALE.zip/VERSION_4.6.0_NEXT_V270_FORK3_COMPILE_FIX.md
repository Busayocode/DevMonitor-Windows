# DevMonitor 4.6.0-NEXT v270 — Fork 3 compile correction

## Fix
The GitHub Actions APK build failed at `MainActivity.kt:632` because `Fork3ActivationPerformance.calculate` requires a `DatabaseStore`, but the caller supplied a profile-aware `StateStore`. The call now passes `store.database`, which exposes the database associated with the currently active profile.

## Scope and safeguards
- Compile correction only; no activation or payment formula changes.
- Device Monitor and Loaded Report Fork 3 totals remain separate.
- Profile-specific database selection remains delegated to `StateStore`.
- v269 search responsiveness, estimate-card badge correction, partner flyer layout, and Drive backup/restore changes are retained.

## Validation status
The source call and versionCode were checked, and the ZIP is checked for integrity. This environment has not confirmed a full Android compilation. Run the GitHub Actions APK workflow; if another compiler error appears, use its exact output for the next targeted fix.
