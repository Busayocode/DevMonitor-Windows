# DevMonitor Android v305 — Agent workflow refinement

## User-reported issues addressed in source
1. Map picker action renamed to **Select location on map**. Added Android network-state permission for osmdroid tile/network handling while preserving the no-API-key OpenStreetMap approach. The previous grid-only map issue is not considered resolved until real-device tiles load.
2. Contact import review shows each phone number with a checkbox, initially checked. Uncheck any number that is not a working phone number or should not be stored. Only checked numbers are saved; emails and address remain separately reviewable.
3. Agents menu has a clearer hierarchy: search, primary Add agent or partner action, then Saved agents and partners. Each agent record presents Details & device links as the primary action and edit/contact/photo/delete as secondary actions. The duplicate Add action is removed.
4. Contact import completion continues to trigger agent-list refresh.

## Protected behavior
No intentional changes to payment formulas or cycle boundaries, MOM physical snapshots, HQ activation snapshots, target rules, or device-agent relationship semantics.

## Verification
ZIP integrity can be checked locally. Gradle compilation and actual Android map tile rendering/contact permission/list-refresh behavior require a successful build and physical-device test; source edits alone do not establish those tests passed.
