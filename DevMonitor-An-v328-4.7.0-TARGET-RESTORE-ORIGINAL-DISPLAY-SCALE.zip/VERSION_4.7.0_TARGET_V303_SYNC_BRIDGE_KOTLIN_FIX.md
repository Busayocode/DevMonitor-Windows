# DevMonitor Android v303 — Sync Bridge Kotlin Compile Fix

## Root cause
GitHub Actions Release #34 failed to compile `SyncBridgeClient.kt` at the agent merge branch. The local variable `db` in `mergeNativeRecord` is already an `android.database.sqlite.SQLiteDatabase`; it does not expose a `readableDatabase` property. That invalid receiver also caused cascading cursor and type-inference diagnostics.

## Fix
Changed the fallback query from `db.readableDatabase.rawQuery(...)` to `db.rawQuery(...)`. The query still reads the existing agent `photo_path` by agent ID and preserves it when the incoming record omits the `photo_path` field.

## Version
- Android `versionCode`: 303
- Android `versionName`: `4.7.0-TARGET-SYNC-BRIDGE-KOTLIN-FIX`

## Guardrails
No changes to payment calculations, MOM databases/snapshots, HQ activation snapshots, target calculations, or the sync exclusion of payment/HQ data.

## Verification status
The ZIP is structurally checked. This does **not** claim that GitHub Actions compilation or device runtime has passed; rerun the Android release workflow and test sync/agent photo preservation on a device.
