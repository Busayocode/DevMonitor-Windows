# Android v314 — Broadcast diagnostics (2026-10-23)

- Added a forced Firestore server-read check for `app_config/devmonitor_broadcast`.
- Settings now displays the diagnostic result and has a **Retry broadcast check** button. Messages distinguish server read failures, missing document, inactive flag, empty message, expired broadcast, and an eligible active broadcast.
- Startup uses the same explicit diagnostic result to decide whether to show the ticker; no Firebase rules or documents are modified by this feature.
- Version code is 314. This is a source ZIP; build and device runtime are not yet verified.
- No intended changes to payment calculations, MOM databases/history, HQ activation snapshots, target logic, report imports, or SMS Checker business rules.
