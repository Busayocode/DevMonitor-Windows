# DevMonitor near-real-time sync — Android v318

- Uses the existing authenticated AES-GCM sync bridge and existing protocol; no new public endpoint is introduced.
- Successful sync cycles repeat every 5 seconds while the Android Next Level screen is active and the app can run.
- The phone sends its current operational sync package and merges the PC response, so changes made on either side can appear on the other side on the next successful cycle.
- On failures, retry backoff remains 2/5/10/20/30 seconds, followed by a 5-minute standby reachability check.
- This is near-real-time polling, not push/event streaming. It is not guaranteed while Android is backgrounded, the Next Level screen is closed, the PC sleeps, the bridge is stopped, or Wi-Fi is unavailable.
- Existing scope exclusions remain: HQ snapshots and payment records are not part of the protected sync payload/merge. Existing operational tables and current merge rules are otherwise unchanged.
- Build and real-device synchronization must be tested in GitHub Actions and on the paired devices before calling this verified.
