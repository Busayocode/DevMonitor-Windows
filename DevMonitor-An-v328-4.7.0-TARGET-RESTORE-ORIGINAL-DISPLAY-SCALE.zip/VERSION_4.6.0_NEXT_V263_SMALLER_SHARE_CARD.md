# DevMonitor 4.6.0-NEXT v263 — Smaller Payment Share Card

- Reduced the payment flyer render scale from 3x to 1.5x.
- PNG canvas is now 1620 × 2715 pixels rather than 3240 × 5430 pixels.
- Approximate main ARGB bitmap memory falls from 67 MiB to 17 MiB, reducing pressure during image creation and WhatsApp handoff.
- Kept the flyer layout and photo placement consistent by scaling the full canvas uniformly.
- Kept the “Estimated Earnings” label and existing estimate/source data unchanged; no payment calculations were modified.
- Preserved background-thread rendering and compression for single-card sharing.
- Android versionCode advanced to 263.
- Gradle compilation and physical-device/WhatsApp validation are still required.
