# Android v310 — Agent list photo thumbnail

Date: 2026-10-23

## Change
The main Agents & Partners menu now shows each saved agent's photo as a 76 dp thumbnail beside their name, address and linked-device summary. If no photo is saved or the file is unavailable, a neutral avatar placeholder is shown in the same position.

The thumbnail reads the existing `Agent.photoPath` used by Add/Edit. It does not duplicate image files or alter contact-import behavior. The working OpenStreetMap picker and photo preview/import flow are retained.

## Protected behavior
No intentional changes to payment formulas, payment cards, MOM snapshots, HQ activation snapshots, target rules, report authority, or device-link business rules.

## Verification
Source-level edit and ZIP integrity checks only. GitHub Actions compilation and on-device runtime should be verified before treating this version as release-ready.
