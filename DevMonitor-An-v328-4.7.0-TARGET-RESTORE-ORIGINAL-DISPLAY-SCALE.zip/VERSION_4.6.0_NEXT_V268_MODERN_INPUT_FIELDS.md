# DevMonitor Android v268 — Modern Search and Input Fields

- Starting point: Fork 3 v267 partner activation performance experiment.
- Changed the 42 Compose `OutlinedTextField` controls to filled Material 3 `TextField` controls to replace thin line-only rectangles with softly filled surfaces.
- Set the theme's extra-small and small field shapes to 16dp rounded corners. Existing surface-container color tokens keep fields distinguishable in light and dark themes.
- Retained labels, placeholders, validators, keyboard configuration, input filtering, dropdown read-only behavior, search filtering, and all calculation/data logic.
- Version code: 268; version name remains `4.6.0-NEXT`.
- Verification: source-level checks and ZIP integrity. Android compile and on-device light/dark visual regression tests remain pending.
