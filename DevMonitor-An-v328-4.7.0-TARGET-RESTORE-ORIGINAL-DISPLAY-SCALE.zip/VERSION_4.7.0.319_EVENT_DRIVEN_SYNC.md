# Version 4.7.0.319 — Event-driven phone/PC sync

See `REALTIME_SYNC_v319.md`. Change-triggered sync supplements rather than replaces the five-second recovery fallback. Sync remains limited to the existing operational projection; HQ snapshots/targets and payment/MOM records remain excluded.
