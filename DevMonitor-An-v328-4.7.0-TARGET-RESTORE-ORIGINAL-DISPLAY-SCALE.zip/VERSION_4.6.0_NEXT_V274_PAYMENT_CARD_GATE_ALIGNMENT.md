# v274 — Payment card eligibility aligned with calculation engine

- Removed the day-of-month bypass that opened Device Monitor payment cards before the 21st without validating historical eligibility.
- The card-opening gate now uses `PaymentEngine.DeviceMonitor.calculate` and opens only when the engine returns a non-null activation progression.
- A `today`-only observation cannot satisfy the historical cumulative Active baseline requirement.
- The existing engine warning is shown when eligibility fails.
- No payment formulas, reward thresholds, FRC treatment, source separation, or tier projection calculations were changed.
