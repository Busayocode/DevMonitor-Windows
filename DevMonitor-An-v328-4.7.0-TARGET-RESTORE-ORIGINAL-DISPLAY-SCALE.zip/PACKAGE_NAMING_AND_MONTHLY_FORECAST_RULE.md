# DevMonitor Source ZIP Naming and Cross-Platform Packaging Rule

## Required filename pattern

- Android: `DevMonitor-An-v{VERSION}-4.7.0-TARGET-{CHANGE}.zip`
- Windows native/PC: `DevMonitor-PC-v{VERSION}-4.7.0-TARGET-{CHANGE}.zip`

The platform marker `An` or `PC` must appear immediately before the version number in every source ZIP filename. Use the next platform-specific version number and a concise, uppercase, hyphen-separated change description.

Examples for this package pair:
- `DevMonitor-An-v294-4.7.0-TARGET-MONTHLY-TARGET-FORECAST.zip`
- `DevMonitor-PC-v280-4.7.0-TARGET-MONTHLY-TARGET-FORECAST.zip`

This is a packaging and identification convention. **Do not change the GitHub Actions ZIP-selection/build workflow solely to accommodate this filename convention**; the existing workflow behavior must remain unaffected. Record this rule in future Android and Windows source ZIP documentation.

## Feature contract: monthly target forecast

The trend feature is a current-calendar-month delivery-rate projection against the existing monthly target, not a multi-month historical trend. Show only neutral figures: monthly target, sales delivered so far, projected month-end sales at the observed daily rate, target achieved percentage, and remaining target balance. Do not add management verdicts, risk labels, red shortfall warnings, or evaluative status language. Preserve the existing two-month data-retention model. Do not modify payment calculations, payment-cycle rules, MOM databases/snapshots, or HQ report authority. Keep refresh user-initiated. Android and Windows implementations/builds must be verified separately; source-level inclusion does not establish a successful build or runtime parity.


## AI voice notification package update
- Android package revision: v296; Windows/PC package revision: v282.
- Continue using `DevMonitor-An-v{VERSION}-4.7.0-TARGET-{CHANGE}.zip` and `DevMonitor-PC-v{VERSION}-4.7.0-TARGET-{CHANGE}.zip`; keep `An`/`PC` immediately before version number.
- GitHub Actions ZIP-selection workflow is not changed.
