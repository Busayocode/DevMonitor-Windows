# Android v313 — Remove obsolete partner authorization

- Removed the standalone `PartnerAuthorization.kt` Firestore request/approval/revocation service.
- Removed the unused legacy `AuthenticationGate` partner-request UI and request-sharing helper. Existing account/profile model types remain only for local database compatibility and Google cloud-backup identity.
- Removed the `partner_authorization_requests` Firestore rule block. Preserved `app_config/devmonitor_version`, broadcast, and release-note rules.
- Kept Google sign-in for Drive backup/restore; this change does not remove Google account cloud backup.
- No payment calculations, MOM records, HQ activation snapshots, target logic, report imports, SMS/device-monitor workflows, or partner/contact directory records were intentionally changed.
- Validation: ZIP integrity and source-level reference checks only. Android compilation/runtime and live Firebase deployment are not verified.
