# Android v261 — Dashboard Partners Card and Profile Builder Fix

- Made the My Partners dashboard card visually consistent with the standard dashboard cards: accent label, heading, supporting description, and full-width action.
- Removed unintended Monitor Settings dialog activation from Profile Builder entry points. Profile Builder now opens alone; the explicit Open Monitor Settings button still opens settings.
- No payment calculations, partner data isolation, profile storage, or other dashboard navigation behavior changed.
- Verification: source inspection and ZIP integrity only; build and first-launch device verification pending.
