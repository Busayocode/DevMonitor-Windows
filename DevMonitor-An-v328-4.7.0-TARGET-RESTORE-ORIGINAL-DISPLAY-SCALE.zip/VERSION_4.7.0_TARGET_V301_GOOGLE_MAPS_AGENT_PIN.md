# DevMonitor Android v301 — Google Maps Agent Pin Picker

## Approved scope
- Add Google Maps SDK-backed in-app agent location selection.
- Tap map to place pin; drag marker to refine; confirm pin to return coordinates to the agent editor; press Save Agent separately to persist.
- Keep postal address distinct from map coordinates.
- Require `GOOGLE_MAPS_API_KEY` Gradle property/build configuration; provide a clear setup message when missing. Do not commit a key.
- Defer multi-contact batch import.
- Windows remains a receiving/display companion for Android-authoritative agent data and linked state, not a second agent-management implementation.

## Protected areas
Payment calculations/rules/cards, MOM databases and snapshots, cycle cutoffs, report import authority, and profile isolation are not intentionally changed.

## Verification
ZIP integrity/source checks only. Android compilation and device testing are pending; live map rendering requires a valid Google Maps Platform key with Maps SDK for Android enabled.
