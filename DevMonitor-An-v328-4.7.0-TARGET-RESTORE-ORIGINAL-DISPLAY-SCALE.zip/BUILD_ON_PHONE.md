# Building DevMonitor on your Android phone

This source package is configured for Android Code Studio / ARM64 phone builds.

## Signed release APK

From the project root, run:

```sh
sh build-phone.sh assembleRelease --console=plain
```

The helper locates Android Code Studio's ARM-compatible AAPT2 and passes it to Gradle with `-Pandroid.aapt2FromMavenOverride=...`. It checks for the configured release keystore, then securely prompts for the keystore password, key password, and Google Drive API key when they are not supplied through environment variables. These secrets are not saved to project files.

Expected APK output:

`app/build/outputs/apk/release/app-release.apk`

## Signed App Bundle (AAB)

```sh
sh build-phone.sh bundleRelease --console=plain
```

Expected output directory: `app/build/outputs/bundle/release/`.

## If AAPT2 is not found

Run in the same terminal and share only the output, not passwords or API keys:

```sh
echo "$HOME"
echo "$PREFIX"
echo "$ANDROID_HOME"
find "$HOME" -type f -name aapt2 -executable 2>/dev/null | head
```

If the ARM-compatible binary is found elsewhere, set `AAPT2_PATH` to its exact path. Do not use a desktop Linux x86_64 AAPT2 binary on the phone.

## Release credentials

Default keystore path:

`/storage/emulated/0/Download/1app/fieldpulse-release.jks`

Default alias: `fieldpulse-release`.

If your keystore is stored elsewhere, set `RELEASE_STORE_FILE` before running the helper. Keep the keystore itself outside the source ZIP. For a private API key supplied in advance, export `DRIVE_REPORT_API_KEY`; otherwise the helper prompts for it without echoing the input.

The build keeps the existing single-worker and non-parallel Gradle settings for phone stability. Release lint checks remain non-blocking; this does not disable app compilation or resource processing.
