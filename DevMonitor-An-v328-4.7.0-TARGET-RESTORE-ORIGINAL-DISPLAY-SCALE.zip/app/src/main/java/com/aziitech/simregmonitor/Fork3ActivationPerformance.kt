package com.aziitech.simregmonitor

import java.time.LocalDate
import java.util.Locale

/**
 * Fork 3 experiment: aggregate the existing per-device activation progression
 * for each HQ Trade Code. This is read-only and deliberately does not write to,
 * replace, or alter either payment calculator or any partner/device records.
 */
object Fork3ActivationPerformance {
    data class SourceTotal(
        val total: Int?,
        val mappedDevices: Int,
        val devicesWithValue: Int,
        val through: LocalDate?
    ) {
        val complete: Boolean get() = mappedDevices > 0 && devicesWithValue == mappedDevices
        val unavailableDevices: Int get() = (mappedDevices - devicesWithValue).coerceAtLeast(0)
    }

    data class PartnerResult(
        val tradeCode: String,
        val deviceCount: Int,
        val cycleStart: LocalDate,
        val cycleEnd: LocalDate,
        val deviceMonitor: SourceTotal,
        val loadedReport: SourceTotal
    )

    fun calculate(
        tradeCodes: List<String>,
        companyStore: CompanyActivationStore,
        deviceStore: DatabaseStore,
        asOfRequested: LocalDate = LocalDate.now()
    ): Map<String, PartnerResult> {
        val asOf = PaymentRules.currentAwareDate(asOfRequested)
        val (cycleStart, cycleEnd) = PaymentRules.paymentCycleForDate(asOf)
        val scopeRows = companyStore.latestDeviceScopeRows()
        val byTradeCode = scopeRows.asSequence()
            .filter { it.tradeCode.isNotBlank() && it.deviceId.isNotBlank() }
            .groupBy { it.tradeCode.trim().uppercase(Locale.US) }
            .mapValues { (_, rows) -> rows.map { canonicalDeviceCode(it.deviceId) }.filter { it.isNotBlank() }.distinct() }

        val out = linkedMapOf<String, PartnerResult>()
        tradeCodes.map { it.trim().uppercase(Locale.US) }.filter { it.isNotBlank() }.distinct().forEach { tradeCode ->
            val devices = byTradeCode[tradeCode].orEmpty()
            val dmValues = mutableListOf<Pair<Int, LocalDate?>>()
            val loadedValues = mutableListOf<Pair<Int, LocalDate?>>()

            devices.forEach { deviceId ->
                // Use the established device-level engines verbatim; Fork 3 only aggregates their outputs.
                runCatching {
                    PaymentEngine.DeviceMonitor.calculate(deviceId, asOf, deviceStore, companyStore)
                }.getOrNull()?.let { progression ->
                    progression.activations?.let { dmValues.add(it.coerceAtLeast(0) to progression.availableThrough) }
                }
                runCatching {
                    PaymentEngine.LoadedReports.calculate(deviceId, asOf, companyStore)
                }.getOrNull()?.let { progression ->
                    progression.activations?.let { loadedValues.add(it.coerceAtLeast(0) to progression.availableThrough) }
                }
            }

            fun sourceTotal(values: List<Pair<Int, LocalDate?>>): SourceTotal = SourceTotal(
                total = values.takeIf { it.isNotEmpty() }?.sumOf { it.first },
                mappedDevices = devices.size,
                devicesWithValue = values.size,
                through = values.mapNotNull { it.second }.minOrNull()
            )

            out[tradeCode] = PartnerResult(
                tradeCode = tradeCode,
                deviceCount = devices.size,
                cycleStart = cycleStart,
                cycleEnd = cycleEnd,
                deviceMonitor = sourceTotal(dmValues),
                loadedReport = sourceTotal(loadedValues)
            )
        }
        return out
    }
}
