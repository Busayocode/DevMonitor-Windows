package com.aziitech.simregmonitor

import android.content.Context
import android.media.MediaPlayer
import java.util.ArrayDeque

/** Offline, pre-rendered onboarding welcomes. Does not use device speech synthesis. */
object DevMonitorWelcomeAudio {
    private const val PREFS = "devmonitor_welcome_audio"
    private const val FIRST_LAUNCH_PLAYED = "first_launch_played"
    private const val STAFF_PROFILE_PREFIX = "staff_profile_played_"
    private val lock = Any()
    private val pending = ArrayDeque<Int>()
    private var current: MediaPlayer? = null

    /** Call only for a genuinely fresh install; the persistent latch prevents repeats. */
    fun playFirstLaunchOnce(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        synchronized(lock) {
            if (prefs.getBoolean(FIRST_LAUNCH_PLAYED, false)) return
            prefs.edit().putBoolean(FIRST_LAUNCH_PLAYED, true).apply()
        }
        enqueue(context, R.raw.dm_welcome_first_launch, prioritize = false)
    }

    /** Staff welcome plays only after a new STAFF profile has been committed successfully. */
    fun playStaffProfileOnce(context: Context, profileId: String) {
        if (profileId.isBlank()) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = STAFF_PROFILE_PREFIX + profileId
        synchronized(lock) {
            if (prefs.getBoolean(key, false)) return
            prefs.edit().putBoolean(key, true).apply()
        }
        enqueue(context, R.raw.dm_welcome_staff_profile, prioritize = false)
    }

    /** Shares the same playback queue as welcomes, preventing audio clips from overlapping. */
    fun playNotification(context: Context, resourceId: Int, prioritize: Boolean) {
        if (resourceId == 0) return
        enqueue(context, resourceId, prioritize)
    }

    private fun enqueue(context: Context, resourceId: Int, prioritize: Boolean) {
        synchronized(lock) {
            if (prioritize) pending.addFirst(resourceId) else pending.addLast(resourceId)
            if (current == null) playNextLocked(context.applicationContext)
        }
    }

    private fun playNextLocked(context: Context) {
        val resourceId = pending.pollFirst() ?: return
        val player = runCatching { MediaPlayer.create(context, resourceId) }.getOrNull()
        if (player == null) { playNextLocked(context); return }
        current = player
        player.setOnCompletionListener { finished ->
            synchronized(lock) {
                runCatching { finished.release() }
                if (current === finished) current = null
                playNextLocked(context)
            }
        }
        player.setOnErrorListener { failed, _, _ ->
            synchronized(lock) {
                runCatching { failed.release() }
                if (current === failed) current = null
                playNextLocked(context)
            }
            true
        }
        runCatching { player.start() }.onFailure {
            runCatching { player.release() }
            current = null
            playNextLocked(context)
        }
    }
}
