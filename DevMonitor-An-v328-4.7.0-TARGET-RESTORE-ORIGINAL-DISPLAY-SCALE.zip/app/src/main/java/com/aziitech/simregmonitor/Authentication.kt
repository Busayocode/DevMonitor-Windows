package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider

private const val GLO_STAFF_PREFIX = "0805557"
private const val OTP_COOLDOWN_MS = 10L * 60L * 1000L

enum class AuthState { SIGNED_OUT, PHONE_REQUIRED, AUTHORIZATION_REQUIRED, AUTHORIZED, REVOKED }

enum class AccountClassification { UNKNOWN, GLO_STAFF_CANDIDATE, AGENT_PARTNER }

data class DevMonitorAccount(
    val accountId: String,
    val googleEmail: String,
    val mainPhone: String,
    val alternatePhone: String?,
    val firebaseUid: String?,
    val phoneVerifiedAt: Long?,
    val classification: AccountClassification,
    val state: AuthState,
    val createdAt: Long,
    val updatedAt: Long
)

data class AuthorizationAuditEvent(
    val id: String,
    val requestId: String,
    val eventType: String,
    val grantorAccountId: String?,
    val recipientAccountId: String,
    val recipientPhone: String,
    val scope: String,
    val timestamp: Long,
    val client: String,
    val reason: String?
)

object DevMonitorAuth {
    fun normalizeNigerianPhone(input: String): String {
        val digits = input.filter(Char::isDigit)
        return when {
            digits.startsWith("234") && digits.length == 13 -> "0" + digits.drop(3)
            digits.length == 10 && digits.firstOrNull() in '7'..'9' -> "0$digits"
            else -> digits
        }
    }

    fun isValidNigerianPhone(phone: String): Boolean =
        phone.length == 11 && phone.startsWith("0") && phone.all(Char::isDigit)

    fun isStaffCandidate(phone: String): Boolean =
        phone.length == 11 && phone.startsWith(GLO_STAFF_PREFIX) && phone.all(Char::isDigit)

    fun classify(phone: String): AccountClassification =
        if (isStaffCandidate(phone)) AccountClassification.GLO_STAFF_CANDIDATE
        else AccountClassification.AGENT_PARTNER

    fun newAccountId(): String = "FP-" + UUID.randomUUID().toString().replace("-", "").take(12).uppercase(Locale.US)
    fun timestamp(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).apply { timeZone = TimeZone.getTimeZone("Africa/Lagos") }.format(Date(ms))

// Legacy partner-authorization UI and request-sharing flow removed in v313.
}
