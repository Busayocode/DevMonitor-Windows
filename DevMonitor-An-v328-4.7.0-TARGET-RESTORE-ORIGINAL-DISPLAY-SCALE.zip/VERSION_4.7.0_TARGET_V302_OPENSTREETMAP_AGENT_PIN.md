# DevMonitor Android v302 — OpenStreetMap agent pin picker

- Replaces the Google Maps SDK pin picker with an in-app OpenStreetMap picker using osmdroid. No Google Maps API key, Google Maps billing setup, or Google Maps SDK dependency is required.
- Supports tapping/long-pressing the map to place the pin, dragging the marker to refine it, reviewing coordinates, and confirming coordinates back into the agent editor. The user must still explicitly press Save Agent to persist coordinates. Postal address remains a separate field.
- Map tiles require an internet connection. OpenStreetMap attribution is displayed in the picker. Tile access is subject to OpenStreetMap tile usage policies; this is not a promise of offline map tiles or unlimited bulk tile downloading.
- Keeps single-contact import with review/merge; multi-contact batch import remains deferred. Windows remains a receiving/display companion for Android-authoritative agent records.
- Payment calculations, payment rules, payment cards and MOM physical databases/snapshots are protected and unchanged.
- Verification status: source inspection and ZIP integrity only. Android compilation and on-device map interaction have not been verified.
