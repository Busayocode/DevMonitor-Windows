# DevMonitor Android v306 — Agent list, email selection, and map tiles

## Changes
- Display saved agents and partners directly on the main Agents & Partners menu.
- Keep Add agent or partner available; selecting a listed agent opens the existing management workflow.
- Contact import includes independent checkboxes for each phone number and email address.
- Use “Address” rather than “Postal address” in the UI.
- Use an explicit HTTPS OpenStreetMap tile URL and tune osmdroid tile retrieval.

## Verification status
- ZIP archive integrity: checked.
- Gradle compilation: not confirmed because the Gradle distribution could not be reached in this environment.
- On-device map tile rendering, contact import, and agent-list refresh: require phone verification.

## Protected logic
No intentional changes to payment calculations, MOM snapshots, HQ activation snapshots, target rules, or device-link business rules.
