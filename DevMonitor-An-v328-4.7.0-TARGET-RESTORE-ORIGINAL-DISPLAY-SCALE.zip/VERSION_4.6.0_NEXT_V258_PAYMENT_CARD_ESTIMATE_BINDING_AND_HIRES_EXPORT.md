# v258 — Payment card estimate binding and high-resolution share export

## Fixes
- SMS Checker share uses the exact Device Monitor payment-cycle estimate object displayed by the payment card, including contributions resolved from Loaded Reports and SMS overrides.
- Loaded Report share uses the existing Loaded Report estimate object.
- Android renderer remains presentation-only and does not calculate payment totals.
- Android PNG export renders the entire card at 2160 × 3620 (2x), sharpening the full layout including text, icons, progression track, detail rows, and footer.

## Validation
- Source-level changes applied.
- Build verification must be run in the Android phone environment with ARM-compatible AAPT2. Windows build verification requires a .NET SDK environment.
