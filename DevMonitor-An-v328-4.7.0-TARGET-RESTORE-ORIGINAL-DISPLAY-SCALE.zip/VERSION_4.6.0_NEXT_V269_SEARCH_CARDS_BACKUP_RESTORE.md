# DevMonitor 4.6.0-NEXT v269 — Search, card composition, backup/restore

Base: v268 `MODERN-INPUT-FIELDS`.

## Changes
- Retained filled, rounded Material 3 fields from v268.
- Covered the embedded sample “Payment Received!” badge in the payment-card hero and replaced it with “Payment Estimate”; the actual estimate continues to come from the existing payment engine.
- Reused the loaded HQ directory snapshot for My Partners search, filtering off the UI thread with a short debounce while retaining v239 search semantics.
- Added vertical space to the partner result flyer so optional details/Fork 3 metrics do not collide with the footer; replaced the baked-in payment-received badge with partner-activity wording on that flyer.
- Improved Drive backup to validate and update a single named app-data backup. Restore now validates SQLite integrity and required DevMonitor tables before staging the restore, and the live DB replacement retains a rollback copy until installation succeeds.

## Preserved
- Payment calculation rules and source selection.
- Partner-search fields and result cap from v239.
- Fork 3 aggregation and existing partner metrics.
- Existing backup location (`appDataFolder`) and explicit user-triggered behavior.

## Verification status
- Source-level checks: confirmed 42 filled text fields and zero outlined text fields; versionCode 269; both restore call sites use the staged installer.
- ZIP integrity: passed (`unzip -t`).
- Android build: not yet confirmed. The phone build environment previously lacked an ARM-compatible AAPT2 binary.
- Runtime verification still required for search latency, card rendering, and Google Drive backup/restore using a signed-in test account.
