# Android v311 — Add Agent/Partner menu cleanup

- Removed the **Batch share earnings cards** button from the Agent / Partner Database dialog.
- The change is limited to the visible menu entry. Existing earnings-card generation/sharing code and all business logic are otherwise unchanged.
- Version code: 311
- Version name: `4.7.0-TARGET-AGENT-MENU-CLEANUP`
- Validation: source-level and ZIP integrity checks passed; Android compilation/runtime not confirmed in this environment.
