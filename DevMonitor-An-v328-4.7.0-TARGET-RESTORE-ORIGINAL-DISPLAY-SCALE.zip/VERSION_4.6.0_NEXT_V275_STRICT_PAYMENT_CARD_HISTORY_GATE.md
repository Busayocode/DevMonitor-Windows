# DevMonitor 4.6.0-NEXT v275 — Strict Payment Card History Gate

Date: 2026-10-17

## Purpose
The v274 gate could still allow the card to open before the 21st because the existing payment calculator intentionally supports a pre-21st estimate from current-month cumulative Active. Card visibility now applies an explicit historical-evidence requirement of its own.

## Eligibility
- Requires a non-empty, device-specific Active history source in the previous calendar month: a Device Monitor observation with a non-null cumulative `active` value, or device-specific Loaded Report activation data.
- Requires current-calendar-month Active evidence from Device Monitor or Loaded Report data.
- On and after the 21st, also requires the calculator to provide a non-null baseline date and cumulative Active value through the 20th.
- The Company Directory/Skeleton is never queried by the gate. Identity, hierarchy, placeholder, and Today-only data cannot satisfy these checks.
- If evidence is missing, the card remains closed and the warning identifies the missing category of evidence.

## Protected behavior
No changes to payment formulas, the 21st–20th cycle, FRC progressive weekly display/exclusion from the main estimate, Sunday bonus qualification, next-tier projections, or Loaded Report / Device Monitor calculator separation.

## Verification
Source-level checks and ZIP integrity only. Android compilation and on-device behavior have not been verified in this environment.
