# DevMonitor Android v324 — Private broadcast administration and intermittent 48-hour display

## Implemented in source
- Broadcast management UI and diagnostics are shown only when the signed-in Firebase Authentication UID matches `BroadcastReleaseManager.ADMIN_FIREBASE_UID`.
- Publishing and stopping also perform an app-side UID check.
- Broadcasts expire after exactly 48 hours.
- The ticker is displayed for 15 seconds every 5 minutes while the broadcast is within its 48-hour window, then hidden.
- Firestore rules allow public reads of `devmonitor_version/devmonitor_broadcast` so ordinary installations can receive announcements; writes to this document require the configured UID.

## Required administrator setup before build/deploy
The administrator Firebase Authentication UID is configured as `ybRtiiwBqCgkoYRSKV1UuziNjgh1` in BOTH:
1. `app/src/main/java/com/aziitech/simregmonitor/BroadcastReleaseManager.kt` (`ADMIN_FIREBASE_UID`)
2. `firestore.rules` (broadcast document rule)

Use the same exact UID from Firebase Console → Authentication → Users. The app only exposes broadcast management to this UID, and Firestore writes to the broadcast document are restricted to the same UID.

Deploy the updated `firestore.rules` to Firebase Console (or the project's normal rules deployment flow) separately from the APK build. Existing rules for other documents are retained in the file; review the full ruleset before publishing to avoid unintended changes to other app features.

## Validation limits
ZIP integrity and XML/resource structure can be checked locally. The ZIP was checked for integrity and the UID placeholder was verified absent from the two active configuration files. No Android Gradle build or live Firestore security test is claimed by this note.
