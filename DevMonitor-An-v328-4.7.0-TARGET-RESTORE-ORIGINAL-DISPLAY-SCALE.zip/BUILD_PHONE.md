# DevMonitor phone build — Android Code Studio / ARM64

This project is configured for release builds from Android Code Studio on an ARM64 Android phone.

## Build a signed release APK

From the project root, run:

```sh
sh build-phone.sh assembleRelease --console=plain
```

The helper:

- searches `AAPT2_PATH`, `$HOME/.androidide/aapt2`, `$PREFIX/bin/aapt2`, and common Android Code Studio app-private paths;
- fails early with a clear message if an executable ARM-compatible AAPT2 cannot be found;
- passes the detected binary to Gradle using `-Pandroid.aapt2FromMavenOverride=...`, avoiding Gradle's incompatible desktop AAPT2 on ARM phones;
- checks for the release keystore and prompts for the keystore/key passwords without echoing them;
- prompts for the Google Drive API key without echoing it unless `DRIVE_REPORT_API_KEY` or `ORG_GRADLE_PROJECT_DRIVE_REPORT_API_KEY` is already supplied;
- does not write signing passwords or the API key into the project files.

The signed APK should be created at `app/build/outputs/apk/release/app-release.apk`.

## Build an Android App Bundle

```sh
sh build-phone.sh bundleRelease --console=plain
```

The AAB should appear under `app/build/outputs/bundle/release/`.

## If AAPT2 is not found

Run the following in the same terminal session and share the output (do not share secrets):

```sh
echo "$HOME"
echo "$PREFIX"
echo "$ANDROID_HOME"
find "$HOME" -type f -name aapt2 -executable 2>/dev/null | head
```

If you find the ARM-compatible binary in another location, set `AAPT2_PATH` to that exact path before running the script. Do not point it at a Linux x86_64 AAPT2 binary.

## Release credentials

Default keystore path:

`/storage/emulated/0/Download/1app/fieldpulse-release.jks`

Default key alias: `fieldpulse-release`

If your keystore is stored elsewhere, set `RELEASE_STORE_FILE` before invoking the script. Passwords are requested interactively and passed to Gradle through temporary environment-backed project properties. Never commit the keystore, passwords, or API key.

## Phone stability

The project retains one Gradle worker and disables parallel Gradle execution for stability on a phone. Release lint checks are non-blocking so `lintVitalAnalyzeRelease` does not indefinitely delay APK creation after compilation. This does not disable Kotlin/Java compilation or Android resource processing.
