# DevMonitor Android v266 — Preserve background checker activity

- Restores non-destructive navigation between My Partners and SMS Checker.
- Removes navigation-triggered cancellation and state clearing of active checker runs, pending permission-resume state, progress, and results.
- Leaves the intermittent, unreproduced cross-menu observation for targeted investigation if it occurs again; no broader state rewrite.
- Payment and partner performance calculations unchanged.
- Build/device validation pending.
