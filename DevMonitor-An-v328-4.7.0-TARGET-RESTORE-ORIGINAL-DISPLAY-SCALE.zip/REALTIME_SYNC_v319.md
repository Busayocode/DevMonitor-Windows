# DevMonitor Android v319 — Event-driven sync listener

- Added a long-poll listener for the PC bridge `/events` endpoint. A PC database/WAL change wakes an immediate encrypted sync.
- Added an Android SQLite/WAL `FileObserver` for local operational changes. A stable operational-payload fingerprint filters out status/settings writes and avoids repeated syncs for unchanged payloads.
- Kept the five-second fallback, existing retry/backoff and foreground/UI-scoped limitations.
- The operational fingerprint is built from the existing sync projection, with `createdAt` excluded so it is stable. HQ snapshots, target values, payment records, and MOM/payment calculations are not part of the payload; `monthly_target` is omitted from `daily_observations` transfer and not overwritten during merge.
- Events carry only a version number; data continues to travel through the encrypted AES-GCM `/sync` protocol.

## Verification status

Source-level changes and ZIP integrity are checked. Android compilation could not be run because Gradle 8.7 could not be downloaded in this environment. Device-level event delivery, echo-loop, reconnect, and sleep/resume tests remain required. Do not increase the fallback interval until those tests pass.
