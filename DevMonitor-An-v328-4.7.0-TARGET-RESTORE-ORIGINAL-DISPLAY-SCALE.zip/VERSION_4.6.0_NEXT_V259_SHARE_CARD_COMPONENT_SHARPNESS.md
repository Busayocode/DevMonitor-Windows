VERSION 4.6.0 NEXT v260 — ESTIMATE LABEL CLARITY

- Changed the share-card photographic hero badge to “Estimated Earnings”.
- Prevents the card from implying a payment has already been received.
- Presentation-only change; payment calculations and source selection remain unchanged.
