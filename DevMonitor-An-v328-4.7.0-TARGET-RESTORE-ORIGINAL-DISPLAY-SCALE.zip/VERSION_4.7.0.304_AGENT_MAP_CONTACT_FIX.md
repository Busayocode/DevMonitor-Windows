# DevMonitor 4.7.0 Target v304 — Agent map, contact import and directory visibility

- Hardened osmdroid initialization with app-specific User-Agent, initialized configuration, cache paths inside the app cache directory, data-connection enabled, and explicit map lifecycle resume. This targets blank square tile grids while retaining OpenStreetMap and its attribution.
- Added Contacts permission request on user-initiated contact import and changed phone/email/postal lookups to query their respective data tables by contact ID rather than querying those projections against the contact URI.
- Moved contact import into the Add/Edit Agent screen. Importing a contact before creating an agent now lets the user review and create a new agent with contact name, address, phone numbers, email addresses and available photo. Existing-agent imports continue to merge without replacing device links.
- Put the saved agent list immediately below search at the top of the Agents dialog, before the add/share actions, and added an empty-state prompt.
- No payment formulas, MOM snapshot rules, HQ activation snapshots or target calculations changed.

ZIP integrity is checked; Android compilation and device runtime must still be verified by the cloud workflow and phone testing.
