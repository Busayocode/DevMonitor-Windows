# v272 — Share-card next-tier earnings opportunity

- Adds the clearly labelled current payment estimate, the exact number of additional activations required to reach the next configured tier, the projected main estimate at that tier, and the incremental gain to Android shareable earnings cards.
- Uses the existing `IncentiveEstimate` fields and tier table. Keeps only the currently qualified Sunday bonus in the projection; does not forecast unqualified future Sunday bonuses.
- Weekly-paid FRC remains visible separately and is excluded from both current and projected main estimates.
- Source selection and the underlying payment engine remain unchanged.
- Validation status: static source/archive checks only; Android build and on-device PNG inspection are pending.
