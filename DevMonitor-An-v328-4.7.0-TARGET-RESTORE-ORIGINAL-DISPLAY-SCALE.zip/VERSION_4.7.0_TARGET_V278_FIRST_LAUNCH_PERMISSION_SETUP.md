# DevMonitor Android v278 — First-launch permission setup

## Change
Added a one-time, step-by-step Android permission setup wizard after the existing welcome introduction on fresh installs. It explains each permission group, shows grant status, supports retrying or skipping, links directly to Android app settings when permission changes are needed, and does not prevent the user from opening DevMonitor if a permission is declined.

## Permission groups
- SMS: send/receive for user-started 3030 monitoring, plus inbox read access for optional recovery.
- Phone/SIM: discover active SIM subscriptions and support SIM selection.
- Location: optional last-known location for map helpers.
- Notifications: Android 13+ system notification permission.

Normal permissions that do not need runtime prompts are not included in the wizard. Existing installations that already completed the welcome introduction are not retroactively shown the first-launch wizard.

## Strictly separate work
Google Drive / online-report configuration is not checked, displayed, or modified by this wizard. Its download issue remains a separate task.

## Protected areas
No payment formulas, payment-cycle rules, MOM/HQ database schemas, report import/download logic, or Windows build logic were changed.

## Version and validation
- `versionCode = 278`
- `versionName = 4.7.0-TARGET-PERMISSION-SETUP`
- Source review and ZIP integrity checks completed. GitHub/Gradle compilation and first-install device validation remain pending.
