# v273 — Historical eligibility gate for payment progression

- Prevents a Device Monitor payment estimate from being produced after the 21st when the required cumulative Active baseline through the 20th is missing.
- Does not assume a zero baseline. The estimate and share action remain unavailable until a valid baseline is recorded or a Loaded Report covering the boundary is imported.
- Existing Loaded Report calculations and all payment tiers, FRC separation, Sunday bonus qualification, and next-tier card logic remain unchanged.
- VersionCode 273. Static source/archive checks only; Android compilation and device verification pending.
