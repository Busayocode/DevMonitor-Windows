# Android v308 — Agent photo thumbnail preview

## Included
- Contact import review displays the contact photo thumbnail when available, otherwise a neutral avatar placeholder.
- Photo bytes are staged temporarily in app cache for preview and copied into app-private agent photo storage only after import confirmation. Cancel/dismiss removes the temporary preview.
- Saved Agents & Partners list rows display thumbnail images. Add/Edit Agent displays the saved thumbnail and offers Select photo for new and existing agents; the selected image previews before save.
- Existing saved photo is retained when merging another contact.

## Protected behavior
No intended changes to payment calculations, MOM snapshots/retention, HQ activation snapshots, target logic, report authority, or device-link rules.

## Verification
ZIP integrity and source inspection only. Gradle compilation and phone runtime were not verified because Gradle distribution download access may be unavailable.
