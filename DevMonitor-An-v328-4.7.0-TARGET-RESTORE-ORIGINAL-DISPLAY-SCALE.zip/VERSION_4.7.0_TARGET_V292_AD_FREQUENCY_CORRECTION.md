# DevMonitor v292 — Ad frequency and report-credit correction

## Changes
- Android `versionCode`: 292.
- First 10 successful report exports remain free. Once the user reaches the limit, a completed rewarded ad grants 5 export credits. The selected report export proceeds only after the ad reward callback confirms the reward.
- Interstitial threshold raised from every 5 to every 10 successful SMS-monitoring result events. The existing natural completion pause is retained; if no interstitial is loaded, monitoring continues without interruption.
- No payment calculation, target calculation, MOM/HQ data-store, Drive, or location-permission changes were made intentionally.

## Not included
Rewarded-ad counting/gating for shared result-estimate cards is not yet implemented. A separate share-counter and unlock policy should be agreed before adding it.

## Verification
Source inspection and ZIP integrity only. Gradle compilation, AdMob delivery, and physical-device testing are still required.
