# DevMonitor Android v316 — LAN discovery, QR scan, and explicit initiation

- Added local UDP discovery on port 43828 for a running DevMonitor Windows bridge. Discovery sends a fixed probe and receives only PC name/address/port; no key or user data is broadcast.
- Added QR scanning for the Windows pairing invitation; it fills the endpoint and key but does not initiate sync automatically.
- The Android user must tap Sync now. Automatic retry/sync loops remain gated until a successful user-initiated sync.
- Windows asks for approval before processing the first encrypted exchange and remembers the approved pairing-key fingerprint.
- Existing AES-GCM sync and manual entry remain available. Build/runtime verification is pending.
