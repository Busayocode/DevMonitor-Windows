# DevMonitor Android v321 — Automatic Sync Activation

Changes from Android v320:
- Reuses a saved PC endpoint and pairing key to activate automatic sync on screen entry.
- Scanning a valid DevMonitor pairing QR saves the connection and activates automatic sync immediately.
- Removes UI copy that described a Windows approval prompt.
- Manual Sync now remains available as a diagnostic/recovery action.

Protected sync exclusions remain unchanged: HQ snapshots/targets, payment records/cycles/calculations, and MOM records are not added to sync.

Validation: source edits and ZIP integrity only; Android compilation and real device transfer have not been verified here.
