# DevMonitor 4.6.0-NEXT v262 — Share Card Responsiveness Fix

- Moved payment-card bitmap rendering and PNG compression off Android's main/UI thread.
- The share chooser is launched on the main thread only after the PNG and FileProvider URI are ready.
- Added graceful completion feedback if rendering or chooser launch fails.
- Keeps the existing selected estimate object and payment/source figures unchanged; this is a responsiveness fix only.
- Version code advanced to 262.
- Runtime/device test and Gradle compilation still required.
