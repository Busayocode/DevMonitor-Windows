# Android v299 — Agent contact fields and linked-device card personalization

## Included source changes
- Additive SQLite schema upgrade adds a persistent `agent_emails` table and `agents.photo_path`; existing agent, phone, device, payment and MOM rows are retained.
- Contact import from the existing contact picker now imports multiple phone numbers and labels, multiple email addresses and labels, and a postal address only when the agent address is blank. Duplicate phone/email values are skipped.
- Contact thumbnail is copied into app-private `agent_photos` storage when the agent does not already have a saved photo. Re-import does not silently replace an existing photo or a manually entered postal address.
- Agent details display linked My Devices codes and allow adding/removing email addresses. Existing device-link workflow remains in place.
- Device earnings share cards use the explicitly linked agent's name and, when available, saved local photo and first phone number. Batch agent cards use the same saved details. This is presentation-only; the exact selected source estimate is passed through unchanged.
- Sync bridge carries email rows to the paired Windows app. Local photo file paths are intentionally not synced because a phone-private filesystem path is not valid on Windows.

## Scope and limitations
- This increment does not yet provide a multi-contact preview/merge wizard, a full map-pin picker, photo replacement/clear controls, or Windows-native contact/photo import. Those remain follow-up acceptance items.
- Existing map coordinate fields and current-location/Maps actions remain unchanged; opening external Maps is not treated as a saved pin-selection workflow.
- No payment formula, payment-cycle boundary, MOM snapshot, trend aggregation, HQ report or device performance calculation was changed.

## Verification status
- ZIP integrity and source-level consistency checks are required before distribution.
- Android compile/device test and Windows compile/runtime test are not claimed unless separately completed and recorded.
