# Android v312 (superseded) — Broadcast Centre and automated release tracker

- Added a cloud-backed, scrolling in-app broadcast ticker. Broadcast messages are read publicly and can be written only by staff allowed by the existing Firestore `isStaff()` rule. Admin controls are shown only when the authenticated phone number matches that staff pattern.
- Broadcast Centre supports top/bottom placement, a 1/3/7/30-day expiry, publish and stop. Apps fetch the active message on launch, so users receive it the next time they open DevMonitor with connectivity. It is not a push notification and does not wake a closed app.
- Added per-version What's New dialog, shown once per version on first launch after upgrade, with a Settings entry to view it again. Notes are bundled in the APK and can be overridden by a staff-published `app_releases/{versionCode}` Firestore document.
- Added `scripts/generate_release_notes.py`; the Android release workflow runs it against version/change documentation before building, reducing manual release-note work.
- Added Firestore rules for public reads and staff-only writes to broadcast/release documents. These rules must be deployed to the Firebase project for cloud publishing to work. Existing `app_config/devmonitor_version` update checks remain intact.
- No payment, MOM, HQ activation snapshot, target, report-import, or device-link business logic was intentionally changed.
- Validation: source review and ZIP integrity only. Android compilation/runtime and live Firestore rules deployment are not verified here.
