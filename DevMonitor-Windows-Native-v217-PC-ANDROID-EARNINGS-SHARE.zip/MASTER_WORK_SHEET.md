# DevMonitor Windows Master Work Sheet

## Current package
- Windows native version: **4.6.0.217**.
- Android handoff baseline: **4.6.0-NEXT versionCode 227**.

## Cross-device earnings-card sharing
- Start on Windows from **Earning Progress → Share an agent card via Android** or **Share Earnings Cards**.
- Select one source for the whole batch: SMS Checker or Loaded Report. Select agent rows; every linked device with values in that source gets a separate PNG.
- Cards show source-only Today, MTD and Active values, the selected source, reporting period, as-of timestamp, and a monitoring-only warning. This PC handoff does not compute a new payment estimate or fill missing values from another source.
- Cards are queued locally as `share_queue` records, included in the existing AES-GCM encrypted sync response, then presented by Android in the native share sheet. Android sends card IDs back as acknowledgements on the next exchange. The PC removes acknowledged queue entries.
- The share-sheet handoff is not proof that WhatsApp or another recipient received a message. User selects recipient and confirms sending.
- Limits: up to 20 cards per batch; transfer uses the existing 15 MB encrypted bridge request limit; Android rejects individual PNG payloads above 2 MB.

## Protected boundaries
- No changes to `PaymentRules.cs` or the Android payment calculation paths.
- HQ snapshots and payment records remain excluded from synchronization.
- Existing five-minute standby reachability policy and bounded retry/backoff behavior are unchanged.

## Verification status
- Source archive and documentation prepared. Android Gradle compilation could not be completed in this environment because the Gradle distribution download requires network access. Windows compilation and paired Android↔PC handoff remain to be verified by GitHub Actions and a real paired-device test.
