# Android / Windows Feature Parity Matrix — v294 (2026-10-21)

## Monthly target delivery forecast (current requirement)
- Both platforms show only the current calendar month against the active profile's configured target.
- Neutral figures only: monthly target, delivered so far, projected month-end at the observed daily rate, target achieved percentage, and remaining target balance.
- Do not display management verdicts or pressure-inducing status labels: no “on track”, “at risk”, red shortfall warnings, or equivalent judgement text.
- Daily sales lists/charts include only recorded observation dates; missing dates are not treated as zero sales.
- Data retention remains two calendar months. Do not expand retention to support trends.
- Projection uses cumulative current-month delivered sales / latest observed calendar day × days in the current month. It is an estimate, not a guarantee.
- Preserve the existing profile/ownership target scoping and agent fixed target of 150 where applicable.
- Payment engine/rules, payment card logic, MOM physical databases/snapshots, report import authority and cutoff rules are protected and unchanged.

## v294 source status
- Android source updated to v294; build/device verification pending.
- Windows source updated to v280; build/runtime verification pending.
- Cross-platform parity is source-level only until both builds and real imported-data comparisons are tested.

---

# Android / Windows Feature Parity Matrix — v293 (2026-10-21)

Purpose: keep phone and Windows-native DevMonitor implementations aligned on product behaviour, not just labels. Update this document alongside `MASTER_WORK_SHEET.md`, `CHANGE_LOG.md`, `NEXT_LEVEL_ROADMAP.md`, and `NEXT_LEVEL_TRACKER.md` for cross-platform changes.

| Feature / contract | Android | Windows native | Acceptance rule |
|---|---|---|---|
| Trend period | Current calendar month vs target | Current calendar month vs target | No 7/30-day or 6/12-month selector; neutral target figures only; no management verdicts. |
| Visual Trends history | Select 6 or 12 calendar months | Must offer equivalent 6 or 12 calendar-month history | Each plotted point represents one calendar month, not one day. |
| Sales comparison | Current MTD vs previous calendar month through same day-of-month | Same calculation and cutoff | Clamp the previous-month cutoff to its last day when the current date's day number does not exist in that month. |
| Monthly sales / Bar 48 / ownership | Sum observed daily values within each month | Same aggregation | Missing observation days remain missing; do not synthesize zero-sales observations. |
| Active total | Latest observed active snapshot within each month | Same aggregation | Do not sum daily active snapshots into a monthly total. |
| Refresh | Explicit user action | Explicit user action | Profile navigation/import must not silently trigger expensive trend recalculation. |
| Protected logic | Payment rules, payment-cycle boundaries, MOM/HQ storage and report authority unchanged | Same protected contracts | Trend implementation must not modify payment or MOM business logic. |
| Documentation | Master sheet, changelog, roadmap, tracker and this matrix | Same shared contract | Mark platform implementation/test status separately; do not claim parity until both builds are verified. |

## v293 Android status

- Source implementation updated to calendar-month aggregation and same-period month-on-month sales comparison.
- Source ZIP integrity and targeted source assertions passed.
- Android Gradle build/device verification: pending.
- Windows-native implementation/build parity: not verified in this Android source package; the Windows project must implement and test the same acceptance rules before parity is marked complete.
