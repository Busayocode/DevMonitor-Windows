package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Private Google Drive appData backup. The database stays local unless the user explicitly backs it up. */
class DriveAuthorizationRequiredException(
    val resolutionIntent: Intent,
    cause: Throwable
) : Exception("Google Drive access needs your approval", cause)

object GoogleDriveBackup {
    private const val SCOPE = "oauth2:https://www.googleapis.com/auth/drive.appdata"
    private const val API = "https://www.googleapis.com/drive/v3/files"
    private const val UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    private const val NAME = "DevMonitorBackup.db"

    suspend fun backup(context: Context, account: GoogleSignInAccount, dbFile: File): String = withContext(Dispatchers.IO) {
        if (!dbFile.isFile || !dbFile.canRead() || dbFile.length() < 1000L) {
            throw IllegalStateException("The local DevMonitor database is missing or too small to back up")
        }
        validateDatabase(dbFile)
        val email = account.email?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Google account email is unavailable")
        val token = getDriveAccessToken(context, email)
        val existing = findBackup(token)
        val boundary = "DevMonitor-${System.currentTimeMillis()}"
        val metadata = JSONObject().put("name", NAME)
        val destination = if (existing == null) {
            "$UPLOAD?uploadType=multipart&fields=id,name,modifiedTime"
        } else {
            "$UPLOAD/${existing.first}?uploadType=multipart&fields=id,name,modifiedTime"
        }
        val conn = URL(destination).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20_000
            conn.readTimeout = 60_000
            conn.requestMethod = if (existing == null) "POST" else "PATCH"
            conn.doOutput = true
            conn.useCaches = false
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
            conn.outputStream.use { out ->
                out.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".toByteArray(Charsets.UTF_8))
                out.write(metadata.toString().toByteArray(Charsets.UTF_8))
                out.write("\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray(Charsets.UTF_8))
                dbFile.inputStream().use { input -> input.copyTo(out) }
                out.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
            }
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("Google Drive backup failed (${conn.responseCode}): ${readError(conn)}")
            }
            if (existing == null) "Backup completed to your Google Drive app data"
            else "Backup updated in your Google Drive app data"
        } finally {
            conn.disconnect()
        }
    }

    suspend fun restore(context: Context, account: GoogleSignInAccount, target: File): String = withContext(Dispatchers.IO) {
        val email = account.email?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Google account email is unavailable")
        val token = getDriveAccessToken(context, email)
        val newest = findBackup(token)
            ?: throw IllegalStateException("No DevMonitor backup was found in this Google account")
        val download = URL("$API/${newest.first}?alt=media").openConnection() as HttpURLConnection
        val bytes = try {
            download.connectTimeout = 20_000
            download.readTimeout = 60_000
            download.setRequestProperty("Authorization", "Bearer $token")
            if (download.responseCode !in 200..299) {
                throw IllegalStateException("Google Drive restore failed (${download.responseCode}): ${readError(download)}")
            }
            download.inputStream.use { it.readBytes() }
        } finally {
            download.disconnect()
        }
        if (bytes.size < 1000) throw IllegalStateException("The cloud backup appears invalid or incomplete")
        target.parentFile?.mkdirs()
        val staged = File(target.parentFile ?: target.absoluteFile.parentFile, target.name + ".download.tmp")
        try {
            staged.outputStream().use { it.write(bytes) }
            validateDatabase(staged)
            if (target.exists() && !target.delete()) throw IllegalStateException("Could not replace the previous temporary restore file")
            if (!staged.renameTo(target)) {
                staged.copyTo(target, overwrite = true)
                staged.delete()
            }
            "Restore downloaded and validated successfully"
        } catch (e: Exception) {
            staged.delete()
            throw e
        }
    }

    /** Obtain the app-folder token and preserve Google's interactive consent flow when required. */
    private fun getDriveAccessToken(context: Context, email: String): String = try {
        GoogleAuthUtil.getToken(context, email, SCOPE)
    } catch (e: UserRecoverableAuthException) {
        throw DriveAuthorizationRequiredException(e.intent, e)
    }

    /** Return the newest existing backup id, or null when this account has none. */
    private fun findBackup(token: String): Pair<String, String>? {
        val q = URLEncoder.encode("name='$NAME' and 'appDataFolder' in parents and trashed=false", "UTF-8")
        val list = JSONObject(request("$API?q=$q&spaces=appDataFolder&fields=files(id,name,modifiedTime)&pageSize=100", token))
        val files = list.optJSONArray("files") ?: JSONArray()
        if (files.length() == 0) return null
        var newestId: String? = null
        var newestTime = ""
        for (i in 0 until files.length()) {
            val item = files.optJSONObject(i) ?: continue
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
            val time = item.optString("modifiedTime")
            if (newestId == null || time > newestTime) {
                newestId = id
                newestTime = time
            }
        }
        return newestId?.let { it to newestTime }
    }

    /** Reject truncated, non-SQLite, or structurally invalid backups before touching live data. */
    private fun validateDatabase(file: File) {
        if (!file.isFile || file.length() < 1000L) throw IllegalStateException("The backup file is empty or incomplete")
        val header = ByteArray(16)
        file.inputStream().use { input ->
            if (input.read(header) != header.size || !header.contentEquals("SQLite format 3\u0000".toByteArray(Charsets.US_ASCII))) {
                throw IllegalStateException("The backup is not a valid DevMonitor SQLite database")
            }
        }
        val db = try {
            SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        } catch (e: Exception) {
            throw IllegalStateException("The backup database could not be opened: ${e.message ?: "invalid database"}", e)
        }
        try {
            db.rawQuery("PRAGMA quick_check", null).use { cursor ->
                if (!cursor.moveToFirst() || !cursor.getString(0).equals("ok", ignoreCase = true)) {
                    throw IllegalStateException("The backup database failed its integrity check")
                }
            }
            val required = setOf("codes", "records", "settings")
            val found = mutableSetOf<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { cursor ->
                while (cursor.moveToNext()) found += cursor.getString(0)
            }
            if (!found.containsAll(required)) throw IllegalStateException("This file is not a complete DevMonitor database backup")
        } finally {
            db.close()
        }
    }

    private fun request(url: String, token: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("Authorization", "Bearer $token")
            if (c.responseCode !in 200..299) {
                throw IllegalStateException("Google Drive request failed (${c.responseCode}): ${readError(c)}")
            }
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun readError(conn: HttpURLConnection): String = runCatching {
        (conn.errorStream ?: return@runCatching "no error details").bufferedReader().use { it.readText() }
            .replace(Regex("\\s+"), " ").take(240)
    }.getOrDefault("no error details")
}
