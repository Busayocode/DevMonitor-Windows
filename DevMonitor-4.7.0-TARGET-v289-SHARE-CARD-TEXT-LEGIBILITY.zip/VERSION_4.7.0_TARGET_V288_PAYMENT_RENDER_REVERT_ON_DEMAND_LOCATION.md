# v288 — Payment render responsiveness and contextual location permission

- Reverted the v287 payment-card bitmap scale from 2.0x to the prior 1.5x. The larger output increased rendering work and did not resolve perceived shared-image quality; payment values, formulas, and logical layout remain unchanged.
- Removed coarse/fine location from first-launch permission onboarding. First-launch setup now covers SMS, phone/SIM information, and notifications only.
- Kept location permissions in the manifest and retained feature-triggered permission requesting in `currentLocation()` when an optional map helper actually needs location.
- No changes to Google Drive, report imports, payment logic, MOM/HQ storage, or partner cards.

## Verification required
Static source and ZIP checks only. Run the normal Android build and test first launch, optional map-helper location request, and share-button responsiveness on a phone.
