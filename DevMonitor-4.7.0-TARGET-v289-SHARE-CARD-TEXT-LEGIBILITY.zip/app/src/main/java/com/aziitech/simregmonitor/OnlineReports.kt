package com.aziitech.simregmonitor

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A read-only public Google Drive report entry. */
data class OnlineReportFile(
    val id: String,
    val name: String,
    val modifiedTime: String?,
    val size: Long?
)

/**
 * Public-folder Google Drive access for company reports.
 *
 * The folder and API key are BuildConfig values so the production folder can be
 * configured without changing the importer. The API key is not treated as a secret;
 * it should be restricted in Google Cloud to the Drive API and the app's intended use.
 */
object OnlineReportStore {
    private const val DRIVE_API = "https://www.googleapis.com/drive/v3/files"
    private const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    private val SUPPORTED_EXTENSIONS = setOf(".xlsx", ".xlsm", ".xls", ".csv")

    fun configured(): Boolean =
        BuildConfig.DRIVE_REPORT_FOLDER_ID.isNotBlank() && BuildConfig.DRIVE_REPORT_API_KEY.isNotBlank()

    fun listReports(): List<OnlineReportFile> {
        check(configured()) { "Online reports are not configured yet." }
        val folderId = BuildConfig.DRIVE_REPORT_FOLDER_ID.trim()
        val apiKey = BuildConfig.DRIVE_REPORT_API_KEY.trim()
        val fields = "nextPageToken,files(id,name,modifiedTime,size,mimeType)"

        // Try the ordinary public-folder listing first, matching the known working phone path.
        // If it returns no supported reports, retry against all drives. Setting the all-drives
        // flags without corpora=allDrives is not sufficient to discover shared-drive content.
        val ordinary = listReportsForCorpus(folderId, apiKey, fields, allDrives = false)
        if (ordinary.reports.isNotEmpty()) return ordinary.reports

        val shared = listReportsForCorpus(folderId, apiKey, fields, allDrives = true)
        if (shared.reports.isNotEmpty()) return shared.reports

        val folderSuffix = folderId.takeLast(6)
        val details = buildString {
            append("Google Drive responded successfully, but no supported Excel/CSV reports were found in folder ending …")
            append(folderSuffix).append(". ")
            append("Files returned by normal listing: ").append(ordinary.rawCount).append("; ")
            append("files returned by all-drives listing: ").append(shared.rawCount).append(". ")
            append("Check that the configured folder contains the report files directly (not only inside a subfolder), ")
            append("and that the folder/files are readable to the API key's public listing request.")
            val names = (ordinary.sampleNames + shared.sampleNames).distinct().take(5)
            if (names.isNotEmpty()) append(" Sample returned names: ").append(names.joinToString(", ")).append(".")
        }
        error(details)
    }

    private data class DriveListingResult(
        val reports: List<OnlineReportFile>,
        val rawCount: Int,
        val sampleNames: List<String>
    )

    private fun listReportsForCorpus(
        folderId: String,
        apiKey: String,
        fields: String,
        allDrives: Boolean
    ): DriveListingResult {
        val query = "'$folderId' in parents and trashed = false and mimeType != 'application/vnd.google-apps.folder'"
        val reports = mutableListOf<OnlineReportFile>()
        val sampleNames = mutableListOf<String>()
        var rawCount = 0
        var pageToken: String? = null
        var pageCount = 0

        while (pageCount < 5) {
            pageCount++
            val queryParams = buildString {
                append("q=").append(URLEncoder.encode(query, "UTF-8"))
                append("&spaces=drive&pageSize=100")
                append("&orderBy=modifiedTime%20desc")
                append("&fields=").append(URLEncoder.encode(fields, "UTF-8"))
                append("&key=").append(URLEncoder.encode(apiKey, "UTF-8"))
                if (allDrives) {
                    append("&corpora=allDrives&includeItemsFromAllDrives=true&supportsAllDrives=true")
                }
                if (!pageToken.isNullOrBlank()) {
                    append("&pageToken=").append(URLEncoder.encode(pageToken, "UTF-8"))
                }
            }
            val connection = (URL("$DRIVE_API?$queryParams").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 12_000
                setRequestProperty("Accept", "application/json")
            }
            try {
                val code = connection.responseCode
                val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    error("Google Drive returned HTTP $code${body.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}")
                }
                val payload = JSONObject(body)
                val files = payload.optJSONArray("files")
                if (files != null) {
                    rawCount += files.length()
                    for (i in 0 until files.length()) {
                        val item = files.optJSONObject(i) ?: continue
                        val id = item.optString("id").trim()
                        val name = item.optString("name").trim()
                        val lowerName = name.lowercase(Locale.US)
                        val mimeType = item.optString("mimeType").trim()
                        if (name.isNotBlank() && sampleNames.size < 5) sampleNames.add(name)
                        val supported = mimeType == XLSX_MIME || SUPPORTED_EXTENSIONS.any { lowerName.endsWith(it) }
                        if (id.isNotBlank() && name.isNotBlank() && supported) {
                            reports.add(
                                OnlineReportFile(
                                    id,
                                    name,
                                    item.optString("modifiedTime").takeIf { it.isNotBlank() },
                                    item.optLong("size").takeIf { it > 0 }
                                )
                            )
                        }
                    }
                }
                pageToken = payload.optString("nextPageToken").takeIf { it.isNotBlank() }
                if (pageToken == null) break
            } finally {
                connection.disconnect()
            }
        }
        return DriveListingResult(
            reports.distinctBy { it.id }.sortedWith(
                compareByDescending<OnlineReportFile> { it.modifiedTime.orEmpty() }
                    .thenBy { it.name.lowercase(Locale.US) }
            ),
            rawCount,
            sampleNames
        )
    }

    fun downloadToCache(context: android.content.Context, file: OnlineReportFile): java.io.File {
        check(NetworkUtils.hasActiveInternet(context)) { NetworkUtils.OFFLINE_MESSAGE }
        check(configured()) { "Online reports are not configured yet." }
        val safeName = file.name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "report.xlsx" }
        val target = java.io.File.createTempFile("fieldpulse_report_", "_$safeName", context.cacheDir)
        val url = URL(
            "$DRIVE_API/${URLEncoder.encode(file.id, "UTF-8")}?alt=media&supportsAllDrives=true&key=${URLEncoder.encode(BuildConfig.DRIVE_REPORT_API_KEY.trim(), "UTF-8")}"
        )
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 120_000
            setRequestProperty("Accept", XLSX_MIME)
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) {
                val detail = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                target.delete()
                error("Unable to download report (HTTP $code${detail.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""})")
            }
            connection.inputStream.use { input -> target.outputStream().use { output -> input.copyTo(output, 64 * 1024) } }
            return target
        } catch (t: Throwable) {
            target.delete()
            throw t
        } finally {
            connection.disconnect()
        }
    }

    fun formatModified(value: String?): String {
        if (value.isNullOrBlank()) return ""
        return runCatching {
            val source = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            source.timeZone = java.util.TimeZone.getTimeZone("UTC")
            val date = source.parse(value) ?: return value
            SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(date)
        }.getOrElse { value }
    }
}

@Composable
fun OnlineReportsDialog(
    onDismiss: () -> Unit,
    onSelect: (OnlineReportFile) -> Unit,
    loadingSelection: Boolean = false,
    selectedName: String? = null
) {
    val context = LocalContext.current
    var reports by remember { mutableStateOf<List<OnlineReportFile>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var refreshing by remember { mutableStateOf(false) }
    var refreshToken by remember { mutableStateOf(0) }

    suspend fun refresh() {
        if (!NetworkUtils.hasActiveInternet(context)) {
            reports = emptyList()
            error = NetworkUtils.OFFLINE_MESSAGE
            return
        }
        if (!OnlineReportStore.configured()) {
            reports = emptyList()
            error = "Online reports are not configured yet. Set the Google Drive folder ID and API key in the build configuration."
            return
        }
        refreshing = true
        error = null
        try {
            val result = withTimeout(25_000) {
                withContext(Dispatchers.IO) {
                    runInterruptible { OnlineReportStore.listReports() }
                }
            }
            reports = result
            error = null
        } catch (t: kotlinx.coroutines.TimeoutCancellationException) {
            reports = emptyList()
            error = "Google Drive took too long to respond. Check the connection and tap Retry."
        } catch (t: kotlinx.coroutines.CancellationException) {
            // Preserve structured cancellation, but always release the loading indicator below.
            throw t
        } catch (t: Throwable) {
            reports = emptyList()
            error = t.message ?: t.javaClass.simpleName
        } finally {
            refreshing = false
        }
    }

    LaunchedEffect(refreshToken) { refresh() }

    AlertDialog(
        onDismissRequest = { if (!loadingSelection) onDismiss() },
        title = { Text("Online Company Reports") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "Choose any report from the shared folder. The latest report is listed first.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                if (loadingSelection) {
                    DevMonitorLoadingState("Downloading ${selectedName ?: "report"}…", "The online report is being prepared for import.")
                } else if (refreshing || reports == null) {
                    DevMonitorLoadingState("Loading online reports…", "Connecting to Google Drive and reading available reports.")
                } else if (!error.isNullOrBlank()) {
                    if (error == NetworkUtils.OFFLINE_MESSAGE) {
                        DevMonitorOfflineState(message = error!!, actionLabel = "Retry", onAction = { refreshToken++ })
                    } else {
                        DevMonitorErrorState(message = error!!, actionLabel = "Retry", onAction = { refreshToken++ })
                    }
                } else if (reports!!.isEmpty()) {
                    DevMonitorEmptyState("No online reports", "No Excel reports are currently available in the configured online folder.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.height(330.dp)) {
                        items(reports!!, key = { it.id }) { report ->
                            val isLatest = report == reports!!.firstOrNull()
                            Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                TextButton(onClick = { if (NetworkUtils.hasActiveInternet(context)) onSelect(report) else error = NetworkUtils.OFFLINE_MESSAGE }, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                                        Text(report.name, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                                        if (isLatest) Text("LATEST • Recommended", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                                        OnlineReportStore.formatModified(report.modifiedTime).takeIf { it.isNotBlank() }?.let {
                                            Text("Updated $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                                Divider()
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss, enabled = !loadingSelection) { Text("Close") }
        }
    )
}
