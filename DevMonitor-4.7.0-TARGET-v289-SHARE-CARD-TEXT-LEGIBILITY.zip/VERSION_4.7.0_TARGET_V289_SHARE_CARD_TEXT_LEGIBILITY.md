# DevMonitor v289 — Share-card text legibility

## Scope
- Based on v288.
- Improve small-text readability and secondary-label contrast in the partner performance and payment earnings share-card images.
- Keep the existing 1.5× bitmap scale to avoid repeating the share-button latency regression from v287.
- Preserve card layout geometry, source values, all payment calculations, payment progression, MOM/HQ stores, Drive configuration, and launch permissions.
- This is a presentation-only change. Small type sizes below 20 logical pixels were selectively increased by 1–3 pixels; recurring secondary labels use darker contrast.

## Validation status
- Source ZIP assembled from v288 and versionCode/versionName advanced to 289.
- No Gradle build or on-device share/compression test has been run yet.
- Verify readability in the final received image on WhatsApp and other share targets; receiver-side image compression may still affect sharpness.
