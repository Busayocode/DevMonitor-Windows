# v287 — High-resolution payment-card share images

## Scope
Presentation-only enhancement to payment-card image sharing.

## Change
The payment-card PNG renderer now uses 2x output scale: 2160 × 4080 pixels instead of 1620 × 3060. Text, small labels, icons, borders and gradients are rasterized at the higher density.

## Preserved
- No payment formulas, eligibility rules, payment-cycle rules, or estimates are recalculated or modified.
- No change to payment source selection or card contents.
- Partner-result card renderer unchanged.
- Rendering remains user-initiated and runs off the UI thread for the async single-card flow.

## Validation
Source-level change and ZIP integrity checks only; Android build and device/share-app visual testing remain to be completed.
