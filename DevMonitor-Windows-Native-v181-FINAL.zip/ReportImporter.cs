using System.IO;
using ClosedXML.Excel;

namespace DevMonitor.Windows;

public static class ReportImporter
{
    public static List<DeviceRow> Read(string path,out DateTime coverageStart,out DateTime coverageEnd)
    {
        using var wb=new XLWorkbook(path);
        var ws=wb.Worksheets.First();
        var used=ws.RangeUsed() ?? throw new InvalidDataException("The workbook contains no data.");
        var rows=used.RowsUsed().ToList();
        if(rows.Count<2) throw new InvalidDataException("The report does not contain a data table.");

        var header=rows[0].Cells().Select(c=>c.GetString().Trim()).ToList();
        int Find(params string[] names){
            for(int i=0;i<header.Count;i++) if(names.Any(n=>header[i].Contains(n,StringComparison.OrdinalIgnoreCase))) return i+1;
            return -1;
        }
        var deviceCol=Find("device","serial","code","sim");
        if(deviceCol<1) throw new InvalidDataException("Could not identify the device/code column.");

        var dateCols=new List<(int col,DateTime date)>();
        for(int c=1;c<=used.ColumnCount();c++){
            var h=header.ElementAtOrDefault(c-1)??"";
            if(DateTime.TryParse(h,out var d)) dateCols.Add((c,d.Date));
            else if(DateTime.TryParse(ws.Cell(1,c).Value.ToString(),out d)) dateCols.Add((c,d.Date));
        }
        if(dateCols.Count==0){
            // Some HQ files place dates on the second header row.
            for(int c=1;c<=used.ColumnCount();c++) if(DateTime.TryParse(ws.Cell(2,c).GetString(),out var d)) dateCols.Add((c,d.Date));
        }
        if(dateCols.Count==0) throw new InvalidDataException("No daily date columns were detected.");

        int Col(string text, string fallback=""){
            var i=Find(text);return i>0?i:Find(fallback);
        }
        var trade=Col("trade","code");var partner=Col("partner","name");var cluster=Col("cluster");
        var region=Col("region");var territory=Col("territory");var staff=Col("staff");
        var map=new Dictionary<string,DeviceRow>(StringComparer.OrdinalIgnoreCase);
        foreach(var row in rows.Skip(1)){
            var id=row.Cell(deviceCol).GetString().Trim();if(string.IsNullOrWhiteSpace(id))continue;
            var daily=new Dictionary<DateTime,int>();
            foreach(var dc in dateCols){
                var cell=row.Cell(dc.col);if(int.TryParse(cell.GetString(),out var n))daily[dc.date]=n;
                else if(cell.TryGetValue<int>(out var ni))daily[dc.date]=ni;
                else if(double.TryParse(cell.GetString(),out var dn))daily[dc.date]=(int)dn;
            }
            var canonical=DevMonitorDb.Canonical(id);
            map[canonical]=new DeviceRow(canonical,
                trade>0?row.Cell(trade).GetString():"",
                partner>0?row.Cell(partner).GetString():"",
                cluster>0?row.Cell(cluster).GetString():"",
                region>0?row.Cell(region).GetString():"",
                territory>0?row.Cell(territory).GetString():"",
                staff>0?row.Cell(staff).GetString():"",daily);
        }
        coverageStart=dateCols.Min(x=>x.date);coverageEnd=dateCols.Max(x=>x.date);
        return map.Values.ToList();
    }
}
