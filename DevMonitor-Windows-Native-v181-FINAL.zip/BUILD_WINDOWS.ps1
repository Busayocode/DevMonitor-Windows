$ErrorActionPreference = "Stop"

Write-Host "=========================================="
Write-Host "Building DevMonitor Windows x64"
Write-Host "=========================================="

dotnet restore .\DevMonitor.Windows.sln
dotnet publish .\DevMonitor.Windows.csproj `
  -c Release `
  -r win-x64 `
  --self-contained true `
  -p:PublishSingleFile=true `
  -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:EnableCompressionInSingleFile=true `
  -o .\publish

$exe = Join-Path $PWD "publish\DevMonitor.exe"
if (-not (Test-Path $exe)) { throw "DevMonitor.exe was not produced." }

Write-Host "Application published: $exe"
Write-Host "To create the normal Windows installer, install Inno Setup and run:"
Write-Host '  iscc .\DevMonitor-Setup.iss'
