using Microsoft.Win32;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DevMonitor.Windows;

public partial class MainWindow : Window
{
    private readonly DevMonitorDb _db=new();
    private string _page="Dashboard";
    private List<DeviceRow> _lastReport=[];
    private DateTime _reportStart,_reportEnd;

    public MainWindow()
    {
        InitializeComponent();
        // Keep the native window fully inside the usable Windows desktop area.
        // This prevents the title bar/close button being positioned off-screen
        // on smaller displays or with display scaling enabled.
        MaxWidth = SystemParameters.WorkArea.Width;
        MaxHeight = SystemParameters.WorkArea.Height;
        Width = Math.Min(Width, MaxWidth);
        Height = Math.Min(Height, MaxHeight);
        if (Width < MinWidth) MinWidth = Math.Max(800, MaxWidth);
        if (Height < MinHeight) MinHeight = Math.Max(520, MaxHeight);
        Left = Math.Max(SystemParameters.WorkArea.Left, SystemParameters.WorkArea.Left + (SystemParameters.WorkArea.Width - Width) / 2);
        Top = Math.Max(SystemParameters.WorkArea.Top, SystemParameters.WorkArea.Top + (SystemParameters.WorkArea.Height - Height) / 2);
        Render("Dashboard");
        Closed += (_,_)=>_db.Dispose();
    }

    private void Nav_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button b && b.Tag is string page) Render(page);
    }

    private void Refresh_Click(object sender,RoutedEventArgs e) { Render(_page); }

    private void Render(string page)
    {
        _page=page;
        PageHost.Content=page switch {
            "Dashboard"=>Dashboard(),
            "Sms"=>SmsPage(),
            "Devices"=>DevicesPage(),
            "Report"=>ReportPage(),
            "Earnings"=>EarningsPage(),
            "Monitor"=>MonitorPage(),
            "MonthOnMonth"=>MonthOnMonthPage(),
            "Agents"=>AgentsPage(),
            "Settings"=>SettingsPage(),
            _=>Dashboard()
        };
        PageTitle.Text=page switch {
            "Sms"=>"SMS Checker","Devices"=>"My Devices","Report"=>"Load Report",
            "Earnings"=>"Earning Progress","Monitor"=>"Device Monitor","MonthOnMonth"=>"Month-on-Month","Agents"=>"Agents & Partners","Settings"=>"Settings",_=>"Dashboard"
        };
        PageEyebrow.Text=page=="Dashboard"?"CONTROL CENTRE":page.ToUpperInvariant();
        FooterText.Text=$"DevMonitor Windows • Local database: {_db.FilePath}";
    }

    private Border Card(UIElement content, Brush? accent=null)
    {
        var b=new Border{Background=Brushes.White,CornerRadius=new CornerRadius(12),Padding=new Thickness(20),Margin=new Thickness(0,0,0,14),BorderBrush=new SolidColorBrush(Color.FromRgb(220,228,234)),BorderThickness=new Thickness(1)};
        var panel=new StackPanel(); if(accent!=null) panel.Children.Add(new Border{Height=4,Background=accent,CornerRadius=new CornerRadius(4),Margin=new Thickness(0,0,0,14)});
        panel.Children.Add(content);b.Child=panel;return b;
    }
    private TextBlock H(string text,double size=20)=>new(){Text=text,FontSize=size,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("TextBrush"),Margin=new Thickness(0,0,0,7)};
    private TextBlock P(string text)=>new(){Text=text,FontSize=14,Foreground=(Brush)FindResource("MutedBrush"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)};
    private Button B(string text,RoutedEventHandler click){var b=new Button{Content=text};b.Click+=click;return b;}
    private StackPanel Stack(params UIElement[] e)
    {
        var panel=new StackPanel();
        foreach(var item in e) panel.Children.Add(item);
        return panel;
    }

    private UIElement Dashboard()
    {
        var root=new StackPanel();
        var count=_db.MyDevices().Count;
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var (cs,ce)=PaymentRules.PaymentCycleForDate(today);
        root.Children.Add(Card(Stack(
            H("Good day — DevMonitor is ready",28),
            P("A native Windows workspace built from the current Android application's operational model. Everything here runs locally unless you explicitly connect a future sync service."),
            new WrapPanel{Children={
                B("SMS CHECKER",(_,_)=>Render("Sms")),
                B("MY DEVICES",(_,_)=>Render("Devices")),
                B("LOAD REPORT",(_,_)=>Render("Report")),
                B("EARNING PROGRESS",(_,_)=>Render("Earnings"))
            }}
        ),(Brush)FindResource("AccentBrush")));
        root.Children.Add(new UniformGrid{Columns=4,Children={
            Metric("MY DEVICES",count.ToString()),
            Metric("PAYMENT CYCLE",$"{cs:dd MMM} → {ce:dd MMM}"),
            Metric("CURRENT MONTH",today.ToString("MMMM yyyy")),
            Metric("PREVIOUS MONTH",today.AddMonths(-1).ToString("MMMM yyyy"))
        }});
        root.Children.Add(Card(Stack(
            H("Current architecture"),
            P("HQ reports are authoritative monthly snapshots. Windows keeps only the current and immediately previous calendar-month stores, imports are Replace All for a month, and import does not silently recalculate downstream screens."),
            B("Open Settings",(_,_)=>Render("Settings"))
        ),Brushes.SteelBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private Border Metric(string title,string value)
    {
        var s=Stack(new TextBlock{Text=title,FontSize=11,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("MutedBrush")},
            new TextBlock{Text=value,FontSize=21,FontWeight=FontWeights.Bold,Margin=new Thickness(0,6,0,0)});
        return new Border{Child=s,Background=Brushes.White,Padding=new Thickness(16),Margin=new Thickness(0,0,10,14),CornerRadius=new CornerRadius(10),BorderBrush=new SolidColorBrush(Color.FromRgb(220,228,234)),BorderThickness=new Thickness(1)};
    }

    private UIElement DevicesPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        root.Children.Add(Card(Stack(H("Your working device set"),P("The Windows version keeps a separate, user-scoped working set. Updating this list never deletes authoritative HQ history."),
            B("Replace My Devices",(_,_)=>EditDevices())) ,Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=480,ItemsSource=ids.Select(x=>new{Device=x}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void EditDevices()
    {
        var w=new Window{Title="Update My Devices",Width=520,Height=430,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var box=new TextBox{AcceptsReturn=true,Text=string.Join(Environment.NewLine,_db.MyDevices()),VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(15)};
        var save=new Button{Content="Save device list",Margin=new Thickness(15),Padding=new Thickness(12)};
        save.Click+=(_,_)=>{_db.ReplaceMyDevices(box.Text.Split(new[]{"\r\n","\n"},StringSplitOptions.RemoveEmptyEntries));w.DialogResult=true;w.Close();Render("Devices");};
        w.Content=new DockPanel{Children={box,save}};DockPanel.SetDock(save,Dock.Bottom);w.ShowDialog();
    }

    private UIElement ReportPage()
    {
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("HQ / SIMReg report import"),P("Choose an Excel report. The first worksheet is parsed into a normalized device/day model. Only the current calendar month or immediately previous month may be stored."),
            B("Choose Excel Report",ImportReport)),Brushes.MediumPurple));
        if(_lastReport.Count>0) root.Children.Add(Card(Stack(
            H($"Loaded report: {_lastReport.Count:N0} devices"),
            P($"Coverage: {_reportStart:yyyy-MM-dd} → {_reportEnd:yyyy-MM-dd}. This is a validated in-memory view; use Store Month to commit it to the local authoritative monthly snapshot."),
            B("Store Month Snapshot",StoreReport)),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void ImportReport(object? s,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="Excel reports|*.xlsx;*.xlsm|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            StatusText.Text="Reading report…";
            _lastReport=ReportImporter.Read(dlg.FileName,out _reportStart,out _reportEnd);
            _db.SetSetting("last_report_file",dlg.FileName);
            StatusText.Text=$"Loaded {_lastReport.Count:N0} devices";
            Render("Report");
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"DevMonitor",MessageBoxButton.OK,MessageBoxImage.Error);StatusText.Text="Import failed";}
    }
    private void StoreReport(object? s,RoutedEventArgs e)
    {
        var month=new DateTime(_reportStart.Year,_reportStart.Month,1);
        var current=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=current.AddMonths(-1);
        if(month!=current && month!=previous){MessageBox.Show(this,"Only the current and immediately previous calendar month can be stored.","DevMonitor");return;}
        var old=_db.StoredCoverageEnd(month);
        if(old.HasValue && _reportEnd<old.Value){MessageBox.Show(this,$"Older report rejected. Stored coverage ends {old:yyyy-MM-dd}.","DevMonitor");return;}
        var source=_db.GetSetting("last_report_file")??"Imported report";
        _db.ReplaceMonthSnapshot(month,_reportStart,_reportEnd,source,_lastReport);
        MessageBox.Show(this,"Monthly snapshot stored. Downstream calculations were not automatically refreshed.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
        Render("Report");
    }

    private UIElement EarningsPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var total=snapshots.Sum(x=>x.Active);
        var sundays=0;
        var estimate=PaymentRules.Estimate(total,sundays);
        root.Children.Add(Card(Stack(H("Earning Progress"),P($"Payment cycle: {PaymentRules.PaymentCycleLabel(DateTime.Today)}"),
            new TextBlock{Text=total.ToString("N0"),FontSize=44,FontWeight=FontWeights.Bold},
            P("Current cycle activations — Active remains the payment/progression input."),
            new TextBlock{Text=$"Estimated subtotal: ₦{estimate.Subtotal:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            P($"Fixed tier: ₦{estimate.FixedReward:N0} • Recharge estimate: ₦{estimate.RechargeBonus:N0} • Sunday bonus: ₦{estimate.SundayBonus:N0}"),
            P(estimate.NextThreshold.HasValue?$"{estimate.ActivationsToNext:N0} activations to the next tier ({estimate.NextThreshold:N0}).":"Highest configured tier reached.")
        ),Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=430,ItemsSource=snapshots.Select(x=>new{Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Status=x.Flag??"OK"}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonitorPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        root.Children.Add(Card(Stack(
            H("Device Monitor"),
            P("Current device activity from the authoritative monthly HQ snapshots. Payment calculations continue to use Active, not MTD."),
            new TextBlock{Text=$"Devices: {snapshots.Count:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            B("Refresh Device Monitor",(_,_)=>Render("Monitor"))
        ),Brushes.SteelBlue));
        root.Children.Add(new DataGrid{ItemsSource=snapshots.Select(x=>new{
            Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Ownership=x.Ownership,Status=x.Flag??"OK"
        }).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=480});
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonthOnMonthPage()
    {
        var root=new StackPanel();
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var currentMonth=new DateTime(today.Year,today.Month,1);
        var previousMonth=currentMonth.AddMonths(-1);
        var currentRows=_db.LoadMonth(currentMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var previousRows=_db.LoadMonth(previousMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var ids=_db.MyDevices().Select(DevMonitorDb.Canonical).ToList();
        var currentEnd=_db.StoredCoverageEnd(currentMonth);
        var previousEnd=_db.StoredCoverageEnd(previousMonth);
        var currentCutoff=Math.Min(today.Day,currentEnd?.Day??0);
        var previousCutoff=Math.Min(currentCutoff,previousEnd?.Day??0);
        var data=new List<object>();
        foreach(var id in ids){
            currentRows.TryGetValue(id,out var c); previousRows.TryGetValue(id,out var p);
            var cur=c?.Daily.Where(k=>k.Key.Month==today.Month&&k.Key.Year==today.Year&&k.Key.Day<=currentCutoff).Sum(k=>k.Value)??0;
            var prev=p?.Daily.Where(k=>k.Key.Month==previousMonth.Month&&k.Key.Year==previousMonth.Year&&k.Key.Day<=previousCutoff).Sum(k=>k.Value)??0;
            data.Add(new{Device=id,Current=cur,Previous=prev,Change=cur-prev});
        }
        root.Children.Add(Card(Stack(
            H("Month-on-Month"),
            P($"User-scoped comparison through the available report cutoff. Current cutoff: day {currentCutoff}; previous-month cutoff: day {previousCutoff}. Missing historical coverage is not treated as zero."),
            new TextBlock{Text=$"Current: {currentMonth:MMMM yyyy}  •  Previous: {previousMonth:MMMM yyyy}",FontSize=18,FontWeight=FontWeights.Bold},
            B("Refresh comparison",(_,_)=>Render("MonthOnMonth"))
        ),Brushes.MediumPurple));
        root.Children.Add(new DataGrid{ItemsSource=data,IsReadOnly=true,AutoGenerateColumns=true,Height=480});
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement SmsPage()
    {
        var root=new StackPanel();
        var sender=new TextBox{Text="Network",Width=180};
        var body=new TextBox{AcceptsReturn=true,Height=90,TextWrapping=TextWrapping.Wrap};
        root.Children.Add(Card(Stack(H("SMS Checker"),P("Windows cannot directly receive an Android SIM's SMS. This desktop workflow accepts SMS text from a connected/synced source and stores it locally for parsing/recheck workflows."),
            new TextBlock{Text="Sender"},sender,new TextBlock{Text="SMS body"},body,
            B("Save incoming SMS",(_,_)=>{_db.AddSms(sender.Text,body.Text);body.Clear();Render("Sms");})),Brushes.SteelBlue));
        var rows=_db.Sms();
        root.Children.Add(Card(Stack(H("Recent SMS",18),new DataGrid{ItemsSource=rows.Select(x=>new{Received=x.Received.ToString("yyyy-MM-dd HH:mm"),Sender=x.Sender,Body=x.Body}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=420})));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement AgentsPage()=>new ScrollViewer{Content=Card(Stack(H("Agents & Partners"),P("Maintain people, locations and linked devices. This native desktop foundation is ready for the same hierarchy and device relationships represented by the Android database."),B("Open device working set",(_,_)=>Render("Devices"))),Brushes.CadetBlue)};

    private UIElement SettingsPage()=>new ScrollViewer{Content=Card(Stack(H("Settings"),P("Desktop settings are local and offline-first. Cloud account, backup and Android/Windows synchronization are deliberately isolated from core calculations."),
        H("Local data",17),P($"Database: {_db.FilePath}"),H("Payment rules",17),P("Payment/progression rules are ported from the supplied Android source and remain separate from report-import UI."),H("Two-month HQ store",17),P("Only the current and immediately previous calendar months are accepted. Older coverage is rejected; same or newer coverage replaces the month's complete snapshot.")),Brushes.Gray)};

    protected override void OnClosed(EventArgs e){base.OnClosed(e);_db.Dispose();}
}
