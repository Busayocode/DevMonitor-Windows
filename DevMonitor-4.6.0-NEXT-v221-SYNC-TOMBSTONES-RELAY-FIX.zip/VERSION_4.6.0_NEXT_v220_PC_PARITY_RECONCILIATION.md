# Android v220 — phone/PC operational reconciliation

- On successful bridge response, Android now applies returned desktop edits to matching operational SQLite rows for query codes, query records, saved lists, query history, daily observations, SMS query attempts, agents, agent phones and agent-device relationships.
- Synced notification records are upserted into the relevant profile inbox using the stable notification ID, including read-state updates.
- The merge intentionally excludes HQ monthly snapshots, payment-cycle/payment records, payment calculations, credentials and cellular SMS sending.
- The bridge remains explicit and user-initiated. Deletion tombstones and conflict UI are still pending; do not treat this as complete deletion synchronization.
