# Android v218 — Phone/PC Sync Bridge

- Added a Sync Bridge panel under Next Level → Health.
- Supports pairing with the Windows v204 local endpoint and a compatible HTTPS relay.
- Uses an AES-GCM encrypted request/response envelope; hosted relay calls also require HTTPS.
- Two-way merges My Devices codes, operational tasks, notes, and SMS inbox history.
- Keeps `.dmdata` fallback and excludes HQ monthly report snapshots and payment records from sync.
- This is protocol v1, not complete feature parity: deletes/tombstones and several entity families are not yet synced.


## v218 extended operational archive transfer
- Added encrypted bridge payload transfer for current/archived query codes, saved query lists, current query result JSON, query history, daily observations, SMS query-attempt metadata, agents, agent phone contacts, agent-device relationships, profile metadata and per-profile in-app notifications.
- Deliberately excludes payment cycles, payment records, HQ activation bridge snapshots, account/authentication records and authorization audit records.
- Windows stores these Android-only families in a searchable local archive and supports JSON/CSV export; they are not yet full native edit workflows on Windows.
- `.dmdata` remains available for existing exchange families; archive-family support is included in the Windows-side exchange format.


## v221 sync reliability update
- The bridge now includes deletion tombstones and applies them after record upserts. Android records deleted through a Windows archive tombstone can be removed from mapped Android operational tables on the next sync.
- This is not yet a universal tombstone system for every Android screen: native Android-side delete actions must also be instrumented, and conflicts involving edits made concurrently with deletion still require a conflict-review workflow.
- Relay protocol merge now preserves extended Android record families and tombstones across sessions.
