# Android v219 — PC Parity Data Bridge

- Extended the existing encrypted phone/PC bridge payload with operational data families that the Windows client did not previously retain: current/archived query codes, query result records, saved query lists, query history, daily observations, SMS query-attempt metadata, agent records, agent phone contacts, agent-device relationships, profile metadata and per-profile in-app notifications.
- Kept this as an explicit user-triggered sync; no background sync was added.
- Deliberately excluded HQ activation snapshots, payment cycles/records, authentication/account credentials and authorization audit history.
- Windows v205 adds a searchable offline archive and JSON/CSV exports for the transferred Android-only families. These are preserved for review/export; native Windows editing workflows are still not complete for every family.
- The existing `.dmdata` fallback remains supported on Windows.
- No payment calculation formulas, thresholds, cycle boundaries or HQ import rules were changed.

Build note: use the Android GitHub Actions workflow to compile versionCode 219; a local Gradle compile could not run in the isolated build environment because Gradle distribution download was unavailable.
