package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight, user-triggered reporting helpers. Does not calculate or alter payment rules. */
data class PaymentCardSharePayload(
    val agentName: String, val deviceCode: String, val source: String, val period: String,
    val asOf: String, val estimate: IncentiveEstimate, val activationDetail: String = ""
)

object ReportExportPack {
    /** Shares the existing displayed estimate as a PNG; this is presentation only. */
    fun sharePaymentCard(context: Context, payload: PaymentCardSharePayload): Boolean =
        sharePaymentCards(context, listOf(payload))

    /** Creates one exact-source image per device and hands all images to the Android share sheet. */
    fun sharePaymentCards(context: Context, payloads: List<PaymentCardSharePayload>): Boolean {
        if (payloads.isEmpty()) return false
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val files = payloads.mapIndexed { index, payload -> createPaymentCardImage(context, payload, "${stamp}_$index") }
            val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it) })
            val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris.first()) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, if (payloads.size == 1) "${payloads.first().agentName} — DevMonitor earnings progression (${payloads.first().source})" else "DevMonitor earnings progression cards — ${payloads.size} device card(s). Please review each card's source and period.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, if (payloads.size == 1) "Share Earnings Card" else "Batch Share Earnings Cards"))
            true
        }.getOrDefault(false)
    }

    /** Opens PC-prepared PNG cards after a user-initiated sync. The PC supplies the exact figures; Android only presents them. */
    fun sharePreparedPngs(context: Context, cards: List<org.json.JSONObject>): List<String> {
        if (cards.isEmpty()) return emptyList()
        return runCatching {
            val files = cards.take(20).mapIndexedNotNull { index, item ->
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
                val encoded = item.optString("pngBase64")
                if (encoded.isBlank()) return@mapIndexedNotNull null
                val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                if (bytes.size > 2_000_000 || !bytes.take(8).toByteArray().contentEquals(byteArrayOf(0x89.toByte(),0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a))) return@mapIndexedNotNull null
                val file = File(context.cacheDir, "DevMonitor_PC_Share_${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.png")
                FileOutputStream(file).use { it.write(bytes) }
                id to file
            }
            if (files.isEmpty()) return@runCatching emptyList()
            val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it.second) })
            val caption = cards.firstOrNull()?.optString("caption")?.takeIf { it.isNotBlank() } ?: "DevMonitor earnings cards prepared on Windows"
            val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris.first()) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, if (uris.size == 1) "Share PC Earnings Card" else "Share PC Earnings Cards").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            files.map { it.first }
        }.getOrDefault(emptyList())
    }

    private fun createPaymentCardImage(context: Context, d: PaymentCardSharePayload, stamp: String): File {
        val width = 1080; val height = 1080
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap); canvas.drawColor(0xFFF4F8FC.toInt())
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00843D.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF26384D.toInt(); textSize = 29f }
        val label = Paint(body).apply { color = 0xFF5C6B7C.toInt(); textSize = 24f }
        canvas.drawRoundRect(36f, 36f, 1044f, 1044f, 34f, 34f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = -1 })
        canvas.drawText("DevMonitor", 76f, 112f, title)
        canvas.drawText("EARNINGS PROGRESSION", 76f, 164f, Paint(title).apply { textSize = 28f; color = 0xFF26384D.toInt() })
        canvas.drawText(d.agentName.take(42), 76f, 226f, Paint(title).apply { textSize = 38f })
        canvas.drawText("Device: ${d.deviceCode.take(42)}", 76f, 278f, body)
        canvas.drawText("Source: ${d.source.take(54)}", 76f, 332f, body)
        canvas.drawText("Reporting period: ${d.period.take(48)}", 76f, 378f, label)
        canvas.drawText("Figures as of: ${d.asOf}", 76f, 420f, label)
        val lines = listOf(
            "Current Activation Achieved" to d.estimate.activations.toString(),
            "Fixed performance reward" to "₦${String.format(Locale.US, "%d", d.estimate.fixedReward)}",
            "Estimated FRC component" to "₦${String.format(Locale.US, "%d", d.estimate.estimatedRechargeBonus)}",
            "Sunday bonus" to "₦${String.format(Locale.US, "%d", d.estimate.sundayBonus)}",
            "Estimated total" to "₦${String.format(Locale.US, "%d", d.estimate.estimatedSubtotal)}"
        )
        var y = 500f
        lines.forEachIndexed { i, pair ->
            canvas.drawRoundRect(64f, y - 36f, 1016f, y + 24f, 16f, 16f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (i == lines.lastIndex) 0xFFE0F3E7.toInt() else 0xFFF3F6F9.toInt() })
            canvas.drawText(pair.first, 86f, y + 3f, label)
            canvas.drawText(pair.second, 700f, y + 3f, Paint(body).apply { typeface = Typeface.DEFAULT_BOLD })
            y += 82f
        }
        canvas.drawText("MONITORING / ESTIMATION ONLY — company official data remains final", 76f, 960f, Paint(label).apply { textSize = 20f; color = 0xFFB42332.toInt() })
        if (d.activationDetail.isNotBlank()) canvas.drawText(d.activationDetail.take(80), 76f, 1000f, Paint(label).apply { textSize = 18f })
        val file = File(context.cacheDir, "DevMonitor_Earnings_${stamp}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle(); return file
    }
    fun shareDailySnapshot(context: Context, dashboard: DashboardSummary, format: SnapshotFormat): Boolean {
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val file = when (format) {
                SnapshotFormat.IMAGE -> createImage(context, dashboard, stamp)
                SnapshotFormat.PDF -> createPdf(context, dashboard, stamp)
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (format == SnapshotFormat.IMAGE) "image/png" else "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "DevMonitor Daily Snapshot — ${dashboard.date}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Daily Snapshot"))
            true
        }.getOrDefault(false)
    }

    private fun createImage(context: Context, d: DashboardSummary, stamp: String): File {
        val width = 1080
        val height = 1320
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFFF7FAFD.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 34f; typeface = Typeface.DEFAULT }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor", 64f, 82f, bold.apply { textSize = 48f; color = 0xFF00843D.toInt() })
        canvas.drawText("Daily Operational Snapshot", 64f, 130f, paint.apply { textSize = 30f; color = 0xFF40546A.toInt() })
        canvas.drawText(d.date, 64f, 178f, paint.apply { textSize = 26f })
        var y = 250f
        val metrics = listOf(
            "Devices observed" to d.deviceCount.toString(),
            "Today's SIMReg" to d.todayTotal.toString(),
            "MTD SIMReg" to d.mtdTotal.toString(),
            "Active" to d.activeTotal.toString(),
            "Bar 48" to d.bar48Total.toString(),
            "Bar 96" to d.bar96Total.toString(),
            "Company today / MTD" to "${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD" to "${d.partnerToday} / ${d.partnerMtd}",
            "Active flags" to d.flags.size.toString()
        )
        for ((label, value) in metrics) {
            canvas.drawRoundRect(54f, y - 34f, width - 54f, y + 28f, 18f, 18f, Paint(paint).apply { color = 0xFFFFFFFF.toInt() })
            canvas.drawText(label, 82f, y + 5f, paint.apply { textSize = 24f; color = 0xFF40546A.toInt() })
            canvas.drawText(value, 800f, y + 5f, bold.apply { textSize = 26f; color = 0xFF12233A.toInt() })
            y += 88f
        }
        y += 28f
        canvas.drawText("Exceptions", 64f, y, bold.apply { textSize = 30f; color = 0xFFD14B5B.toInt() })
        y += 48f
        val flags = d.flags.take(8)
        if (flags.isEmpty()) canvas.drawText("No active flags recorded.", 64f, y, paint.apply { textSize = 24f })
        else flags.forEach { flag ->
            val line = "• ${flag.code}: ${flag.reason}"
            canvas.drawText(line.take(78), 70f, y, paint.apply { textSize = 21f; color = 0xFF40546A.toInt() })
            y += 38f
        }
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private fun createPdf(context: Context, d: DashboardSummary, stamp: String): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(612, 792, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 14f }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor — Daily Operational Snapshot", 36f, 48f, bold.apply { textSize = 20f; color = 0xFF00843D.toInt() })
        canvas.drawText("Date: ${d.date}", 36f, 72f, paint)
        val lines = listOf(
            "Devices observed: ${d.deviceCount}", "Today's SIMReg: ${d.todayTotal}", "MTD SIMReg: ${d.mtdTotal}",
            "Active: ${d.activeTotal}", "Bar 48: ${d.bar48Total}", "Bar 96: ${d.bar96Total}",
            "Company today / MTD: ${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD: ${d.partnerToday} / ${d.partnerMtd}", "Active flags: ${d.flags.size}"
        )
        var y = 110f
        lines.forEach { canvas.drawText(it, 42f, y, paint); y += 25f }
        y += 12f
        canvas.drawText("Exceptions", 36f, y, bold.apply { textSize = 16f; color = 0xFFD14B5B.toInt() }); y += 25f
        d.flags.take(14).forEach { flag ->
            val text = "${flag.code} — ${flag.reason}"
            canvas.drawText(text.take(92), 42f, y, paint.apply { textSize = 10f; color = 0xFF40546A.toInt() }); y += 17f
            if (y > 750f) return@forEach
        }
        doc.finishPage(page)
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}

enum class SnapshotFormat { IMAGE, PDF }
