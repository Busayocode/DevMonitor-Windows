package com.aziitech.simregmonitor

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed interface NextLevelResult {
    data class Trends(val rows: List<NextLevelEngine.AdvancedTrend>) : NextLevelResult
    data class Anomalies(val rows: List<NextLevelEngine.Anomaly>) : NextLevelResult
    data class Reconciliation(val rows: List<NextLevelEngine.Reconciliation>) : NextLevelResult
    data class Health(val value: NextLevelEngine.Health) : NextLevelResult
}

@Composable
fun NextLevelScreen(
    context: Context,
    db: DatabaseStore,
    company: CompanyActivationStore,
    monthlyTarget: Int,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onClose: () -> Unit
) {
    var section by remember { mutableStateOf(3) }
    var trends by remember { mutableStateOf<List<NextLevelEngine.AdvancedTrend>>(emptyList()) }
    var anomalies by remember { mutableStateOf<List<NextLevelEngine.Anomaly>>(emptyList()) }
    var reconciliation by remember { mutableStateOf<List<NextLevelEngine.Reconciliation>>(emptyList()) }
    var health by remember { mutableStateOf<NextLevelEngine.Health?>(null) }
    var busy by remember { mutableStateOf(false) }
    var refreshedAt by remember { mutableStateOf<String?>(null) }
    var bridgeEndpoint by remember { mutableStateOf(db.getSetting("sync_bridge_endpoint") ?: "http://192.168.1.10:43827") }
    var bridgeKey by remember { mutableStateOf(db.getSetting("sync_pairing_key") ?: "") }
    var bridgeStatus by remember { mutableStateOf(db.getSetting("sync_bridge_status") ?: "Not connected") }
    var bridgeBusy by remember { mutableStateOf(false) }
    var bridgeApproved by remember { mutableStateOf(db.getSetting("sync_bridge_approved") == "true") }
    var discoveryStatus by remember { mutableStateOf("Not searched yet") }
    var discoveredPcs by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    val qrScanner = rememberLauncherForActivityResult(ScanContract()) { result ->
        val raw = result.contents ?: return@rememberLauncherForActivityResult
        runCatching {
            val uri = Uri.parse(raw)
            require(uri.scheme == "devmonitor" && uri.host == "pair") { "This is not a DevMonitor pairing QR code." }
            val endpoint = uri.getQueryParameter("endpoint") ?: error("QR code has no PC endpoint.")
            val key = uri.getQueryParameter("key") ?: error("QR code has no pairing key.")
            require(endpoint.startsWith("http://") && key.length >= 16) { "Pairing details are invalid." }
            onBridgeEndpointChange(endpoint)
            onBridgeKeyChange(key)
            db.setSetting("sync_bridge_endpoint", endpoint)
            db.setSetting("sync_pairing_key", key)
            discoveryStatus = "QR read successfully. Check the PC address, then tap Sync now; Windows will ask for approval."
        }.onFailure { discoveryStatus = "QR not accepted: ${it.message ?: "invalid code"}" }
    }
    val scope = rememberCoroutineScope()
    fun refresh(target: Int = section) {
        if (busy) return
        busy = true
        scope.launch {
            val result = withContext(Dispatchers.Default) {
                when (target) {
                    0 -> NextLevelResult.Trends(NextLevelEngine.advancedTrends(db, target = monthlyTarget))
                    1 -> NextLevelResult.Anomalies(NextLevelEngine.anomalies(db))
                    2 -> NextLevelResult.Reconciliation(NextLevelEngine.reconcile(db, company))
                    else -> NextLevelResult.Health(NextLevelEngine.health(context, db, company))
                }
            }
            when (result) {
                is NextLevelResult.Trends -> trends = result.rows
                is NextLevelResult.Anomalies -> anomalies = result.rows
                is NextLevelResult.Reconciliation -> reconciliation = result.rows
                is NextLevelResult.Health -> health = result.value
            }
            refreshedAt = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date())
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        modifier = Modifier.fillMaxWidth(),
        title = { Text("NEXT LEVEL", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Text("Advanced intelligence, reconciliation, health and recovery — all refresh-driven.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Trends", "Anomalies", "HQ", "Health").forEachIndexed { i, label ->
                        FilterChip(selected = section == i, onClick = { section = i }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                DevMonitorOutlinedButton(onClick = { refresh() }, enabled = !busy) { Text(if (busy) "Working…" else "↻ Refresh") }
                if (refreshedAt != null) Text("Refreshed $refreshedAt", style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(8.dp))
                when (section) {
                    0 -> AdvancedTrendsBody(trends, onRefresh = { refresh(0) })
                    1 -> AnomalyBody(anomalies, onRefresh = { refresh(1) })
                    2 -> ReconciliationBody(reconciliation, onRefresh = { refresh(2) })
                    3 -> HealthBody(
                        health = health,
                        onBackup = onBackup,
                        onRestore = onRestore,
                        onOptimize = {
                            if (!busy) {
                                busy = true
                                scope.launch {
                                    withContext(Dispatchers.IO) { NextLevelEngine.optimizeDatabase(db) }
                                    refreshedAt = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date())
                                    busy = false
                                }
                            }
                        },
                        onRefresh = { refresh(3) },
                        context = context,
                        db = db,
                        bridgeEndpoint = bridgeEndpoint,
                        onBridgeEndpointChange = { bridgeEndpoint = it },
                        bridgeKey = bridgeKey,
                        onBridgeKeyChange = { bridgeKey = it },
                        bridgeStatus = bridgeStatus,
                        onBridgeStatusChange = { bridgeStatus = it },
                        bridgeBusy = bridgeBusy,
                        onBridgeBusyChange = { bridgeBusy = it },
                        scope = scope
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable private fun AdvancedTrendsBody(rows: List<NextLevelEngine.AdvancedTrend>, onRefresh: () -> Unit) {
    if (rows.isEmpty()) { DevMonitorEmptyState("No current-month observations", "Press Refresh after current-month observations are available.", "Refresh", onRefresh); return }
    val r = rows.last()
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item {
            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                Text("MONTHLY TARGET & DELIVERY", fontWeight = FontWeight.ExtraBold, color = AuroraBlue)
                Spacer(Modifier.height(8.dp))
                Text("Month: ${r.date}")
                Text("Monthly target: ${if (r.target > 0) r.target.toString() else "Not set"}  •  Delivered so far: ${r.sales}", fontWeight = FontWeight.SemiBold)
                Text("Projected month-end: ${r.projectedMonthEnd}", fontWeight = FontWeight.SemiBold)
                Text("Target achieved: ${r.achievementPercent?.let { String.format(Locale.US, "%.1f%%", it) } ?: "—"}")
                r.remainingTarget?.let { Text("Remaining target balance: $it") }
                if (r.target > 0) LinearProgressIndicator(progress = { ((r.achievementPercent ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Text("Observed devices: ${r.observedDevices}", style = MaterialTheme.typography.labelSmall)
            }
        }
        item {
            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraEmerald) {
                Text("DAILY SALES THIS MONTH", fontWeight = FontWeight.ExtraBold, color = AuroraEmerald)
                r.dailySales.forEach { (date, value) -> Text("${date.substringAfterLast("-")}  •  $value sales", style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable private fun AnomalyBody(rows: List<NextLevelEngine.Anomaly>, onRefresh: () -> Unit) {
    if (rows.isEmpty()) { DevMonitorEmptyState("No deterministic anomalies", "No configured operational signal was detected in the selected period.", "Refresh", onRefresh) ; return }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(rows) { r ->
            AuroraGlassCard(Modifier.fillMaxWidth(), if (r.severity == "HIGH") MaterialTheme.colorScheme.error else AuroraEmerald) {
                Text("${r.severity} • ${r.title}", fontWeight = FontWeight.ExtraBold)
                Text(r.code, style = MaterialTheme.typography.labelMedium)
                Text(r.detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable private fun ReconciliationBody(rows: List<NextLevelEngine.Reconciliation>, onRefresh: () -> Unit) {
    if (rows.isEmpty()) { DevMonitorEmptyState("No reconciliation rows", "Load a current report and have local observations available, then refresh.", "Refresh", onRefresh) ; return }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(rows) { r ->
            AuroraGlassCard(Modifier.fillMaxWidth(), if (r.status == "MATCH") AuroraGreen else MaterialTheme.colorScheme.error) {
                Text(r.date, fontWeight = FontWeight.Bold)
                Text("Local ${r.localObserved}  •  HQ ${r.hqObserved}  •  Difference ${r.difference}", style = MaterialTheme.typography.bodySmall)
                Text(r.status, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable private fun HealthBody(
    health: NextLevelEngine.Health?,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onOptimize: () -> Unit,
    onRefresh: () -> Unit,
    context: Context,
    db: DatabaseStore,
    bridgeEndpoint: String,
    onBridgeEndpointChange: (String) -> Unit,
    bridgeKey: String,
    onBridgeKeyChange: (String) -> Unit,
    bridgeStatus: String,
    onBridgeStatusChange: (String) -> Unit,
    bridgeBusy: Boolean,
    onBridgeBusyChange: (Boolean) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    if (health == null) { DevMonitorEmptyState("Diagnostics not run", "Refresh to inspect connectivity, data freshness, SMS storage and database health.", "Refresh", onRefresh) ; return }
    val currentBridgeBusy by rememberUpdatedState(bridgeBusy)
    fun updateBridgeStatus(value: String) {
        onBridgeStatusChange(value)
        db.setSetting("sync_bridge_status", value)
        db.setSetting("sync_bridge_status_updated_at", System.currentTimeMillis().toString())
        if (value.startsWith("Connected", ignoreCase = true)) db.setSetting("sync_bridge_last_success", System.currentTimeMillis().toString())
    }
    // Bounded active-session sync loop: finite retry cycle, then a five-minute standby check.
    // Android may suspend this screen when backgrounded; this is not a claim of an always-on service.
    LaunchedEffect(bridgeEndpoint, bridgeKey, bridgeApproved) {
        if (!bridgeApproved || bridgeEndpoint.isBlank() || bridgeKey.length < 16) return@LaunchedEffect
        db.setSetting("sync_bridge_endpoint", bridgeEndpoint.trim())
        db.setSetting("sync_pairing_key", bridgeKey)
        while (true) {
            if (currentBridgeBusy) { delay(5_000); continue }
            var connected = false
            val waits = listOf(2_000L, 5_000L, 10_000L, 20_000L, 30_000L)
            for (attempt in 0..waits.size) {
                if (currentBridgeBusy) { delay(2_000); continue }
                onBridgeBusyChange(true)
                val result = try { runCatching { withContext(Dispatchers.IO) { SyncBridgeClient.sync(context, db, bridgeEndpoint, bridgeKey) } } } finally { onBridgeBusyChange(false) }
                if (result.isSuccess) {
                    connected = true
                    val value = result.getOrThrow()
                    updateBridgeStatus("Connected • auto-sync active • ${value.tasks} tasks, ${value.notes} notes, ${value.devices} device codes • ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
                    break
                } else {
                    updateBridgeStatus("Reconnecting (${attempt + 1}/${waits.size + 1})… ${result.exceptionOrNull()?.message ?: "connection failed"}")
                    if (attempt < waits.size) delay(waits[attempt])
                }
            }
            if (connected) delay(30_000L) else {
                updateBridgeStatus("Offline • retry cycle exhausted; next reachability check in 5 minutes")
                delay(5 * 60_000L)
            }
        }
    }
    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item { AuroraGlassCard(Modifier.fillMaxWidth(), if (health.online) AuroraGreen else MaterialTheme.colorScheme.error) {
            Text(if (health.online) "ONLINE" else "OFFLINE", fontWeight = FontWeight.ExtraBold)
            Text("Observation rows: ${health.observationRows}  •  SMS inbox: ${health.smsRows}")
            Text("Latest HQ coverage: ${health.reportCoverage ?: "none"}")
            Text("Database: ${health.databaseRows} indexed records  •  Free storage ${health.freeStorageMb} MB", style = MaterialTheme.typography.bodySmall)
            Text("SQLite integrity: ${health.databaseIntegrity}", style = MaterialTheme.typography.bodySmall)
        } }
        item { Text("Pair with Windows PC", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold) }
        item { Text("On Windows, open Pair Phone ↔ PC and start the local bridge. Use Find PC on local network or enter the PC LAN URL below, then enter the private pairing key shown on the PC. Keep both devices on the same trusted Wi-Fi and keep DevMonitor open on the PC.", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold) }
        item { Text("Operational two-way sync over local Wi-Fi or a trusted HTTPS endpoint. Once paired, auto-sync retries while this screen is active: 5 attempts (2/5/10/20/30 seconds), then a 5-minute standby check. Successful sessions sync every 30 seconds. Android may suspend this loop when the app is backgrounded. AES-GCM encrypted; HQ snapshots and payment records are excluded.", style = MaterialTheme.typography.bodySmall) }
        item { DevMonitorOutlinedButton(onClick = { qrScanner.launch(ScanOptions().setPrompt("Scan DevMonitor pairing QR").setBeepEnabled(false).setOrientationLocked(false)) }, enabled = !bridgeBusy) { Text("Scan PC pairing QR code") } }
        item { DevMonitorOutlinedButton(onClick = {
            if (bridgeBusy) return@DevMonitorOutlinedButton
            discoveryStatus = "Searching local Wi-Fi…"
            scope.launch {
                val result = runCatching { withContext(Dispatchers.IO) { SyncBridgeDiscovery.discover() } }
                discoveredPcs = result.getOrDefault(emptyList())
                discoveryStatus = when {
                    result.isFailure -> "Discovery failed: ${result.exceptionOrNull()?.message ?: "network error"}"
                    discoveredPcs.isEmpty() -> "No DevMonitor PC found. Confirm both devices are on the same Wi-Fi and Windows bridge is running. You can still enter the address manually."
                    else -> "Found ${discoveredPcs.size} PC(s). Tap one below to use its address."
                }
            }
        }, enabled = !bridgeBusy) { Text("Find PC on local network") } }
        item { Text(discoveryStatus, style = MaterialTheme.typography.bodySmall) }
        items(discoveredPcs) { pc ->
            DevMonitorOutlinedButton(onClick = {
                onBridgeEndpointChange(pc.first)
                db.setSetting("sync_bridge_endpoint", pc.first)
                discoveryStatus = "Selected ${pc.second}. Enter the private key shown on the PC, then tap Sync now to request pairing approval."
            }, modifier = Modifier.fillMaxWidth()) { Text(pc.second) }
        }
        item { TextField(value=bridgeEndpoint,onValueChange=onBridgeEndpointChange,label={Text("PC address / sync URL")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
        item { TextField(value=bridgeKey,onValueChange=onBridgeKeyChange,label={Text("Private PC pairing key")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
        item { Text(bridgeStatus, style = MaterialTheme.typography.bodySmall) }
        item { DevMonitorOutlinedButton(onClick={
            if (bridgeBusy) return@DevMonitorOutlinedButton
            db.setSetting("sync_bridge_endpoint", bridgeEndpoint.trim())
            db.setSetting("sync_pairing_key", bridgeKey)
            onBridgeBusyChange(true)
            updateBridgeStatus("Synchronizing…")
            scope.launch {
                val result = runCatching {
                    withContext(Dispatchers.IO) { SyncBridgeClient.sync(context, db, bridgeEndpoint, bridgeKey) }
                }
                if (result.isSuccess) {
                    bridgeApproved = true
                    db.setSetting("sync_bridge_approved", "true")
                }
                updateBridgeStatus(result.fold(
                    { "Synced • ${it.devices} device codes, ${it.tasks} tasks, ${it.notes} notes, ${it.sms} SMS records, ${it.extended} archived Android records" },
                    { "Sync failed: ${it.message ?: "unknown error"}" }
                ))
                onBridgeBusyChange(false)
            }
        },enabled=!bridgeBusy) { Text(if(bridgeBusy)"Synchronizing…" else "Sync now") } }
        item { Text("Keep the pairing key private. Discovery sends only a local network probe; it never broadcasts the pairing key. Tap Sync now to initiate pairing on Android; the PC also asks for approval before the first encrypted exchange. Automatic retries start only after a successful user-initiated sync. QR-code pairing is not yet implemented. For remote sync, use an HTTPS reverse proxy or trusted VPN; never expose the plain HTTP LAN port directly to the public internet.", style = MaterialTheme.typography.bodySmall) }
        item { Text("Sync Centre", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DevMonitorOutlinedButton(onClick = onBackup, modifier = Modifier.weight(1f)) { Text("Backup") }
            DevMonitorOutlinedButton(onClick = onRestore, modifier = Modifier.weight(1f)) { Text("Restore") }
        } }
        item {
            DevMonitorOutlinedButton(onClick = onOptimize) { Text("Optimize local database") }
        }
        item { Text("Auto-sync is active only while this screen remains active; it is not an always-on Android background service. Keep Windows bridge running. Background continuous sync needs a separately permissioned Android service or OS-scheduled work.", style = MaterialTheme.typography.bodySmall) }
        item { Text("Explain-this: local observations are Device Monitor evidence; HQ values come from the latest Loaded Report available to the current month. Differences are surfaced, not silently corrected.", style = MaterialTheme.typography.bodySmall) }
    }
}
