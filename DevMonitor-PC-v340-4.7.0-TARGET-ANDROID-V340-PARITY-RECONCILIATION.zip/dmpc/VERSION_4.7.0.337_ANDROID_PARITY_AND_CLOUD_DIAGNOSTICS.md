# DevMonitor Windows/PC v337 — Android v337 parity review and cloud diagnostics

**Date:** 2026-11-04  
**Windows source base:** PC v328  
**Android reference:** Android v337  
**Scope:** Applicable Android parity work, clear outstanding items, and safer Windows diagnostics. This is not a claim that every phone feature belongs on Windows.

## Itemized update register

### 1. Agent and partner records — retain Android authority; improve the Windows receiving experience
- **Already present in PC v328:** synced agent directory, linked-device display, phone/email display, address and saved coordinates, OpenStreetMap handoff, thumbnail placeholder, and photo-status explanation.
- **v337 action:** preserve the read-only Windows ownership boundary. Windows must not independently edit or merge Android-authoritative agent identity, contact rows, saved pins, or device links.
- **Still required:** validate that the Android `agents`, `agent_phones`, `agent_emails`, and `agent_devices` rows arrive completely and consistently in the PC archive after real paired sync. Current Android sync projection explicitly includes agent identity/location and phone/email rows; confirm all related records and deletion markers round-trip.
- **Acceptance:** create/edit/merge an agent on Android, sync, close/reopen the PC directory, and confirm names, postal address, phones/labels, emails/labels, coordinates and device links match exactly. Verify unlink/delete and duplicate handling.

### 2. Agent photos — actual image-byte transfer is still missing
- **Already present in PC v328:** thumbnail/initials presentation and a truthful placeholder status. A phone-private filesystem path is not a PC-readable image.
- **Not implemented in v337:** no image-byte transfer is claimed. A safe solution requires a paired Android + Windows protocol change, not merely opening `photo_path` on Windows.
- **Required design:** Android exports the approved photo bytes (not its private path) with agent ID, MIME type, byte length and content hash; Windows validates size/type/hash, writes to an app-owned photo cache using generated filenames, and maps the cached image to the agent ID. Deletion/replacement must propagate as explicit state. Avoid arbitrary path writes and executable formats. Set a conservative image limit and skip/reject oversized or malformed payloads without failing the rest of sync.
- **Acceptance:** new photo, replace, clear, offline/reconnect, duplicate delivery, corrupted payload, oversized payload, and deleted-agent tests. Confirm photo bytes are not exposed in logs or general-purpose exports.

### 3. Saved agent locations — Windows display/handoff is already implemented
- **Already present in PC v328:** validates latitude/longitude and opens the selected pin in OpenStreetMap; missing/invalid coordinates prompt the user to set and save the pin on Android.
- **v337 action:** retain this behaviour and document it as partial parity pending real sync validation. Android's in-app pin picker remains the editing authority.
- **Acceptance:** set/move/save a pin on Android, sync, verify exact coordinates in Windows and correct map destination. Test missing and out-of-range coordinates.

### 4. Broadcast and release information — Windows diagnostics upgraded
- **Previously present:** read-only Firestore fetch for release highlights and a global broadcast banner. A broad catch hid whether a document was missing, inactive, expired, empty, or unreadable.
- **Implemented in v337:** Dashboard now shows separate release-configuration/release-document and broadcast diagnostics; it distinguishes missing documents, HTTP read failures, missing/empty highlights, inactive broadcasts, empty messages, expired messages, and eligible active broadcasts. Added a user-triggered **Refresh cloud status** action and last-checked time.
- **Preserved:** Firestore remains read-only. Cloud failure is non-fatal; the offline-first desktop workspace remains usable. No publishing, rules changes, second sign-in, or secrets were added.
- **Acceptance:** verify each diagnostic state against test documents/live project, confirm active/non-expired banner only, and verify refresh while offline does not block local work.

### 5. Google Drive backup/restore — compatibility review required; not falsely marked complete
- **Android v335 reference:** creates new backups in Drive `appDataFolder`, verifies the returned Drive file ID, and restores by searching that app-data space. This is separate from Online Reports' shared-folder API-key feature.
- **Windows v328:** has user-initiated offline database backup/restore with integrity/schema checks and a pre-restore safety backup. No equivalent authenticated Drive app-data implementation is established by the inspected Windows source.
- **Required next work:** inspect Android backup file format/schema/version and authentication scope; define an explicit Windows sign-in/consent/token lifecycle and compatible restore validation; preserve offline backup/restore as an independent fallback. Never reuse the Online Reports API key as an OAuth credential.
- **Acceptance:** same-account Android backup → Windows restore (if supported by approved design) → integrity check; Windows-created backup → Android restore only if format compatibility is explicitly established; revoke/expired-token/offline/duplicate backup cases. Do not implement until the auth and format contracts are settled.

### 6. Phone–PC synchronization — preserve encrypted protocol; verify full Android v337 record coverage
- **Already present:** encrypted exchange, first-pair approval, event-driven change notifications, five-second fallback, and Windows-side archive storage.
- **v337 action:** no protocol rewrite. Documented validation targets now include agent contacts, linked devices, location fields, tombstones/deletions, and any future photo-byte payload as a separately versioned extension.
- **Acceptance:** paired-device tests for initial sync, incremental sync, reconnect/catch-up, duplicate event, concurrent changes, deletion propagation, and no echo loops. The event endpoint remains a change hint, not proof that data exchange succeeded.

### 7. SMS Checker — intentionally phone-only
- Android v337 contains the sequential Recheck queue failure correction (`continue` after an SMS send failure).
- Windows remains a receiver/reviewer of phone-side results; it must not attempt to send SMS or imitate the Android SMS permission/telephony flow.
- **Acceptance:** verify PC receives and displays phone results after Android queue completion; no PC SMS sender is introduced.

### 8. Build, version and project records — updated
- Advanced Windows assembly, file and informational versions to `4.7.0.337`.
- Advanced Windows installer identity/output filename to `4.7.0.337`.
- Added this itemized parity register and updated the Windows master worksheet, change log and Android/Windows parity matrix.
- Kept the existing `DevMonitor-PC-v{VERSION}-...zip` naming rule. No workflow changes are required solely for the platform prefix.

## Protected behaviour — unchanged
- Payment engine/formulas, 21st–20th payment cycle, eligibility gates, Sunday/FRC treatment, MOM databases/snapshots, HQ activation snapshots, target calculations, report-import authority, two-month retention, and source ownership.
- Windows does not send SMS. Android remains authoritative for agent identity, contact rows, photo selection, coordinates and linked-device assignments.
- Offline backup remains available; cloud diagnostics never become a startup requirement.

## Verification status
- Source review and ZIP integrity: to be recorded after packaging.
- .NET 8/WPF compilation, Windows installer execution, live Firestore diagnostics, paired sync, and Windows runtime/UI testing: **pending GitHub Actions and real-device/desktop validation**.
- Full photo parity and authenticated Drive app-data parity: **not implemented; explicitly outstanding**.
