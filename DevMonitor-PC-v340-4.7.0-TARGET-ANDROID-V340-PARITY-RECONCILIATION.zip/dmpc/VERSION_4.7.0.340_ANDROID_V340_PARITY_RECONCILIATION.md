# DevMonitor Windows/PC v340 — Android v340 parity reconciliation

## Base
- `DevMonitor-PC-v337-4.7.0-TARGET-ANDROID-PARITY-CLOUD-DIAGNOSTICS.zip` (latest Windows source package found in the Library).
- Reconciled against Android v340 integrated source: daily SMS Checker history, original earnings progression card legibility preservation, company-first SMS Checker ordering, Recheck priority, and the partner-specific timeout.

## Windows changes in this increment
- Advanced Windows assembly, file, informational, and installer version identity from `4.7.0.337` to `4.7.0.340`.
- Updated the shared Android/Windows parity register, master worksheet, and changelog with the v340 integration status and platform ownership boundaries.
- No Windows SMS sender was added. Windows continues to receive and display phone-originated SMS Checker results only.
- No separate Windows daily SMS history viewer was added: Android v340 stores daily device and partner history in phone-local SQLite databases, and the current Windows sync projection does not transfer those history databases/records. This remains an explicit parity gap rather than a falsely claimed feature.
- Earnings progression PNG generation and native share-sheet presentation remain Android responsibilities. Windows continues to prepare/queue supported share-card handoffs; it does not replace the Android original-card renderer.

## Protected behaviour
- `PaymentRules.cs`, payment calculations/cutoffs, MOM databases/snapshots, HQ/report import authority, target forecasts, two-month retention, and encrypted phone/PC sync protocol were not changed.
- Windows offline backup/restore remains unchanged. Android Drive `appDataFolder` authorization and backup changes are not represented as implemented on Windows.
- No Android-only AdMob, SMS permission, or mobile runtime behaviour was introduced into Windows.

## Verification status
- Source package ZIP integrity: pending final packaging check.
- Project/installer version consistency: checked during packaging.
- WPF/.NET build, installer execution, and paired Android/Windows runtime verification: not performed in this environment; GitHub Actions/Windows testing is still required.
