# Android / Windows Feature Parity Matrix — Android v301 / Windows v286 (2026-10-22)

## Agent data ownership and OpenStreetMap pin selection
- Android is authoritative for agent records and device associations. Windows only receives/displays synced agent details and linked device state; no parallel native agent CRUD workflow.
- Android single-contact import includes a review/merge step. Multi-contact batch import is deferred by explicit user decision.
- Android location picker uses OpenStreetMap: tap/long-press to place a pin, refine the marker, review coordinates, then explicitly save the agent. Postal address is a separate field. No Google Maps API key or billing setup is required for the map.
- `GOOGLE_MAPS_API_KEY` must be configured in Gradle/GitHub build configuration and enabled for Maps SDK for Android. No API key is embedded.
- Windows displays synced names, addresses, phones, emails and device links. Android-local photo paths are not image payloads and must not be treated as portable photos.
- Payment engine/rules/cards and MOM physical DB/snapshot behavior remain protected.
- Source/ZIP checks only; build/runtime verification pending.

---

# Android / Windows Feature Parity Matrix — v295 / Windows v281 (2026-10-21)

## Monthly target delivery forecast (current requirement)
- Both platforms show only the current calendar month against the active profile's configured target.
- Neutral figures only: monthly target, delivered so far, projected month-end at the observed daily rate, target achieved percentage, and remaining target balance.
- Do not display management verdicts or pressure-inducing status labels: no “on track”, “at risk”, red shortfall warnings, or equivalent judgement text.
- Daily sales lists/charts include only recorded observation dates; missing dates are not treated as zero sales.
- Data retention remains two calendar months. Do not expand retention to support trends.
- Projection uses cumulative current-month delivered sales / latest observed calendar day × days in the current month. It is an estimate, not a guarantee.
- Preserve the existing profile/ownership target scoping and agent fixed target of 150 where applicable.
- Payment engine/rules, payment card logic, MOM physical databases/snapshots, report import authority and cutoff rules are protected and unchanged.

## v294 source status
- Android source updated to v294; build/device verification pending.
- Windows source updated to v280; build/runtime verification pending.
- Cross-platform parity is source-level only until both builds and real imported-data comparisons are tested.

---

# Android / Windows Feature Parity Matrix — v293 (2026-10-21)

Purpose: keep phone and Windows-native DevMonitor implementations aligned on product behaviour, not just labels. Update this document alongside `MASTER_WORK_SHEET.md`, `CHANGE_LOG.md`, `NEXT_LEVEL_ROADMAP.md`, and `NEXT_LEVEL_TRACKER.md` for cross-platform changes.

| Feature / contract | Android | Windows native | Acceptance rule |
|---|---|---|---|
| Trend period | Current calendar month vs target | Current calendar month vs target | No 7/30-day or 6/12-month selector; neutral target figures only; no management verdicts. |
| Monthly target forecast | Current calendar month only; no 6/12-month selector | Same neutral monthly target forecast | Show target, sales so far, projected month-end sales, target achieved percentage, and remaining balance only; no management verdicts or risk labels. |
| Forecast basis | Current-month sales delivered to date divided by elapsed days, projected through the current month end | Same forecast basis | Label as an estimate; do not add historical comparisons or synthesize missing observations as zero. |
| Scope and retention | Current calendar month only | Same scope | Existing two-month data retention remains unchanged. |
| Active total | Latest observed active snapshot within each month | Same aggregation | Do not sum daily active snapshots into a monthly total. |
| Refresh | Explicit user action | Explicit user action | Profile navigation/import must not silently trigger expensive trend recalculation. |
| Protected logic | Payment rules, payment-cycle boundaries, MOM/HQ storage and report authority unchanged | Same protected contracts | Trend implementation must not modify payment or MOM business logic. |
| Documentation | Master sheet, changelog, roadmap, tracker and this matrix | Same shared contract | Mark platform implementation/test status separately; do not claim parity until both builds are verified. |

## v293 Android status

- Source implementation updated to calendar-month aggregation and same-period month-on-month sales comparison.
- Source ZIP integrity and targeted source assertions passed.
- Android Gradle build/device verification: pending.
- Windows-native implementation/build parity: not verified in this Android source package; the Windows project must implement and test the same acceptance rules before parity is marked complete.

## Package naming rule and monthly target forecast — ANDROID v294

- Required filenames place `An` (Android) or `PC` (Windows native) immediately before the version number.
- GitHub Actions workflow remains unchanged by this naming convention.
- Forecast labels are neutral only; no management verdicts or pressure-inducing status labels.
- Build and runtime status must be recorded separately for each platform.


## AI voice and notification sounds (planned)
- Android v295 and Windows v281 must share event categories: important actionable alerts and user-requested task completions only.
- Both platforms should support spoken announcement and futuristic sound effects independently, plus preview/mute and safe fallback.
- No announcements for routine progress/background events; do not speak sensitive report/device/payment details.
- Status: plan documented; implementation and cross-platform tests pending.


## AI voice notification parity — finalized audio approach

- Both platforms bundle and play the same fixed pre-rendered alert and task-completion WAVs; neither relies on device speech synthesis.
- Only warning/error alerts and explicit completed tasks announce; ordinary info/progress notices remain silent.
- Audio is non-blocking/best-effort and must not trigger data refreshes or alter payment, MOM, HQ/report, or retention behavior.
- Android and Windows build/device verification is still pending.

## Agents, linked devices and card personalization — Android v299 / Windows v284

| Capability | Android v299 | Windows/PC v284 | Status |
|---|---|---|---|
| Agent ↔ My Devices relationship | Existing saved link/unlink retained and surfaced in agent details | Existing relationship archive and partner/device summary retained | Existing support; source/runtime verification pending |
| Multiple phone numbers and labels | Contact picker imports multiple values; duplicate values skipped | Retained in synced Android archive | Partial parity |
| Multiple email addresses and labels | New local table; add/remove UI; contact import; sync export | New family accepted and retained in archive | Partial parity |
| Contact thumbnail | Copies to app-private storage if no photo already exists; used by Android share card | Android-local file path is not portable; native PC photo support not implemented | Android-only in this increment |
| Personalized device share card | Linked agent name, local photo if available, first phone number | Existing queued cards and linked-agent name remain; native photo personalization not implemented | Partial parity |
| Contact preview/merge, edit/clear photo, saved map-pin picker | Not yet implemented in this increment | Not yet implemented | Outstanding |
| Payment and MOM rules | Unchanged by design | Unchanged by design | Protected |

Do not mark full Agents parity complete until the outstanding rows are implemented and both builds/runtime workflows are verified.

## Agents database follow-up (2026-10-22, Android v300 / PC v285)
- Windows Agents directory displays imported email addresses and clarifies that Android photo paths are not transferable image content.
- Remaining parity gaps: native Windows agent/contact/photo editing, image-byte sync, contact preview/merge, saved map pin workflow, and Windows card photo rendering.


## Android v302 / Windows v287 — OpenStreetMap agent location
- Android remains the source of truth for agent records, coordinates, contacts and device links.
- Android uses an OpenStreetMap-based pin picker; no Google Maps API key/billing setup is required for map selection.
- Windows displays synced latitude/longitude and provides a selected-agent action to open the saved pin on OpenStreetMap. Windows remains read-only for agent management.
- Coordinate absence/invalidity is surfaced as a friendly prompt to set the pin on Android and sync again.
- Build and runtime verification remain pending until the Android and Windows build workflows complete and both applications are tested.


## Windows/PC v288 agent photo-list parity (2026-10-23)
- PC agent directory includes a photo thumbnail slot with initials placeholder and a photo status column.
- Windows can render a photo only if the path points to a file accessible on that PC. Current sync transmits `photo_path`, not image bytes; Android-private photos therefore remain placeholders.
- Actual image-byte sync remains outstanding and must be implemented with size limits, safe file handling, and privacy-aware transfer before claiming photo parity.
- Android remains authoritative for agent records and linked devices.


# Android v337 / Windows-PC v337 parity register (2026-11-04)

| Area | Android v337 | Windows-PC v337 | Status / acceptance |
|---|---|---|---|
| Agent identity and linked devices | Authoritative agent/contact/device-link records | Read-only synced directory and links | Source support exists; paired sync/create-edit-delete verification pending |
| Phones and emails | Multiple labeled values; contact review/import | Displays synced labeled values | Verify full rows, labels, duplicate handling and deletion markers after sync |
| Agent photos | App-private photo selection/replace/clear | Placeholder/status; no Android-private path is treated as an image | **Outstanding:** coordinated byte-transfer protocol with size/type/hash validation and clear/delete propagation |
| Agent location | OpenStreetMap pin selection and explicit save | Validates coordinates and opens OpenStreetMap | Partial parity; verify actual saved-pin sync |
| Broadcast/release | Android v314 diagnostics and remote release/broadcast handling | v337 Dashboard diagnostics distinguish missing, inactive, empty, expired and read-failure states; manual refresh | Source parity improved; live Firestore test pending |
| Google Drive backup | v335 appDataFolder upload/search/restore | Offline backup/restore only | **Outstanding:** OAuth/token lifecycle and backup-format compatibility review; offline backup retained |
| Phone–PC sync | Encrypted exchange + event-triggered initiation | Encrypted exchange + event long-poll endpoint | Preserve protocol; test reconnect, catch-up, tombstones, no echo loops |
| SMS Checker | Phone sends SMS; v337 sequential Recheck queue correction | Receives/displays phone-side results only | Intentionally phone-only; no Windows SMS sender |
| Payment/MOM/HQ/report rules | Protected | Protected | No changes authorized or intended in v337 |

Do not label full parity complete until build and paired-device acceptance tests pass. Photo-byte and Drive app-data parity remain explicitly incomplete.


# Android v340 / Windows-PC v340 parity register (2026-11-07)

| Area | Android v340 | Windows-PC v340 | Status / acceptance |
|---|---|---|---|
| SMS Checker execution | Phone sends SMS; company-first ordering, Recheck priority, normal 2-minute timeout and partner 3-minute timeout | No SMS sender; receives/displays phone-originated results | Intentional platform ownership; verify paired sync of result updates |
| Daily SMS history | Separate device and partner history stores/dialogs; retains completed outcomes including timeout/send-failed | Current sync projection does not transfer these phone-local history databases/records; no desktop history viewer | **Outstanding parity gap.** Define a bounded, privacy-safe sync DTO before adding a Windows history view; do not copy SQLite database files across platforms |
| Earnings progression share card | Original Android card retained; supporting-label legibility improved without replacing its composition | Existing PC prepare-and-queue workflow hands cards to Android; Android remains the renderer/share-sheet owner | Partial parity by design; preserve original Android card renderer |
| Payment/MOM/HQ/report/targets | Existing protected rules unchanged in v340 integration | Existing protected Windows rules unchanged | No changes authorized or made |
| Google Drive backup | Android v335+ appDataFolder backup/restore path | Windows remains offline-backup oriented | Cloud backup parity remains outstanding; no claim of Windows Drive parity |

Windows v340 source package version metadata and parity documentation are updated. Windows compilation, installer execution, and paired-device tests remain pending; do not mark full parity complete until those checks pass.
