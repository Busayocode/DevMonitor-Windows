## Current PC pairing UI update — v317
- Sidebar and Dashboard now expose **Pair Phone ↔ PC** as the clear entry point to the existing encrypted sync bridge.
- Pairing currently still uses the PC URL and pairing key manually; QR-code scanning and automatic discovery remain future implementation work and must not be represented as shipped.
- Preserve the AES-GCM bridge and exclusion of authoritative payment/MOM/HQ snapshot data from sync merges.
- Verification: ZIP integrity and XAML XML well-formedness; no Windows build/runtime test.

## Current PC cumulative reference — v288 (2026-10-23)
- Latest cumulative Windows source package: `DevMonitor-PC-v288-4.7.0-TARGET-AGENT-DIRECTORY-PHOTO-THUMBNAIL.zip`.
- Retains PC v287 OpenStreetMap agent-location support and the cumulative v280 monthly target forecast / v282 bundled notification-audio changes.
- Agent list now has a thumbnail column and initials placeholder. Actual Android-only photos remain unavailable on PC until image bytes are included in sync; do not describe this as completed cross-device photo sync.
- Protected: payment rules, MOM DBs/snapshots, HQ data authority, target calculations and device-link ownership.
- Verification: ZIP integrity/source-level checks only; Windows build and runtime not verified in this environment.

## Windows v287 — OpenStreetMap agent-location parity (2026-10-22)
- Windows remains read-only for Android-authoritative agent records and linked devices.
- Added an OpenStreetMap action to the Windows Agents directory: select a synced agent with valid saved latitude/longitude and open its pin in the browser. Missing/invalid coordinates show a clear instruction to set the pin on Android and sync again.
- Updated the architecture documentation to OpenStreetMap; no Google Maps SDK key or billing configuration is required for the map.
- Preserved Windows-native workflows, sync ownership boundaries, HQ snapshots, and payment calculations.

## Windows v286 — Android-authoritative agent directory (2026-10-22)

- Windows Agents view is read-only for Android-originated agent details and device links. Android remains the source of truth; edit agent records on Android and sync them to Windows.
- Removed the shortcut suggesting Windows-native agent editing. Agent/phone/email/device-link record families are no longer offered as editable archive record types, while received records remain viewable/exportable as part of the archive.
- Windows continues to show agent name, postal address, phones, emails and linked device codes. Android-local photo paths are not treated as transferable image files.
- OpenStreetMap is used for Android pin selection without a Google Maps SDK/API key requirement; Windows receives saved coordinates in the synced agent record and can open the selected pin on OpenStreetMap.
- Build/runtime verification pending. Payment/MOM behavior remains protected.



## Windows v281 — AI voice + notification sound plan (2026-10-21)

- Recorded the approved JARVIS-inspired direction: original futuristic sound effects plus robotic/futuristic spoken announcements for important alerts and completed tasks only.
- This is planning/documentation only; notification feature code has not been implemented in this package.
- Proposed Windows approach uses the available Windows speech facility and local original/licensed WAV effects, with parity controls, preview, duplicate suppression, privacy-safe generic phrases, and fallback when speech is unavailable.
- Excludes routine progress, repeated device updates, navigation, and background events from spoken announcements.
- PaymentRules/payment calculations, payment cards, MOM databases/snapshots, two-month retention, HQ import authority, and explicit-refresh behavior remain protected.
- Compile/runtime verification pending. See DEVMonitor_AI_VOICE_NOTIFICATION_PLAN.md.

## Windows v280 — Monthly target delivery forecast (2026-10-21)

- Replaced the 7-day / 30-day Trends & Insights page with a current-calendar-month target view.
- Neutral figures only: monthly target, delivered so far, projected month-end at observed daily rate, target achieved percentage, and remaining target balance. No on-track/at-risk verdicts or red shortfall warnings.
- Daily sales table shows recorded dates only. Projection is an estimate based on delivered sales through the latest recorded day divided by that day number, multiplied by days in the month.
- Preserved the two-month HQ snapshot retention and existing role-specific target scope (Agent target fixed at 150; Staff/Partner target scope remains profile-based).
- PaymentRules.cs, payment calculation logic, MOM/payment storage and authoritative HQ snapshot import rules unchanged.
- Verification: source review and ZIP integrity only; Windows compilation/runtime verification pending.

## 4.7 Target refinement + WPF compile fix (v278)
- Target achievement percentage is actual activity divided by the expected cumulative target for the same reporting day.
- No shortfall/deficit amount or behind-pace warning is displayed. Full-month target progress remains a separate, neutral percentage.
- Removed an unsupported WPF FormattedText.TextRenderingMode assignment that prevented Windows compilation; retained normal WPF text rendering.


## Windows 4.7.0.276 — Target
- Added a monthly target field to Profile & Company. Staff and Partner require a positive target; Agent target is fixed at 150.
- Added a Monthly Target card to Month-on-Month with cumulative current-month HQ activations, target achievement percentage, expected-to-date pace, and shortfall/on-track status.
- Staff and Partner totals are aggregated across all matching devices in the current HQ month; Agent totals use the saved My Devices scope.
- No payment formula or authoritative HQ snapshot/import behavior changed. Source-level review completed; Windows compilation remains pending.

## Windows v235 — Strict payment-card history and My Partners search parity (2026-10-17)
- Ported the Android v275 evidence-based payment-card eligibility principle to PC-initiated SMS Checker card batches: require device-specific Active history from the previous calendar month, a successful current-month phone Active result, and after the 20th a qualifying baseline through the 20th plus a successful post-20th Active result.
- Missing evidence now produces a specific skip reason at every point in the month; missing history is never treated as zero. Loaded Report card sourcing remains independent and is not filled from SMS Checker values.
- Aligned Windows My Partners lookup with Android v239/v252: searches the latest retained HQ directory, supports case-insensitive partial partner-name/Trade-Code matching, ignores blank Trade Codes, deduplicates by canonical Trade Code, and caps visible matches at 12. Historical snapshots remain accessible in Loaded Report.
- Preserved the established payment tier table, FRC weekly separation, Sunday-bonus qualification, next-tier projection, native Android share handoff, HQ snapshot data, and existing Windows offline workflows.
- Verification: source-level review and ZIP integrity checks; Windows compilation and paired-device runtime verification remain to be run in GitHub Actions.

## Windows v234 — Historical eligibility gate for payment progression (2026-10-17)
- PC-initiated SMS Checker card batches now require a valid historical Active baseline through the 20th after the 21st-cycle boundary. A missing baseline causes that device's card to be skipped with an explicit reason, never treated as zero.
- Baseline eligibility checks successful phone Active history or a device row in an imported HQ report whose coverage spans the required month start through the 20th; a successful post-20th Active observation is also required to create a current-cycle card.
- Loaded Report cards remain independent; next-tier card, FRC weekly separation, source isolation, and PC-to-Android handoff are preserved.
- Windows project version 4.6.0.234; compilation and paired-device verification pending.

## Windows v232 — FRC weekly payment separation (2026-10-17)
- Kept the existing FRC cumulative calculation and display, with the clarification “Progressively paid weekly”.
- Excluded FRC from the main payment estimate subtotal; the main estimate is now fixed performance reward plus qualifying Sunday bonus only.
- Applied the changed subtotal consistently to Earning Progress and PC-generated earnings flyers and their sync payloads, while retaining the separately visible FRC value.
- Preserved activation tiers, Sunday qualification, and source selection/isolation.
- Source/archive checks only; Windows compilation and paired-device runtime verification remain pending.

- Share-card truth-in-labeling: PC hero must say “ESTIMATED EARNINGS” or “ESTIMATE UNAVAILABLE”, never imply a payment has already been received. Renderer remains presentation-only.
## Current update — Windows v230 share-card component sharpness
- Earnings card is rasterized at 3x (3240 × 4260) with explicit Segoe UI typography and grayscale antialiasing for clearer individual components.
- Renderer remains presentation-only and consumes the existing estimate object; payment rules unchanged.
- Windows build verification pending.

## Current update — Windows v221 (2026-10-12)

- Deliverable: DevMonitor-Windows-Native-v221-EARNINGS-FLIER-REACH-MESSAGES-CONNECTION-STATUS.zip
- Scope: earnings flier visual direction, reach-step-specific encouragement copy, and PC–Android connection-status visibility/parity.
- Guardrail: payment calculations and category thresholds remain unchanged; card values must come only from the chosen source.
- Verification: ZIP integrity checked; no claim of a successful platform build.

# DevMonitor Windows Master Work Sheet

## Current package
- Windows native version: **4.6.0.232** (source package; build not yet verified).
- Android handoff baseline: **4.6.0-NEXT versionCode 227**.

## Cross-device earnings-card sharing
- Start on Windows from **Earning Progress → Share an agent card via Android** or **Share Earnings Cards**.
- Select one source for the whole batch: SMS Checker or Loaded Report. Select agent rows; every linked device with values in that source gets a separate PNG.
- Cards show source-only Today, MTD and Active values, the selected source, reporting period, as-of timestamp, and a monitoring-only warning. This PC handoff does not compute a new payment estimate or fill missing values from another source.
- Cards are queued locally as `share_queue` records, included in the existing AES-GCM encrypted sync response, then presented by Android in the native share sheet. Android sends card IDs back as acknowledgements on the next exchange. The PC removes acknowledged queue entries.
- The share-sheet handoff is not proof that WhatsApp or another recipient received a message. User selects recipient and confirms sending.
- Limits: up to 20 cards per batch; transfer uses the existing 15 MB encrypted bridge request limit; Android rejects individual PNG payloads above 2 MB.

## Protected boundaries
- No changes to `PaymentRules.cs` or the Android payment calculation paths.
- HQ snapshots and payment records remain excluded from synchronization.
- Existing five-minute standby reachability policy and bounded retry/backoff behavior are unchanged.

## Verification status
- Source archive and documentation prepared. Android Gradle compilation could not be completed in this environment because the Gradle distribution download requires network access. Windows compilation and paired Android↔PC handoff remain to be verified by GitHub Actions and a real paired-device test.


## Windows v222 connection feedback and navigation contrast (2026-10-13)
- Inactive sidebar navigation now uses higher-contrast white text and a slightly larger font.
- Header refresh still refreshes the current page and now also checks the local bridge health endpoint when the bridge is running. If stopped, it explains the exact Phone Data Exchange action needed to start it.
- A local health response is not represented as proof of a successful Android sync. Payment calculations remain unchanged.


## Windows v223 — My Partner workspace and Android v237 parity pass
- Added a dedicated My Partner navigation page. It searches imported HQ snapshots by partner name/trade code and selecting a row fills the form.
- Partner entries and history tables live in a separate `%LOCALAPPDATA%\DevMonitor\my_partner.db`, scoped to the local profile; no writes to My Devices, SMS Checker observations, HQ snapshots, or payment progression.
- Windows does not send SMS and does not fabricate partner-check outcomes. Phone-side result delivery and native desktop toast notifications remain follow-up verification/work items.
- Payment rules are unchanged.
- Validation: ZIP integrity and XAML XML validation performed; .NET/Windows compilation unavailable in this environment.


## Windows v224 — My Partners refinement
- My Partners is revealed only for a saved STAFF profile and is hidden for AGENT/PARTNER roles.
- Search loaded report by partner name or Trade Code, select a match to populate official details, and view personalized result details.
- Export the current My Partners result preview as a PNG share card.
- Separate `my_partner.db` retained; original SMS Checker and payment rules remain unchanged.

## Windows v225 — Share-card progression parity (2026-10-15)
- PC-generated SMS Checker and Loaded Report earnings cards now use the branded flyer layout and show activation tiers at 30, 50, 70, 100, 150, 200, 250 and 300 based only on the selected source's Active value.
- The progression graphic and encouragement copy are presentation-only; all payment calculations remain governed by the existing payment rules. Missing Active values are labelled unavailable rather than guessed.
- PC continues to queue PNGs for Android's native share sheet. The separate My Partners result card remains a lookup-result artifact and is not assigned invented payment progression.
- No duplicate Flags menu item was found in Windows navigation source. Build verification still requires the Windows GitHub Actions workflow.


## v226 follow-up — Share card parity
- [x] Correct PC activation progress fill to represent 0–300 scale instead of progress toward the next milestone only.
- [ ] Run Windows GitHub Actions build and inspect generated PNG before release.

## v227 — Photographic earnings flyer
- Windows share cards now include an embedded photographic hero asset alongside branded promotional copy.
- Figures remain source-specific; activation progression is based only on the selected source's Active count.
- Build verification pending.


## v228 share-card correction
- Share-card output includes the established estimated subtotal, fixed reward, FRC component, and Sunday bonus.
- Estimate is calculated using PaymentRules from the chosen source's Active figure. Loaded Report Sunday bonus only uses qualifying Sundays from the same selected HQ report; SMS Checker estimate does not mix sources.
- Missing Active input is reported as unavailable.
- Photo asset dimensions: 1542 × 1545 for cleaner downsampling. Build verification pending.


## v229 — Share card display-only estimate and full-card resolution
- `RenderSharePng` accepts `IncentiveEstimate?` and only displays the supplied values; it no longer calls `PaymentRules.Estimate` internally.
- Whole-card output is now 2160 × 2840 at 192 DPI.
- Source-specific data selection remains in `QueueShareCards`; the rendering function is a presentation layer.


## Shareable payment card — next-tier earnings opportunity (v233, 2026-10-17)
- PC-generated earnings-card PNGs now show clearly labelled current payment estimate, the exact activations remaining to the next configured tier, projected main estimate at that tier, and incremental gain.
- The renderer consumes the selected source's existing `IncentiveEstimate`. It retains the current qualifying Sunday bonus, does not forecast future Sunday bonuses, and excludes weekly-paid FRC from current/projected totals.
- Source selection and PC-to-Android handoff remain unchanged; canvas expanded to keep the new panel separate from the footer.
- Validation: source-level checks; Windows compile and generated-PNG visual review pending.


## Windows v279 — Android 4.7 parity review and share-card legibility

- Based on the supplied Windows Native v278 source and reviewed against Android v292.
- Ported the latest applicable share-card legibility direction to the Windows earnings-card renderer: stronger contrast for supporting labels, larger supporting text, and width-fitting for long source/period, estimate breakdown, tier, and projection-note lines.
- Rendering remains presentation-only and consumes the existing `IncentiveEstimate`; no payment formula, source-selection, Sunday qualification, FRC treatment, or Target calculation was changed.
- Advanced Windows assembly/file/informational version and installer identity to `4.7.0.279`.
- Android v291 on-demand location permission is Android-specific and has no equivalent Windows runtime permission flow.
- Android v292 AdMob report-export credits and SMS-monitoring interstitial threshold are Android SDK/phone behaviours. They are documented as not ported to Windows; no unsupported AdMob SDK or artificial desktop ad gate was added.
- Broader parity items remain tracked in `ANDROID_WINDOWS_PARITY_MATRIX.md`, including dedicated typed editors, complete operational-history reconciliation, company activation report-history views, and full role/screen parity.
- Verification: source-level checks and ZIP integrity only. The .NET 8 Windows build and generated PNG visual review require Windows/GitHub Actions; this environment has no `dotnet` SDK.

## WINDOWS/PC v280 — monthly target forecast and package naming correction

- Trend scope is the current calendar month only, projecting month-end sales from the observed delivery rate against the existing monthly target.
- Display only neutral figures: target, sales so far, projected month-end, target achieved percentage, and remaining balance. No management verdicts, risk labels, or red shortfall warnings.
- Existing two-month retention and protected payment/MOM/HQ logic remain unchanged.
- Packaging rule documented in `PACKAGE_NAMING_AND_MONTHLY_FORECAST_RULE.md`: Android uses `DevMonitor-An-v{VERSION}-...zip`; Windows native uses `DevMonitor-PC-v{VERSION}-...zip`. GitHub workflow unchanged.
- Source ZIP integrity checked; compile/runtime testing must be reported separately and is not implied by this entry.


## Windows/PC v282 — bundled pre-rendered AI voice notifications

- Replaced the earlier device-speech-engine proposal with fixed, bundled WAV audio; no phone or PC text-to-speech engine is required.
- Added an original futuristic chime plus the fixed spoken alert and task-completion phrases.
- Alert clip is limited to warning/error kinds; completion clip is limited to explicit completed-task notifications. Routine information stays silent.
- Audio is best-effort and must not interrupt or trigger business operations. Payment/MOM/HQ logic and two-month retention are protected and unchanged by design.
- Build and runtime playback verification remain pending.

## Next implementation increment — Agents and device-card personalization (Windows/PC v284)
- Added acceptance of synced `agent_emails` records in the archive/sync path.
- Full native agent contact/photo editing and rendering, contact preview/merge, and saved map-pin picker remain outstanding; do not mark complete based on archive acceptance alone.
- Preserve payment/MOM/HQ calculations and snapshot stores; build/runtime verification pending.

## Agents continuation — Windows v285 (2026-10-22)
- The PC Agents directory now displays imported email addresses and makes the Android-local nature of `photo_path` explicit.
- Outstanding: native PC contact/email/photo editing, image bytes sync, contact preview/merge, saved map-pin editor, and photo-personalized Windows share cards. Do not treat a path from an Android device as a Windows file path.
- Payment/MOM calculations and snapshots remain protected.


## Current Windows source update — v314 (2026-10-23)
- Advanced Windows source version to 4.7.0.314 from v288.
- Added read-only Firestore REST retrieval for the broadcast ticker and remote release highlights using project `fieldpulse-b3eb3`.
- No partner-authorization request implementation existed in the inspected PC source; no such flow was added. Existing agent/contact/partner directory functions remain.
- Protected payment, MOM, HQ activation snapshots, targets, forecast formulas, import rules and sync ownership.
- Validation: ZIP integrity and source checks only. .NET build and live Firebase runtime are not confirmed.


## v317 — Windows navigation accessibility fix
- Increased inactive navigation label contrast.
- Changed selected navigation item to a pale teal with dark text for clear focus.
- Strengthened hover contrast.
- Removed the narrow vertical OFFLINE-FIRST explanatory sidebar panel that wrapped text vertically.
- Navigation routes and business logic unchanged. Source package ZIP integrity and XAML XML parsing checked; Windows compilation/runtime not verified in this environment.

## 2026-10-24 — v321 / Android v319 event-driven sync work

- Added a Windows `/events` long-poll endpoint backed by SQLite database/WAL file-change signals and an Android listener that initiates the existing encrypted sync on PC changes.
- Added an Android SQLite/WAL observer with a stable operational-payload fingerprint to initiate sync on meaningful local changes; unchanged settings/status writes are filtered out.
- Retained the five-second fallback. Do not raise it to 30 seconds until real Android/Windows device testing verifies event delivery, reconnect/resume catch-up, no sync echo loops, and operational record consistency.
- Kept the existing encrypted sync protocol and first-pair approval. The event endpoint returns only a version number.
- Explicitly removed `monthly_target` from Android `daily_observations` transfer projection and merge writes. HQ snapshots/targets, payment records, and MOM/payment calculations remain out of scope.
- Package verification: both source ZIPs pass ZIP integrity. Compilation/runtime verification is blocked in this environment (no .NET SDK; Gradle wrapper cannot download Gradle because network DNS is unavailable). Treat as source-ready, not build-verified.


## Windows/PC v337 — Android v337 parity review and diagnostics (2026-11-04)
- Advanced Windows project/installer version to 4.7.0.337.
- Dashboard cloud diagnostics now separately report release configuration/document and broadcast states, including missing, inactive, empty, expired and HTTP/read-failure cases; added user-triggered refresh and last-checked time. Firestore remains read-only and optional.
- Retained Android authority for agent/contact/photo/location/device-link records. Windows v328 already displays synced contact fields, device links and coordinates; real paired-sync validation is required.
- Photo-byte transfer is still outstanding: Android-private paths are not portable. Requires a coordinated, size-limited, validated Android+Windows protocol extension; no fake photo parity claimed.
- Windows OpenStreetMap handoff remains display-only; Android owns pin editing.
- Android v335 Drive `appDataFolder` backup behaviour is not yet matched by authenticated Windows Drive backup/restore. Keep offline Windows backup/restore; define OAuth and DB-format compatibility before implementing cloud parity.
- Android v337 SMS Recheck queue fix is phone-only. Windows remains a receiver of phone results and must not send SMS.
- Protected payment/MOM/HQ/report/target/retention rules remain unchanged. See `VERSION_4.7.0.337_ANDROID_PARITY_AND_CLOUD_DIAGNOSTICS.md` for the itemized register and acceptance tests.
- Validation: source and archive checks only until Windows GitHub Actions build, installer test, live Firestore test and paired-device sync tests complete.


## Windows/PC v340 — Android v340 parity reconciliation (2026-11-07)
- Advanced Windows project/installer version identity to 4.7.0.340 from the latest Library PC v337 source package.
- Documented Android v340 SMS Checker history as phone-local; current sync DTO exports latest SMS results but does not transfer the new daily device/partner history stores. Windows remains a receiver, never an SMS sender.
- Preserved the original Android earnings progression card as the renderer; Windows retains its existing prepare-and-queue handoff and does not introduce a replacement card design.
- PaymentRules, MOM databases/snapshots, HQ/report authority, targets, two-month retention, and encrypted sync protocol were not modified.
- Validation: source metadata and documentation update only; ZIP integrity checked at packaging. Windows .NET/WPF build, installer, and paired-device runtime verification remain pending.
- See `VERSION_4.7.0.340_ANDROID_V340_PARITY_RECONCILIATION.md` and `ANDROID_WINDOWS_PARITY_MATRIX.md`.
