# Android v218 — Phone/PC Sync Bridge

- Added a Sync Bridge panel under Next Level → Health.
- Supports pairing with the Windows v204 local endpoint and a compatible HTTPS relay.
- Uses an AES-GCM encrypted request/response envelope; hosted relay calls also require HTTPS.
- Two-way merges My Devices codes, operational tasks, notes, and SMS inbox history.
- Keeps `.dmdata` fallback and excludes HQ monthly report snapshots and payment records from sync.
- This is protocol v1, not complete feature parity: deletes/tombstones and several entity families are not yet synced.
