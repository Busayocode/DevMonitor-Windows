package com.aziitech.simregmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import java.time.Instant

/** Shared protocol v1. Operational sync only: HQ snapshots and payment records are never sent. */
object SyncBridgeClient {
    data class Result(val tasks:Int,val notes:Int,val sms:Int,val devices:Int)
    fun sync(context: Context, db: DatabaseStore, endpoint: String, pairingKey: String): Result {
        require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) { "Enter a valid http(s) bridge URL." }
        require(pairingKey.length >= 16) { "Pairing key must be at least 16 characters." }
        val request=packageJson(context,db)
        val body=JSONObject().put("payload",Base64.getEncoder().encodeToString(encrypt(request.toString(),pairingKey).toByteArray()))
        val conn=(URL(endpoint.trimEnd('/')+"/sync").openConnection() as HttpURLConnection)
        conn.requestMethod="POST";conn.connectTimeout=8000;conn.readTimeout=20000;conn.doOutput=true
        conn.setRequestProperty("Content-Type","application/json");conn.setRequestProperty("Cache-Control","no-store");if(endpoint.trim().startsWith("https://",true))conn.setRequestProperty("X-DevMonitor-Pairing-Key",pairingKey)
        conn.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}
        val code=conn.responseCode
        val raw=(if(code in 200..299)conn.inputStream else conn.errorStream).bufferedReader().use{it.readText()}
        if(code !in 200..299) throw IllegalStateException("Bridge HTTP $code: $raw")
        val response=JSONObject(raw);val encrypted=Base64.getDecoder().decode(response.getString("payload"));val json=decrypt(encrypted,pairingKey)
        merge(context,db,JSONObject(json))
        val merged=JSONObject(json)
        return Result(merged.optJSONArray("tasks")?.length()?:0,merged.optJSONArray("notes")?.length()?:0,merged.optJSONArray("sms")?.length()?:0,merged.optJSONArray("myDevices")?.length()?:0)
    }
    private fun packageJson(context:Context,db:DatabaseStore):JSONObject {
        val root=JSONObject().put("protocol",1).put("createdAt",Instant.now().toString())
        val devices=JSONArray();MyDevicesStore(context).use{it.codes().forEach(devices::put)};root.put("myDevices",devices)
        val tasks=JSONArray();db.operationalTasks().forEach{t->tasks.put(JSONObject().put("id",t.id).put("title",t.title).put("details",t.details).put("dueDate",t.dueDate).put("priority",t.priority).put("linkType",t.linkType).put("linkValue",t.linkValue).put("completed",t.completed).put("createdAt",Instant.ofEpochMilli(t.createdAt).toString()).put("updatedAt",Instant.ofEpochMilli(t.updatedAt).toString()))};root.put("tasks",tasks)
        val notes=JSONArray();db.operationalNotes().forEach{n->notes.put(JSONObject().put("id",n.id).put("title",n.title).put("body",n.body).put("linkType",n.linkType).put("linkValue",n.linkValue).put("pinned",n.pinned).put("createdAt",Instant.ofEpochMilli(n.createdAt).toString()).put("updatedAt",Instant.ofEpochMilli(n.updatedAt).toString()))};root.put("notes",notes)
        val sms=JSONArray();db.allSms().forEach{v->sms.put(JSONObject().put("sender",v.sender).put("body",v.body).put("received",Instant.ofEpochMilli(v.receivedAt).toString()))};root.put("sms",sms)
        return root
    }
    private fun merge(context:Context,db:DatabaseStore,root:JSONObject){
        val devices=root.optJSONArray("myDevices")?:JSONArray();val local=MyDevicesStore(context);local.use{val combined=(it.codes()+List(devices.length()){devices.optString(it)}).distinct();it.replaceCodes(combined)}
        val tasks=root.optJSONArray("tasks")?:JSONArray();for(i in 0 until tasks.length()){val o=tasks.optJSONObject(i)?:continue;val created=parseInstant(o.optString("createdAt"));val updated=parseInstant(o.optString("updatedAt"));val incoming=OperationalTask(0,o.optString("title"),o.optString("details"),o.optString("dueDate").takeIf{it.isNotBlank()&&it!="null"},o.optString("priority","NORMAL"),o.optString("linkType").takeIf{it.isNotBlank()&&it!="null"},o.optString("linkValue").takeIf{it.isNotBlank()&&it!="null"},o.optBoolean("completed"),created,updated);val existing=db.operationalTasks().firstOrNull{it.title==incoming.title&&it.createdAt==created};if(existing==null)db.saveOperationalTask(incoming) else if(updated>=existing.updatedAt)db.saveOperationalTask(incoming.copy(id=existing.id,createdAt=existing.createdAt))}
        val notes=root.optJSONArray("notes")?:JSONArray();for(i in 0 until notes.length()){val o=notes.optJSONObject(i)?:continue;val created=parseInstant(o.optString("createdAt"));val updated=parseInstant(o.optString("updatedAt"));val incoming=OperationalNote(0,o.optString("title"),o.optString("body"),o.optString("linkType").takeIf{it.isNotBlank()&&it!="null"},o.optString("linkValue").takeIf{it.isNotBlank()&&it!="null"},o.optBoolean("pinned"),created,updated);val existing=db.operationalNotes().firstOrNull{it.title==incoming.title&&it.createdAt==created};if(existing==null)db.saveOperationalNote(incoming) else if(updated>=existing.updatedAt)db.saveOperationalNote(incoming.copy(id=existing.id,createdAt=existing.createdAt))}
        val sms=root.optJSONArray("sms")?:JSONArray();for(i in 0 until sms.length()){val o=sms.optJSONObject(i)?:continue;val sender=o.optString("sender");val body=o.optString("body");val at=parseInstant(o.optString("received"));if(db.allSms().none{it.sender==sender&&it.body==body&&it.receivedAt==at})db.addSms(sender,body,at)}
    }
    private fun parseInstant(s:String):Long=runCatching{Instant.parse(s).toEpochMilli()}.getOrDefault(System.currentTimeMillis())
    private fun key(pass:String)=MessageDigest.getInstance("SHA-256").digest(pass.toByteArray(Charsets.UTF_8))
    private fun encrypt(plain:String,pass:String):ByteArray{val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,SecretKeySpec(key(pass),"AES"),GCMParameterSpec(128,nonce));return nonce+c.doFinal(plain.toByteArray(Charsets.UTF_8))}
    private fun decrypt(data:ByteArray,pass:String):String{require(data.size>=28){"Invalid encrypted bridge payload."};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,SecretKeySpec(key(pass),"AES"),GCMParameterSpec(128,data.copyOfRange(0,12)));return c.doFinal(data.copyOfRange(12,data.size)).toString(Charsets.UTF_8)}
}
