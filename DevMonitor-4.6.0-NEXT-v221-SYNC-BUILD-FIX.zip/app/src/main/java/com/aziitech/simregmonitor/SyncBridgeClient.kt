package com.aziitech.simregmonitor

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import java.time.Instant

/** Shared protocol v1. Operational sync only: HQ snapshots and payment records are never sent. */
object SyncBridgeClient {
    data class Result(val tasks:Int,val notes:Int,val sms:Int,val devices:Int,val extended:Int)
    fun sync(context: Context, db: DatabaseStore, endpoint: String, pairingKey: String): Result {
        require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) { "Enter a valid http(s) bridge URL." }
        require(pairingKey.length >= 16) { "Pairing key must be at least 16 characters." }
        val request=packageJson(context,db)
        val body=JSONObject().put("payload",Base64.getEncoder().encodeToString(encrypt(request.toString(),pairingKey)))
        val conn=(URL(endpoint.trimEnd('/')+"/sync").openConnection() as HttpURLConnection)
        conn.requestMethod="POST";conn.connectTimeout=8000;conn.readTimeout=20000;conn.doOutput=true
        conn.setRequestProperty("Content-Type","application/json");conn.setRequestProperty("Cache-Control","no-store");if(endpoint.trim().startsWith("https://",true))conn.setRequestProperty("X-DevMonitor-Pairing-Key",pairingKey)
        conn.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}
        val code=conn.responseCode
        val raw=(if(code in 200..299)conn.inputStream else conn.errorStream).bufferedReader().use{it.readText()}
        if(code !in 200..299) throw IllegalStateException("Bridge HTTP $code: $raw")
        val response=JSONObject(raw);val encrypted=Base64.getDecoder().decode(response.getString("payload"));val json=decrypt(encrypted,pairingKey)
        merge(context,db,JSONObject(json))
        val merged=JSONObject(json)
        return Result(merged.optJSONArray("tasks")?.length()?:0,merged.optJSONArray("notes")?.length()?:0,merged.optJSONArray("sms")?.length()?:0,merged.optJSONArray("myDevices")?.length()?:0,merged.optJSONArray("extendedData")?.length()?:0)
    }
    private fun packageJson(context:Context,db:DatabaseStore):JSONObject {
        val root=JSONObject().put("protocol",1).put("createdAt",Instant.now().toString())
        val devices=JSONArray();MyDevicesStore(context).use{it.codes().forEach(devices::put)};root.put("myDevices",devices)
        val tasks=JSONArray();db.operationalTasks().forEach{t->tasks.put(JSONObject().put("id",t.id).put("title",t.title).put("details",t.details).put("dueDate",t.dueDate).put("priority",t.priority).put("linkType",t.linkType).put("linkValue",t.linkValue).put("completed",t.completed).put("createdAt",Instant.ofEpochMilli(t.createdAt).toString()).put("updatedAt",Instant.ofEpochMilli(t.updatedAt).toString()))};root.put("tasks",tasks)
        val notes=JSONArray();db.operationalNotes().forEach{n->notes.put(JSONObject().put("id",n.id).put("title",n.title).put("body",n.body).put("linkType",n.linkType).put("linkValue",n.linkValue).put("pinned",n.pinned).put("createdAt",Instant.ofEpochMilli(n.createdAt).toString()).put("updatedAt",Instant.ofEpochMilli(n.updatedAt).toString()))};root.put("notes",notes)
        val sms=JSONArray();db.allSms().forEach{v->sms.put(JSONObject().put("sender",v.sender).put("body",v.body).put("received",Instant.ofEpochMilli(v.receivedAt).toString()))};root.put("sms",sms)
        // Transfer operational/query history that the desktop does not model natively yet.
        // HQ activation snapshots and payment-cycle/payment-record tables are intentionally excluded.
        val extended=JSONArray()
        fun addTable(type:String, sql:String, key:(JSONObject)->String) {
            db.readableDatabase.rawQuery(sql,null).use { cursor ->
                while(cursor.moveToNext()) {
                    val row=JSONObject()
                    for(i in 0 until cursor.columnCount) {
                        val value=when(cursor.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_NULL -> JSONObject.NULL
                            android.database.Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(i)
                            android.database.Cursor.FIELD_TYPE_FLOAT -> cursor.getDouble(i)
                            else -> cursor.getString(i)
                        }
                        row.put(cursor.getColumnName(i),value)
                    }
                    extended.put(JSONObject().put("type",type).put("key",key(row)).put("payload",row))
                }
            }
        }
        addTable("query_codes","SELECT code,type,archived,created_at,updated_at FROM codes") { it.optString("code") }
        addTable("query_records","SELECT code,json FROM records") { it.optString("code") }
        addTable("saved_query_lists","SELECT name,codes_json,updated_at FROM saved_lists") { it.optString("name") }
        addTable("query_history","SELECT id,completed_at,json FROM history ORDER BY completed_at DESC LIMIT 3000") { it.optString("id") }
        addTable("daily_observations","SELECT code,obs_date,ownership,today,mtd,active,bar48,bar96,duplicates,monthly_target,received_at FROM daily_observations") { it.optString("code")+"|"+it.optString("obs_date") }
        addTable("sms_query_attempts","SELECT id,operation_id,code,destination,sent_at,attempt FROM sms_query_attempts") { it.optString("id") }
        addTable("agents","SELECT id,name,address,latitude,longitude,created_at,updated_at FROM agents") { it.optString("id") }
        addTable("agent_phones","SELECT id,agent_id,phone,label FROM agent_phones") { it.optString("id") }
        addTable("agent_devices","SELECT agent_id,code FROM agent_devices") { it.optString("agent_id")+"|"+it.optString("code") }
        addTable("sync_tombstones","SELECT entity_type,entity_key,deleted_at FROM sync_tombstones") { it.optString("entity_type")+"|"+it.optString("entity_key") }
        // Profile metadata and per-profile in-app notifications are operational, not authentication records.
        val profileStore=ProfileStore(context)
        val profiles=profileStore.load()
        profiles.forEach { p ->
            val row=JSONObject().put("id",p.id).put("name",p.name).put("phone",p.phone).put("userType",p.userType)
                .put("staffLevel",p.staffLevel).put("partnerCode",p.partnerCode).put("deviceId",p.deviceId)
                .put("division",p.division).put("region",p.region).put("staffName",p.staffName)
                .put("territory",p.territory).put("codes",JSONArray(p.codes))
            extended.put(JSONObject().put("type","profile_metadata").put("key",p.id).put("payload",row))
            NotificationStore.list(context,p.id).forEach { n ->
                val notification=JSONObject().put("id",n.id).put("profileId",p.id).put("title",n.title).put("message",n.message)
                    .put("timestamp",n.timestamp).put("kind",n.kind).put("read",n.read)
                extended.put(JSONObject().put("type","notifications").put("key",p.id+"|"+n.id).put("payload",notification))
            }
        }
        root.put("extendedData",extended)
        return root
    }
    private fun merge(context:Context,db:DatabaseStore,root:JSONObject){
        val devices=root.optJSONArray("myDevices")?:JSONArray();val local=MyDevicesStore(context);local.use{val combined=(it.codes()+List(devices.length()){devices.optString(it)}).distinct();it.replaceCodes(combined)}
        val tasks=root.optJSONArray("tasks")?:JSONArray();for(i in 0 until tasks.length()){val o=tasks.optJSONObject(i)?:continue;val created=parseInstant(o.optString("createdAt"));val updated=parseInstant(o.optString("updatedAt"));val incoming=OperationalTask(0,o.optString("title"),o.optString("details"),o.optString("dueDate").takeIf{it.isNotBlank()&&it!="null"},o.optString("priority","NORMAL"),o.optString("linkType").takeIf{it.isNotBlank()&&it!="null"},o.optString("linkValue").takeIf{it.isNotBlank()&&it!="null"},o.optBoolean("completed"),created,updated);val existing=db.operationalTasks().firstOrNull{it.title==incoming.title&&it.createdAt==created};if(existing==null)db.saveOperationalTask(incoming) else if(updated>=existing.updatedAt)db.saveOperationalTask(incoming.copy(id=existing.id,createdAt=existing.createdAt))}
        val notes=root.optJSONArray("notes")?:JSONArray();for(i in 0 until notes.length()){val o=notes.optJSONObject(i)?:continue;val created=parseInstant(o.optString("createdAt"));val updated=parseInstant(o.optString("updatedAt"));val incoming=OperationalNote(0,o.optString("title"),o.optString("body"),o.optString("linkType").takeIf{it.isNotBlank()&&it!="null"},o.optString("linkValue").takeIf{it.isNotBlank()&&it!="null"},o.optBoolean("pinned"),created,updated);val existing=db.operationalNotes().firstOrNull{it.title==incoming.title&&it.createdAt==created};if(existing==null)db.saveOperationalNote(incoming) else if(updated>=existing.updatedAt)db.saveOperationalNote(incoming.copy(id=existing.id,createdAt=existing.createdAt))}
        val sms=root.optJSONArray("sms")?:JSONArray();for(i in 0 until sms.length()){val o=sms.optJSONObject(i)?:continue;val sender=o.optString("sender");val body=o.optString("body");val at=parseInstant(o.optString("received"));if(db.allSms().none{it.sender==sender&&it.body==body&&it.receivedAt==at})db.addSms(sender,body,at)}
        // Reconcile desktop-side notification read-state updates back into the matching Android profile inbox.
        val extended=root.optJSONArray("extendedData")?:JSONArray()
        val extendedItems=(0 until extended.length()).mapNotNull { extended.optJSONObject(it) }
            .sortedBy { when(it.optString("type")) { "agents" -> 0; "agent_phones" -> 1; "agent_devices" -> 2; else -> 3 } }
        for(item in extendedItems.filter { it.optString("type")!="sync_tombstones" }){
            val type=item.optString("type")
            val p=item.optJSONObject("payload")?:continue
            runCatching { mergeNativeRecord(context,db,type,p) }
            if(type!="notifications")continue
            val profileId=p.optString("profileId");val id=p.optString("id")
            if(profileId.isBlank()||id.isBlank())continue
            val stamp=p.optLong("timestamp",0L)
            NotificationStore.upsertSynced(context,profileId,DevMonitorNotification(id,p.optString("title"),p.optString("message"),stamp,p.optString("kind","info"),p.optBoolean("read",false)))
        }
        for(item in extendedItems.filter { it.optString("type")=="sync_tombstones" }){
            val p=item.optJSONObject("payload")?:continue
            runCatching { mergeNativeRecord(db,"sync_tombstones",p) }
        }
    }

    /** Apply returned desktop edits to matching Android operational tables only. HQ/payment tables are deliberately absent. */
    private fun mergeNativeRecord(context:Context,store:DatabaseStore,type:String,p:JSONObject) {
        val db=store.writableDatabase
        fun text(name:String,default:String="")=p.optString(name,default).takeUnless { it=="null" }?:default
        fun long(name:String)=if(p.isNull(name)) 0L else p.optLong(name)
        fun int(name:String)=if(p.isNull(name)) 0 else p.optInt(name)
        if(type=="sync_tombstones"){
            val entityType=text("entityType",text("entity_type"));val entityKey=text("entityKey",text("entity_key"));
            val rawDeleted=text("deletedAt",text("deleted_at"));val deletedAt=rawDeleted.toLongOrNull()?.takeIf{it>0}?:runCatching{Instant.parse(rawDeleted).toEpochMilli()}.getOrDefault(System.currentTimeMillis())
            if(entityType.isBlank()||entityKey.isBlank()||entityType=="sync_tombstones")return
            db.beginTransaction();try{
                db.execSQL("INSERT OR REPLACE INTO sync_tombstones(entity_type,entity_key,deleted_at) VALUES(?,?,?)",arrayOf(entityType,entityKey,deletedAt))
                val parts=entityKey.split("|")
                when(entityType){
                    "query_codes"->db.delete("codes","code=?",arrayOf(entityKey))
                    "query_records"->db.delete("records","code=?",arrayOf(entityKey))
                    "saved_query_lists"->db.delete("saved_lists","name=?",arrayOf(entityKey))
                    "query_history"->db.delete("history","id=?",arrayOf(entityKey))
                    "daily_observations"->{if(parts.size>=2)db.delete("daily_observations","code=? AND obs_date=?",arrayOf(parts[0],parts[1]))}
                    "sms_query_attempts"->db.delete("sms_query_attempts","id=?",arrayOf(entityKey))
                    "agents"->db.delete("agents","id=?",arrayOf(entityKey))
                    "agent_phones"->db.delete("agent_phones","id=?",arrayOf(entityKey))
                    "agent_devices"->{if(parts.size>=2)db.delete("agent_devices","agent_id=? AND code=?",arrayOf(parts[0],parts[1]))}
                    "profile_metadata"->Unit
                    "notifications"->{if(parts.size>=2)NotificationStore.deleteSynced(context,parts[0],parts.drop(1).joinToString("|"))}
                }
                db.setTransactionSuccessful()
            }finally{db.endTransaction()}
            return
        }
        val values=ContentValues()
        val table=when(type){
            "query_codes"->{values.put("code",text("code"));values.put("type",text("type"));values.put("archived",int("archived"));values.put("created_at",long("created_at"));values.put("updated_at",long("updated_at"));"codes"}
            "query_records"->{values.put("code",text("code"));values.put("json",text("json"));"records"}
            "saved_query_lists"->{values.put("name",text("name"));values.put("codes_json",text("codes_json","[]"));values.put("updated_at",long("updated_at"));"saved_lists"}
            "query_history"->{values.put("id",long("id"));values.put("completed_at",long("completed_at"));values.put("json",text("json"));"history"}
            "daily_observations"->{values.put("code",text("code"));values.put("obs_date",text("obs_date"));values.put("ownership",text("ownership"));values.put("today",if(p.isNull("today"))null else int("today"));values.put("mtd",if(p.isNull("mtd"))null else int("mtd"));values.put("active",if(p.isNull("active"))null else int("active"));values.put("bar48",if(p.isNull("bar48"))null else int("bar48"));values.put("bar96",if(p.isNull("bar96"))null else int("bar96"));values.put("duplicates",if(p.isNull("duplicates"))null else int("duplicates"));values.put("monthly_target",if(p.isNull("monthly_target"))null else int("monthly_target"));values.put("received_at",text("received_at"));"daily_observations"}
            "sms_query_attempts"->{values.put("id",long("id"));values.put("operation_id",text("operation_id"));values.put("code",text("code"));values.put("destination",text("destination"));values.put("sent_at",long("sent_at"));values.put("attempt",int("attempt"));"sms_query_attempts"}
            "agents"->{values.put("id",long("id"));values.put("name",text("name"));values.put("address",text("address"));if(!p.isNull("latitude"))values.put("latitude",p.optDouble("latitude"));if(!p.isNull("longitude"))values.put("longitude",p.optDouble("longitude"));values.put("created_at",long("created_at"));values.put("updated_at",long("updated_at"));"agents"}
            "agent_phones"->{values.put("id",long("id"));values.put("agent_id",long("agent_id"));values.put("phone",text("phone"));values.put("label",text("label"));"agent_phones"}
            "agent_devices"->{values.put("agent_id",long("agent_id"));values.put("code",text("code"));"agent_devices"}
            else->return
        }
        db.insertWithOnConflict(table,null,values,SQLiteDatabase.CONFLICT_REPLACE)
    }
    private fun parseInstant(s:String):Long=runCatching{Instant.parse(s).toEpochMilli()}.getOrDefault(System.currentTimeMillis())
    private fun key(pass:String)=MessageDigest.getInstance("SHA-256").digest(pass.toByteArray(Charsets.UTF_8))
    private fun encrypt(plain:String,pass:String):ByteArray{val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,SecretKeySpec(key(pass),"AES"),GCMParameterSpec(128,nonce));return nonce+c.doFinal(plain.toByteArray(Charsets.UTF_8))}
    private fun decrypt(data:ByteArray,pass:String):String{require(data.size>=28){"Invalid encrypted bridge payload."};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,SecretKeySpec(key(pass),"AES"),GCMParameterSpec(128,data.copyOfRange(0,12)));return c.doFinal(data.copyOfRange(12,data.size)).toString(Charsets.UTF_8)}
}
