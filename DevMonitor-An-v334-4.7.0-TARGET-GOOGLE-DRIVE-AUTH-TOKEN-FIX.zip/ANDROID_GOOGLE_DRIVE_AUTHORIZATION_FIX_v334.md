# Android v334 — Use the Identity authorization token for Drive Backup/Restore

## Root cause identified in v333
The v333 flow requested the Drive App Folder scope through Google's `AuthorizationClient.authorize()`, but then discarded the `AuthorizationResult` and called the older `GoogleAuthUtil.getToken()` path inside `GoogleDriveBackup`. That mixed two token-acquisition mechanisms and meant the token returned by the interactive consent flow was never actually used for the Drive API request.

## v334 correction
- The authorization flow now passes the `AuthorizationResult.accessToken` directly to the exact pending Backup or Restore action.
- The same token handoff is used whether Google already has consent or returns a `PendingIntent` requiring user approval.
- The returned grant is checked for the exact `drive.appdata` scope, and an empty token is rejected before any Drive request.
- `GoogleDriveBackup` now uses the supplied short-lived access token for the Drive API calls; the redundant `GoogleAuthUtil.getToken()` and recoverable-auth exception path have been removed.
- Both Settings and Next Level Backup/Restore controls use the same corrected token handoff.
- Cancellation, missing token, missing scope, and authorization failures continue to stop the operation with a visible message. No false success is reported.

## Preserved
- Existing Google Cloud project, OAuth clients, package name, signing certificate configuration, and `drive.appdata` scope.
- Drive `appDataFolder` file format and backup filename.
- Existing upload/update and newest-backup download behavior.
- SQLite checkpointing, integrity validation, and staged restore safeguards.
- Offline SAF backup/restore.
- Online Reports Drive folder/API-key configuration remains separate and unchanged.
- Payment calculations, MOM databases/snapshots, cycle rules, report authority, SMS monitoring, and Windows source are unchanged.

## Version
- Android `versionCode`: 334
- Android `versionName`: `4.7.0-TARGET-GOOGLE-DRIVE-AUTH-TOKEN-FIX-V334`

## Validation status
- Source-level token-flow review and ZIP integrity checks completed.
- Gradle compilation has not been run in this environment.
- GitHub Actions compilation and physical-device tests are still required: first-time consent, already-granted consent, backup upload/update, restore download, restore database install, and cancellation.
