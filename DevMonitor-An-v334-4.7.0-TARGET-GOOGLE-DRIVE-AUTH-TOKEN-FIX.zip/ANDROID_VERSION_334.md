# Android v334 — Google Drive Backup/Restore token handoff correction

- `AuthorizationClient.authorize()` is now the single source of the Drive access token for the requested user action.
- The access token returned after either an existing grant or interactive consent is passed directly into `GoogleDriveBackup`.
- The app verifies the `drive.appdata` grant and rejects missing scope or blank tokens.
- Removed the redundant `GoogleAuthUtil.getToken()` request path that previously discarded the Identity API token and mixed authorization mechanisms.
- Settings and Next Level Backup/Restore share the corrected flow.
- Preserved SQLite checkpointing, validation, staged restore, offline SAF backup/restore, and the separate Online Reports Drive configuration.
- Payment/MOM logic, snapshots, cycle rules, SMS monitoring, and Windows source unchanged.
- Android versionCode: 334.
- Android versionName: `4.7.0-TARGET-GOOGLE-DRIVE-AUTH-TOKEN-FIX-V334`.
- Build/runtime status: not yet compiled or device-tested; GitHub Actions and physical-device verification required.
