using Microsoft.Win32;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;

namespace DevMonitor.Windows;

public partial class MainWindow : Window
{
    private readonly DevMonitorDb _db=new();
    private SyncBridgeServer? _syncBridge;
    private string _page="Dashboard";
    private List<DeviceRow> _lastReport=[];
    private DateTime _reportStart,_reportEnd;

    public MainWindow()
    {
        InitializeComponent();
        // Keep the native window fully inside the usable Windows desktop area.
        // This prevents the title bar/close button being positioned off-screen
        // on smaller displays or with display scaling enabled.
        MaxWidth = SystemParameters.WorkArea.Width;
        MaxHeight = SystemParameters.WorkArea.Height;
        Width = Math.Min(Width, MaxWidth);
        Height = Math.Min(Height, MaxHeight);
        if (Width < MinWidth) MinWidth = Math.Max(800, MaxWidth);
        if (Height < MinHeight) MinHeight = Math.Max(520, MaxHeight);
        Left = Math.Max(SystemParameters.WorkArea.Left, SystemParameters.WorkArea.Left + (SystemParameters.WorkArea.Width - Width) / 2);
        Top = Math.Max(SystemParameters.WorkArea.Top, SystemParameters.WorkArea.Top + (SystemParameters.WorkArea.Height - Height) / 2);
        Render("Dashboard");
        Closed += (_,_)=>_db.Dispose();
    }

    private void Nav_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button b && b.Tag is string page) Render(page);
    }

    private void Refresh_Click(object sender,RoutedEventArgs e) { Render(_page); }

    private void Render(string page)
    {
        _page=page;
        foreach (var nav in NavPanel.Children.OfType<Button>())
        {
            nav.Background = nav.Tag is string tag && tag == page ? (Brush)FindResource("SidebarSelectedBrush") : Brushes.Transparent;
            nav.Foreground = Brushes.White;
                nav.Effect = nav.Tag is string selected && selected == page ? (Effect)FindResource("ButtonShadow") : null;
        }
        PageHost.Content=page switch {
            "Dashboard"=>Dashboard(),
            "Sms"=>SmsPage(),
            "Devices"=>DevicesPage(),
            "Report"=>ReportPage(),
            "Earnings"=>EarningsPage(),
            "Monitor"=>MonitorPage(),
            "MonthOnMonth"=>MonthOnMonthPage(),
            "Agents"=>AgentsPage(),
            "Tasks"=>TasksPage(),
            "Notes"=>NotesPage(),
            "Activity"=>ActivityPage(),
            "Inbox"=>InboxPage(),
            "Exports"=>ExportsPage(),
            "LoadedReport"=>LoadedReportPage(),
            "Trends"=>TrendsPage(),
            "ActionCentre"=>ActionCentrePage(),
            "Profile"=>ProfilePage(),
            "Exchange"=>ExchangePage(),
            "AndroidData"=>AndroidDataPage(),
            "Settings"=>SettingsPage(),
            _=>Dashboard()
        };
        PageTitle.Text=page switch {
            "Sms"=>"SMS Checker","Devices"=>"My Devices","Report"=>"Load Report",
            "Earnings"=>"Earning Progress","Monitor"=>"Device Monitor","MonthOnMonth"=>"Month-on-Month","Agents"=>"Agents & Partners","Tasks"=>"Tasks & Follow-ups","Notes"=>"Notes","Activity"=>"Device Activity Timeline","Inbox"=>"Notifications / Inbox","Exports"=>"Export Centre","LoadedReport"=>"Loaded Report","Trends"=>"Trends & Insights","ActionCentre"=>"Action Centre","Profile"=>"Profile & Company","Exchange"=>"Phone Data Exchange","AndroidData"=>"Android Data Archive","Settings"=>"Settings",_=>"Dashboard"
        };
        PageEyebrow.Text=page=="Dashboard"?"CONTROL CENTRE":page.ToUpperInvariant();
        FooterText.Text=$"DevMonitor Windows • Local database: {_db.FilePath}";
    }

    private Border Card(UIElement content, Brush? accent=null)
    {
        var b=new Border{Background=Brushes.White,CornerRadius=new CornerRadius(12),Padding=new Thickness(20),Margin=new Thickness(0,0,0,14),BorderBrush=(Brush)FindResource("BorderBrush"),BorderThickness=new Thickness(1),Effect=(Effect)FindResource("SoftShadow")};
        var panel=new StackPanel(); if(accent!=null) panel.Children.Add(new Border{Height=4,Background=accent,CornerRadius=new CornerRadius(4),Margin=new Thickness(0,0,0,14)});
        panel.Children.Add(content);b.Child=panel;return b;
    }
    private TextBlock H(string text,double size=20)=>new(){Text=text,FontSize=size,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("TextBrush"),Margin=new Thickness(0,0,0,7)};
    private TextBlock P(string text)=>new(){Text=text,FontSize=14,Foreground=(Brush)FindResource("MutedBrush"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)};
    private Button B(string text,RoutedEventHandler click){var b=new Button{Content=text,Style=(Style)FindResource("PrimaryButton")};b.Click+=click;return b;}
    private StackPanel Stack(params UIElement[] e)
    {
        var panel=new StackPanel();
        foreach(var item in e) panel.Children.Add(item);
        return panel;
    }

    private UIElement Dashboard()
    {
        var root=new StackPanel();
        var count=_db.MyDevices().Count;
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var (cs,ce)=PaymentRules.PaymentCycleForDate(today);
        root.Children.Add(Card(Stack(
            H("Good day — DevMonitor is ready",28),
            P("A native Windows workspace built from the current Android application's operational model. Everything here runs locally unless you explicitly connect a future sync service."),
            new WrapPanel{Children={
                B("SMS CHECKER",(_,_)=>Render("Sms")),
                B("MY DEVICES",(_,_)=>Render("Devices")),
                B("LOAD REPORT",(_,_)=>Render("Report")),
                B("EARNING PROGRESS",(_,_)=>Render("Earnings")),
                B("TASKS",(_,_)=>Render("Tasks")),
                B("NOTES",(_,_)=>Render("Notes")),
                B("EXPORT",(_,_)=>Render("Exports")),
                B("LOADED REPORT",(_,_)=>Render("LoadedReport")),
                B("TRENDS",(_,_)=>Render("Trends")),
                B("ACTION CENTRE",(_,_)=>Render("ActionCentre")),
                B("PHONE EXCHANGE",(_,_)=>Render("Exchange"))
            }}
        ),(Brush)FindResource("AccentBrush")));
        root.Children.Add(new UniformGrid{Columns=4,Children={
            Metric("MY DEVICES",count.ToString()),
            Metric("PAYMENT CYCLE",$"{cs:dd MMM} → {ce:dd MMM}"),
            Metric("CURRENT MONTH",today.ToString("MMMM yyyy")),
            Metric("PREVIOUS MONTH",today.AddMonths(-1).ToString("MMMM yyyy")),
            Metric("OPEN TASKS",_db.Tasks(false).Count.ToString()),
            Metric("UNREAD ALERTS",_db.UnreadNotifications().ToString()),
            Metric("PHONE RESULTS",_db.PhoneResults().Count.ToString())
        }});
        root.Children.Add(Card(Stack(
            H("Current architecture"),
            P("HQ reports are authoritative monthly snapshots. Windows keeps only the current and immediately previous calendar-month stores, imports are Replace All for a month, and import does not silently recalculate downstream screens."),
            B("Open Settings",(_,_)=>Render("Settings"))
        ),Brushes.SteelBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private Border Metric(string title,string value)
    {
        var s=Stack(new TextBlock{Text=title,FontSize=11,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("MutedBrush")},
            new TextBlock{Text=value,FontSize=21,FontWeight=FontWeights.Bold,Margin=new Thickness(0,6,0,0)});
        return new Border{Child=s,Background=Brushes.White,Padding=new Thickness(18),Margin=new Thickness(0,0,12,14),CornerRadius=new CornerRadius(12),BorderBrush=(Brush)FindResource("BorderBrush"),BorderThickness=new Thickness(1)};
    }

    private UIElement DevicesPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        root.Children.Add(Card(Stack(H("Your working device set"),P("The Windows version keeps a separate, user-scoped working set. Updating this list never deletes authoritative HQ history."),
            B("Replace My Devices",(_,_)=>EditDevices())) ,Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=480,ItemsSource=ids.Select(x=>new{Device=x}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void EditDevices()
    {
        var w=new Window{Title="Update My Devices",Width=520,Height=430,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var box=new TextBox{AcceptsReturn=true,Text=string.Join(Environment.NewLine,_db.MyDevices()),VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(15)};
        var save=new Button{Content="Save device list",Margin=new Thickness(15),Padding=new Thickness(12)};
        save.Click+=(_,_)=>{_db.ReplaceMyDevices(box.Text.Split(new[]{"\r\n","\n"},StringSplitOptions.RemoveEmptyEntries));w.DialogResult=true;w.Close();Render("Devices");};
        w.Content=new DockPanel{Children={box,save}};DockPanel.SetDock(save,Dock.Bottom);w.ShowDialog();
    }

    private UIElement ReportPage()
    {
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("HQ / SIMReg report import"),P("Choose an Excel report. The first worksheet is parsed into a normalized device/day model. Only the current calendar month or immediately previous month may be stored."),
            B("Choose Excel Report",ImportReport)),Brushes.MediumPurple));
        if(_lastReport.Count>0) root.Children.Add(Card(Stack(
            H($"Loaded report: {_lastReport.Count:N0} devices"),
            P($"Coverage: {_reportStart:yyyy-MM-dd} → {_reportEnd:yyyy-MM-dd}. This is a validated in-memory view; use Store Month to commit it to the local authoritative monthly snapshot."),
            B("Store Month Snapshot",StoreReport)),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void ImportReport(object? s,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="Excel reports|*.xlsx;*.xlsm|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            StatusText.Text="Reading report…";
            _lastReport=ReportImporter.Read(dlg.FileName,out _reportStart,out _reportEnd);
            _db.SetSetting("last_report_file",dlg.FileName);
            StatusText.Text=$"Loaded {_lastReport.Count:N0} devices";
            Render("Report");
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"DevMonitor",MessageBoxButton.OK,MessageBoxImage.Error);StatusText.Text="Import failed";}
    }
    private void StoreReport(object? s,RoutedEventArgs e)
    {
        var month=new DateTime(_reportStart.Year,_reportStart.Month,1);
        var current=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=current.AddMonths(-1);
        if(month!=current && month!=previous){MessageBox.Show(this,"Only the current and immediately previous calendar month can be stored.","DevMonitor");return;}
        var old=_db.StoredCoverageEnd(month);
        if(old.HasValue && _reportEnd<old.Value){MessageBox.Show(this,$"Older report rejected. Stored coverage ends {old:yyyy-MM-dd}.","DevMonitor");return;}
        var source=_db.GetSetting("last_report_file")??"Imported report";
        _db.ReplaceMonthSnapshot(month,_reportStart,_reportEnd,source,_lastReport);
        _db.AddNotification("Report imported",$"{month:MMMM yyyy} snapshot stored through {_reportEnd:dd MMM yyyy}.","success");
        MessageBox.Show(this,"Monthly snapshot stored. Downstream calculations were not automatically refreshed.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
        Render("Report");
    }

    private UIElement EarningsPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var total=snapshots.Sum(x=>x.Active);
        var sundays=0;
        var estimate=PaymentRules.Estimate(total,sundays);
        root.Children.Add(Card(Stack(H("Earning Progress"),P($"Payment cycle: {PaymentRules.PaymentCycleLabel(DateTime.Today)}"),
            new TextBlock{Text=total.ToString("N0"),FontSize=44,FontWeight=FontWeights.Bold},
            P("Current cycle activations — Active remains the payment/progression input."),
            new TextBlock{Text=$"Estimated subtotal: ₦{estimate.Subtotal:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            P($"Fixed tier: ₦{estimate.FixedReward:N0} • Recharge estimate: ₦{estimate.RechargeBonus:N0} • Sunday bonus: ₦{estimate.SundayBonus:N0}"),
            P(estimate.NextThreshold.HasValue?$"{estimate.ActivationsToNext:N0} activations to the next tier ({estimate.NextThreshold:N0}).":"Highest configured tier reached.")
        ),Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=430,ItemsSource=snapshots.Select(x=>new{Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Status=x.Flag??"OK"}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonitorPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        root.Children.Add(Card(Stack(
            H("Device Monitor"),
            P("Current device activity from the authoritative monthly HQ snapshots. Payment calculations continue to use Active, not MTD."),
            new TextBlock{Text=$"Devices: {snapshots.Count:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            B("Refresh Device Monitor",(_,_)=>Render("Monitor"))
        ),Brushes.SteelBlue));
        root.Children.Add(new DataGrid{ItemsSource=snapshots.Select(x=>new{
            Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Ownership=x.Ownership,Status=x.Flag??"OK"
        }).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=480});
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonthOnMonthPage()
    {
        var root=new StackPanel();
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var currentMonth=new DateTime(today.Year,today.Month,1);
        var previousMonth=currentMonth.AddMonths(-1);
        var currentRows=_db.LoadMonth(currentMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var previousRows=_db.LoadMonth(previousMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var ids=_db.MyDevices().Select(DevMonitorDb.Canonical).ToList();
        var currentEnd=_db.StoredCoverageEnd(currentMonth);
        var previousEnd=_db.StoredCoverageEnd(previousMonth);
        var currentCutoff=Math.Min(today.Day,currentEnd?.Day??0);
        var previousCutoff=Math.Min(currentCutoff,previousEnd?.Day??0);
        var data=new List<(string Device,int Current,int Previous,int Change)>();
        foreach(var id in ids){
            currentRows.TryGetValue(id,out var c); previousRows.TryGetValue(id,out var p);
            var cur=c?.Daily.Where(k=>k.Key.Month==today.Month&&k.Key.Year==today.Year&&k.Key.Day<=currentCutoff).Sum(k=>k.Value)??0;
            var prev=p?.Daily.Where(k=>k.Key.Month==previousMonth.Month&&k.Key.Year==previousMonth.Year&&k.Key.Day<=previousCutoff).Sum(k=>k.Value)??0;
            data.Add((id,cur,prev,cur-prev));
        }
        var grid=new DataGrid{ItemsSource=data.Select(x=>new{Device=x.Device,Current=x.Current,Previous=x.Previous,Change=x.Change,Trend=x.Change>0?"Up":x.Change<0?"Down":"Flat"}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=480};
        root.Children.Add(Card(Stack(
            H("Month-on-Month"),
            P($"User-scoped comparison through the available report cutoff. Current cutoff: day {currentCutoff}; previous-month cutoff: day {previousCutoff}. Missing historical coverage is not treated as zero. Rows: {data.Count:N0}."),
            new TextBlock{Text=$"Current: {currentMonth:MMMM yyyy}  •  Previous: {previousMonth:MMMM yyyy}",FontSize=18,FontWeight=FontWeights.Bold},
            new WrapPanel{Children={
                B("Refresh comparison",(_,_)=>Render("MonthOnMonth")),
                B("Export comparison CSV",(_,_)=>{
                    var lines=data.Select(x=>$"{Csv(x.Device)},{x.Current},{x.Previous},{x.Change},{(x.Change>0?"Up":x.Change<0?"Down":"Flat")}");
                    SaveCsv($"DevMonitor_MonthOnMonth_{currentMonth:yyyy_MM}.csv","Device,CurrentMonth,PreviousMonth,Change,Trend",lines);
                })
            }}
        ),Brushes.MediumPurple));
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement SmsPage()
    {
        var root=new StackPanel();
        var code=new TextBox{Height=38,Width=220};
        var status=new ComboBox{ItemsSource=new[]{"OK","ERROR","PENDING","ZERO_DEVICES"},SelectedIndex=0,Height=38,Width=150,Margin=new Thickness(8,0,8,0),ToolTip="Use ZERO_DEVICES only when the phone workflow explicitly reports no assigned devices."};
        var today=new TextBox{Height=38,Width=90}; var mtd=new TextBox{Height=38,Width=90}; var active=new TextBox{Height=38,Width=90};
        var b48=new TextBox{Height=38,Width=90}; var b96=new TextBox{Height=38,Width=90};
        root.Children.Add(Card(Stack(
            H("SMS Checker"),
            P("Windows cannot directly receive an Android SIM's SMS. It can, however, store and use results delivered from the phone app or pasted/imported locally. No SMS is sent from Windows."),
            new WrapPanel{Children={
                new TextBlock{Text="Device",VerticalAlignment=VerticalAlignment.Center},code,
                new TextBlock{Text="Status",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(12,0,0,0)},status
            }},
            new WrapPanel{Children={
                new TextBlock{Text="Today",VerticalAlignment=VerticalAlignment.Center},today,
                new TextBlock{Text="MTD",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},mtd,
                new TextBlock{Text="Active",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},active,
                new TextBlock{Text="48h",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},b48,
                new TextBlock{Text="96h",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},b96
            }},
            B("Store phone result",(_,_)=>{
                if(string.IsNullOrWhiteSpace(code.Text)){MessageBox.Show(this,"Enter a device code.");return;}
                int? Num(string x)=>int.TryParse(x,out var n)?n:null;
                _db.SavePhoneResult(new PhoneQueryResult(DevMonitorDb.Canonical(code.Text),status.SelectedItem?.ToString()??"OK",Num(today.Text),Num(mtd.Text),Num(active.Text),Num(b48.Text),Num(b96.Text),DateTime.UtcNow,"Manual/local phone result"));
                _db.AddNotification("Phone result stored",$"Result stored for {DevMonitorDb.Canonical(code.Text)}.","sms");
                Render("Sms");
            })
        ),Brushes.SteelBlue));

        var phone=_db.PhoneResults();
        var phoneSearch=new TextBox{Width=280,Height=38,Margin=new Thickness(0,0,8,8),ToolTip="Search device code or status"};
        var phoneGrid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=420};
        var phoneCount=new TextBlock{Text=$"Stored phone results: {phone.Count:N0}",FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,8)};
        void LoadPhoneResults(){
            var q=phoneSearch.Text.Trim();
            var filtered=_db.PhoneResults().Where(x=>string.IsNullOrWhiteSpace(q)||x.DeviceId.Contains(DevMonitorDb.Canonical(q),StringComparison.OrdinalIgnoreCase)||x.Status.Contains(q,StringComparison.OrdinalIgnoreCase)).Take(500).ToList();
            phoneGrid.ItemsSource=filtered.Select(x=>new{Device=x.DeviceId,Status=x.Status,Today=x.Today,MTD=x.Mtd,Active=x.Active,Bar48=x.Bar48,Bar96=x.Bar96,Received=x.ResultAt.ToLocalTime().ToString("dd MMM yyyy HH:mm")}).ToList();
            phoneCount.Text=$"Matching phone results: {filtered.Count:N0}";
        }
        phoneSearch.TextChanged+=(_,_)=>LoadPhoneResults();
        root.Children.Add(Card(Stack(
            H("Phone results & search",18),
            P("Search by device code or status, including explicit ZERO_DEVICES results. These records remain local/offline; Device Monitor prefers a phone result only when newer than the stored HQ report."),
            new WrapPanel{Children={phoneSearch,B("Clear search",(_,_)=>phoneSearch.Clear())}},phoneCount,phoneGrid
        ),Brushes.SteelBlue));
        LoadPhoneResults();

        var sms=_db.Sms();
        root.Children.Add(Card(Stack(
            H($"Raw SMS history ({sms.Count:N0})",18),
            P("Raw SMS records are retained for audit/review. They are not required for Windows calculations once a structured phone result has been stored."),
            new DataGrid{ItemsSource=sms.Select(x=>new{Received=x.Received.ToString("yyyy-MM-dd HH:mm"),Sender=x.Sender,Body=x.Body}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=300}
        )));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement AgentsPage()
    {
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(month);
        var groups=rows.GroupBy(r=>string.IsNullOrWhiteSpace(r.PartnerName)?"Unassigned":r.PartnerName).Select(g=>new{Partner=g.Key,Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Region=string.Join(", ",g.Select(x=>x.Region).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Take(3)),Activations=g.Sum(x=>x.Daily.Where(d=>d.Key.Month==month.Month&&d.Key.Year==month.Year).Sum(d=>d.Value))}).OrderByDescending(x=>x.Activations).ToList();
        var root=new StackPanel();root.Children.Add(Card(Stack(H("Agents & Partners"),P("A working management view derived from the authoritative HQ report. Partner/device counts and current-month activity update whenever the report snapshot is refreshed."),H($"{groups.Count} partner groups",17),new WrapPanel{Children={B("Open My Devices",(_,_)=>Render("Devices")),B("Open Device Monitor",(_,_)=>Render("Monitor")),B("Create follow-up",(_,_)=>Render("Tasks"))}}),Brushes.CadetBlue));
        root.Children.Add(Card(new DataGrid{ItemsSource=groups,IsReadOnly=true,AutoGenerateColumns=true,Height=430},Brushes.CadetBlue));
        var androidAgents=_db.AndroidRecords("agents").Select(ReadAndroidPayload).ToList();
        var androidPhones=_db.AndroidRecords("agent_phones").Select(ReadAndroidPayload).ToList();
        var androidDevices=_db.AndroidRecords("agent_devices").Select(ReadAndroidPayload).ToList();
        if(androidAgents.Count>0){
            string Field(JsonElement e,string key)=>e.TryGetProperty(key,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():"";
            var linked=androidAgents.Select(a=>{var id=Field(a,"id");return new{Agent=Field(a,"name"),Address=Field(a,"address"),Phones=string.Join(", ",androidPhones.Where(p=>Field(p,"agent_id")==id).Select(p=>Field(p,"phone")+(string.IsNullOrWhiteSpace(Field(p,"label"))?"":" ("+Field(p,"label")+")"))),Devices=string.Join(", ",androidDevices.Where(d=>Field(d,"agent_id")==id).Select(d=>Field(d,"code")))};}).ToList();
            root.Children.Add(Card(Stack(H("Android agent directory & assignments",18),P("Agent contacts and device assignments received from the phone are shown alongside the HQ-derived company hierarchy. Use Manage Android records to create, edit or delete agents, phone contacts and device assignments locally; changes travel on the next explicit sync."),new DataGrid{ItemsSource=linked,IsReadOnly=true,AutoGenerateColumns=true,Height=300},B("Manage agents, phones & assignments",(_,_)=>Render("AndroidData"))),Brushes.SteelBlue));
        }
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private static JsonElement ReadAndroidPayload(AndroidRecord record){using var doc=JsonDocument.Parse(record.PayloadJson);return doc.RootElement.Clone();}

    private UIElement TasksPage()
    {
        var root=new StackPanel(); var tasks=_db.Tasks();
        root.Children.Add(Card(Stack(H("Tasks & Follow-ups"),P("Create persistent operational follow-ups and optionally link them to a device, partner or staff member."),
            B("Add Task",(_,_)=>TaskEditor(null))),Brushes.MediumSeaGreen));
        var taskGrid=new DataGrid{ItemsSource=tasks,IsReadOnly=true,AutoGenerateColumns=true,Height=390,SelectionMode=DataGridSelectionMode.Single};
        root.Children.Add(Card(Stack(H($"Open: {tasks.Count(x=>!x.Completed)}  •  Completed: {tasks.Count(x=>x.Completed)}",17),taskGrid,
            new WrapPanel{Children={
                B("Edit selected",(_,_)=>{if(taskGrid.SelectedItem is OperationalTask selected)TaskEditor(selected);else MessageBox.Show(this,"Select a task first.");}),
                B("Toggle complete",(_,_)=>{if(taskGrid.SelectedItem is OperationalTask selected){_db.SetTaskCompleted(selected.Id,!selected.Completed);_db.AddNotification(selected.Completed?"Task reopened":"Task completed",selected.Title,"task");Render("Tasks");}else MessageBox.Show(this,"Select a task first.");}),
                B("Delete selected",(_,_)=>{if(taskGrid.SelectedItem is OperationalTask selected&&MessageBox.Show(this,$"Delete task '{selected.Title}'?","Confirm delete",MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes){_db.DeleteTask(selected.Id);Render("Tasks");}else if(taskGrid.SelectedItem is not OperationalTask)MessageBox.Show(this,"Select a task first.");})
            }}),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void TaskEditor(OperationalTask? existing)
    {
        var w=new Window{Title=existing==null?"New Follow-up":"Edit Follow-up",Width=560,Height=520,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var title=new TextBox{Text=existing?.Title??""}; var details=new TextBox{Text=existing?.Details??"",AcceptsReturn=true,Height=100,TextWrapping=TextWrapping.Wrap};
        var due=new TextBox{Text=existing?.DueDate??"",ToolTip="Optional: YYYY-MM-DD"}; var priority=new ComboBox{ItemsSource=new[]{"LOW","NORMAL","HIGH"},SelectedItem=existing?.Priority??"NORMAL",Margin=new Thickness(0,5,0,9),Height=40};
        var link=new TextBox{Text=existing?.LinkValue??"",ToolTip="Optional device / partner / staff reference"};
        var save=B("Save Task",(_,_)=>{if(string.IsNullOrWhiteSpace(title.Text)){MessageBox.Show(w,"Task title is required.");return;} if(!string.IsNullOrWhiteSpace(due.Text)&&!DateTime.TryParse(due.Text,out _)){MessageBox.Show(w,"Use a valid date such as 2026-10-31.");return;} _db.SaveTask(new OperationalTask(existing?.Id??0,title.Text,details.Text,string.IsNullOrWhiteSpace(due.Text)?null:due.Text,(priority.SelectedItem?.ToString()??"NORMAL"),string.IsNullOrWhiteSpace(link.Text)?null:"REFERENCE",string.IsNullOrWhiteSpace(link.Text)?null:link.Text,existing?.Completed??false,existing?.CreatedAt??DateTime.UtcNow,DateTime.UtcNow));_db.AddNotification("Task saved",title.Text,"task");w.DialogResult=true;w.Close();Render("Tasks");});
        var close=B("Cancel",(_,_)=>w.Close()); var panel=Stack(H(existing==null?"New follow-up":"Edit follow-up",22),new TextBlock{Text="Task title"},title,new TextBlock{Text="Details"},details,new TextBlock{Text="Due date"},due,new TextBlock{Text="Priority"},priority,new TextBlock{Text="Linked reference (optional)"},link,new WrapPanel{Children={save,close}});w.Content=new ScrollViewer{Content=panel};w.ShowDialog();
    }

    private UIElement NotesPage()
    {
        var notes=_db.Notes(); var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Notes"),P("Keep durable operational notes alongside your device and report work. Pin important notes so they stay at the top."),B("Add Note",(_,_)=>NoteEditor(null))),Brushes.MediumPurple));
        root.Children.Add(Card(Stack(H($"{notes.Count} saved notes",17),new DataGrid{ItemsSource=notes.Select(n=>new{Id=n.Id,Title=n.Title,Preview=n.Body.Length>100?n.Body[..100]+"…":n.Body,Pinned=n.Pinned?"Pinned":"",Updated=n.UpdatedAt.ToLocalTime().ToString("dd MMM HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=420}),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void NoteEditor(OperationalNote? existing)
    {
        var w=new Window{Title=existing==null?"New Note":"Edit Note",Width=620,Height=500,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var title=new TextBox{Text=existing?.Title??""};var body=new TextBox{Text=existing?.Body??"",AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,Height=220};var pinned=new CheckBox{Content="Pin this note",IsChecked=existing?.Pinned??false,Margin=new Thickness(0,8,0,12)};
        var save=B("Save Note",(_,_)=>{if(string.IsNullOrWhiteSpace(body.Text)){MessageBox.Show(w,"Note body is required.");return;}_db.SaveNote(new OperationalNote(existing?.Id??0,title.Text,body.Text,null,null,pinned.IsChecked==true,existing?.CreatedAt??DateTime.UtcNow,DateTime.UtcNow));w.DialogResult=true;w.Close();Render("Notes");});
        var cancel=B("Cancel",(_,_)=>w.Close());w.Content=Stack(H(existing==null?"New note":"Edit note",22),new TextBlock{Text="Title (optional)"},title,new TextBlock{Text="Note"},body,pinned,new WrapPanel{Children={save,cancel}});w.ShowDialog();
    }

    private UIElement ActivityPage()
    {
        var ids=_db.MyDevices();var selected=ids.FirstOrDefault()??"";var root=new StackPanel();
        var combo=new ComboBox{ItemsSource=ids,SelectedItem=selected,MinWidth=260,Height=40,Margin=new Thickness(0,5,8,9)};
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=500};
        void Load(){var id=combo.SelectedItem?.ToString()??"";var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(month).FirstOrDefault(x=>DevMonitorDb.Canonical(x.DeviceId)==DevMonitorDb.Canonical(id));var events=new List<object>();if(rows!=null)foreach(var d in rows.Daily.OrderByDescending(x=>x.Key))events.Add(new{Date=d.Key.ToString("dd MMM yyyy"),Type="OBSERVATION",Event="SIMReg",Details=$"Value {d.Value:N0}"});foreach(var t in _db.Tasks().Where(t=>string.Equals(t.LinkValue,id,StringComparison.OrdinalIgnoreCase)))events.Add(new{Date=t.UpdatedAt.ToLocalTime().ToString("dd MMM yyyy"),Type="TASK",Event=t.Completed?"Task completed":"Task updated",Details=t.Title});foreach(var n in _db.Notes().Where(n=>string.Equals(n.LinkValue,id,StringComparison.OrdinalIgnoreCase)))events.Add(new{Date=n.UpdatedAt.ToLocalTime().ToString("dd MMM yyyy"),Type="NOTE",Event="Note updated",Details=n.Title});grid.ItemsSource=events.OrderByDescending(x=>x.GetType().GetProperty("Date")?.GetValue(x)?.ToString()).ToList();}
        combo.SelectionChanged+=(_,_)=>Load();
        root.Children.Add(Card(Stack(H("Device Activity Timeline"),P("A chronological view combining imported HQ observations with linked operational work."),new WrapPanel{Children={new TextBlock{Text="Device",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,8,0)},combo,B("Refresh timeline",(_,_)=>Load())}}),Brushes.SteelBlue));root.Children.Add(Card(grid,Brushes.SteelBlue));Load();return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement InboxPage()
    {
        var notes=_db.Notifications();var grid=new DataGrid{ItemsSource=notes,IsReadOnly=true,AutoGenerateColumns=true,Height=520,SelectionMode=DataGridSelectionMode.Single};var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Notifications / Inbox"),P("Local operational alerts plus Android profile notifications imported during sync. Android notification read state is reconciled by source ID; HQ snapshots and payment data are not involved."),new WrapPanel{Children={B("Mark all read",(_,_)=>{_db.MarkAllNotificationsRead();foreach(var r in _db.AndroidRecords("notifications")){try{using var doc=JsonDocument.Parse(r.PayloadJson);var node=System.Text.Json.Nodes.JsonNode.Parse(r.PayloadJson) as System.Text.Json.Nodes.JsonObject;if(node!=null){node["read"]=true;_db.MergeAndroidRecord(r.Type,r.Key,node.ToJsonString());}}catch{}}Render("Inbox");}),B("Refresh",(_,_)=>Render("Inbox")),B("Open Android notification records",(_,_)=>Render("AndroidData"))}}),Brushes.Orange));
        root.Children.Add(Card(grid,Brushes.Orange));return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ExportsPage()
    {
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=Card(Stack(H("Export Centre"),P("Create user-controlled CSV files from the current local data. Export never changes calculations or the database."),
            B("Export My Devices",(_,_)=>ExportMyDevices()),B("Export Device Monitor",(_,_)=>ExportMonitor()),B("Export Current Month",(_,_)=>ExportMonth()),B("Export Partner Summary",(_,_)=>ExportPartners()),B("Export Tasks & Notes",(_,_)=>ExportOperations())),Brushes.DarkCyan)};
    }
    private void SaveCsv(string suggested,string header,IEnumerable<string> lines){var dlg=new SaveFileDialog{Filter="CSV files|*.csv",FileName=suggested};if(dlg.ShowDialog()!=true)return;System.IO.File.WriteAllText(dlg.FileName,header+Environment.NewLine+string.Join(Environment.NewLine,lines));StatusText.Text=$"Exported {System.IO.Path.GetFileName(dlg.FileName)}";}
    private static string Csv(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
    private void ExportMyDevices()=>SaveCsv("DevMonitor_MyDevices.csv","Device",_db.MyDevices().Select(Csv));
    private void ExportMonitor()=>SaveCsv("DevMonitor_DeviceMonitor.csv","Device,Today,MTD,Active,Status",_db.DeviceSnapshots(_db.MyDevices(),DateTime.Today).Select(x=>$"{Csv(x.DeviceId)},{x.Today},{x.Mtd},{x.Active},{Csv(x.Flag??"OK")}"));
    private void ExportMonth(){var m=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(m);SaveCsv($"DevMonitor_{m:yyyy_MM}.csv","Device,Date,Value,Partner,Region,Cluster,Staff",rows.SelectMany(r=>r.Daily.Select(d=>$"{Csv(r.DeviceId)},{d.Key:yyyy-MM-dd},{d.Value},{Csv(r.PartnerName)},{Csv(r.Region)},{Csv(r.Cluster)},{Csv(r.StaffName)}")));}
    private void ExportOperations(){SaveCsv("DevMonitor_Operations.csv","Type,Title,Details,DueOrUpdated,Status",_db.Tasks().Select(t=>$"TASK,{Csv(t.Title)},{Csv(t.Details)},{Csv(t.DueDate??t.UpdatedAt.ToString("yyyy-MM-dd"))},{t.Completed}").Concat(_db.Notes().Select(n=>$"NOTE,{Csv(n.Title)},{Csv(n.Body)},{n.UpdatedAt:yyyy-MM-dd},")));}
    private void ExportPartners(){
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var rows=_db.LoadMonth(month).GroupBy(r=>string.IsNullOrWhiteSpace(r.PartnerName)?"Unassigned":r.PartnerName)
            .Select(g=>new{Partner=g.Key,Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Activations=g.Sum(x=>x.Daily.Where(d=>d.Key.Year==month.Year&&d.Key.Month==month.Month).Sum(d=>d.Value)),Regions=string.Join("; ",g.Select(x=>x.Region).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct())})
            .OrderByDescending(x=>x.Activations).ToList();
        SaveCsv($"DevMonitor_PartnerSummary_{month:yyyy_MM}.csv","Partner,Devices,CurrentMonthActivations,Regions",rows.Select(x=>$"{Csv(x.Partner)},{x.Devices},{x.Activations},{Csv(x.Regions)}"));
    }


    private UIElement LoadedReportPage()
    {
        var root=new StackPanel();
        var reports=_db.Reports();
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=month.AddMonths(-1);
        var selected=reports.FirstOrDefault()?.Month ?? month;
        var combo=new ComboBox{ItemsSource=reports.Select(r=>$"{r.Month:MMMM yyyy} • {r.CoverageStart:dd MMM}–{r.CoverageEnd:dd MMM} • {r.DeviceCount:N0} devices").ToList(),SelectedIndex=0,MinWidth=420,Height=38};
        var search=new TextBox{Width=300,Height=38,Margin=new Thickness(8,0,8,0),ToolTip="Device, partner, region, staff or trade code"};
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=520};
        void Load()
        {
            var info=reports.ElementAtOrDefault(combo.SelectedIndex);
            if(info==null){grid.ItemsSource=null;return;}
            var rows=_db.SearchReport(info.Month,search.Text);
            grid.ItemsSource=rows.Select(r=>new {
                Device=r.DeviceId,TradeCode=r.TradeCode,Partner=r.PartnerName,Cluster=r.Cluster,
                Region=r.Region,Territory=r.Territory,Staff=r.StaffName,
                Days=r.Daily.Count,Total=r.Daily.Values.Sum()
            }).ToList();
            StatusText.Text=$"{rows.Count:N0} report rows";
        }
        search.KeyDown+=(o,e)=>{if(e.Key==System.Windows.Input.Key.Enter)Load();};
        combo.SelectionChanged+=(o,e)=>Load();
        root.Children.Add(Card(Stack(
            H("Loaded Report"),
            P("The complete imported monthly snapshot remains available offline. Search is local and does not require the internet. The report itself remains authoritative; presentation filtering never deletes data."),
            new WrapPanel{Children={
                new TextBlock{Text="Report",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,8,0)},
                combo,search,B("Search",(_,_)=>Load()),
                B("Show All",(_,_)=>{search.Clear();Load();})
            }},
            H("Available snapshots",17)
        ),Brushes.MediumPurple));
        root.Children.Add(Card(grid,Brushes.MediumPurple));
        Load();
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement TrendsPage()
    {
        var root=new StackPanel();
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var cm=new DateTime(today.Year,today.Month,1);
        var pm=cm.AddMonths(-1);
        var current=_db.DailyTrend(cm,_db.MyDevices());
        var previous=_db.DailyTrend(pm,_db.MyDevices());
        var curTotal=current.Sum(x=>x.Value); var prevTotal=previous.Sum(x=>x.Value);
        var delta=curTotal-prevTotal;
        var pct=prevTotal==0?null:(double?)delta/prevTotal*100.0;
        var partner=_db.PartnerTotals(cm).Take(12).Select(x=>new{Partner=x.Key,Activations=x.Value}).ToList();
        root.Children.Add(new UniformGrid{Columns=4,Children={
            Metric("CURRENT MTD",curTotal.ToString("N0")),
            Metric("PREVIOUS PERIOD",prevTotal.ToString("N0")),
            Metric("CHANGE",delta>=0?$"+{delta:N0}":delta.ToString("N0")),
            Metric("CHANGE %",pct.HasValue?$"{pct:+0.0;-0.0;0.0}%":"—")
        }});
        root.Children.Add(Card(Stack(
            H("7-day / 30-day operating trend"),
            P("Report-aware trends are calculated from the locally stored HQ snapshots. Missing future report days are never interpreted as zero."),
            new DataGrid{ItemsSource=current.Select(x=>new{Date=x.Date.ToString("dd MMM"),Activations=x.Value}).TakeLast(30).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=300}
        ),Brushes.SteelBlue));
        root.Children.Add(Card(Stack(H("Partner performance",18),new DataGrid{ItemsSource=partner,IsReadOnly=true,AutoGenerateColumns=true,Height=300}),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ActionCentrePage()
    {
        var open=_db.Tasks(false);
        var unread=_db.Notifications().Where(x=>!x.Read).ToList();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var flagged=snapshots.Where(x=>!string.IsNullOrWhiteSpace(x.Flag)).ToList();
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Action Centre"),P("Prioritized offline actions from tasks, alerts and device/report exceptions."),
            new UniformGrid{Columns=3,Children={Metric("OPEN TASKS",open.Count.ToString()),Metric("UNREAD ALERTS",unread.Count.ToString()),Metric("FLAGGED DEVICES",flagged.Count.ToString())}}
        ),Brushes.Orange));
        if(open.Count>0) root.Children.Add(Card(Stack(H("Tasks requiring attention",18),new DataGrid{ItemsSource=open.Take(20).Select(t=>new{Task=t.Title,Priority=t.Priority,Due=t.DueDate??"—",Reference=t.LinkValue??"—"}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Tasks",(_,_)=>Render("Tasks"))),Brushes.MediumSeaGreen));
        if(unread.Count>0) root.Children.Add(Card(Stack(H("Unread notifications",18),new DataGrid{ItemsSource=unread.Take(20).Select(n=>new{When=n.Timestamp.ToLocalTime().ToString("dd MMM HH:mm"),Title=n.Title,Message=n.Message,Type=n.Kind}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Inbox",(_,_)=>Render("Inbox"))),Brushes.Orange));
        if(flagged.Count>0) root.Children.Add(Card(Stack(H("Device exceptions",18),new DataGrid{ItemsSource=flagged.Select(x=>new{Device=x.DeviceId,Status=x.Flag,Active=x.Active,MTD=x.Mtd}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Device Monitor",(_,_)=>Render("Monitor"))),Brushes.IndianRed));
        if(open.Count==0&&unread.Count==0&&flagged.Count==0) root.Children.Add(Card(Stack(H("All clear",22),P("There are no outstanding local actions or exceptions.")),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ProfilePage()
    {
        var profile=new LocalProfile(
            _db.GetSetting("profile_name")??"Windows User",
            _db.GetSetting("profile_role")??"AGENT",
            _db.GetSetting("profile_partner")??"",
            _db.GetSetting("profile_region")??"",
            _db.GetSetting("profile_territory")??"",
            _db.GetSetting("profile_staff")??"");
        var name=new TextBox{Text=profile.Name};var role=new ComboBox{ItemsSource=new[]{"AGENT","PARTNER","STAFF"},SelectedItem=profile.Role,Height=38};
        var partner=new TextBox{Text=profile.Partner};var region=new TextBox{Text=profile.Region};var territory=new TextBox{Text=profile.Territory};var staff=new TextBox{Text=profile.Staff};
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Profile & Company"),P("The Windows edition keeps its own local profile and derives management views from the imported HQ report. Profile settings work offline."),
            new TextBlock{Text="Name"},name,new TextBlock{Text="Role"},role,new TextBlock{Text="Partner / company"},partner,new TextBlock{Text="Region"},region,new TextBlock{Text="Territory"},territory,new TextBlock{Text="Staff / manager"},staff,
            B("Save profile",(_,_)=>{_db.SetSetting("profile_name",name.Text.Trim());_db.SetSetting("profile_role",role.SelectedItem?.ToString()??"AGENT");_db.SetSetting("profile_partner",partner.Text.Trim());_db.SetSetting("profile_region",region.Text.Trim());_db.SetSetting("profile_territory",territory.Text.Trim());_db.SetSetting("profile_staff",staff.Text.Trim());_db.AddNotification("Profile updated","Local profile changes saved.","profile");StatusText.Text="Profile saved";})
        ),Brushes.CadetBlue));
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var rows=_db.LoadMonth(month);
        var hierarchy=rows.GroupBy(x=>string.IsNullOrWhiteSpace(x.Region)?"Unassigned region":x.Region).Select(g=>new{
            Region=g.Key,Partners=g.Select(x=>x.PartnerName).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Clusters=g.Select(x=>x.Cluster).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Staff=g.Select(x=>x.StaffName).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Activations=g.Sum(x=>x.Daily.Values.Sum())
        }).OrderByDescending(x=>x.Activations).ToList();
        root.Children.Add(Card(Stack(H("Company skeleton",18),P("Region → partner → cluster → staff/device relationships are reconstructed locally from the loaded HQ snapshot."),
            new DataGrid{ItemsSource=hierarchy,IsReadOnly=true,AutoGenerateColumns=true,Height=350}
        ),Brushes.CadetBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ExchangePage()
    {
        var results=_db.PhoneResults();
        var root=new StackPanel();
        root.Children.Add(Card(Stack(
            H("Phone Data Exchange"),
            P("Pair Android and Windows on the same Wi-Fi, or use a trusted HTTPS reverse-proxy endpoint for remote sync. Sync payloads are AES-GCM encrypted with the pairing key even on local HTTP. HQ monthly snapshots and payment data are deliberately excluded from sync merges."),
            B("Start local sync bridge",StartSyncBridge),
            B("Stop local sync bridge",StopSyncBridge),
            B("Sync with HTTPS cloud relay",SyncWithCloud),
            P($"Local bridge: {(_syncBridge?.IsRunning==true ? "RUNNING" : "STOPPED")} • Port 43827 • LAN IPs: {SyncBridgeServer.GetLanAddresses()}"),
            B("Import .dmdata fallback",ImportExchange),
            B("Export .dmdata fallback",ExportExchange),
            H($"Stored phone results: {results.Count:N0}",18),
            P(results.Count==0?"No phone query results have been imported yet.":"The latest phone results are retained locally and can be used while offline.")
        ),Brushes.DarkCyan));
        if(results.Count>0) root.Children.Add(Card(new DataGrid{ItemsSource=results.Take(100).Select(x=>new{Device=x.DeviceId,Status=x.Status,Today=x.Today,MTD=x.Mtd,Active=x.Active,At=x.ResultAt.ToLocalTime().ToString("dd MMM yyyy HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=400},Brushes.DarkCyan));
        var counts=_db.AndroidRecordCounts();
        root.Children.Add(Card(Stack(H("Android query & relationship archive",18),P("Imported from Android sync: saved query lists, archived/current query codes, query result records and history, daily observations, SMS attempt/recovery metadata, agents, phone contacts and device-to-agent relationships. These are retained locally for offline review/export; they never overwrite authoritative HQ snapshots or payment records."),
            H($"Archived Android records: {_db.AndroidRecords().Count:N0}",16),
            new DataGrid{ItemsSource=counts.Select(x=>new{RecordFamily=x.Key,Records=x.Value}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=210},
            B("Export Android archive JSON",ExportAndroidArchive),B("Export Android archive index CSV",ExportAndroidArchiveIndex)
        ),Brushes.SteelBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private void StartSyncBridge(object? sender,RoutedEventArgs e){
        try{
            var token=_db.GetSetting("sync_pairing_key");
            if(string.IsNullOrWhiteSpace(token)){token=Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(24)).TrimEnd('=');_db.SetSetting("sync_pairing_key",token);}
            _syncBridge?.Dispose();_syncBridge=new SyncBridgeServer(token,MergeSyncPackage);_syncBridge.Start();
            MessageBox.Show(this,$"Local bridge is running on port 43827.\n\nPairing key (enter on Android):\n{token}\n\nLAN addresses: {SyncBridgeServer.GetLanAddresses()}\n\nUse http://LAN-IP:43827/sync. Payloads are encrypted; keep the key private.","DevMonitor Sync Bridge",MessageBoxButton.OK,MessageBoxImage.Information);
            StatusText.Text="Local sync bridge running";Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,"Could not start the local bridge. If Windows reports URL access denied, run the URL reservation command in the bridge README as administrator.\n\n"+ex.Message,"Sync Bridge",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private void StopSyncBridge(object? sender,RoutedEventArgs e){_syncBridge?.Stop();_syncBridge?.Dispose();_syncBridge=null;StatusText.Text="Local sync bridge stopped";Render("Exchange");}
    private async void SyncWithCloud(object? sender,RoutedEventArgs e){
        var endpoint=Microsoft.VisualBasic.Interaction.InputBox("HTTPS relay base URL (for example https://sync.example.com)","DevMonitor Cloud Sync",_db.GetSetting("sync_cloud_endpoint")??"").Trim();
        if(string.IsNullOrWhiteSpace(endpoint))return;
        if(!endpoint.StartsWith("https://",StringComparison.OrdinalIgnoreCase)){MessageBox.Show(this,"Cloud sync requires HTTPS with a valid certificate.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Warning);return;}
        var token=_db.GetSetting("sync_pairing_key");
        if(string.IsNullOrWhiteSpace(token)){token=Microsoft.VisualBasic.Interaction.InputBox("Create or enter the same pairing key used on Android (at least 16 characters).","DevMonitor Cloud Sync","");if(string.IsNullOrWhiteSpace(token))return;_db.SetSetting("sync_pairing_key",token);}
        try{
            _db.SetSetting("sync_cloud_endpoint",endpoint);
            var json=JsonSerializer.Serialize(BuildSyncDto(),new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
            var bytes=System.Text.Encoding.UTF8.GetBytes(json);var nonce=System.Security.Cryptography.RandomNumberGenerator.GetBytes(12);var key=System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(token));var cipher=new byte[bytes.Length+16];
            using(var aes=new System.Security.Cryptography.AesGcm(key,16))aes.Encrypt(nonce,bytes,cipher.AsSpan(0,bytes.Length),cipher.AsSpan(bytes.Length,16));
            var body=JsonSerializer.Serialize(new{payload=Convert.ToBase64String(nonce.Concat(cipher).ToArray())});
            using var client=new HttpClient{Timeout=TimeSpan.FromSeconds(25)};using var req=new HttpRequestMessage(HttpMethod.Post,endpoint.TrimEnd('/')+"/sync");req.Headers.Add("X-DevMonitor-Pairing-Key",token);req.Content=new StringContent(body,System.Text.Encoding.UTF8,"application/json");
            using var response=await client.SendAsync(req);var text=await response.Content.ReadAsStringAsync();response.EnsureSuccessStatusCode();var envelope=JsonDocument.Parse(text);var combined=Convert.FromBase64String(envelope.RootElement.GetProperty("payload").GetString()??"");var outNonce=combined[..12];var data=combined[12..];var plain=new byte[data.Length-16];using(var aes=new System.Security.Cryptography.AesGcm(key,16))aes.Decrypt(outNonce,data.AsSpan(0,data.Length-16),data.AsSpan(data.Length-16,16),plain);
            MergeSyncPackage(System.Text.Encoding.UTF8.GetString(plain));StatusText.Text="Cloud sync completed";MessageBox.Show(this,"HTTPS cloud sync completed.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,"Cloud sync failed: "+ex.Message,"DevMonitor",MessageBoxButton.OK,MessageBoxImage.Error);}
    }
    private string MergeSyncPackage(string json){
        var dto=JsonSerializer.Deserialize<SyncDto>(json,new JsonSerializerOptions{PropertyNameCaseInsensitive=true})??throw new System.IO.InvalidDataException("Invalid sync package.");
        if(dto.Protocol!=1)throw new System.IO.InvalidDataException("Unsupported sync protocol.");
        if(dto.MyDevices.Count>100000||dto.Tasks.Count>50000||dto.Notes.Count>50000||dto.Sms.Count>100000||dto.ExtendedData.Count>100000)throw new System.IO.InvalidDataException("Sync package exceeds safe limits.");
        if(dto.Tasks.Any(x=>string.IsNullOrWhiteSpace(x.Title)||x.Title.Length>1000)||dto.Notes.Any(x=>x.Title.Length>1000||x.Body.Length>200000))throw new System.IO.InvalidDataException("Sync package contains invalid task or note fields.");
        ValidateAndroidRecords(dto.ExtendedData);
        var phoneResults=ParseAndroidQueryResults(dto.ExtendedData);
        foreach(var t in dto.Tasks)_db.MergeSyncedTask(t);
        foreach(var n in dto.Notes)_db.MergeSyncedNote(n);
        foreach(var sms in dto.Sms)_db.MergeSyncedSms(sms.Sender,sms.Body,sms.Received);
        foreach(var q in phoneResults)_db.MergeSyncedPhoneResult(q);
        foreach(var row in dto.ExtendedData.Where(x=>!x.Type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase))){
            if(string.IsNullOrWhiteSpace(row.Type)||string.IsNullOrWhiteSpace(row.Key)||row.Payload.ValueKind!=JsonValueKind.Object)continue;
            _db.MergeAndroidRecord(row.Type,row.Key,row.Payload.GetRawText());
            if(string.Equals(row.Type,"notifications",StringComparison.OrdinalIgnoreCase)){
                var payload=row.Payload;
                string TextField(string name,string fallback="")=>payload.TryGetProperty(name,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():fallback;
                long epoch=0;long.TryParse(TextField("timestamp"),out epoch);
                var when=epoch>0?DateTimeOffset.FromUnixTimeMilliseconds(epoch).UtcDateTime:DateTime.UtcNow;
                var read=payload.TryGetProperty("read",out var rv)&&rv.ValueKind==JsonValueKind.True;
                _db.MergeAndroidNotification(row.Key,TextField("title","Android notification"),TextField("message"),TextField("kind","info"),when,read);
            }
        }
        foreach(var row in dto.ExtendedData.Where(x=>x.Type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase))){
            _db.MergeAndroidRecord(row.Type,row.Key,row.Payload.GetRawText());
            ApplySyncTombstone(row);
        }
        _db.ReplaceMyDevices(_db.MyDevices().Concat(dto.MyDevices));
        _db.AddNotification("Phone/PC sync completed",$"Merged {dto.Tasks.Count} tasks, {dto.Notes.Count} notes, {dto.Sms.Count} SMS records and {dto.ExtendedData.Count} extended Android records. HQ snapshots and payment records were not changed.","sync");
        return JsonSerializer.Serialize(BuildSyncDto(),new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
    }
    private void ApplySyncTombstone(AndroidEntityDto row){
        if(row.Payload.ValueKind!=JsonValueKind.Object)return;
        string Read(string name)=>row.Payload.TryGetProperty(name,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():"";
        var type=Read("entityType");if(type.Length==0)type=Read("entity_type");var key=Read("entityKey");if(key.Length==0)key=Read("entity_key");
        if(string.IsNullOrWhiteSpace(type)||string.IsNullOrWhiteSpace(key))return;
        if(type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase))return;
        _db.DeleteAndroidRecord(type,key,createTombstone:false);
    }

    private static void ValidateAndroidRecords(IEnumerable<AndroidEntityDto> records){
        var allowed=new HashSet<string>(StringComparer.OrdinalIgnoreCase){"query_codes","query_records","saved_query_lists","query_history","daily_observations","sms_query_attempts","agents","agent_phones","agent_devices","profile_metadata","notifications","sync_tombstones"};
        foreach(var row in records)if(!allowed.Contains(row.Type)||string.IsNullOrWhiteSpace(row.Key)||row.Key.Length>512||row.Payload.ValueKind!=JsonValueKind.Object||row.Payload.GetRawText().Length>500_000)throw new System.IO.InvalidDataException("Sync/archive includes an invalid or unsupported Android record. No records were merged.");
    }
    private static List<PhoneQueryResult> ParseAndroidQueryResults(IEnumerable<AndroidEntityDto> records)
    {
        var output=new List<PhoneQueryResult>();
        foreach(var row in records.Where(x=>x.Type.Equals("query_records",StringComparison.OrdinalIgnoreCase)))
        {
            if(!row.Payload.TryGetProperty("json",out var jsonValue)||jsonValue.ValueKind!=JsonValueKind.String)continue;
            using var recordDoc=JsonDocument.Parse(jsonValue.GetString()??"{}");var record=recordDoc.RootElement;
            var code=record.TryGetProperty("code",out var codeValue)?codeValue.GetString():null;
            if(string.IsNullOrWhiteSpace(code))throw new System.IO.InvalidDataException("An Android query result is missing its device code.");
            var recordStatus=record.TryGetProperty("status",out var statusValue)?statusValue.GetString()??"UNRECOGNIZED":"UNRECOGNIZED";
            var completed=record.TryGetProperty("completedAt",out var completedValue)&&completedValue.TryGetInt64(out var epoch)?epoch:DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            JsonElement result=default;var hasResult=record.TryGetProperty("result",out result)&&result.ValueKind==JsonValueKind.Object;
            int? Number(string name){if(!hasResult||!result.TryGetProperty(name,out var v)||v.ValueKind!=JsonValueKind.Number||!v.TryGetInt32(out var n))return null;return n;}
            var received=hasResult&&result.TryGetProperty("receivedAt",out var receivedValue)?receivedValue.GetString():null;
            var resultAt=DateTime.TryParse(received,out var parsed)?parsed:DateTimeOffset.FromUnixTimeMilliseconds(Math.Max(0,completed)).UtcDateTime;
            var status=string.Equals(recordStatus,"SUCCESS",StringComparison.OrdinalIgnoreCase)?"OK":recordStatus;
            var raw=hasResult&&result.TryGetProperty("raw",out var rawValue)?rawValue.GetString()??"":record.TryGetProperty("error",out var errorValue)?errorValue.GetString()??"":"";
            output.Add(new PhoneQueryResult(DevMonitorDb.Canonical(code),status,Number("today"),Number("mtd"),Number("active"),Number("bar48"),Number("bar96"),resultAt,raw));
        }
        return output;
    }
    private SyncDto BuildSyncDto()=>new(){MyDevices=_db.MyDevices(),Tasks=_db.Tasks(),Notes=_db.Notes(),Sms=_db.Sms().Select(x=>new SmsDto{Sender=x.Sender,Body=x.Body,Received=x.Received}).ToList(),ExtendedData=_db.AndroidRecords().Select(x=>new AndroidEntityDto{Type=x.Type,Key=x.Key,Payload=JsonDocument.Parse(x.PayloadJson).RootElement.Clone()}).ToList()};
    private sealed class SyncDto{public int Protocol{get;set;}=1;public string CreatedAt{get;set;}=DateTime.UtcNow.ToString("O");public List<string> MyDevices{get;set;}=[];public List<OperationalTask> Tasks{get;set;}=[];public List<OperationalNote> Notes{get;set;}=[];public List<SmsDto> Sms{get;set;}=[];public List<AndroidEntityDto> ExtendedData{get;set;}=[];}
    private sealed class AndroidEntityDto{public string Type{get;set;}="";public string Key{get;set;}="";public JsonElement Payload{get;set;}}

    private sealed class ExchangeDto
    {
        public string Version {get;set;}="1";
        public string CreatedAt {get;set;}=DateTime.UtcNow.ToString("O");
        public List<string> MyDevices {get;set;}=[];
        public List<PhoneQueryResult> PhoneResults {get;set;}=[];
        public List<OperationalTask> Tasks {get;set;}=[];
        public List<OperationalNote> Notes {get;set;}=[];
        public List<AppNotification> Notifications {get;set;}=[];
        public List<SmsDto> Sms {get;set;}=[];
        public List<AndroidEntityDto> ExtendedData {get;set;}=[];
    }
    private sealed class SmsDto { public string Sender {get;set;}=""; public string Body {get;set;}=""; public DateTime Received {get;set;} }

    private void ExportExchange(object? sender,RoutedEventArgs e)
    {
        var dto=new ExchangeDto{
            MyDevices=_db.MyDevices(),PhoneResults=_db.PhoneResults(),Tasks=_db.Tasks(),Notes=_db.Notes(),Notifications=_db.Notifications(),
            Sms=_db.Sms().Select(x=>new SmsDto{Sender=x.Sender,Body=x.Body,Received=x.Received}).ToList(),
            ExtendedData=_db.AndroidRecords().Select(x=>new AndroidEntityDto{Type=x.Type,Key=x.Key,Payload=JsonDocument.Parse(x.PayloadJson).RootElement.Clone()}).ToList()
        };
        var dlg=new SaveFileDialog{Filter="DevMonitor data package|*.dmdata",FileName=$"DevMonitor-Phone-Exchange-{DateTime.Now:yyyyMMdd-HHmm}.dmdata"};
        if(dlg.ShowDialog()!=true)return;
        System.IO.File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(dto,new JsonSerializerOptions{WriteIndented=true}));
        StatusText.Text=$"Exported {System.IO.Path.GetFileName(dlg.FileName)}";
        _db.AddNotification("Data package exported",System.IO.Path.GetFileName(dlg.FileName),"exchange");
    }

    private void ImportExchange(object? sender,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="DevMonitor data package|*.dmdata;*.json|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            var dto=JsonSerializer.Deserialize<ExchangeDto>(System.IO.File.ReadAllText(dlg.FileName),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
            if(dto==null)throw new System.IO.InvalidDataException("The package could not be read.");
            if(dto.Version!="1")throw new System.IO.InvalidDataException($"Unsupported DevMonitor package version '{dto.Version}'. No data was imported.");
            if(dto.MyDevices.Count>100000||dto.PhoneResults.Count>100000||dto.Tasks.Count>50000||dto.Notes.Count>50000||dto.Notifications.Count>100000||dto.Sms.Count>100000||dto.ExtendedData.Count>100000)throw new System.IO.InvalidDataException("The package exceeds safe import limits. No data was imported.");
            if(dto.PhoneResults.Any(q=>string.IsNullOrWhiteSpace(q.DeviceId)||q.DeviceId.Length>128||new[]{q.Today,q.Mtd,q.Active,q.Bar48,q.Bar96}.Any(n=>n.HasValue&&n.Value<0)))throw new System.IO.InvalidDataException("The package contains an invalid phone result (missing device code or negative count). No data was imported.");
            ValidateAndroidRecords(dto.ExtendedData);
            var syncedPhoneResults=ParseAndroidQueryResults(dto.ExtendedData);
            if(dto.MyDevices.Count>0)_db.ReplaceMyDevices(dto.MyDevices);
            foreach(var q in dto.PhoneResults)_db.SavePhoneResult(q);
            foreach(var t in dto.Tasks)_db.SaveTask(t with {Id=0});
            foreach(var n in dto.Notes)_db.SaveNote(n with {Id=0});
            foreach(var n in dto.Notifications)_db.AddNotification(n.Title,n.Message,n.Kind);
            foreach(var sms in dto.Sms)_db.MergeSyncedSms(sms.Sender,sms.Body,sms.Received);
            foreach(var q in syncedPhoneResults)_db.MergeSyncedPhoneResult(q);
            foreach(var row in dto.ExtendedData){if(!string.IsNullOrWhiteSpace(row.Type)&&!string.IsNullOrWhiteSpace(row.Key)&&row.Payload.ValueKind==JsonValueKind.Object)_db.MergeAndroidRecord(row.Type,row.Key,row.Payload.GetRawText());}
            _db.AddNotification("Phone data imported",$"{dto.PhoneResults.Count:N0} phone results and {dto.ExtendedData.Count:N0} extended Android records imported from {System.IO.Path.GetFileName(dlg.FileName)}.","exchange");
            MessageBox.Show(this,"Phone data package imported. The data is now available offline.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
            Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"Data package import failed",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    private UIElement AndroidDataPage()
    {
        var root=new StackPanel();
        var initialTypes=new List<string>{"All families"}.Concat(_db.AndroidRecords().Select(x=>x.Type).Distinct().OrderBy(x=>x)).ToList();
        var family=new ComboBox{ItemsSource=initialTypes,SelectedIndex=0,MinWidth=220,Height=36,Margin=new Thickness(0,0,8,8)};
        var search=new TextBox{Width=280,Height=36,Margin=new Thickness(0,0,8,8),ToolTip="Search family, key or payload"};
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=520,SelectionMode=DataGridSelectionMode.Single};
        void Load(){
            var records=_db.AndroidRecords();var type=family.SelectedItem?.ToString();var q=search.Text?.Trim()??"";
            grid.ItemsSource=records.Where(x=>(type=="All families"||string.IsNullOrWhiteSpace(type)||x.Type==type)&&(q.Length==0||x.Type.Contains(q,StringComparison.OrdinalIgnoreCase)||x.Key.Contains(q,StringComparison.OrdinalIgnoreCase)||x.PayloadJson.Contains(q,StringComparison.OrdinalIgnoreCase))).Take(2000).ToList();
        }
        void EditSelected(){if(grid.SelectedItem is not AndroidRecord selected){MessageBox.Show(this,"Select an Android record first.");return;}EditAndroidRecord(selected);Load();}
        family.SelectionChanged+=(_,_)=>Load();search.TextChanged+=(_,_)=>Load();
        root.Children.Add(Card(Stack(H("Android Data Archive",22),P("Manage Android-originated query lists, query codes, history, observations, SMS attempt metadata, agents, phone contacts, device assignments, profile metadata and notifications. Changes are stored locally and sent on the next explicit sync. HQ monthly snapshots and payment records are not editable here."),
            new WrapPanel{Children={family,search,B("Refresh",(_,_)=>{Load();StatusText.Text="Android archive refreshed";}),B("Add record",(_,_)=>{EditAndroidRecord(null);Load();}),B("Edit selected",(_,_)=>EditSelected()),B("Delete selected",(_,_)=>{if(grid.SelectedItem is not AndroidRecord r){MessageBox.Show(this,"Select a record first.");return;}if(MessageBox.Show(this,$"Delete {r.Type} / {r.Key}? This deletion will be sent to paired devices on the next sync.","Confirm delete",MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes){_db.DeleteAndroidRecord(r.Type,r.Key);Load();StatusText.Text="Record deleted; deletion marker queued for sync";}}),B("Export JSON",ExportAndroidArchive),B("Export index CSV",ExportAndroidArchiveIndex)}},
            H($"{_db.AndroidRecords().Count:N0} archived records",16),grid),Brushes.SteelBlue));
        Load();return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private void EditAndroidRecord(AndroidRecord? existing){
        var w=new Window{Title=existing==null?"Add Android archive record":"Edit Android archive record",Width=760,Height=680,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var type=new ComboBox{ItemsSource=new[]{"query_codes","query_records","saved_query_lists","query_history","daily_observations","sms_query_attempts","agents","agent_phones","agent_devices","profile_metadata","notifications"},SelectedItem=existing?.Type??"query_codes",Height=36,IsEnabled=existing==null};
        var key=new TextBox{Text=existing?.Key??"",Height=36};
        var payload=new TextBox{Text=existing?.PayloadJson??"{\n  \"code\": \"\",\n  \"type\": \"\",\n  \"archived\": 0,\n  \"created_at\": 0,\n  \"updated_at\": 0\n}",AcceptsReturn=true,AcceptsTab=true,TextWrapping=TextWrapping.NoWrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Auto,FontFamily=new System.Windows.Media.FontFamily("Consolas"),FontSize=13};
        var save=B("Save record",(_,_)=>{try{
            var t=type.SelectedItem?.ToString()??"";var k=key.Text.Trim();if(string.IsNullOrWhiteSpace(t)||string.IsNullOrWhiteSpace(k))throw new System.IO.InvalidDataException("Family and record key are required.");
            using var doc=JsonDocument.Parse(payload.Text);if(doc.RootElement.ValueKind!=JsonValueKind.Object)throw new System.IO.InvalidDataException("Payload must be a JSON object.");if(payload.Text.Length>500000)throw new System.IO.InvalidDataException("Payload exceeds the 500 KB limit.");
            if(existing!=null&&(existing.Type!=t||existing.Key!=k))_db.DeleteAndroidRecord(existing.Type,existing.Key);
            _db.MergeAndroidRecord(t,k,doc.RootElement.GetRawText());
            if(t=="notifications"){
                string Field(string n,string d="")=>doc.RootElement.TryGetProperty(n,out var v)&&v.ValueKind!=JsonValueKind.Null?v.ToString():d;
                long.TryParse(Field("timestamp"),out var ms);var when=ms>0?DateTimeOffset.FromUnixTimeMilliseconds(ms).UtcDateTime:DateTime.UtcNow;
                var read=doc.RootElement.TryGetProperty("read",out var rv)&&rv.ValueKind==JsonValueKind.True;
                _db.MergeAndroidNotification(k,Field("title","Android notification"),Field("message"),Field("kind","info"),when,read);
            }
            w.DialogResult=true;w.Close();
        }catch(Exception ex){MessageBox.Show(w,ex.Message,"Cannot save Android record",MessageBoxButton.OK,MessageBoxImage.Error);}});
        w.Content=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=Stack(H(existing==null?"New archive record":"Edit archive record",22),P("This editor works on operational Android records only. Keep the payload schema valid for its selected family. It does not edit HQ report snapshots or payment records."),new TextBlock{Text="Record family"},type,new TextBlock{Text="Record key"},key,new TextBlock{Text="Payload JSON"},payload,new WrapPanel{Children={save,B("Cancel",(_,_)=>w.Close())}})};
        w.ShowDialog();
    }

    private void ExportAndroidArchive(object? sender,RoutedEventArgs e){
        var dlg=new SaveFileDialog{Filter="JSON archive|*.json",FileName=$"DevMonitor_Android_Archive_{DateTime.Now:yyyyMMdd-HHmm}.json"};if(dlg.ShowDialog()!=true)return;
        var records=_db.AndroidRecords().Select(x=>new{type=x.Type,key=x.Key,updatedAt=x.UpdatedAt,payload=JsonDocument.Parse(x.PayloadJson).RootElement.Clone()}).ToList();
        System.IO.File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(new{format="DevMonitorAndroidArchiveV1",exportedAt=DateTime.UtcNow,records},new JsonSerializerOptions{WriteIndented=true}));
        StatusText.Text=$"Exported {records.Count:N0} Android archive records";
    }
    private void ExportAndroidArchiveIndex(object? sender,RoutedEventArgs e){
        SaveCsv("DevMonitor_Android_Archive_Index.csv","RecordFamily,Key,UpdatedAt,PayloadBytes",_db.AndroidRecords().Select(x=>$"{Csv(x.Type)},{Csv(x.Key)},{Csv(x.UpdatedAt.ToString("O"))},{System.Text.Encoding.UTF8.GetByteCount(x.PayloadJson)}"));
    }

    private UIElement SettingsPage()=>new ScrollViewer{Content=Card(Stack(H("Settings"),P("Desktop settings are local and offline-first. Cloud account, backup and Android/Windows synchronization are deliberately isolated from core calculations."),
        H("Local data",17),P($"Database: {_db.FilePath}"),H("Payment rules",17),P("Payment/progression rules are ported from the supplied Android source and remain separate from report-import UI."),H("Two-month HQ store",17),P("Only the current and immediately previous calendar months are accepted. Older coverage is rejected; same or newer coverage replaces the month's complete snapshot.")),Brushes.Gray)};

    protected override void OnClosed(EventArgs e){_syncBridge?.Dispose();base.OnClosed(e);_db.Dispose();}
}
