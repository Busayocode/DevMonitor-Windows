# DevMonitor Windows 4.6.0.210 — Build hardening

- Explicitly qualifies `System.IO.File`, `System.IO.Path`, and `System.IO.InvalidDataException` in MainWindow.xaml.cs.
- Uses `DataGridSelectionMode.Single` for WPF DataGrid controls.
- Carries forward v209 sync/build fixes and preserves the separate SyncRelay project exclusion from the WPF application compile.
- No payment calculation rules were changed.

Build status: source ZIP integrity checked; a .NET build was not available in the packaging environment. Verify with the repository's GitHub Actions workflow.
