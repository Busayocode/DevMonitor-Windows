using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;

namespace DevMonitor.Windows;

public sealed class DevMonitorDb : IDisposable
{
    private readonly SqliteConnection _db;
    public string FilePath { get; }

    public DevMonitorDb()
    {
        var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"DevMonitor");
        Directory.CreateDirectory(dir);
        FilePath=Path.Combine(dir,"devmonitor.db");
        _db=new SqliteConnection($"Data Source={FilePath}");
        _db.Open();
        Initialize();
    }

    private void Initialize()
    {
        using var cmd=_db.CreateCommand();
        cmd.CommandText="""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS my_devices(device_id TEXT PRIMARY KEY,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS daily_observations(
            device_id TEXT NOT NULL, obs_date TEXT NOT NULL, ownership TEXT,
            today INTEGER, mtd INTEGER, active INTEGER, bar48 INTEGER, bar96 INTEGER,
            trade_code TEXT, partner_name TEXT, cluster TEXT, region TEXT, territory TEXT, staff_name TEXT,
            PRIMARY KEY(device_id,obs_date));
        CREATE TABLE IF NOT EXISTS hq_months(
            month TEXT PRIMARY KEY, coverage_start TEXT NOT NULL, coverage_end TEXT NOT NULL,
            source_file TEXT NOT NULL, imported_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hq_rows(
            month TEXT NOT NULL, device_id TEXT NOT NULL, trade_code TEXT, partner_name TEXT,
            cluster TEXT, region TEXT, territory TEXT, staff_name TEXT, obs_date TEXT NOT NULL, value INTEGER NOT NULL,
            PRIMARY KEY(month,device_id,obs_date));
        CREATE TABLE IF NOT EXISTS sms_inbox(
            id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,body TEXT NOT NULL,received_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS phone_query_results(
            id INTEGER PRIMARY KEY AUTOINCREMENT,device_id TEXT NOT NULL,status TEXT NOT NULL,
            today INTEGER,mtd INTEGER,active INTEGER,bar48 INTEGER,bar96 INTEGER,
            result_at TEXT NOT NULL,raw TEXT NOT NULL DEFAULT '');
        CREATE INDEX IF NOT EXISTS idx_phone_query_device ON phone_query_results(device_id,result_at);
        CREATE TABLE IF NOT EXISTS operational_tasks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,details TEXT NOT NULL DEFAULT '',due_date TEXT,
            priority TEXT NOT NULL DEFAULT 'NORMAL',link_type TEXT,link_value TEXT,completed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS operational_notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT '',body TEXT NOT NULL,link_type TEXT,link_value TEXT,
            pinned INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS notifications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,message TEXT NOT NULL,timestamp TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'info',read INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS android_records(
            entity_type TEXT NOT NULL, entity_key TEXT NOT NULL, payload_json TEXT NOT NULL,
            updated_at TEXT NOT NULL, PRIMARY KEY(entity_type,entity_key));
        CREATE INDEX IF NOT EXISTS idx_android_records_type ON android_records(entity_type);
        CREATE TABLE IF NOT EXISTS android_notification_map(
            source_key TEXT PRIMARY KEY, notification_id INTEGER NOT NULL, source_timestamp TEXT NOT NULL DEFAULT '');
        """;
        cmd.ExecuteNonQuery();
    }

    public void SetSetting(string key,string value) {
        using var c=_db.CreateCommand(); c.CommandText="INSERT INTO settings(key,value) VALUES($k,$v) ON CONFLICT(key) DO UPDATE SET value=$v";
        c.Parameters.AddWithValue("$k",key); c.Parameters.AddWithValue("$v",value); c.ExecuteNonQuery();
    }
    public string? GetSetting(string key) {
        using var c=_db.CreateCommand(); c.CommandText="SELECT value FROM settings WHERE key=$k"; c.Parameters.AddWithValue("$k",key);
        return c.ExecuteScalar()?.ToString();
    }
    public void ReplaceMyDevices(IEnumerable<string> ids) {
        using var tx=_db.BeginTransaction();
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText="DELETE FROM my_devices";c.ExecuteNonQuery();}
        foreach(var id in ids.Where(x=>!string.IsNullOrWhiteSpace(x)).Select(Canonical).Distinct()){
            using var c=_db.CreateCommand(); c.Transaction=tx;c.CommandText="INSERT INTO my_devices(device_id,updated_at) VALUES($id,$at)";
            c.Parameters.AddWithValue("$id",id);c.Parameters.AddWithValue("$at",DateTime.UtcNow.ToString("O"));c.ExecuteNonQuery();
        }
        tx.Commit();
    }
    public List<string> MyDevices(){
        using var c=_db.CreateCommand();c.CommandText="SELECT device_id FROM my_devices ORDER BY device_id";
        using var r=c.ExecuteReader();var o=new List<string>();while(r.Read())o.Add(r.GetString(0));return o;
    }

    public void ReplaceMonthSnapshot(DateTime month,DateTime start,DateTime end,string source,List<DeviceRow> rows)
    {
        var monthKey=new DateTime(month.Year,month.Month,1).ToString("yyyy-MM");
        using var tx=_db.BeginTransaction();
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText="DELETE FROM hq_rows WHERE month=$m";c.Parameters.AddWithValue("$m",monthKey);c.ExecuteNonQuery();}
        foreach(var row in rows){
            foreach(var kv in row.Daily){
                if(kv.Key.Date<start.Date || kv.Key.Date>end.Date) continue;
                using var c=_db.CreateCommand();c.Transaction=tx;
                c.CommandText=@"INSERT INTO hq_rows(month,device_id,trade_code,partner_name,cluster,region,territory,staff_name,obs_date,value)
                                 VALUES($m,$id,$t,$p,$c,$r,$te,$s,$d,$v)";
                c.Parameters.AddWithValue("$m",monthKey);c.Parameters.AddWithValue("$id",Canonical(row.DeviceId));
                c.Parameters.AddWithValue("$t",row.TradeCode);c.Parameters.AddWithValue("$p",row.PartnerName);
                c.Parameters.AddWithValue("$c",row.Cluster);c.Parameters.AddWithValue("$r",row.Region);
                c.Parameters.AddWithValue("$te",row.Territory);c.Parameters.AddWithValue("$s",row.StaffName);
                c.Parameters.AddWithValue("$d",kv.Key.ToString("yyyy-MM-dd"));c.Parameters.AddWithValue("$v",kv.Value);
                c.ExecuteNonQuery();
            }
        }
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText=@"INSERT INTO hq_months(month,coverage_start,coverage_end,source_file,imported_at)
            VALUES($m,$s,$e,$f,$i) ON CONFLICT(month) DO UPDATE SET coverage_start=$s,coverage_end=$e,source_file=$f,imported_at=$i";
            c.Parameters.AddWithValue("$m",monthKey);c.Parameters.AddWithValue("$s",start.ToString("yyyy-MM-dd"));
            c.Parameters.AddWithValue("$e",end.ToString("yyyy-MM-dd"));c.Parameters.AddWithValue("$f",source);c.Parameters.AddWithValue("$i",DateTime.UtcNow.ToString("O"));c.ExecuteNonQuery();}
        tx.Commit();
    }

    public DateTime? StoredCoverageEnd(DateTime month){
        using var c=_db.CreateCommand();c.CommandText="SELECT coverage_end FROM hq_months WHERE month=$m";c.Parameters.AddWithValue("$m",new DateTime(month.Year,month.Month,1).ToString("yyyy-MM"));
        var x=c.ExecuteScalar()?.ToString();return DateTime.TryParse(x,out var d)?d:null;
    }

    public List<DeviceSnapshot> DeviceSnapshots(IEnumerable<string> deviceIds,DateTime asOf)
    {
        var ids=deviceIds.Select(Canonical).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var result=new List<DeviceSnapshot>();
        foreach(var id in ids){
            using var c=_db.CreateCommand();
            c.CommandText=@"SELECT obs_date,value FROM hq_rows
                WHERE device_id=$id AND obs_date<= $d ORDER BY obs_date DESC LIMIT 40";
            c.Parameters.AddWithValue("$id",id);
            c.Parameters.AddWithValue("$d",asOf.ToString("yyyy-MM-dd"));
            var daily=new List<(DateTime d,int v)>();
            using(var r=c.ExecuteReader())
            {
                while(r.Read()) daily.Add((DateTime.Parse(r.GetString(0)),r.GetInt32(1)));
            }

            var latestPhone=PhoneResults(id).FirstOrDefault();
            var monthKey=new DateTime(asOf.Year,asOf.Month,1).ToString("yyyy-MM");
            DateTime? reportImported=null;
            using(var rc=_db.CreateCommand()){
                rc.CommandText="SELECT imported_at FROM hq_months WHERE month=$m";
                rc.Parameters.AddWithValue("$m",monthKey);
                var rv=rc.ExecuteScalar()?.ToString();
                if(DateTime.TryParse(rv,out var rd)) reportImported=rd;
            }

            if(daily.Count==0){
                if(latestPhone!=null){
                    result.Add(new DeviceSnapshot(id,"PHONE","",latestPhone.Today??0,latestPhone.Mtd??0,latestPhone.Active??0,
                        latestPhone.Bar48??0,latestPhone.Bar96??0,latestPhone.ResultAt,
                        latestPhone.Status.Equals("OK",StringComparison.OrdinalIgnoreCase)?null:latestPhone.Status));
                } else {
                    result.Add(new DeviceSnapshot(id,"HQ","",0,0,0,0,0,asOf,"No HQ activity"));
                }
                continue;
            }

            var today=daily.First().v;
            var mtd=daily.Where(x=>x.d.Month==asOf.Month&&x.d.Year==asOf.Year).Sum(x=>x.v);
            var cycle=PaymentRules.PaymentCycleForDate(asOf);
            var active=daily.Where(x=>x.d>=cycle.Start&&x.d<=asOf).Sum(x=>x.v);

            if(latestPhone!=null && (!reportImported.HasValue || latestPhone.ResultAt>reportImported.Value)){
                result.Add(new DeviceSnapshot(id,"PHONE","",latestPhone.Today??today,latestPhone.Mtd??mtd,latestPhone.Active??active,
                    latestPhone.Bar48??0,latestPhone.Bar96??0,latestPhone.ResultAt,
                    latestPhone.Status.Equals("OK",StringComparison.OrdinalIgnoreCase)?null:latestPhone.Status));
            } else {
                result.Add(new DeviceSnapshot(id,"HQ","",today,mtd,active,0,0,asOf,null));
            }
        }
        return result;
    }

    public List<DeviceRow> LoadMonth(DateTime month)
    {
        var key=new DateTime(month.Year,month.Month,1).ToString("yyyy-MM");
        using var c=_db.CreateCommand();c.CommandText=@"SELECT device_id,trade_code,partner_name,cluster,region,territory,staff_name,obs_date,value
            FROM hq_rows WHERE month=$m ORDER BY device_id,obs_date";c.Parameters.AddWithValue("$m",key);
        using var r=c.ExecuteReader();var map=new Dictionary<string,DeviceRow>(StringComparer.OrdinalIgnoreCase);
        while(r.Read()){
            var id=r.GetString(0);
            if(!map.TryGetValue(id,out var row)){row=new DeviceRow(id,r.GetString(1),r.GetString(2),r.GetString(3),r.GetString(4),r.GetString(5),r.GetString(6),new());map[id]=row;}
            row.Daily[DateTime.Parse(r.GetString(7))]=r.GetInt32(8);
        }
        return map.Values.ToList();
    }

    public void SavePhoneResult(PhoneQueryResult q)
    {
        using var c=_db.CreateCommand();
        c.CommandText="INSERT INTO phone_query_results(device_id,status,today,mtd,active,bar48,bar96,result_at,raw) VALUES($id,$st,$t,$m,$a,$b48,$b96,$at,$raw)";
        c.Parameters.AddWithValue("$id",Canonical(q.DeviceId)); c.Parameters.AddWithValue("$st",q.Status);
        c.Parameters.AddWithValue("$t",(object?)q.Today??DBNull.Value); c.Parameters.AddWithValue("$m",(object?)q.Mtd??DBNull.Value);
        c.Parameters.AddWithValue("$a",(object?)q.Active??DBNull.Value); c.Parameters.AddWithValue("$b48",(object?)q.Bar48??DBNull.Value);
        c.Parameters.AddWithValue("$b96",(object?)q.Bar96??DBNull.Value); c.Parameters.AddWithValue("$at",q.ResultAt.ToString("O"));
        c.Parameters.AddWithValue("$raw",q.Raw??""); c.ExecuteNonQuery();
    }
    public void MergeSyncedPhoneResult(PhoneQueryResult q)
    {
        using var c=_db.CreateCommand();
        c.CommandText="SELECT COUNT(*) FROM phone_query_results WHERE device_id=$id AND result_at=$at AND raw=$raw";
        c.Parameters.AddWithValue("$id",Canonical(q.DeviceId));c.Parameters.AddWithValue("$at",q.ResultAt.ToString("O"));c.Parameters.AddWithValue("$raw",q.Raw??"");
        if(Convert.ToInt32(c.ExecuteScalar())>0)return;
        SavePhoneResult(q);
    }
    public List<PhoneQueryResult> PhoneResults(string? device=null)
    {
        using var c=_db.CreateCommand();
        c.CommandText="SELECT device_id,status,today,mtd,active,bar48,bar96,result_at,raw FROM phone_query_results "+(string.IsNullOrWhiteSpace(device)?"":"WHERE device_id=$id ")+"ORDER BY result_at DESC LIMIT 500";
        if(!string.IsNullOrWhiteSpace(device)) c.Parameters.AddWithValue("$id",Canonical(device));
        using var r=c.ExecuteReader(); var list=new List<PhoneQueryResult>();
        while(r.Read()) list.Add(new PhoneQueryResult(r.GetString(0),r.GetString(1),r.IsDBNull(2)?null:r.GetInt32(2),r.IsDBNull(3)?null:r.GetInt32(3),r.IsDBNull(4)?null:r.GetInt32(4),r.IsDBNull(5)?null:r.GetInt32(5),r.IsDBNull(6)?null:r.GetInt32(6),DateTime.Parse(r.GetString(7)),r.GetString(8)));
        return list;
    }
    public void ClearPhoneResults(){using var c=_db.CreateCommand();c.CommandText="DELETE FROM phone_query_results";c.ExecuteNonQuery();}
    public void AddSms(string sender,string body)=>AddSms(sender,body,DateTime.Now);
    public void AddSms(string sender,string body,DateTime received){
        using var c=_db.CreateCommand();c.CommandText="INSERT INTO sms_inbox(sender,body,received_at) VALUES($s,$b,$t)";
        c.Parameters.AddWithValue("$s",sender);c.Parameters.AddWithValue("$b",body);c.Parameters.AddWithValue("$t",received.ToUniversalTime().ToString("O"));c.ExecuteNonQuery();
    }
    public List<(string Sender,string Body,DateTime Received)> Sms(){
        using var c=_db.CreateCommand();c.CommandText="SELECT sender,body,received_at FROM sms_inbox ORDER BY id DESC LIMIT 200";using var r=c.ExecuteReader();
        var list=new List<(string,string,DateTime)>();while(r.Read())list.Add((r.GetString(0),r.GetString(1),DateTime.Parse(r.GetString(2))));return list;
    }

    public List<OperationalTask> Tasks(bool includeCompleted=true){
        using var c=_db.CreateCommand(); c.CommandText=$"SELECT id,title,details,due_date,priority,link_type,link_value,completed,created_at,updated_at FROM operational_tasks WHERE {(includeCompleted?"1=1":"completed=0")} ORDER BY completed ASC, CASE WHEN due_date IS NULL OR due_date='' THEN 1 ELSE 0 END,due_date ASC,updated_at DESC";
        using var r=c.ExecuteReader(); var list=new List<OperationalTask>(); while(r.Read()) list.Add(new OperationalTask(r.GetInt64(0),r.GetString(1),r.GetString(2),r.IsDBNull(3)?null:r.GetString(3),r.GetString(4),r.IsDBNull(5)?null:r.GetString(5),r.IsDBNull(6)?null:r.GetString(6),r.GetInt32(7)!=0,DateTime.Parse(r.GetString(8)),DateTime.Parse(r.GetString(9)))); return list;
    }
    public void MergeSyncedTask(OperationalTask t){
        using var find=_db.CreateCommand();find.CommandText="SELECT id,updated_at FROM operational_tasks WHERE title=$t AND created_at=$c LIMIT 1";find.Parameters.AddWithValue("$t",t.Title.Trim());find.Parameters.AddWithValue("$c",t.CreatedAt.ToUniversalTime().ToString("O"));
        using var r=find.ExecuteReader(); if(r.Read()){var id=r.GetInt64(0);var priorUpdated=DateTime.Parse(r.GetString(1));r.Close();if(t.UpdatedAt.ToUniversalTime()<priorUpdated.ToUniversalTime())return;using var u=_db.CreateCommand();u.CommandText="UPDATE operational_tasks SET details=$d,due_date=$due,priority=$p,link_type=$lt,link_value=$lv,completed=$done,updated_at=$now WHERE id=$id";u.Parameters.AddWithValue("$d",t.Details);u.Parameters.AddWithValue("$due",(object?)t.DueDate??DBNull.Value);u.Parameters.AddWithValue("$p",t.Priority);u.Parameters.AddWithValue("$lt",(object?)t.LinkType??DBNull.Value);u.Parameters.AddWithValue("$lv",(object?)t.LinkValue??DBNull.Value);u.Parameters.AddWithValue("$done",t.Completed?1:0);u.Parameters.AddWithValue("$now",t.UpdatedAt.ToUniversalTime().ToString("O"));u.Parameters.AddWithValue("$id",id);u.ExecuteNonQuery();return;}
        r.Close(); using var c=_db.CreateCommand();c.CommandText="INSERT INTO operational_tasks(title,details,due_date,priority,link_type,link_value,completed,created_at,updated_at) VALUES($t,$d,$due,$p,$lt,$lv,$done,$created,$updated)";c.Parameters.AddWithValue("$t",t.Title.Trim());c.Parameters.AddWithValue("$d",t.Details);c.Parameters.AddWithValue("$due",(object?)t.DueDate??DBNull.Value);c.Parameters.AddWithValue("$p",t.Priority);c.Parameters.AddWithValue("$lt",(object?)t.LinkType??DBNull.Value);c.Parameters.AddWithValue("$lv",(object?)t.LinkValue??DBNull.Value);c.Parameters.AddWithValue("$done",t.Completed?1:0);c.Parameters.AddWithValue("$created",t.CreatedAt.ToUniversalTime().ToString("O"));c.Parameters.AddWithValue("$updated",t.UpdatedAt.ToUniversalTime().ToString("O"));c.ExecuteNonQuery();
    }
    public void MergeSyncedNote(OperationalNote n){
        using var find=_db.CreateCommand();find.CommandText="SELECT id,updated_at FROM operational_notes WHERE title=$t AND created_at=$c LIMIT 1";find.Parameters.AddWithValue("$t",n.Title.Trim());find.Parameters.AddWithValue("$c",n.CreatedAt.ToUniversalTime().ToString("O"));using var reader=find.ExecuteReader(); long? id=null;DateTime? priorUpdated=null;if(reader.Read()){id=reader.GetInt64(0);priorUpdated=DateTime.Parse(reader.GetString(1));}reader.Close();
        if(id!=null){if(priorUpdated.HasValue&&n.UpdatedAt.ToUniversalTime()<priorUpdated.Value.ToUniversalTime())return;using var u=_db.CreateCommand();u.CommandText="UPDATE operational_notes SET body=$b,link_type=$lt,link_value=$lv,pinned=$pin,updated_at=$now WHERE id=$id";u.Parameters.AddWithValue("$b",n.Body);u.Parameters.AddWithValue("$lt",(object?)n.LinkType??DBNull.Value);u.Parameters.AddWithValue("$lv",(object?)n.LinkValue??DBNull.Value);u.Parameters.AddWithValue("$pin",n.Pinned?1:0);u.Parameters.AddWithValue("$now",n.UpdatedAt.ToUniversalTime().ToString("O"));u.Parameters.AddWithValue("$id",id.Value);u.ExecuteNonQuery();return;}
        using var c=_db.CreateCommand();c.CommandText="INSERT INTO operational_notes(title,body,link_type,link_value,pinned,created_at,updated_at) VALUES($t,$b,$lt,$lv,$pin,$created,$updated)";c.Parameters.AddWithValue("$t",n.Title.Trim());c.Parameters.AddWithValue("$b",n.Body);c.Parameters.AddWithValue("$lt",(object?)n.LinkType??DBNull.Value);c.Parameters.AddWithValue("$lv",(object?)n.LinkValue??DBNull.Value);c.Parameters.AddWithValue("$pin",n.Pinned?1:0);c.Parameters.AddWithValue("$created",n.CreatedAt.ToUniversalTime().ToString("O"));c.Parameters.AddWithValue("$updated",n.UpdatedAt.ToUniversalTime().ToString("O"));c.ExecuteNonQuery();
    }
    public void MergeSyncedSms(string sender,string body,DateTime received){using var f=_db.CreateCommand();f.CommandText="SELECT COUNT(*) FROM sms_inbox WHERE sender=$s AND body=$b AND received_at=$t";f.Parameters.AddWithValue("$s",sender);f.Parameters.AddWithValue("$b",body);f.Parameters.AddWithValue("$t",received.ToUniversalTime().ToString("O"));if(Convert.ToInt32(f.ExecuteScalar())>0)return;AddSms(sender,body,received);}

    public long SaveTask(OperationalTask t){
        var now=DateTime.UtcNow.ToString("O"); using var c=_db.CreateCommand();
        if(t.Id==0){c.CommandText="INSERT INTO operational_tasks(title,details,due_date,priority,link_type,link_value,completed,created_at,updated_at) VALUES($t,$d,$due,$p,$lt,$lv,0,$now,$now);SELECT last_insert_rowid();";}
        else {c.CommandText="UPDATE operational_tasks SET title=$t,details=$d,due_date=$due,priority=$p,link_type=$lt,link_value=$lv,completed=$done,updated_at=$now WHERE id=$id;SELECT $id;";c.Parameters.AddWithValue("$id",t.Id);c.Parameters.AddWithValue("$done",t.Completed?1:0);}
        c.Parameters.AddWithValue("$t",t.Title.Trim());c.Parameters.AddWithValue("$d",t.Details.Trim());c.Parameters.AddWithValue("$due",(object?)t.DueDate??DBNull.Value);c.Parameters.AddWithValue("$p",t.Priority);c.Parameters.AddWithValue("$lt",(object?)t.LinkType??DBNull.Value);c.Parameters.AddWithValue("$lv",(object?)t.LinkValue??DBNull.Value);c.Parameters.AddWithValue("$now",now);return Convert.ToInt64(c.ExecuteScalar());
    }
    public void SetTaskCompleted(long id,bool done){using var c=_db.CreateCommand();c.CommandText="UPDATE operational_tasks SET completed=$d,updated_at=$u WHERE id=$id";c.Parameters.AddWithValue("$d",done?1:0);c.Parameters.AddWithValue("$u",DateTime.UtcNow.ToString("O"));c.Parameters.AddWithValue("$id",id);c.ExecuteNonQuery();}
    public void DeleteTask(long id){using var c=_db.CreateCommand();c.CommandText="DELETE FROM operational_tasks WHERE id=$id";c.Parameters.AddWithValue("$id",id);c.ExecuteNonQuery();}
    public List<OperationalNote> Notes(){using var c=_db.CreateCommand();c.CommandText="SELECT id,title,body,link_type,link_value,pinned,created_at,updated_at FROM operational_notes ORDER BY pinned DESC,updated_at DESC";using var r=c.ExecuteReader();var list=new List<OperationalNote>();while(r.Read())list.Add(new OperationalNote(r.GetInt64(0),r.GetString(1),r.GetString(2),r.IsDBNull(3)?null:r.GetString(3),r.IsDBNull(4)?null:r.GetString(4),r.GetInt32(5)!=0,DateTime.Parse(r.GetString(6)),DateTime.Parse(r.GetString(7))));return list;}
    public long SaveNote(OperationalNote n){var now=DateTime.UtcNow.ToString("O");using var c=_db.CreateCommand();if(n.Id==0){c.CommandText="INSERT INTO operational_notes(title,body,link_type,link_value,pinned,created_at,updated_at) VALUES($t,$b,$lt,$lv,$pin,$now,$now);SELECT last_insert_rowid();";}else{c.CommandText="UPDATE operational_notes SET title=$t,body=$b,link_type=$lt,link_value=$lv,pinned=$pin,updated_at=$now WHERE id=$id;SELECT $id;";c.Parameters.AddWithValue("$id",n.Id);}c.Parameters.AddWithValue("$t",n.Title.Trim());c.Parameters.AddWithValue("$b",n.Body.Trim());c.Parameters.AddWithValue("$lt",(object?)n.LinkType??DBNull.Value);c.Parameters.AddWithValue("$lv",(object?)n.LinkValue??DBNull.Value);c.Parameters.AddWithValue("$pin",n.Pinned?1:0);c.Parameters.AddWithValue("$now",now);return Convert.ToInt64(c.ExecuteScalar());}
    public void SetNotePinned(long id,bool pinned){using var c=_db.CreateCommand();c.CommandText="UPDATE operational_notes SET pinned=$p,updated_at=$u WHERE id=$id";c.Parameters.AddWithValue("$p",pinned?1:0);c.Parameters.AddWithValue("$u",DateTime.UtcNow.ToString("O"));c.Parameters.AddWithValue("$id",id);c.ExecuteNonQuery();}
    public void DeleteNote(long id){using var c=_db.CreateCommand();c.CommandText="DELETE FROM operational_notes WHERE id=$id";c.Parameters.AddWithValue("$id",id);c.ExecuteNonQuery();}
    public List<AppNotification> Notifications(){using var c=_db.CreateCommand();c.CommandText="SELECT id,title,message,timestamp,kind,read FROM notifications ORDER BY id DESC LIMIT 100";using var r=c.ExecuteReader();var list=new List<AppNotification>();while(r.Read())list.Add(new AppNotification(r.GetInt64(0),r.GetString(1),r.GetString(2),DateTime.Parse(r.GetString(3)),r.GetString(4),r.GetInt32(5)!=0));return list;}
    public void AddNotification(string title,string message,string kind="info"){using var c=_db.CreateCommand();c.CommandText="INSERT INTO notifications(title,message,timestamp,kind,read) VALUES($t,$m,$ts,$k,0)";c.Parameters.AddWithValue("$t",title);c.Parameters.AddWithValue("$m",message);c.Parameters.AddWithValue("$ts",DateTime.Now.ToString("O"));c.Parameters.AddWithValue("$k",kind);c.ExecuteNonQuery();}
    public void MarkNotificationRead(long id){using var c=_db.CreateCommand();c.CommandText="UPDATE notifications SET read=1 WHERE id=$id";c.Parameters.AddWithValue("$id",id);c.ExecuteNonQuery();}
    public void MarkAllNotificationsRead(){using var c=_db.CreateCommand();c.CommandText="UPDATE notifications SET read=1";c.ExecuteNonQuery();}
    public int UnreadNotifications(){using var c=_db.CreateCommand();c.CommandText="SELECT COUNT(*) FROM notifications WHERE read=0";return Convert.ToInt32(c.ExecuteScalar());}

    public void MergeAndroidRecord(string type,string key,string payloadJson)
    {
        var allowed=new HashSet<string>(StringComparer.OrdinalIgnoreCase){"query_codes","query_records","saved_query_lists","query_history","daily_observations","sms_query_attempts","agents","agent_phones","agent_devices","profile_metadata","notifications","sync_tombstones"};
        if(!allowed.Contains(type)) throw new InvalidDataException("Unsupported Android record family.");
        if(string.IsNullOrWhiteSpace(key)||key.Length>512||payloadJson.Length>500_000) throw new InvalidDataException("Invalid Android record key or payload size.");
        using var c=_db.CreateCommand();
        c.CommandText="INSERT INTO android_records(entity_type,entity_key,payload_json,updated_at) VALUES($t,$k,$p,$u) ON CONFLICT(entity_type,entity_key) DO UPDATE SET payload_json=$p,updated_at=$u";
        c.Parameters.AddWithValue("$t",type);c.Parameters.AddWithValue("$k",key);c.Parameters.AddWithValue("$p",payloadJson);c.Parameters.AddWithValue("$u",DateTime.UtcNow.ToString("O"));c.ExecuteNonQuery();
    }
    public List<AndroidRecord> AndroidRecords(string? type=null)
    {
        using var c=_db.CreateCommand();c.CommandText="SELECT entity_type,entity_key,payload_json,updated_at FROM android_records"+(string.IsNullOrWhiteSpace(type)?"":" WHERE entity_type=$t")+" ORDER BY entity_type,entity_key";
        if(!string.IsNullOrWhiteSpace(type))c.Parameters.AddWithValue("$t",type);
        using var r=c.ExecuteReader();var rows=new List<AndroidRecord>();while(r.Read())rows.Add(new AndroidRecord(r.GetString(0),r.GetString(1),r.GetString(2),DateTime.Parse(r.GetString(3))));return rows;
    }
    public Dictionary<string,int> AndroidRecordCounts()=>AndroidRecords().GroupBy(x=>x.Type).ToDictionary(g=>g.Key,g=>g.Count());

    public void DeleteAndroidRecord(string type,string key,bool createTombstone=true){
        using var tx=_db.BeginTransaction();
        using(var c=_db.CreateCommand()){c.Transaction=tx;c.CommandText="DELETE FROM android_records WHERE entity_type=$t AND entity_key=$k";c.Parameters.AddWithValue("$t",type);c.Parameters.AddWithValue("$k",key);c.ExecuteNonQuery();}
        if(createTombstone && !type.Equals("sync_tombstones",StringComparison.OrdinalIgnoreCase)){
            var tombstoneKey=type+"|"+key;
            var payload=System.Text.Json.JsonSerializer.Serialize(new{entityType=type,entityKey=key,deletedAt=DateTimeOffset.UtcNow.ToString("O")});
            using var t=_db.CreateCommand();t.Transaction=tx;t.CommandText="INSERT INTO android_records(entity_type,entity_key,payload_json,updated_at) VALUES('sync_tombstones',$k,$p,$u) ON CONFLICT(entity_type,entity_key) DO UPDATE SET payload_json=$p,updated_at=$u";t.Parameters.AddWithValue("$k",tombstoneKey);t.Parameters.AddWithValue("$p",payload);t.Parameters.AddWithValue("$u",DateTime.UtcNow.ToString("O"));t.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public void MergeAndroidNotification(string sourceKey,string title,string message,string kind,DateTime timestamp,bool read){
        if(string.IsNullOrWhiteSpace(sourceKey)||sourceKey.Length>600)return;
        using var tx=_db.BeginTransaction(); long? id=null; string? priorStamp=null;
        using(var find=_db.CreateCommand()){find.Transaction=tx;find.CommandText="SELECT notification_id,source_timestamp FROM android_notification_map WHERE source_key=$k";find.Parameters.AddWithValue("$k",sourceKey);using var r=find.ExecuteReader();if(r.Read()){id=r.GetInt64(0);priorStamp=r.GetString(1);}}
        var stamp=timestamp.ToUniversalTime().ToString("O");
        if(id.HasValue){
            if(DateTime.TryParse(priorStamp,out var prior)&&prior.ToUniversalTime()>timestamp.ToUniversalTime()){tx.Commit();return;}
            using var u=_db.CreateCommand();u.Transaction=tx;u.CommandText="UPDATE notifications SET title=$t,message=$m,timestamp=$ts,kind=$kind,read=$read WHERE id=$id";u.Parameters.AddWithValue("$t",title);u.Parameters.AddWithValue("$m",message);u.Parameters.AddWithValue("$ts",stamp);u.Parameters.AddWithValue("$kind",kind);u.Parameters.AddWithValue("$read",read?1:0);u.Parameters.AddWithValue("$id",id.Value);u.ExecuteNonQuery();
            using var map=_db.CreateCommand();map.Transaction=tx;map.CommandText="UPDATE android_notification_map SET source_timestamp=$ts WHERE source_key=$k";map.Parameters.AddWithValue("$ts",stamp);map.Parameters.AddWithValue("$k",sourceKey);map.ExecuteNonQuery();
        }else{
            using var n=_db.CreateCommand();n.Transaction=tx;n.CommandText="INSERT INTO notifications(title,message,timestamp,kind,read) VALUES($t,$m,$ts,$kind,$read);SELECT last_insert_rowid();";n.Parameters.AddWithValue("$t",title);n.Parameters.AddWithValue("$m",message);n.Parameters.AddWithValue("$ts",stamp);n.Parameters.AddWithValue("$kind",kind);n.Parameters.AddWithValue("$read",read?1:0);var newId=Convert.ToInt64(n.ExecuteScalar());
            using var map=_db.CreateCommand();map.Transaction=tx;map.CommandText="INSERT INTO android_notification_map(source_key,notification_id,source_timestamp) VALUES($k,$id,$ts)";map.Parameters.AddWithValue("$k",sourceKey);map.Parameters.AddWithValue("$id",newId);map.Parameters.AddWithValue("$ts",stamp);map.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public bool SetAndroidNotificationRead(string sourceKey,bool read){
        using var c=_db.CreateCommand();c.CommandText="SELECT notification_id FROM android_notification_map WHERE source_key=$k";c.Parameters.AddWithValue("$k",sourceKey);var v=c.ExecuteScalar();if(v==null)return false;var id=Convert.ToInt64(v);MarkNotificationReadState(id,read);return true;
    }
    public void MarkNotificationReadState(long id,bool read){using var c=_db.CreateCommand();c.CommandText="UPDATE notifications SET read=$r WHERE id=$id";c.Parameters.AddWithValue("$r",read?1:0);c.Parameters.AddWithValue("$id",id);c.ExecuteNonQuery();}

    public static string Canonical(string id)=>Regex.Replace(id.Trim().ToUpperInvariant(),"[^A-Z0-9]","");

    public List<ReportInfo> Reports()
    {
        using var c=_db.CreateCommand();
        c.CommandText="SELECT month,coverage_start,coverage_end,source_file,imported_at,(SELECT COUNT(DISTINCT device_id) FROM hq_rows r WHERE r.month=h.month) FROM hq_months h ORDER BY month DESC";
        using var r=c.ExecuteReader(); var list=new List<ReportInfo>();
        while(r.Read()){
            var month=DateTime.Parse(r.GetString(0)+"-01");
            list.Add(new ReportInfo(r.GetString(0),month,DateTime.Parse(r.GetString(1)),DateTime.Parse(r.GetString(2)),r.GetString(3),DateTime.Parse(r.GetString(4)),r.GetInt32(5)));
        }
        return list;
    }

    public List<DeviceRow> SearchReport(DateTime month,string? query=null)
    {
        var rows=LoadMonth(month);
        if(string.IsNullOrWhiteSpace(query)) return rows;
        var q=Canonical(query);
        return rows.Where(x => Canonical(x.DeviceId).Contains(q) ||
            Canonical(x.TradeCode).Contains(q) ||
            x.PartnerName.Contains(query,StringComparison.OrdinalIgnoreCase) ||
            x.Region.Contains(query,StringComparison.OrdinalIgnoreCase) ||
            x.Cluster.Contains(query,StringComparison.OrdinalIgnoreCase) ||
            x.Territory.Contains(query,StringComparison.OrdinalIgnoreCase) ||
            x.StaffName.Contains(query,StringComparison.OrdinalIgnoreCase)).ToList();
    }

    public List<(DateTime Date,int Value)> DailyTrend(DateTime month, IEnumerable<string>? scope=null)
    {
        var allowed=scope?.Select(Canonical).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var rows=LoadMonth(month);
        return rows.SelectMany(r=>r.Daily.Select(d=>(d.Key,d.Value,r.DeviceId)))
            .Where(x=>allowed==null || allowed.Contains(Canonical(x.DeviceId)))
            .GroupBy(x=>x.Key.Date).OrderBy(x=>x.Key).Select(g=>(g.Key,g.Sum(x=>x.Value))).ToList();
    }

    public Dictionary<string,int> PartnerTotals(DateTime month)
    {
        return LoadMonth(month).GroupBy(x=>string.IsNullOrWhiteSpace(x.PartnerName)?"Unassigned":x.PartnerName)
            .OrderByDescending(g=>g.Sum(r=>r.Daily.Values.Sum()))
            .ToDictionary(g=>g.Key,g=>g.Sum(r=>r.Daily.Values.Sum()));
    }

    public List<(DateTime Date,int Value)> DeviceHistory(string deviceId, DateTime month)
    {
        var id=Canonical(deviceId);
        var row=LoadMonth(month).FirstOrDefault(x=>Canonical(x.DeviceId)==id);
        return row?.Daily.OrderBy(x=>x.Key).Select(x=>(x.Key,x.Value)).ToList() ?? new();
    }

    public void ClearOperationalData()
    {
        using var tx=_db.BeginTransaction();
        foreach(var table in new[]{"operational_tasks","operational_notes","notifications","sms_inbox"}){
            using var c=_db.CreateCommand(); c.Transaction=tx; c.CommandText=$"DELETE FROM {table}"; c.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public void Dispose()=>_db.Dispose();
}
