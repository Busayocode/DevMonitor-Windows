# DevMonitor Windows v209 — Sync/build fixes

This patch corrects compile errors reported by GitHub Actions after v208:

- Added explicit namespaces for WPF effects, file/path APIs and HTTP client APIs.
- Used `DataGridSelectionMode.Single` for WPF DataGrid selection.
- Corrected two `Children.Add` calls that passed the accent brush to `Add` instead of to `Card`.
- Preserved the SMS received timestamp when merging synced SMS, with an overload in `DevMonitorDb`.
- Kept SyncRelay C# sources excluded from the WPF app compilation; the relay remains a separate Web SDK project.

Build status: source-level corrections only. A full .NET build must be confirmed by GitHub Actions.
