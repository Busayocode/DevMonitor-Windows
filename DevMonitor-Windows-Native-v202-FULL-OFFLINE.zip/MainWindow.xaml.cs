using Microsoft.Win32;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DevMonitor.Windows;

public partial class MainWindow : Window
{
    private readonly DevMonitorDb _db=new();
    private string _page="Dashboard";
    private List<DeviceRow> _lastReport=[];
    private DateTime _reportStart,_reportEnd;

    public MainWindow()
    {
        InitializeComponent();
        // Keep the native window fully inside the usable Windows desktop area.
        // This prevents the title bar/close button being positioned off-screen
        // on smaller displays or with display scaling enabled.
        MaxWidth = SystemParameters.WorkArea.Width;
        MaxHeight = SystemParameters.WorkArea.Height;
        Width = Math.Min(Width, MaxWidth);
        Height = Math.Min(Height, MaxHeight);
        if (Width < MinWidth) MinWidth = Math.Max(800, MaxWidth);
        if (Height < MinHeight) MinHeight = Math.Max(520, MaxHeight);
        Left = Math.Max(SystemParameters.WorkArea.Left, SystemParameters.WorkArea.Left + (SystemParameters.WorkArea.Width - Width) / 2);
        Top = Math.Max(SystemParameters.WorkArea.Top, SystemParameters.WorkArea.Top + (SystemParameters.WorkArea.Height - Height) / 2);
        Render("Dashboard");
        Closed += (_,_)=>_db.Dispose();
    }

    private void Nav_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button b && b.Tag is string page) Render(page);
    }

    private void Refresh_Click(object sender,RoutedEventArgs e) { Render(_page); }

    private void Render(string page)
    {
        _page=page;
        foreach (var nav in NavPanel.Children.OfType<Button>())
        {
            nav.Background = nav.Tag is string tag && tag == page ? (Brush)FindResource("SidebarSelectedBrush") : Brushes.Transparent;
            nav.Foreground = Brushes.White;
                nav.Effect = nav.Tag is string selected && selected == page ? (Effect)FindResource("ButtonShadow") : null;
        }
        PageHost.Content=page switch {
            "Dashboard"=>Dashboard(),
            "Sms"=>SmsPage(),
            "Devices"=>DevicesPage(),
            "Report"=>ReportPage(),
            "Earnings"=>EarningsPage(),
            "Monitor"=>MonitorPage(),
            "MonthOnMonth"=>MonthOnMonthPage(),
            "Agents"=>AgentsPage(),
            "Tasks"=>TasksPage(),
            "Notes"=>NotesPage(),
            "Activity"=>ActivityPage(),
            "Inbox"=>InboxPage(),
            "Exports"=>ExportsPage(),
            "LoadedReport"=>LoadedReportPage(),
            "Trends"=>TrendsPage(),
            "ActionCentre"=>ActionCentrePage(),
            "Profile"=>ProfilePage(),
            "Exchange"=>ExchangePage(),
            "Settings"=>SettingsPage(),
            _=>Dashboard()
        };
        PageTitle.Text=page switch {
            "Sms"=>"SMS Checker","Devices"=>"My Devices","Report"=>"Load Report",
            "Earnings"=>"Earning Progress","Monitor"=>"Device Monitor","MonthOnMonth"=>"Month-on-Month","Agents"=>"Agents & Partners","Tasks"=>"Tasks & Follow-ups","Notes"=>"Notes","Activity"=>"Device Activity Timeline","Inbox"=>"Notifications / Inbox","Exports"=>"Export Centre","LoadedReport"=>"Loaded Report","Trends"=>"Trends & Insights","ActionCentre"=>"Action Centre","Profile"=>"Profile & Company","Exchange"=>"Phone Data Exchange","Settings"=>"Settings",_=>"Dashboard"
        };
        PageEyebrow.Text=page=="Dashboard"?"CONTROL CENTRE":page.ToUpperInvariant();
        FooterText.Text=$"DevMonitor Windows • Local database: {_db.FilePath}";
    }

    private Border Card(UIElement content, Brush? accent=null)
    {
        var b=new Border{Background=Brushes.White,CornerRadius=new CornerRadius(12),Padding=new Thickness(20),Margin=new Thickness(0,0,0,14),BorderBrush=(Brush)FindResource("BorderBrush"),BorderThickness=new Thickness(1),Effect=(Effect)FindResource("SoftShadow")};
        var panel=new StackPanel(); if(accent!=null) panel.Children.Add(new Border{Height=4,Background=accent,CornerRadius=new CornerRadius(4),Margin=new Thickness(0,0,0,14)});
        panel.Children.Add(content);b.Child=panel;return b;
    }
    private TextBlock H(string text,double size=20)=>new(){Text=text,FontSize=size,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("TextBrush"),Margin=new Thickness(0,0,0,7)};
    private TextBlock P(string text)=>new(){Text=text,FontSize=14,Foreground=(Brush)FindResource("MutedBrush"),TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)};
    private Button B(string text,RoutedEventHandler click){var b=new Button{Content=text,Style=(Style)FindResource("PrimaryButton")};b.Click+=click;return b;}
    private StackPanel Stack(params UIElement[] e)
    {
        var panel=new StackPanel();
        foreach(var item in e) panel.Children.Add(item);
        return panel;
    }

    private UIElement Dashboard()
    {
        var root=new StackPanel();
        var count=_db.MyDevices().Count;
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var (cs,ce)=PaymentRules.PaymentCycleForDate(today);
        root.Children.Add(Card(Stack(
            H("Good day — DevMonitor is ready",28),
            P("A native Windows workspace built from the current Android application's operational model. Everything here runs locally unless you explicitly connect a future sync service."),
            new WrapPanel{Children={
                B("SMS CHECKER",(_,_)=>Render("Sms")),
                B("MY DEVICES",(_,_)=>Render("Devices")),
                B("LOAD REPORT",(_,_)=>Render("Report")),
                B("EARNING PROGRESS",(_,_)=>Render("Earnings")),
                B("TASKS",(_,_)=>Render("Tasks")),
                B("NOTES",(_,_)=>Render("Notes")),
                B("EXPORT",(_,_)=>Render("Exports")),
                B("LOADED REPORT",(_,_)=>Render("LoadedReport")),
                B("TRENDS",(_,_)=>Render("Trends")),
                B("ACTION CENTRE",(_,_)=>Render("ActionCentre")),
                B("PHONE EXCHANGE",(_,_)=>Render("Exchange"))
            }}
        ),(Brush)FindResource("AccentBrush")));
        root.Children.Add(new UniformGrid{Columns=4,Children={
            Metric("MY DEVICES",count.ToString()),
            Metric("PAYMENT CYCLE",$"{cs:dd MMM} → {ce:dd MMM}"),
            Metric("CURRENT MONTH",today.ToString("MMMM yyyy")),
            Metric("PREVIOUS MONTH",today.AddMonths(-1).ToString("MMMM yyyy")),
            Metric("OPEN TASKS",_db.Tasks(false).Count.ToString()),
            Metric("UNREAD ALERTS",_db.UnreadNotifications().ToString()),
            Metric("PHONE RESULTS",_db.PhoneResults().Count.ToString())
        }});
        root.Children.Add(Card(Stack(
            H("Current architecture"),
            P("HQ reports are authoritative monthly snapshots. Windows keeps only the current and immediately previous calendar-month stores, imports are Replace All for a month, and import does not silently recalculate downstream screens."),
            B("Open Settings",(_,_)=>Render("Settings"))
        ),Brushes.SteelBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private Border Metric(string title,string value)
    {
        var s=Stack(new TextBlock{Text=title,FontSize=11,FontWeight=FontWeights.Bold,Foreground=(Brush)FindResource("MutedBrush")},
            new TextBlock{Text=value,FontSize=21,FontWeight=FontWeights.Bold,Margin=new Thickness(0,6,0,0)});
        return new Border{Child=s,Background=Brushes.White,Padding=new Thickness(18),Margin=new Thickness(0,0,12,14),CornerRadius=new CornerRadius(12),BorderBrush=(Brush)FindResource("BorderBrush"),BorderThickness=new Thickness(1)};
    }

    private UIElement DevicesPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        root.Children.Add(Card(Stack(H("Your working device set"),P("The Windows version keeps a separate, user-scoped working set. Updating this list never deletes authoritative HQ history."),
            B("Replace My Devices",(_,_)=>EditDevices())) ,Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=480,ItemsSource=ids.Select(x=>new{Device=x}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void EditDevices()
    {
        var w=new Window{Title="Update My Devices",Width=520,Height=430,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var box=new TextBox{AcceptsReturn=true,Text=string.Join(Environment.NewLine,_db.MyDevices()),VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(15)};
        var save=new Button{Content="Save device list",Margin=new Thickness(15),Padding=new Thickness(12)};
        save.Click+=(_,_)=>{_db.ReplaceMyDevices(box.Text.Split(new[]{"\r\n","\n"},StringSplitOptions.RemoveEmptyEntries));w.DialogResult=true;w.Close();Render("Devices");};
        w.Content=new DockPanel{Children={box,save}};DockPanel.SetDock(save,Dock.Bottom);w.ShowDialog();
    }

    private UIElement ReportPage()
    {
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("HQ / SIMReg report import"),P("Choose an Excel report. The first worksheet is parsed into a normalized device/day model. Only the current calendar month or immediately previous month may be stored."),
            B("Choose Excel Report",ImportReport)),Brushes.MediumPurple));
        if(_lastReport.Count>0) root.Children.Add(Card(Stack(
            H($"Loaded report: {_lastReport.Count:N0} devices"),
            P($"Coverage: {_reportStart:yyyy-MM-dd} → {_reportEnd:yyyy-MM-dd}. This is a validated in-memory view; use Store Month to commit it to the local authoritative monthly snapshot."),
            B("Store Month Snapshot",StoreReport)),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void ImportReport(object? s,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="Excel reports|*.xlsx;*.xlsm|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            StatusText.Text="Reading report…";
            _lastReport=ReportImporter.Read(dlg.FileName,out _reportStart,out _reportEnd);
            _db.SetSetting("last_report_file",dlg.FileName);
            StatusText.Text=$"Loaded {_lastReport.Count:N0} devices";
            Render("Report");
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"DevMonitor",MessageBoxButton.OK,MessageBoxImage.Error);StatusText.Text="Import failed";}
    }
    private void StoreReport(object? s,RoutedEventArgs e)
    {
        var month=new DateTime(_reportStart.Year,_reportStart.Month,1);
        var current=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=current.AddMonths(-1);
        if(month!=current && month!=previous){MessageBox.Show(this,"Only the current and immediately previous calendar month can be stored.","DevMonitor");return;}
        var old=_db.StoredCoverageEnd(month);
        if(old.HasValue && _reportEnd<old.Value){MessageBox.Show(this,$"Older report rejected. Stored coverage ends {old:yyyy-MM-dd}.","DevMonitor");return;}
        var source=_db.GetSetting("last_report_file")??"Imported report";
        _db.ReplaceMonthSnapshot(month,_reportStart,_reportEnd,source,_lastReport);
        _db.AddNotification("Report imported",$"{month:MMMM yyyy} snapshot stored through {_reportEnd:dd MMM yyyy}.","success");
        MessageBox.Show(this,"Monthly snapshot stored. Downstream calculations were not automatically refreshed.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
        Render("Report");
    }

    private UIElement EarningsPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var total=snapshots.Sum(x=>x.Active);
        var sundays=0;
        var estimate=PaymentRules.Estimate(total,sundays);
        root.Children.Add(Card(Stack(H("Earning Progress"),P($"Payment cycle: {PaymentRules.PaymentCycleLabel(DateTime.Today)}"),
            new TextBlock{Text=total.ToString("N0"),FontSize=44,FontWeight=FontWeights.Bold},
            P("Current cycle activations — Active remains the payment/progression input."),
            new TextBlock{Text=$"Estimated subtotal: ₦{estimate.Subtotal:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            P($"Fixed tier: ₦{estimate.FixedReward:N0} • Recharge estimate: ₦{estimate.RechargeBonus:N0} • Sunday bonus: ₦{estimate.SundayBonus:N0}"),
            P(estimate.NextThreshold.HasValue?$"{estimate.ActivationsToNext:N0} activations to the next tier ({estimate.NextThreshold:N0}).":"Highest configured tier reached.")
        ),Brushes.MediumSeaGreen));
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=430,ItemsSource=snapshots.Select(x=>new{Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Status=x.Flag??"OK"}).ToList()};
        root.Children.Add(grid);
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonitorPage()
    {
        var root=new StackPanel();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        root.Children.Add(Card(Stack(
            H("Device Monitor"),
            P("Current device activity from the authoritative monthly HQ snapshots. Payment calculations continue to use Active, not MTD."),
            new TextBlock{Text=$"Devices: {snapshots.Count:N0}",FontSize=24,FontWeight=FontWeights.Bold},
            B("Refresh Device Monitor",(_,_)=>Render("Monitor"))
        ),Brushes.SteelBlue));
        root.Children.Add(new DataGrid{ItemsSource=snapshots.Select(x=>new{
            Device=x.DeviceId,Today=x.Today,MTD=x.Mtd,Active=x.Active,Ownership=x.Ownership,Status=x.Flag??"OK"
        }).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=480});
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement MonthOnMonthPage()
    {
        var root=new StackPanel();
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var currentMonth=new DateTime(today.Year,today.Month,1);
        var previousMonth=currentMonth.AddMonths(-1);
        var currentRows=_db.LoadMonth(currentMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var previousRows=_db.LoadMonth(previousMonth).ToDictionary(x=>DevMonitorDb.Canonical(x.DeviceId),StringComparer.OrdinalIgnoreCase);
        var ids=_db.MyDevices().Select(DevMonitorDb.Canonical).ToList();
        var currentEnd=_db.StoredCoverageEnd(currentMonth);
        var previousEnd=_db.StoredCoverageEnd(previousMonth);
        var currentCutoff=Math.Min(today.Day,currentEnd?.Day??0);
        var previousCutoff=Math.Min(currentCutoff,previousEnd?.Day??0);
        var data=new List<object>();
        foreach(var id in ids){
            currentRows.TryGetValue(id,out var c); previousRows.TryGetValue(id,out var p);
            var cur=c?.Daily.Where(k=>k.Key.Month==today.Month&&k.Key.Year==today.Year&&k.Key.Day<=currentCutoff).Sum(k=>k.Value)??0;
            var prev=p?.Daily.Where(k=>k.Key.Month==previousMonth.Month&&k.Key.Year==previousMonth.Year&&k.Key.Day<=previousCutoff).Sum(k=>k.Value)??0;
            data.Add(new{Device=id,Current=cur,Previous=prev,Change=cur-prev});
        }
        root.Children.Add(Card(Stack(
            H("Month-on-Month"),
            P($"User-scoped comparison through the available report cutoff. Current cutoff: day {currentCutoff}; previous-month cutoff: day {previousCutoff}. Missing historical coverage is not treated as zero."),
            new TextBlock{Text=$"Current: {currentMonth:MMMM yyyy}  •  Previous: {previousMonth:MMMM yyyy}",FontSize=18,FontWeight=FontWeights.Bold},
            B("Refresh comparison",(_,_)=>Render("MonthOnMonth"))
        ),Brushes.MediumPurple));
        root.Children.Add(new DataGrid{ItemsSource=data,IsReadOnly=true,AutoGenerateColumns=true,Height=480});
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement SmsPage()
    {
        var root=new StackPanel();
        var code=new TextBox{Height=38,Width=220};
        var status=new ComboBox{ItemsSource=new[]{"OK","ERROR","PENDING"},SelectedIndex=0,Height=38,Width=140,Margin=new Thickness(8,0,8,0)};
        var today=new TextBox{Height=38,Width=90}; var mtd=new TextBox{Height=38,Width=90}; var active=new TextBox{Height=38,Width=90};
        var b48=new TextBox{Height=38,Width=90}; var b96=new TextBox{Height=38,Width=90};
        root.Children.Add(Card(Stack(
            H("SMS Checker"),
            P("Windows cannot directly receive an Android SIM's SMS. It can, however, store and use results delivered from the phone app or pasted/imported locally. No SMS is sent from Windows."),
            new WrapPanel{Children={
                new TextBlock{Text="Device",VerticalAlignment=VerticalAlignment.Center},code,
                new TextBlock{Text="Status",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(12,0,0,0)},status
            }},
            new WrapPanel{Children={
                new TextBlock{Text="Today",VerticalAlignment=VerticalAlignment.Center},today,
                new TextBlock{Text="MTD",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},mtd,
                new TextBlock{Text="Active",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},active,
                new TextBlock{Text="48h",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},b48,
                new TextBlock{Text="96h",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,0,0)},b96
            }},
            B("Store phone result",(_,_)=>{
                if(string.IsNullOrWhiteSpace(code.Text)){MessageBox.Show(this,"Enter a device code.");return;}
                int? Num(string x)=>int.TryParse(x,out var n)?n:null;
                _db.SavePhoneResult(new PhoneQueryResult(DevMonitorDb.Canonical(code.Text),status.SelectedItem?.ToString()??"OK",Num(today.Text),Num(mtd.Text),Num(active.Text),Num(b48.Text),Num(b96.Text),DateTime.UtcNow,"Manual/local phone result"));
                _db.AddNotification("Phone result stored",$"Result stored for {DevMonitorDb.Canonical(code.Text)}.","sms");
                Render("Sms");
            })
        ),Brushes.SteelBlue));

        var phone=_db.PhoneResults();
        root.Children.Add(Card(Stack(
            H($"Stored phone results ({phone.Count:N0})",18),
            P("These results remain available offline and Device Monitor will prefer a phone result when it is newer than the stored HQ report."),
            new DataGrid{ItemsSource=phone.Take(200).Select(x=>new{Device=x.DeviceId,Status=x.Status,Today=x.Today,MTD=x.Mtd,Active=x.Active,Bar48=x.Bar48,Bar96=x.Bar96,Received=x.ResultAt.ToLocalTime().ToString("dd MMM yyyy HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=420}
        ),Brushes.SteelBlue));

        var sms=_db.Sms();
        root.Children.Add(Card(Stack(
            H($"Raw SMS history ({sms.Count:N0})",18),
            P("Raw SMS records are retained for audit/review. They are not required for Windows calculations once a structured phone result has been stored."),
            new DataGrid{ItemsSource=sms.Select(x=>new{Received=x.Received.ToString("yyyy-MM-dd HH:mm"),Sender=x.Sender,Body=x.Body}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=300}
        )));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement AgentsPage()
    {
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(month);
        var groups=rows.GroupBy(r=>string.IsNullOrWhiteSpace(r.PartnerName)?"Unassigned":r.PartnerName).Select(g=>new{Partner=g.Key,Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Region=string.Join(", ",g.Select(x=>x.Region).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Take(3)),Activations=g.Sum(x=>x.Daily.Where(d=>d.Key.Month==month.Month&&d.Key.Year==month.Year).Sum(d=>d.Value))}).OrderByDescending(x=>x.Activations).ToList();
        var root=new StackPanel();root.Children.Add(Card(Stack(H("Agents & Partners"),P("A working management view derived from the authoritative HQ report. Partner/device counts and current-month activity update whenever the report snapshot is refreshed."),H($"{groups.Count} partner groups",17),new WrapPanel{Children={B("Open My Devices",(_,_)=>Render("Devices")),B("Open Device Monitor",(_,_)=>Render("Monitor")),B("Create follow-up",(_,_)=>Render("Tasks"))}}),Brushes.CadetBlue));
        root.Children.Add(Card(new DataGrid{ItemsSource=groups,IsReadOnly=true,AutoGenerateColumns=true,Height=430},Brushes.CadetBlue));return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement TasksPage()
    {
        var root=new StackPanel(); var tasks=_db.Tasks();
        root.Children.Add(Card(Stack(H("Tasks & Follow-ups"),P("Create persistent operational follow-ups and optionally link them to a device, partner or staff member."),
            B("Add Task",(_,_)=>TaskEditor(null))),Brushes.MediumSeaGreen));
        root.Children.Add(Card(Stack(H($"Open: {tasks.Count(x=>!x.Completed)}  •  Completed: {tasks.Count(x=>x.Completed)}",17),
            new DataGrid{ItemsSource=tasks.Select(t=>new{Id=t.Id,Task=t.Title,Priority=t.Priority,Due=t.DueDate??"—",Link=t.LinkValue??"—",Status=t.Completed?"Done":"Open",Updated=t.UpdatedAt.ToLocalTime().ToString("dd MMM HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=390,SelectionMode=SelectionMode.Single}),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void TaskEditor(OperationalTask? existing)
    {
        var w=new Window{Title=existing==null?"New Follow-up":"Edit Follow-up",Width=560,Height=520,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var title=new TextBox{Text=existing?.Title??""}; var details=new TextBox{Text=existing?.Details??"",AcceptsReturn=true,Height=100,TextWrapping=TextWrapping.Wrap};
        var due=new TextBox{Text=existing?.DueDate??"",ToolTip="Optional: YYYY-MM-DD"}; var priority=new ComboBox{ItemsSource=new[]{"LOW","NORMAL","HIGH"},SelectedItem=existing?.Priority??"NORMAL",Margin=new Thickness(0,5,0,9),Height=40};
        var link=new TextBox{Text=existing?.LinkValue??"",ToolTip="Optional device / partner / staff reference"};
        var save=B("Save Task",(_,_)=>{if(string.IsNullOrWhiteSpace(title.Text)){MessageBox.Show(w,"Task title is required.");return;} if(!string.IsNullOrWhiteSpace(due.Text)&&!DateTime.TryParse(due.Text,out _)){MessageBox.Show(w,"Use a valid date such as 2026-10-31.");return;} _db.SaveTask(new OperationalTask(existing?.Id??0,title.Text,details.Text,string.IsNullOrWhiteSpace(due.Text)?null:due.Text,(priority.SelectedItem?.ToString()??"NORMAL"),string.IsNullOrWhiteSpace(link.Text)?null:"REFERENCE",string.IsNullOrWhiteSpace(link.Text)?null:link.Text,existing?.Completed??false,existing?.CreatedAt??DateTime.UtcNow,DateTime.UtcNow));_db.AddNotification("Task saved",title.Text,"task");w.DialogResult=true;w.Close();Render("Tasks");});
        var close=B("Cancel",(_,_)=>w.Close()); var panel=Stack(H(existing==null?"New follow-up":"Edit follow-up",22),new TextBlock{Text="Task title"},title,new TextBlock{Text="Details"},details,new TextBlock{Text="Due date"},due,new TextBlock{Text="Priority"},priority,new TextBlock{Text="Linked reference (optional)"},link,new WrapPanel{Children={save,close}});w.Content=new ScrollViewer{Content=panel};w.ShowDialog();
    }

    private UIElement NotesPage()
    {
        var notes=_db.Notes(); var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Notes"),P("Keep durable operational notes alongside your device and report work. Pin important notes so they stay at the top."),B("Add Note",(_,_)=>NoteEditor(null))),Brushes.MediumPurple));
        root.Children.Add(Card(Stack(H($"{notes.Count} saved notes",17),new DataGrid{ItemsSource=notes.Select(n=>new{Id=n.Id,Title=n.Title,Preview=n.Body.Length>100?n.Body[..100]+"…":n.Body,Pinned=n.Pinned?"Pinned":"",Updated=n.UpdatedAt.ToLocalTime().ToString("dd MMM HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=420}),Brushes.MediumPurple));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }
    private void NoteEditor(OperationalNote? existing)
    {
        var w=new Window{Title=existing==null?"New Note":"Edit Note",Width=620,Height=500,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var title=new TextBox{Text=existing?.Title??""};var body=new TextBox{Text=existing?.Body??"",AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,Height=220};var pinned=new CheckBox{Content="Pin this note",IsChecked=existing?.Pinned??false,Margin=new Thickness(0,8,0,12)};
        var save=B("Save Note",(_,_)=>{if(string.IsNullOrWhiteSpace(body.Text)){MessageBox.Show(w,"Note body is required.");return;}_db.SaveNote(new OperationalNote(existing?.Id??0,title.Text,body.Text,null,null,pinned.IsChecked==true,existing?.CreatedAt??DateTime.UtcNow,DateTime.UtcNow));w.DialogResult=true;w.Close();Render("Notes");});
        var cancel=B("Cancel",(_,_)=>w.Close());w.Content=Stack(H(existing==null?"New note":"Edit note",22),new TextBlock{Text="Title (optional)"},title,new TextBlock{Text="Note"},body,pinned,new WrapPanel{Children={save,cancel}});w.ShowDialog();
    }

    private UIElement ActivityPage()
    {
        var ids=_db.MyDevices();var selected=ids.FirstOrDefault()??"";var root=new StackPanel();
        var combo=new ComboBox{ItemsSource=ids,SelectedItem=selected,MinWidth=260,Height=40,Margin=new Thickness(0,5,8,9)};
        var grid=new DataGrid{IsReadOnly=true,AutoGenerateColumns=true,Height=500};
        void Load(){var id=combo.SelectedItem?.ToString()??"";var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(month).FirstOrDefault(x=>DevMonitorDb.Canonical(x.DeviceId)==DevMonitorDb.Canonical(id));var events=new List<object>();if(rows!=null)foreach(var d in rows.Daily.OrderByDescending(x=>x.Key))events.Add(new{Date=d.Key.ToString("dd MMM yyyy"),Type="OBSERVATION",Event="SIMReg",Details=$"Value {d.Value:N0}"});foreach(var t in _db.Tasks().Where(t=>string.Equals(t.LinkValue,id,StringComparison.OrdinalIgnoreCase)))events.Add(new{Date=t.UpdatedAt.ToLocalTime().ToString("dd MMM yyyy"),Type="TASK",Event=t.Completed?"Task completed":"Task updated",Details=t.Title});foreach(var n in _db.Notes().Where(n=>string.Equals(n.LinkValue,id,StringComparison.OrdinalIgnoreCase)))events.Add(new{Date=n.UpdatedAt.ToLocalTime().ToString("dd MMM yyyy"),Type="NOTE",Event="Note updated",Details=n.Title});grid.ItemsSource=events.OrderByDescending(x=>x.GetType().GetProperty("Date")?.GetValue(x)?.ToString()).ToList();}
        combo.SelectionChanged+=(_,_)=>Load();
        root.Children.Add(Card(Stack(H("Device Activity Timeline"),P("A chronological view combining imported HQ observations with linked operational work."),new WrapPanel{Children={new TextBlock{Text="Device",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,8,0)},combo,B("Refresh timeline",(_,_)=>Load())}}),Brushes.SteelBlue));root.Children.Add(Card(grid),Brushes.SteelBlue);Load();return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement InboxPage()
    {
        var notes=_db.Notifications();var root=new StackPanel();root.Children.Add(Card(Stack(H("Notifications / Inbox"),P("Local operational alerts generated by imports and workflow actions."),new WrapPanel{Children={B("Mark all read",(_,_)=>{_db.MarkAllNotificationsRead();Render("Inbox");}),B("Clear view",(_,_)=>Render("Inbox"))}}),Brushes.Orange));
        root.Children.Add(Card(new DataGrid{ItemsSource=notes.Select(n=>new{Id=n.Id,When=n.Timestamp.ToLocalTime().ToString("dd MMM yyyy HH:mm"),Type=n.Kind,Title=n.Title,Message=n.Message,Status=n.Read?"Read":"Unread"}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=520}),Brushes.Orange);return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ExportsPage()
    {
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=Card(Stack(H("Export Centre"),P("Create user-controlled CSV files from the current local data. Export never changes calculations or the database."),
            B("Export My Devices",(_,_)=>ExportMyDevices()),B("Export Device Monitor",(_,_)=>ExportMonitor()),B("Export Current Month",(_,_)=>ExportMonth()),B("Export Tasks & Notes",(_,_)=>ExportOperations())),Brushes.DarkCyan)};
    }
    private void SaveCsv(string suggested,string header,IEnumerable<string> lines){var dlg=new SaveFileDialog{Filter="CSV files|*.csv",FileName=suggested};if(dlg.ShowDialog()!=true)return;File.WriteAllText(dlg.FileName,header+Environment.NewLine+string.Join(Environment.NewLine,lines));StatusText.Text=$"Exported {Path.GetFileName(dlg.FileName)}";}
    private static string Csv(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
    private void ExportMyDevices()=>SaveCsv("DevMonitor_MyDevices.csv","Device",_db.MyDevices().Select(Csv));
    private void ExportMonitor()=>SaveCsv("DevMonitor_DeviceMonitor.csv","Device,Today,MTD,Active,Status",_db.DeviceSnapshots(_db.MyDevices(),DateTime.Today).Select(x=>$"{Csv(x.DeviceId)},{x.Today},{x.Mtd},{x.Active},{Csv(x.Flag??"OK")}"));
    private void ExportMonth(){var m=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);var rows=_db.LoadMonth(m);SaveCsv($"DevMonitor_{m:yyyy_MM}.csv","Device,Date,Value,Partner,Region,Cluster,Staff",rows.SelectMany(r=>r.Daily.Select(d=>$"{Csv(r.DeviceId)},{d.Key:yyyy-MM-dd},{d.Value},{Csv(r.PartnerName)},{Csv(r.Region)},{Csv(r.Cluster)},{Csv(r.StaffName)}")));}
    private void ExportOperations(){SaveCsv("DevMonitor_Operations.csv","Type,Title,Details,DueOrUpdated,Status",_db.Tasks().Select(t=>$"TASK,{Csv(t.Title)},{Csv(t.Details)},{Csv(t.DueDate??t.UpdatedAt.ToString("yyyy-MM-dd"))},{t.Completed}").Concat(_db.Notes().Select(n=>$"NOTE,{Csv(n.Title)},{Csv(n.Body)},{n.UpdatedAt:yyyy-MM-dd},")));}


    private UIElement LoadedReportPage()
    {
        var root=new StackPanel();
        var reports=_db.Reports();
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var previous=month.AddMonths(-1);
        var selected=reports.FirstOrDefault()?.Month ?? month;
        var combo=new ComboBox{ItemsSource=reports.Select(r=>$"{r.Month:MMMM yyyy} • {r.CoverageStart:dd MMM}–{r.CoverageEnd:dd MMM} • {r.DeviceCount:N0} devices").ToList(),SelectedIndex=0,MinWidth=420,Height=38};
        var search=new TextBox{Width=300,Height=38,Margin=new Thickness(8,0,8,0),ToolTip="Device, partner, region, staff or trade code"};
        var grid=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,Height=520};
        void Load()
        {
            var info=reports.ElementAtOrDefault(combo.SelectedIndex);
            if(info==null){grid.ItemsSource=null;return;}
            var rows=_db.SearchReport(info.Month,search.Text);
            grid.ItemsSource=rows.Select(r=>new {
                Device=r.DeviceId,TradeCode=r.TradeCode,Partner=r.PartnerName,Cluster=r.Cluster,
                Region=r.Region,Territory=r.Territory,Staff=r.StaffName,
                Days=r.Daily.Count,Total=r.Daily.Values.Sum()
            }).ToList();
            StatusText.Text=$"{rows.Count:N0} report rows";
        }
        search.KeyDown+=(o,e)=>{if(e.Key==System.Windows.Input.Key.Enter)Load();};
        combo.SelectionChanged+=(o,e)=>Load();
        root.Children.Add(Card(Stack(
            H("Loaded Report"),
            P("The complete imported monthly snapshot remains available offline. Search is local and does not require the internet. The report itself remains authoritative; presentation filtering never deletes data."),
            new WrapPanel{Children={
                new TextBlock{Text="Report",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,8,0)},
                combo,search,B("Search",(_,_)=>Load()),
                B("Show All",(_,_)=>{search.Clear();Load();})
            }},
            H("Available snapshots",17)
        ),Brushes.MediumPurple));
        root.Children.Add(Card(grid),Brushes.MediumPurple);
        Load();
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement TrendsPage()
    {
        var root=new StackPanel();
        var today=PaymentRules.CurrentAwareDate(DateTime.Today);
        var cm=new DateTime(today.Year,today.Month,1);
        var pm=cm.AddMonths(-1);
        var current=_db.DailyTrend(cm,_db.MyDevices());
        var previous=_db.DailyTrend(pm,_db.MyDevices());
        var curTotal=current.Sum(x=>x.Value); var prevTotal=previous.Sum(x=>x.Value);
        var delta=curTotal-prevTotal;
        var pct=prevTotal==0?null:(double?)delta/prevTotal*100.0;
        var partner=_db.PartnerTotals(cm).Take(12).Select(x=>new{Partner=x.Key,Activations=x.Value}).ToList();
        root.Children.Add(new UniformGrid{Columns=4,Children={
            Metric("CURRENT MTD",curTotal.ToString("N0")),
            Metric("PREVIOUS PERIOD",prevTotal.ToString("N0")),
            Metric("CHANGE",delta>=0?$"+{delta:N0}":delta.ToString("N0")),
            Metric("CHANGE %",pct.HasValue?$"{pct:+0.0;-0.0;0.0}%":"—")
        }});
        root.Children.Add(Card(Stack(
            H("7-day / 30-day operating trend"),
            P("Report-aware trends are calculated from the locally stored HQ snapshots. Missing future report days are never interpreted as zero."),
            new DataGrid{ItemsSource=current.Select(x=>new{Date=x.Date.ToString("dd MMM"),Activations=x.Value}).TakeLast(30).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=300}
        ),Brushes.SteelBlue));
        root.Children.Add(Card(Stack(H("Partner performance",18),new DataGrid{ItemsSource=partner,IsReadOnly=true,AutoGenerateColumns=true,Height=300}),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ActionCentrePage()
    {
        var open=_db.Tasks(false);
        var unread=_db.Notifications().Where(x=>!x.Read).ToList();
        var ids=_db.MyDevices();
        var snapshots=_db.DeviceSnapshots(ids,DateTime.Today);
        var flagged=snapshots.Where(x=>!string.IsNullOrWhiteSpace(x.Flag)).ToList();
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Action Centre"),P("Prioritized offline actions from tasks, alerts and device/report exceptions."),
            new UniformGrid{Columns=3,Children={Metric("OPEN TASKS",open.Count.ToString()),Metric("UNREAD ALERTS",unread.Count.ToString()),Metric("FLAGGED DEVICES",flagged.Count.ToString())}}
        ),Brushes.Orange));
        if(open.Count>0) root.Children.Add(Card(Stack(H("Tasks requiring attention",18),new DataGrid{ItemsSource=open.Take(20).Select(t=>new{Task=t.Title,Priority=t.Priority,Due=t.DueDate??"—",Reference=t.LinkValue??"—"}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Tasks",(_,_)=>Render("Tasks"))),Brushes.MediumSeaGreen));
        if(unread.Count>0) root.Children.Add(Card(Stack(H("Unread notifications",18),new DataGrid{ItemsSource=unread.Take(20).Select(n=>new{When=n.Timestamp.ToLocalTime().ToString("dd MMM HH:mm"),Title=n.Title,Message=n.Message,Type=n.Kind}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Inbox",(_,_)=>Render("Inbox"))),Brushes.Orange));
        if(flagged.Count>0) root.Children.Add(Card(Stack(H("Device exceptions",18),new DataGrid{ItemsSource=flagged.Select(x=>new{Device=x.DeviceId,Status=x.Flag,Active=x.Active,MTD=x.Mtd}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=260},B("Open Device Monitor",(_,_)=>Render("Monitor"))),Brushes.IndianRed));
        if(open.Count==0&&unread.Count==0&&flagged.Count==0) root.Children.Add(Card(Stack(H("All clear",22),P("There are no outstanding local actions or exceptions.")),Brushes.MediumSeaGreen));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ProfilePage()
    {
        var profile=new LocalProfile(
            _db.GetSetting("profile_name")??"Windows User",
            _db.GetSetting("profile_role")??"AGENT",
            _db.GetSetting("profile_partner")??"",
            _db.GetSetting("profile_region")??"",
            _db.GetSetting("profile_territory")??"",
            _db.GetSetting("profile_staff")??"");
        var name=new TextBox{Text=profile.Name};var role=new ComboBox{ItemsSource=new[]{"AGENT","PARTNER","STAFF"},SelectedItem=profile.Role,Height=38};
        var partner=new TextBox{Text=profile.Partner};var region=new TextBox{Text=profile.Region};var territory=new TextBox{Text=profile.Territory};var staff=new TextBox{Text=profile.Staff};
        var root=new StackPanel();
        root.Children.Add(Card(Stack(H("Profile & Company"),P("The Windows edition keeps its own local profile and derives management views from the imported HQ report. Profile settings work offline."),
            new TextBlock{Text="Name"},name,new TextBlock{Text="Role"},role,new TextBlock{Text="Partner / company"},partner,new TextBlock{Text="Region"},region,new TextBlock{Text="Territory"},territory,new TextBlock{Text="Staff / manager"},staff,
            B("Save profile",(_,_)=>{_db.SetSetting("profile_name",name.Text.Trim());_db.SetSetting("profile_role",role.SelectedItem?.ToString()??"AGENT");_db.SetSetting("profile_partner",partner.Text.Trim());_db.SetSetting("profile_region",region.Text.Trim());_db.SetSetting("profile_territory",territory.Text.Trim());_db.SetSetting("profile_staff",staff.Text.Trim());_db.AddNotification("Profile updated","Local profile changes saved.","profile");StatusText.Text="Profile saved";})
        ),Brushes.CadetBlue));
        var month=new DateTime(DateTime.Today.Year,DateTime.Today.Month,1);
        var rows=_db.LoadMonth(month);
        var hierarchy=rows.GroupBy(x=>string.IsNullOrWhiteSpace(x.Region)?"Unassigned region":x.Region).Select(g=>new{
            Region=g.Key,Partners=g.Select(x=>x.PartnerName).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Clusters=g.Select(x=>x.Cluster).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Staff=g.Select(x=>x.StaffName).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().Count(),
            Devices=g.Select(x=>x.DeviceId).Distinct().Count(),Activations=g.Sum(x=>x.Daily.Values.Sum())
        }).OrderByDescending(x=>x.Activations).ToList();
        root.Children.Add(Card(Stack(H("Company skeleton",18),P("Region → partner → cluster → staff/device relationships are reconstructed locally from the loaded HQ snapshot."),
            new DataGrid{ItemsSource=hierarchy,IsReadOnly=true,AutoGenerateColumns=true,Height=350}
        ),Brushes.CadetBlue));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private UIElement ExchangePage()
    {
        var results=_db.PhoneResults();
        var root=new StackPanel();
        root.Children.Add(Card(Stack(
            H("Phone Data Exchange"),
            P("Move locally stored results between the Android and Windows apps without requiring both apps to be online. This is a transport package, not live synchronization. It can carry My Devices, phone query results, tasks, notes, notifications and SMS history."),
            B("Import phone package",ImportExchange),
            B("Export Windows package",ExportExchange),
            H($"Stored phone results: {results.Count:N0}",18),
            P(results.Count==0?"No phone query results have been imported yet.":"The latest phone results are retained locally and can be used while offline.")
        ),Brushes.DarkCyan));
        if(results.Count>0) root.Children.Add(Card(new DataGrid{ItemsSource=results.Take(100).Select(x=>new{Device=x.DeviceId,Status=x.Status,Today=x.Today,MTD=x.Mtd,Active=x.Active,At=x.ResultAt.ToLocalTime().ToString("dd MMM yyyy HH:mm")}).ToList(),IsReadOnly=true,AutoGenerateColumns=true,Height=400},Brushes.DarkCyan));
        return new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};
    }

    private sealed class ExchangeDto
    {
        public string Version {get;set;}="1";
        public string CreatedAt {get;set;}=DateTime.UtcNow.ToString("O");
        public List<string> MyDevices {get;set;}=[];
        public List<PhoneQueryResult> PhoneResults {get;set;}=[];
        public List<OperationalTask> Tasks {get;set;}=[];
        public List<OperationalNote> Notes {get;set;}=[];
        public List<AppNotification> Notifications {get;set;}=[];
        public List<SmsDto> Sms {get;set;}=[];
    }
    private sealed class SmsDto { public string Sender {get;set;}=""; public string Body {get;set;}=""; public DateTime Received {get;set;} }

    private void ExportExchange(object? sender,RoutedEventArgs e)
    {
        var dto=new ExchangeDto{
            MyDevices=_db.MyDevices(),PhoneResults=_db.PhoneResults(),Tasks=_db.Tasks(),Notes=_db.Notes(),Notifications=_db.Notifications(),
            Sms=_db.Sms().Select(x=>new SmsDto{Sender=x.Sender,Body=x.Body,Received=x.Received}).ToList()
        };
        var dlg=new SaveFileDialog{Filter="DevMonitor data package|*.dmdata",FileName=$"DevMonitor-Phone-Exchange-{DateTime.Now:yyyyMMdd-HHmm}.dmdata"};
        if(dlg.ShowDialog()!=true)return;
        File.WriteAllText(dlg.FileName,JsonSerializer.Serialize(dto,new JsonSerializerOptions{WriteIndented=true}));
        StatusText.Text=$"Exported {Path.GetFileName(dlg.FileName)}";
        _db.AddNotification("Data package exported",Path.GetFileName(dlg.FileName),"exchange");
    }

    private void ImportExchange(object? sender,RoutedEventArgs e)
    {
        var dlg=new OpenFileDialog{Filter="DevMonitor data package|*.dmdata;*.json|All files|*.*"};
        if(dlg.ShowDialog()!=true)return;
        try{
            var dto=JsonSerializer.Deserialize<ExchangeDto>(File.ReadAllText(dlg.FileName),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
            if(dto==null)throw new InvalidDataException("The package could not be read.");
            if(dto.MyDevices.Count>0)_db.ReplaceMyDevices(dto.MyDevices);
            foreach(var q in dto.PhoneResults)_db.SavePhoneResult(q);
            foreach(var t in dto.Tasks)_db.SaveTask(t with {Id=0});
            foreach(var n in dto.Notes)_db.SaveNote(n with {Id=0});
            foreach(var n in dto.Notifications)_db.AddNotification(n.Title,n.Message,n.Kind);
            foreach(var sms in dto.Sms)_db.AddSms(sms.Sender,sms.Body);
            _db.AddNotification("Phone data imported",$"{dto.PhoneResults.Count:N0} stored phone results imported from {Path.GetFileName(dlg.FileName)}.","exchange");
            MessageBox.Show(this,"Phone data package imported. The data is now available offline.","DevMonitor",MessageBoxButton.OK,MessageBoxImage.Information);
            Render("Exchange");
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"Data package import failed",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    private UIElement SettingsPage()=>new ScrollViewer{Content=Card(Stack(H("Settings"),P("Desktop settings are local and offline-first. Cloud account, backup and Android/Windows synchronization are deliberately isolated from core calculations."),
        H("Local data",17),P($"Database: {_db.FilePath}"),H("Payment rules",17),P("Payment/progression rules are ported from the supplied Android source and remain separate from report-import UI."),H("Two-month HQ store",17),P("Only the current and immediately previous calendar months are accepted. Older coverage is rejected; same or newer coverage replaces the month's complete snapshot.")),Brushes.Gray)};

    protected override void OnClosed(EventArgs e){base.OnClosed(e);_db.Dispose();}
}
