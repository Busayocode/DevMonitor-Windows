# DevMonitor Windows Native v183 — Feature Expansion

This build continues from v182 and adds persistent operational features aligned with the Android application: Tasks & Follow-ups, Notes, Device Activity Timeline, Notifications/Inbox, management-oriented Agents & Partners reporting, and a local CSV Export Centre.

The payment engine and two-month HQ snapshot architecture are unchanged. The new operational tables are local SQLite tables and do not alter HQ calculations.

## v183 changes
- Persistent Tasks & Follow-ups with due date, priority and completion state.
- Persistent Notes with pinning.
- Device Activity Timeline combining current-month HQ observations with linked tasks/notes.
- Local Notifications/Inbox with unread counts and import/workflow alerts.
- Agents & Partners management view based on imported HQ hierarchy.
- CSV Export Centre for devices, monitor data, current month and operations.
- Dashboard quick actions and operational counts.

# DevMonitor — Native Windows Edition (source v181)

This project is a **real Windows desktop application** rebuilt from the supplied
DevMonitor Android v181 source. It does not use a web renderer, Vite, React,
Electron, or a browser window.

## What is carried over

- Dashboard / control-centre workflow
- SMS Checker desktop/sync boundary
- My Devices working set
- HQ/SIMReg Excel import
- Current + previous calendar month HQ storage
- Replace-All authoritative monthly snapshots
- Out-of-order month import
- Older coverage rejection
- Payment cycle dates (21st–20th)
- Active as the payment/progression input
- Activation reward tiers and Sunday qualification
- Earning Progress view
- Agents & Partners foundation
- Local/offline-first SQLite persistence
- Windows file dialogs and desktop navigation

## Important Windows difference

A Windows PC cannot directly read the Android phone's SIM SMS inbox.
The desktop SMS Checker therefore has a local inbox/sync boundary: SMS text can
be supplied by a future Android-to-PC bridge, or entered/imported for testing.
The PC architecture keeps SMS ingestion separate from the calculation engine.

## Build

Requirements:
- Windows 10/11 x64
- .NET 8 SDK
- Inno Setup 6 for the installer

Run:

    powershell -ExecutionPolicy Bypass -File .\BUILD_WINDOWS.ps1

The result is a self-contained `DevMonitor.exe` under `publish`. The normal
end-user release is the generated `DevMonitor-Setup-*.exe` installer.

## Windows installation

The release is intended to be installed, not run as a portable application.
The installer places DevMonitor under Program Files, creates a Start Menu
shortcut, optionally creates a desktop shortcut, and registers an uninstall
entry with Windows. The application database remains in the user's local
application-data folder so reinstalling/upgrading does not put user data inside
the Program Files installation directory.

## GitHub Actions

`.github/workflows/build-windows.yml` restores and publishes the self-contained
Windows x64 application, installs Inno Setup on the Windows runner, builds the
normal Windows installer, and uploads the installer as the primary artifact. A
developer-only publish artifact is also retained for diagnostics.

## Data

The application creates:

`%LOCALAPPDATA%\DevMonitor\devmonitor.db`

The database is local and uses WAL mode. The two-month HQ model is represented
inside the database as month-keyed authoritative snapshots; import does not
automatically refresh derived screens.

## Icon

`Assets/devmonitor_icon.png` is the icon taken directly from the supplied
Android source package. It is also converted to the Windows application icon
during packaging.


## v4.6.0.182 — Modern UI pass

- Preserved the v181 application/data/payment implementation as the functional baseline.
- Added a consistent modern DevMonitor visual system: rounded controls, softer surfaces, depth/shadows, improved spacing and typography.
- Added a teal primary action treatment with pressed/hover states.
- Added rounded, focus-aware text inputs.
- Improved navigation with rounded menu items, hover states and a clearly highlighted active page.
- Improved cards and dashboard metrics with cleaner borders and elevation.
- Increased the default workspace size for a more comfortable Windows desktop layout.
- No payment calculation rules or report/database logic were intentionally changed in this visual pass.


## 4.6.0.202 — Full Offline Feature Set / Phone Data Ready

This Windows release is intended as a full offline-capable desktop counterpart to the Android application, not a foundation-only shell.

Implemented feature areas:
- Dashboard command centre and Action Centre
- SMS Checker as a non-sending desktop result store/review surface
- My Devices
- HQ report import with two-month authoritative storage and replace-all semantics
- Loaded Report search and full local report access
- Device Monitor with newer stored phone results taking precedence over older HQ snapshots
- Earning Progress and payment-tier estimates
- Month-on-Month report-aware comparison
- Agents & Partners / company hierarchy
- Tasks & Follow-ups
- Notes
- Device Activity Timeline
- Notifications / Inbox
- Trends & Insights
- Export Centre
- Local Profile & Company structure
- Phone Data Exchange package (.dmdata) for offline transfer of My Devices, phone results, tasks, notes, notifications and SMS history
- Local SQLite persistence and WAL-based offline operation

Windows does not send SMS. Phone-originated results can be transferred into the Windows local store and used without an internet connection. Live Android/Windows synchronization is deliberately not included in this release; it is the next integration phase.

Protected business rules:
- Payment calculation remains in PaymentRules.cs.
- Active remains the payment/progression input.
- HQ reports remain authoritative monthly snapshots.
- Only current and immediately previous calendar months are stored.
- Import is replace-all for a month.
- Month-on-Month remains report-data/cutoff based and separate from payment-cycle logic.
