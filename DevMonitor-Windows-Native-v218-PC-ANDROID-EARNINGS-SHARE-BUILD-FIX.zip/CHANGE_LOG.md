# DevMonitor Windows Change Log

## 4.6.0.218 — Earnings-card handoff build fix
- Fixed an unterminated interpolated string in the PC-initiated earnings-card sharing message by escaping line breaks.
- Retained the v217 sharing workflow and payment calculation boundaries; no payment rules were changed.
- Build verification must be completed by the repository's Windows GitHub Actions workflow.

## 4.6.0.217 — PC-initiated earnings-card handoff
- Added a native Share Earnings Cards page and an entry point from Earning Progress.
- Allows agent selection and a single source per batch: SMS Checker or Loaded Report.
- Reuses source-held/device-monitor figures only; cards contain Today, MTD and Active where available. No new payment estimate is calculated and no cross-source fallback is allowed.
- Generates per-device PNGs and stores them in a local `share_queue`; the encrypted sync response hands them to Android.
- Android opens its native share sheet after receiving the prepared images. Phone acknowledges card IDs on the next exchange; Windows removes acknowledged items.
- No change to payment rules, HQ/payment data sync exclusion, or existing retry/standby sync policy.
- Verification: ZIP integrity and XAML XML checked. Build and live paired-device handoff require GitHub Actions and device testing.
