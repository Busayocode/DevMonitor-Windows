## Android v292 — Ad frequency and report-credit correction (2026-10-21)

- Based on the prepared v291 source package; Android `versionCode = 292`.
- Preserved the first 10 successful report exports as free. After that, each completed rewarded ad grants 5 additional report-export credits (previously 3). A successful export consumes one credit; failed/cancelled exports do not consume a credit.
- Increased the interstitial threshold from every 5 to every 10 successful SMS-monitoring result events. Interstitials remain restricted to the existing natural task-completion pause and are skipped if no ad is ready.
- No payment calculations, target logic, MOM/HQ storage, Drive configuration, or location permission flow intentionally changed.
- Rewarded ads for shared result-estimate cards are not included in this package yet; their separate counting/gating rule needs confirmation before implementation.
- Source/ZIP checks only; Gradle build, live AdMob testing, and on-device verification remain pending.

## Latest update — Android v291 On-demand location permission (2026-10-21)

- Base package: prepared v290 share-card legibility package.
- Removed location from first-launch permissions; onboarding now presents only SMS monitoring, phone/SIM information, and Android notifications (3 steps).
- Retained location permissions for the feature that actually needs them, using the existing `currentLocation()` runtime permission flow.
- Preserved v290 share-card readability changes and the 1.5× image scale.
- No payment formulas/values, Target logic, MOM/HQ storage, Drive configuration, or SMS Checker behavior intentionally changed.
- Verification: source-level checks and ZIP integrity only; full Gradle build and phone testing are not yet verified.

## Latest update — Android v290 Share-card text legibility (2026-10-20)

- Base package: user-supplied `DevMonitor-4.7.0-TARGET-v284-RESPONSIVE-COMPACT-UI.zip`.
- Advanced Android `versionCode` to 290.
- Improved contrast and minimum text sizes for the payment share-card's secondary labels and small-print sections; fitted long note/detail lines to available width.
- Retained 1.5× output scale to avoid the slow sharing seen after the v287 2× bitmap increase.
- No payment formulas or values, Target logic, report storage semantics, Drive configuration, or SMS Checker behavior intentionally changed.
- Verification: source/ZIP checks only; full Gradle release build and on-device/share-recipient validation are still required.

## Latest update — Android v284 Responsive Compact UI (2026-10-20)

- Based on v283 Online Drive Report Configuration Fix.
- Tightened default custom-button padding and minimum height; shortened My Partners code-entry guidance and reduced its initial field height.
- Simplified the My Partners activation-performance explanation without removing source-separated Device Monitor / Loaded Report values or completeness indicators.
- No payment formulas, Target calculations, report parsing, Drive configuration, partner search behavior, or regular SMS Checker behavior intentionally changed.
- Verification: ZIP integrity and source-diff checks; compilation and on-device responsive testing are not yet verified.

## Latest update — v283 Online Drive Report Configuration Fix

- `app/build.gradle.kts` now defaults `DRIVE_REPORT_FOLDER_ID` to the established company report folder ID `1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI` when no Gradle property overrides it.
- This matches the current GitHub workflow that injects `DRIVE_REPORT_API_KEY` but may not inject a folder ID.
- The API key remains external build configuration and is not added to the source ZIP.
- Online report access still requires the Google Drive API to be enabled for the supplied key and the target folder/files to be publicly readable. A GitHub Actions build and runtime download test are still required to confirm end-to-end success.

## Latest source package: Android v282
- Based on v281 permission-setting compile fix.
- My Partners menu eligibility now includes saved Staff and Partner profiles and continues to exclude Agent profiles; the regular SMS Checker remains separate.
- Added active-profile name/type personalization on the dashboard. Device payment share cards prefer the saved active Agent/Staff profile name with a PROFILE label, while the linked agent name/AGENT label remains the fallback.
- Existing Target percentage logic, payment formulas, source separation, FRC treatment, and HQ report semantics are intentionally unchanged.
- Build status: source-level checks only; a full Gradle release build and GitHub Actions run are still required.

# DevMonitor Master Work Sheet — current build status (2026-10-19)

## Latest source package: Android v281
- Base: uploaded `DevMonitor-4.7.0-TARGET-v280-RESTORE-FORK-FEATURES-REMOVE-LABEL.zip`.
- Build blocker identified from GitHub Actions: five unresolved references to `SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN` in `MainActivity.kt`.
- Fix applied in v281: declared the missing constant with the persistent key `first_launch_permission_setup_seen`; advanced Android `versionCode` to 281.
- v280 feature changes retained: restore Fork 3 partner activation-performance calculation and partner share-card section, while removing the visible “Fork 3” label; preserve welcome-tour persistence safeguard and notification test-alert removal.
- Build status: **not yet verified by a full Gradle release build or GitHub Actions run**. The source ZIP is structurally valid, but that is not equivalent to a successful build.

## Release verification checklist
- [ ] GitHub Actions `build-android` completes `compileReleaseKotlin` and `assembleRelease`.
- [ ] Confirm fresh install shows the one-time permission setup after welcome; existing installations are not forced through it.
- [ ] Confirm dismiss/finish state persists across app restart.
- [ ] Confirm partner activation performance remains separate for Device Monitor and Loaded Reports and does not alter payment formulas.
- [ ] Confirm the partner share card says “ACTIVATION PERFORMANCE”, not “FORK 3”.
- [ ] Regression-check Target expected-to-date percentage and no numeric shortfall/deficit display.

---

## Current Android update — v278 first-launch permission setup (2026-10-19)
- Fresh installs see a permission wizard after the existing welcome screen; existing installs are not retroactively prompted by this one-time onboarding.
- Separate purpose explanations and grant-status checks cover SMS monitoring/recovery, phone/SIM discovery, optional location map helpers, and Android 13+ system notifications. Each step can be granted, retried, or skipped.
- Google Drive / online report configuration is deliberately excluded and remains a separate issue.
- Payment calculations, MOM/HQ storage, report import behavior, and Windows build logic are protected. Android versionCode 278; build/device verification pending.

## 4.7 Target refinement — expected-to-date achievement (v277)
- Target achievement percentage is actual activity divided by the expected cumulative target for the same reporting day.
- No shortfall/deficit amount or behind-pace warning is displayed. Full-month target progress remains a separate, neutral percentage.


## Development 4.7 Target — monthly activation targets
- Staff and Partner profiles now require a positive monthly target during profile creation/editing; Agent profiles use the fixed target of 150.
- The profile target is stored with profile metadata and survives app upgrades; legacy Agent profiles default to 150.
- The Month-on-Month performance card shows cumulative current-month activity against the configured target, target-achievement percentage, expected cumulative value by the current day, and whether actual activity is on or behind expected pace.
- Expected pace is calculated proportionally across the actual number of calendar days in the current month. The progress bar caps visually at 100%, while the displayed achievement percentage can exceed 100%.
- Existing report/payment calculations and HQ snapshot semantics are not changed. Source review completed; Android build/runtime verification remains pending.

## Phone release-build configuration (2026-10-17)
- Current app source remains versionCode 275 / versionName `4.6.0-NEXT`; this is a build-environment packaging update, not an app-version bump.
- `build-phone.sh` detects Android Code Studio ARM-compatible AAPT2, passes `android.aapt2FromMavenOverride`, checks release keystore availability, and requests missing release secrets without echoing them.
- The Drive API key is no longer stored as an active placeholder in `gradle.properties`; the release helper prompts or accepts a local environment variable and injects it only for that build.
- Phone build guide updated with signed APK/AAB commands, expected outputs, and AAPT2 troubleshooting. Payment rules and the v275 historical eligibility gate are untouched.

## Android v275 — Strict historical evidence gate for payment cards (2026-10-17)
- Device Monitor payment cards now require genuine device-specific Active evidence in both the previous and current calendar months, from Device Monitor observations and/or Loaded Report activation data.
- From the 21st onward, the card additionally requires the payment engine's valid cumulative Active baseline through the 20th.
- Company Directory/Skeleton data is not consulted and cannot qualify as activation history. This specifically closes the pre-21st path where current-month Active alone could open the card.
- Payment formulas, source separation, FRC treatment, Sunday bonuses, and tier calculations remain unchanged.
- Android versionCode 275. Build/device verification pending.

## Android v273 — Historical eligibility gate for payment progression (2026-10-17)
- Device Monitor payment progression cards open only when the existing Device Monitor payment engine returns a valid activation progression, on every day of the month. A `today` count alone does not satisfy the cumulative Active baseline requirement.
- Removed the unsafe fallback that subtracted zero when the baseline was missing. The card and sharing action now inherit the unavailable state from the existing payment engine; warning text explains the missing history.
- Loaded Report calculation and source separation remain unchanged. Payment tiers, FRC weekly separation, Sunday bonus qualification, and next-tier earnings card are preserved.
- Android versionCode 273; compilation and on-device verification pending.

## v271 — Exclude weekly-paid FRC from main estimate (2026-10-17)
- Kept the existing FRC cumulative calculation and visible value, now labelled “Progressively paid weekly”.
- Excluded FRC from the main payment estimate total; the total now includes only the established fixed performance reward and qualifying Sunday bonus. FRC is not erased from records or its separate display.
- Applied the same total to payment progression summaries, exported payment-card totals, and spreadsheet summary values through the existing estimate subtotal field.
- Preserved activation tiers, source separation, Sunday qualification, and the underlying FRC cumulative calculation.
- Android versionCode 271. Source checks and ZIP integrity only; build and device verification remain pending.

## v269 — Search responsiveness, payment-estimate hero, partner flyer layout, and cloud backup/restore (2026-10-16)
- Kept the v268 filled, rounded Material 3 search/input fields; the change remains source-implemented and requires on-device light/dark verification.
- Fixed the earnings hero artwork at render time: the source photo contains baked-in “Payment Received!” wording and a sample amount, so the card now masks that badge and clearly labels the area “Payment Estimate”. The actual estimate remains in its existing calculated panel; payment logic and source selection are untouched.
- Improved My Partners name/Trade Code search responsiveness by filtering the already-loaded HQ directory snapshot in memory on `Dispatchers.Default`, with a short debounce. Preserved the v239 match fields, minimum query length, result cap, and code-selection behavior; removed repeated SQLite reads on each keystroke.
- Stabilized the partner result flyer composition by increasing its canvas height and moving the footer below the largest optional Fork 3/details panel. The partner flyer also masks the photo’s baked-in payment-received badge with neutral partner-activity wording.
- Hardened Google Drive app-data backup/restore: validate the local SQLite database before upload, update the existing named backup instead of creating duplicates, apply connection/read timeouts and actionable HTTP errors, validate downloaded SQLite integrity/schema before restore, and stage/rollback the live database replacement to avoid overwriting it with an invalid or partial file.
- Android versionCode 269. Source ZIP and static checks only; Android build and runtime/device verification remain pending.

## v268 — Modern rounded search and input fields (2026-10-16)
- Modernized the app's standard Compose search and input controls by switching the 42 thin outlined text fields to filled Material 3 fields with the existing theme's surface-container colors.
- Applied a consistent 16dp rounded field shape for a softer, more contemporary look across search, form, profile, settings, partner, notes, task, report and bridge inputs.
- Preserved field labels, hints, input transformations, read-only dropdown behavior, validation/error states, search handlers, and all underlying data/payment logic. No search queries or business calculations were changed.
- Android versionCode 268. Source and ZIP checks only; Android compilation and light/dark device visual verification remain pending.

## Current experiment — Android v267 Fork 3 partner Activation Performance
- Added isolated, read-only `Fork3ActivationPerformance.kt` to aggregate the existing device-level activation progression outputs for each My Partners Trade Code using the latest retained HQ device-to-partner mapping.
- Each partner shows Device Monitor and Loaded Report totals independently. Device Monitor follows the existing Device Monitor payment engine, including freshness and baseline rules; Loaded Report follows its own calculator. Values are not combined across the two source totals.
- Incomplete partner totals are labelled as subtotals with available/mapped device counts; missing device estimates are not treated as zero. No mapped devices or no valid source evidence is shown as unavailable.
- Fork 3 values can also be included in the shareable partner result card; existing 30-30 Today / MTD / B48 / B96 values remain separate.
- Payment calculations and source stores are unchanged; experiment is read-only. Android versionCode 267. Build and on-device verification pending.

## Current update — Android v266 restores non-destructive navigation
- Reverted the v265 fix that cancelled checker runs and cleared in-memory state when switching between SMS Checker and My Partners.
- Background checking and progress are preserved across navigation; no aggressive isolation changes are applied for an intermittent, unreproduced observation.
- If the rare cross-menu display issue returns, investigate the specific route/state transition with logs rather than stopping background activity.
- Android versionCode 266. Compilation and on-device tests remain pending.

## Current update — Android v265 partner card and checker isolation fixes
- Partner share-card identity now comes from the same HQ partner directory used by the result row, fixing the missing partner name on the exported image.
- Removed the redundant hero badge from partner and earnings cards so the main result/earnings panel is the single display of the key value.
- Partner flyer canvas shortened to 1320 logical pixels (1980 px at 1.5x) and footer moved close below the metrics, with room for all optional location details.
- Switching between SMS Checker and My Partners cancels an in-flight checker run and clears pending permission-resume work to prevent route/UI leakage between the primary and partner workspaces.
- No calculations changed. Android versionCode 265. ZIP/source validation done; build and on-device testing pending.

## Current update — Android v264 partner performance flyer sharing
- My Partners result sharing now uses the same flyer-style design language as the earnings card: branded DM header, photo hero, clear partner profile, and a high-contrast performance panel.
- The card includes partner name, Trade Code, available cluster/region/territory, and existing Today / MTD / B48 / B96 performance values. Partners have no earnings tiers; none are displayed or inferred.
- Render scale is 1.5x (1620 × 2715). Partner card rendering and PNG compression run asynchronously before opening the Android share chooser to reduce UI blocking.
- No partner metrics are recalculated; original checker, payment engine, and report semantics remain unchanged. Android versionCode 264.
- Build script attempt here stopped before compilation because this environment lacks an ARM-compatible AAPT2; real Android compilation and WhatsApp/device sharing tests remain pending.

## Current update — Android v263 smaller payment share-card image
- Reduced the exported payment flyer from 3x to 1.5x raster scale, changing output from 3240 × 5430 to 1620 × 2715 pixels.
- Estimated primary ARGB bitmap footprint drops from about 67 MiB to about 17 MiB (roughly 75% less), helping reduce memory pressure when sharing to WhatsApp.
- Preserved existing flyer composition, the “Estimated Earnings” label, source selection, and the exact existing estimate object passed into the card renderer. No payment formula or figure generation changed.
- Single-card image generation and PNG compression remain asynchronous on a background thread; chooser handoff stays on the main thread after preparation.
- Android versionCode 263. ZIP integrity/source checks can be performed here; Gradle build and real-device WhatsApp test remain pending.

## Current update — Android v261 dashboard and profile-builder polish
- My Partners dashboard card now follows the standard dashboard card hierarchy with a full-width “Open My Partners” action.
- Profile Builder entry points no longer open Monitor Settings behind the profile dialog; the dedicated “Open Monitor Settings” action remains intact.
- Payment logic and data flows unchanged. Android version code 261; build/device verification pending.

- Share-card truth-in-labeling: photographic hero badge reads “Estimated Earnings”; never imply payment has been received while the app is still estimating. Renderer remains presentation-only.
## Current update — Android v259 share-card component sharpness
- Exported earnings flyer is rendered at 3x logical resolution (3240 × 5430) with anti-aliased/subpixel-aware text settings and dithering for cleaner typography and UI details.
- This is a presentation-only change. Shared estimates remain sourced from the selected payment card; no payment rules or data calculations are changed.
- Build/device verification is pending.

## Current release — v248 My Partners UI correction
- My Partners is a partner-code-only workspace: no Zero Devices action or My Devices setup action may run from this route.
- Partner-code input examples use PT-001 / TRADE-2048; search/results and Quick Check messaging use partner terminology.
- Original Device Monitor retains its device-specific controls. My Partners remains staff-only and isolated in `sms_checker_2.db`.
- Android version code: 248 (`4.6.0-NEXT`). Build and device validation pending.

## v247 — Staff-only partner-code workspace refinement (2026-10-14)
- Made the My Partners dashboard card and drawer entry visible only for the active, successfully saved Staff profile. Eligibility updates only after the profile-save/rebuild flow completes; selecting Staff in an open profile editor does not reveal the card prematurely.
- Kept the My Partners card immediately above MOM and preserved the restored four-card quick-action group.
- Replaced device-oriented input guidance and search labels with partner Trade Code examples and partner-specific result headings.
- Removed Zero Devices and Open My Devices setup actions from My Partners while retaining Zero Devices for the original Device Monitor. Hid device ownership and payment-progression actions in My Partners; partner results can still be rechecked.
- Kept `sms_checker_2.db` as the isolated checker store and guarded SMS recovery from writing partner results into primary Device Monitor observations.
- Advanced Android `versionCode` from 246 to 247; `versionName` remains `4.6.0-NEXT`. Payment calculations and thresholds were not changed.
- Verification: source-level checks and ZIP integrity only. Android build, first-launch stability, and on-device role visibility remain unverified; first-launch crash root cause requires device Logcat to confirm.

## v246 — My Partners dashboard placement and naming (2026-10-14)
- Renamed the user-facing SMS Checker 2 navigation item and checker screen heading to **My Partners**.
- Restored the original four-card dashboard quick-action group (SMS Checker, My Devices, Load Report, Earning Progress).
- Positioned a dedicated My Partners card immediately above the Month-on-Month Comparison (MOM) dashboard card.
- Kept the isolated `sms_checker_2.db` storage path and original SMS Checker entry. No database migration or payment logic changes.
- Android `versionCode = 246`; `versionName = 4.6.0-NEXT`. GitHub Actions and device verification pending.

## v245 — SMS Check 2 compile correction (2026-10-14)

- Moved the `selectedTab` state declaration to the beginning of `SimRegMonitorApp`, before it is referenced to select `smsChecker2Store` and by the checker-tab reload effect.
- Version code advanced to 245.
- This addresses the v244 GitHub Actions Kotlin error `Unresolved reference: selectedTab` at lines 544 and 558–559.
- Build/device verification still required.

## v244 — Independent SMS Check 2 database and dashboard card
- Added a separate SMS CHECK 2 dashboard quick-action card and retained its navigation entry.
- Added a dedicated `sms_checker_2.db` database via an isolated StateStore path. SMS Checker 2 loads/saves its own current device codes, query records, saved lists, archives, history, and SMS-query attempt records.
- The shared SMS engine/UI is reused to preserve existing check/retry/import/result behavior; the two checker datasets are selected by active menu and reloaded on navigation.
- Kept device-monitor profile databases, HQ reports, payment engine, and My Devices data on their existing stores. Shared phone/SIM permissions and transmission hardware remain OS-level resources.
- Source/ZIP validation only; Android build and on-device isolation testing still required.
# v243 — Add SMS Checker 2 menu

- Added a separate **SMS Checker 2** entry in the navigation drawer.
- Routes to the complete existing SMS Checker screen and workflows, including code entry, Add list/Replace, Quick Check, Zero Devices (when permitted), Excel import, saved/archived lists, run status, and results.
- Original SMS Checker navigation remains unchanged. Both entries currently use the existing checker data/results and SMS engine; this avoids creating a second divergent payment or SMS processing implementation.
- No payment formulas, notification behavior, import semantics, or My Partner removal changed.
- Android compilation/device testing remains pending.

---

## v242 — Remove stale My Partner storage reference (GitHub compile fix)
- Removed the remaining `myPartnerStore.saveCheck(...)` call from the general Partner Summary SMS response flow. The My Partner menu/store is no longer part of this UI, so the dangling reference caused `Unresolved reference 'myPartnerStore'` during Kotlin compilation.
- Preserved the general Partner Summary result display and its SMS response parsing; only the obsolete My Partner-history write was removed.
- Advanced Android `versionCode` from 241 to 242. `versionName` remains `4.6.0-NEXT`.
- Payment logic, reports, notifications, and device observations were not changed.
- Verification: source reference/version checks and ZIP integrity; full Android compilation still needs GitHub Actions confirmation.

## v241 — Remove My Partner menu cleanly
- Removed the staff-only My Partner drawer entry and its standalone dialog/search/partner management UI.
- Kept the general Partner Summary / My Devices partner lookup flow intact; it is shared by existing My Devices operations and is not the removed menu.
- Preserved v240/v239 source baseline, notification changes, and existing payment/report logic.
- The unused `MyPartnerStore.kt` implementation file is retained but no longer called by the main UI, avoiding risky unrelated deletion of database code.
- Verification: source checks and ZIP integrity only; Android compilation/device testing still required.

## v240 — My Partner SMS stays in its menu
- Check by SMS no longer closes My Partner or changes the main app tab before SIM selection.
- Partner summary remains associated with the selected partner trade code and is stored in separate My Partner history.
- No earnings-card image or payment calculation changes.

## Current update — Android v239 My Partner search fix

The My Partner search field now changes only the search query. Results are filtered against loaded-report partner names/trade codes; selecting a result fills the name/code fields. Manual entry is still supported. Payment logic and separate My Partner storage are unchanged.

## Current update — Android v238 permission callback compile fix
- Fixes the GitHub Actions Kotlin compile failure in `MainActivity.kt`: `onRequestPermissionsResult` now declares `permissions: Array<String>` to match the Android Activity override.
- Preserves the v237 permission-grant handling that flushes queued system notifications.
- Build identity: `versionCode = 238`, `versionName = 4.6.0-NEXT`.
- Protected: payment formulas and thresholds, report import logic, notification event coverage, and database schemas.
- Verification pending: rerun GitHub Actions Android build and test notification delivery on an Android device.

## Current update — Android v237 app-wide notification delivery
- Fixes the first-event permission flow: the event that triggers Android's notification permission prompt is queued and delivered if permission is granted.
- Adds a Test alert action to Notifications & Inbox for immediate on-device delivery verification.
- Existing event coverage includes monitoring pass success/failure, report imports, export success/failure, payment-cycle reminder, and version-check outcome. Further event coverage can be expanded without changing payment logic.
- No changes to payment formulas, thresholds, My Partner standalone DB, or main device data.
- Build and actual Android notification delivery remain unverified until GitHub Actions and device test pass.

## Current continuation — v234 My Partner
- Added staff-only My Partner menu, separate from My Devices.
- Partner records are entered manually after profile creation and stored separately per active profile.
- Reuses SMS Checker check flow and Loaded Report viewer; no new payment formula.
- Pending validation: GitHub Android build, staff/non-staff visibility, add/edit/remove persistence, SMS result matching, and Loaded Report partner-code matching.

## Current development override — Android v232 (2026-10-13)

- **Connection UI:** the PC-link status indicator belongs in the app-bar action row beside the notification bell and flag, not under the DevMonitor logo/name. Full connection details remain in Next Level → Health.
- **Earnings export:** the existing payment-card share action now renders a promotional portrait PNG flier, not a plain report-style list. It uses only the already-selected source estimate, identifies source and reporting period, shows a reach-step-specific encouragement line, and carries an estimation-only warning.
- **Protected logic:** no changes to PaymentEngine, PaymentRules, payment thresholds, cycle boundaries, or source selection.
- **Verification gate:** run the Android GitHub Actions build and inspect the exported PNG on-device before treating v232 as build-verified.

## Current update — Android v230 (2026-10-12)

- Deliverable: DevMonitor-4.6.0-NEXT-v230-EARNINGS-FLIER-REACH-MESSAGES-CONNECTION-STATUS.zip
- Scope: earnings flier visual direction, reach-step-specific encouragement copy, and PC–Android connection-status visibility/parity.
- Guardrail: payment calculations and category thresholds remain unchanged; card values must come only from the chosen source.
- Verification: ZIP integrity checked; no claim of a successful platform build.

## 4.6.0-NEXT v226 — Source-faithful earnings-card sharing and agent/device links
- Existing payment card can be shared as a PNG from its own displayed source. The image labels source and cycle/date and repeats the existing card values without adding a new calculator.
- Batch sharing is source-locked (SMS Checker OR Loaded Report), one card per linked device, with unavailable figures skipped and reported. It must never merge sources to fill gaps.
- My Devices codes can be linked/unlinked directly from an agent record. Existing manual code linking remains available.
- WhatsApp and other destinations use the Android share sheet; recipient selection and send remain user-controlled. Fully automated WhatsApp delivery would require an explicitly configured official business API integration.
- Protected: PaymentEngine formulas/thresholds, 21st–20th cycle, report import rules, and five-minute sync standby checks.

# DevMonitor — CURRENT DEVELOPMENT OVERRIDE — 4.6.0-NEXT v225

> **Current Android development build identity:** `versionCode = 225` / `4.6.0-NEXT`. The ZIP is an Android project; do not infer that Windows has been updated from this package alone.

## v223 continuation scope
- Preserve the v222 analytics/version-awareness integration and v218-v221 encrypted, explicit Phone ↔ PC Sync Bridge.
- Preserve payment calculation, payment-cycle boundaries, HQ import rules, and Month-on-Month formulas.
- Android release build and signing verification must pass in GitHub Actions before this version is considered build-verified.
- Windows analytics parity and live cross-device sync testing remain pending separate Windows-source integration and runtime validation.


## v185 — GitHub Actions compile correction

- Fixed the `CompanyActivationStore.loadReportForDevice()` daily-map type mismatch reported by GitHub Actions.
- The established `SimRegReportRow.daily` contract remains `Map<Int, Int>` (day-of-month to count).
- Exact-date activation values are additionally retained in `dailyByDate` for the targeted Loaded Report result.
- No business-rule or UI behaviour was changed by this correction.
- v184 Staff Action Centre visibility remains intact: Staff hidden; Agent/Partner visible.


## v183 — Remove automatic post-profile dashboard guided tour

**Status: IMPLEMENTED IN v183 SOURCE PACKAGE**

- Removed the automatic/static main-dashboard orientation that previously launched after a new profile was created.
- Dashboard no longer enters a guided-tour state after profile creation.
- Removed the dashboard-tour target tracking and tour-specific scrolling from the dashboard presentation.
- The normal dashboard cards and navigation remain unchanged.
- The separate BUILD PROFILE first-setup spotlight remains governed by the no-profile condition.
- The SMS CHECKER guided tour remains removed as previously established.
- No payment, HQ report, Device Monitor, SMS operational, Profile Builder, or report-search business logic was changed by this removal.

# DevMonitor — CURRENT ARCHITECTURE OVERRIDE — 4.6.0-NEXT v187

> **Current build identity:** `versionCode = 187` / `4.6.0-NEXT`

## 4.6.0-NEXT v187 — Loaded Report startup performance correction
- Opening a saved Loaded Report no longer eagerly materializes the full HQ report.
- The initial viewer uses the bounded My Devices working set; full HQ data is requested only through explicit Show All.
- Targeted one-device dashboard results retain the existing bounded `loadReportForDevice()` path.
- Report table presentation starts at 100 rows and expands by explicit 100-row batches from the bottom.
- No payment, Device Monitor, SMS, report-storage, or profile-ownership business rules were changed.

## 4.6.0-NEXT v186 — Staff dashboard/payment visibility + Quick Check label
- The dashboard **PAYMENT CYCLE** card is role-gated: visible for **AGENT** and **PARTNER**, hidden for **STAFF**.
- This rule applies to the whole card, not merely its controls or contents.
- Device Monitor / SMS Checker one-off enquiry action is now labelled **Quick Check**.
- Quick Check retains the existing behaviour of checking entered code(s) without adding them to My Devices.
- No payment calculation, payment-cycle logic, SMS workflow, or Device Monitor business logic changed.


> **Current v170 recovery override:** v162.1 is the recovery code base. Approved post-v162.1 UI improvements are selectively retained, especially the single informative floating waiting window. This override supersedes earlier same-coverage rejection wording and any older four-MOM-database wording where they conflict with the current v161/v165 architecture.



## 4.6.0-NEXT v176 — Company Skeleton compile correction
- Corrected two `SimRegReportRow` constructor calls in `CompanyActivationStore.kt`.
- The calls were passing `Map<LocalDate, Int>` into the `division: String` parameter because the optional `division` slot had been omitted.
- The fix explicitly supplies an empty division string and preserves the date-keyed activation map in `dailyByDate`.
- No payment, activation calculation, report import, Company Skeleton, profile hierarchy, or HQ storage logic was changed by this correction.
- This is a compile-only correction to the v176 Company Skeleton / Profile onboarding package.

## 4.6.0-NEXT v173 — Device Monitor compact result cards
- Reduced vertical footprint of My Devices / Device Monitor result cards to improve field scanning and reduce unnecessary scrolling.
- Device code remains the strongest visual identifier; ownership, status, flags, performance metrics, errors and recheck behavior remain visible.
- Performance metrics are presented in one compact row (Today, MTD, B48, B96) when a result exists.
- Successive unflagged cards use subtle Aurora accent variation (blue, emerald, violet); flagged cards retain the error accent.
- Removed the duplicate in-card payment-progression viewer. Each result now has one primary **EARNING PROGRESS** button, alongside **Recheck**.
- This is presentation/navigation-only. PaymentEngine, PaymentRules, PaymentCycleResolver, Device Monitor/SMS logic and payment data pathways were not changed.

## 4.6.0-NEXT v172 — Historical Fixes + Loaded Report Carry-Forward
- v172 carries forward the non-conflicting documented fixes from the historical line rather than treating Loaded Report as the only change.
- Profile Builder scrolling, profile deletion, MOM search/detail, Device Monitor payment freshness protection, targeted payment search, and the unified floating waiting window remain active.
- Dashboard search preserves the selected source when opening a result.
- Payment-page presentation is simplified without changing search or payment logic.
- Loaded Report import remains calculation-isolated but immediately displays the exact validated report; Open Loaded Report directly retrieves the latest stored report.
- PaymentEngine, payment formulas, Device Monitor/SMS rules, and the two-month HQ architecture remain protected.

## 4.6.0-NEXT v162 — Dashboard clarity / role-aware UX
- Dashboard quick actions use plain-language names: **SMS CHECKER**, **MY DEVICES**, **LOAD REPORT**, and **EARNING PROGRESS**.
- The same EARNING PROGRESS terminology is used for the bottom navigation destination.
- The dashboard Action Centre is shown only for **AGENT** and **PARTNER** profiles; it is hidden for **STAFF** profiles.
- Removed the obsolete **Manage authentication & authorization** Settings button completely.
- Removed developer-facing Google OAuth/SHA-1 troubleshooting text from normal Settings UI.
- Replaced technical Google Drive storage explanation with a concise user-facing connection message.
- Google sign-in, backup/restore behavior, payment logic, report logic and underlying authentication implementation are otherwise unchanged.
- Added profile-level saved-device management: individual devices can be removed from My Devices with confirmation; removal changes only the profile working set and does not delete underlying HQ/report history.

## Monthly HQ snapshot storage / import policy
- **Two physical HQ month databases only:** one file for the current calendar month and one file for the immediately previous calendar month, named `fieldpulse_company_YYYY_MM.db`.
- The previous rolling three-calendar-month HQ database is superseded by this architecture. Historical material beyond the two active months is not retained in the HQ activation store.
- HQ activation reports are treated as **authoritative monthly exports**. A report covers exactly one calendar month.
- Import is **Replace All for the report month**: when a newer report for that month is accepted, the existing monthly snapshot is atomically cleared and replaced with the new HQ export. Devices absent from the new export are therefore removed from that month's stored snapshot, correctly reflecting HQ transfers, additions, removals/expunged devices and zero-activity devices.
- **Import ordering:** the current and previous month are independently addressable. A valid August report can be imported after September has already been stored. The existence of newer September data does not block August.
- **Older-report safeguard:** within a month, an incoming report with an older coverage end than the stored snapshot is rejected. A report with the same coverage end is **accepted as a replacement**, not treated as a duplicate. A newer coverage end also replaces the stored snapshot. The accepted report is a complete monthly snapshot.
- Reports outside the current/previous two-month window are rejected.
- Import is **storage-only**. It does not refresh My Devices, Device Monitor, Month-on-Month, payment progression, dashboard intelligence, estimations, or other derived views. Existing Refresh/action buttons remain responsible for those operations.
- Payment calculation, payment-cycle rules, progression thresholds and estimator formulas are protected. They now retrieve their Loaded Report evidence through the month-aware CompanyActivationStore rather than relying on a single continuous three-month database.
- Month-on-Month no longer maintains four duplicate physical SQLite databases. Its calculation/search layer reads the same two authoritative monthly HQ stores and may use Device Monitor only as its established read-only freshness/enrichment source.
- The former `devmonitor_mom_*` derived databases are obsolete caches and are removed on migration.
- Existing users are migrated from `fieldpulse_company_activations.db` into the current/previous month files once; only the final normalized monthly state is carried forward.
- Version/build target: **versionCode 162**, versionName `4.6.0-NEXT`.

---

## 4.6.0-NEXT v170 — Recovery / PC + Cloud Build Alignment
- Recovery source base is **v162.1**. Later Loaded Report workflow/render-selection experiments are not inherited wholesale.
- Retained approved post-v162.1 UI work, especially the **single app-wide floating waiting window** with operation, current major step, projected overall percentage, one progress bar and concise status.
- The waiting-window percentage is a fixed representation of the existing workflow stages; it is not a new row-counting, calculation or performance-monitoring system.
- HQ same-coverage replacement is now authoritative: older coverage is rejected; newer coverage replaces; **same coverage date also replaces** the complete monthly snapshot.
- Current and previous calendar months remain independently addressable and import order does not matter.
- Current month on 1 October 2026 is October 2026; previous month is September 2026. August is outside the active two-month HQ window.
- PaymentEngine/payment formulas, Device Monitor/SMS logic, Profile Builder, and release identity remain protected.
- Added `BUILD_FOR_PC.md` as the explicit desktop/PC compilation guide. The PC path uses the standard desktop Android SDK/AAPT2 toolchain; it must not use the phone-only ARM AAPT2 override.
- `BUILD_CLOUD.md`, `README.md`, `MASTER_WORK_SHEET.md`, and the PC build guidance are kept aligned so the PC-oriented branch can advance without losing the phone/cloud build paths.

---

## 4.5.2.1 — Notification & Inbox compile correction / cloud build preparation
- Fixed the nullable `activeProfileId` arguments introduced by the Notification & Inbox layer. Notification storage now receives a resolved profile ID while preserving profile isolation.
- Fixed the Compose notification-drawer `Text()` call so the `Modifier` is supplied correctly.
- Added a GitHub Actions cloud-build workflow using Java 17, Gradle wrapper 8.7 and `assembleDebug`.
- Added phone-only cloud-build instructions in `CLOUD_BUILD.md`.
- No notification behavior, payment logic, SMS logic, report logic, profile database rules, or performance policy was intentionally changed.

## 4.5.2 — NEXT LEVEL notification/inbox foundation
- Added a lightweight, profile-scoped **Notifications & Inbox** for user-facing operational notices.
- Added unread count badge in the top bar and drawer access.
- Notifications are local and capped; they do not require network access or background processing.
- Added notices for completed monitoring, monitoring failures/timeouts, report imports, exports, and the existing 18th–20th payment-cycle reminder.
- Month-end remains a reminder only: no automatic monitoring, calculation, estimation, synchronization, or heavy work is triggered.
- Opening/switching profiles only loads that profile's cached notification list; it does not perform operational calculations.
- Users can mark individual notifications read or mark all read.
- Performance policy remains: heavy work is user initiated; natural immediate continuation after a foreground action is allowed.

## Next appearance direction
- Appearance/theme evolution is now an approved creative phase, not a blanket theme replacement.
- The overall DevMonitor visual language may be refined freely while green/emerald/mint are introduced as selected variations.
- Aurora remains a foundation but may be substantially evolved where useful.

## 4.5.1 — Appearance / Theme Evolution

- NEXT LEVEL appearance work has begun from the compile-fixed 4.5.0 Sound & Haptics baseline.
- Existing Aurora visual language remains the foundation; this is an evolution, not a forced theme replacement.
- Added a richer green family (emerald, mint, deep green) as selective Aurora variations.
- Added subtle green tinting to shared Aurora backgrounds/cards and introduced green variation into selected dashboard quick actions and metrics.
- Payment-cycle presentation now uses an emerald accent while retaining the existing status semantics.
- Existing blue/cyan/violet accents remain in use so the interface keeps visual variety and hierarchy.
- No business logic, payment rules, profile isolation, SMS behavior, reporting rules, or user-initiated performance policy was changed by the appearance work.
- Phone performance remains a design constraint: visual polish must not introduce heavy background processing.
## NEXT LEVEL — 4.5.0 Phase 1

### Modern productivity-suite foundation
- Added the NEXT LEVEL product roadmap and incremental delivery tracker.
- Dashboard upgraded into a command-centre experience with global active-profile search, quick actions, live payment-cycle progression and an Action Centre.
- Payment-cycle dashboard value is calculated from the existing payment-cycle/company activation pathways; no duplicate payment rules were introduced.
- Search and Action Centre drill-downs reuse existing Device Monitor/payment/flags pathways.
- Profile-scoped operational data architecture remains intact.
- Remaining Phase 1 work is explicitly tracked in `NEXT_LEVEL_TRACKER.md`.

## 0. CURRENT DEVELOPMENT NOTE — 4.4.2

### Dashboard Month-on-Month card + payment wording
- Expanded the dashboard **MONTH-ON-MONTH COMPARISON** section into a full Aurora card rather than a mini header strip.
- The dashboard card displays the currently available Month-on-Month result: current MTD, same-period-last-month total, change/percentage and as-of date.
- Added separate **Refresh** and **Open Full Comparison** actions; the existing Month-on-Month calculation/data architecture is unchanged.
- Payment estimate cards now label the primary progression number **Current Activation Achieved** instead of **Activations used**.
- No payment calculation, progression thresholds, Month-on-Month calculation, report processing, or database logic was changed by this wording/presentation update.

## 0. CURRENT DEVELOPMENT NOTE — 4.4.1

### One-off Device Enquiry
- **My Devices remains the persistent default working group.**
- Device Monitor input now has a separate **Check Now — don't add to My Devices** path for random/new device enquiries.
- Check Now sends the entered code(s) directly instead of appending them to the My Devices queue. This prevents a single new enquiry from waiting behind the entire My Devices batch.
- One-off results are displayed separately from My Devices results.
- One-off checks still record normal Device Monitor observations/history and can open the existing payment estimate/progression card.
- **Add list**, **Replace**, batch Start/Refresh, Continue and Retry retain their existing working-set behavior.
- Payment calculation/resolver/progression, Month-to-Month architecture, report processing, and the My Devices database are protected and unchanged by this feature.

### 4.3.5.58 — Superseded Month-to-Month Search Draft
- 4.3.5.58 temporarily introduced a staff search against the full company device/hierarchy database.
- That search scope was superseded by 4.3.5.59 and must not be treated as the final architecture.
- The final search scope is the four dedicated Month-to-Month databases only, with Device Monitor allowed only as a read-only peek for matching-result enrichment.


### 4.3.5.57 — Isolated Month-to-Month Data Layer
- Month-to-Month is now a self-contained data feature. Its calculator does not query `fieldpulse_company_activations.db` or the existing normalized activation tables.
- Dedicated databases: `devmonitor_mom_previous.db`, `devmonitor_mom_previous_my_devices.db`, `devmonitor_mom_current.db`, `devmonitor_mom_current_my_devices.db`.
- Fifth source is a read-only peek at the existing Device Monitor `daily_observations` database at calculation time.
- Previous month: partial files replace the isolated snapshot until a filename containing `activation` represents a complete first-to-last-day month; that full activation snapshot locks the month.
- Current month: incremental replacement continues as newer same-month reports arrive.
- Filename month controls which Month-to-Month store can be updated.
- My Devices projections are rebuilt when a report is imported or the My Devices profile changes.
- Comparison cutoff is the newest valid current-month date among the isolated loaded-report snapshot and genuinely newer Device Monitor observations. Previous-month side stops at the same day-of-month.
- Payment logic is protected and untouched by this work.


## 4.5.0 — NEXT LEVEL performance-policy correction
### User-initiated operations refinement
- Month-end background monitoring remains disabled; the legacy scheduler/receiver only cancels old alarms and never starts operational work.
- On the 18th–20th, the dashboard may display a lightweight **Month-end review reminder**. It is informational only and asks the user to decide when to refresh/review.
- The reminder does not calculate, estimate, monitor SMS, import reports, sync data or launch heavy work.
- Switching profiles remains a presentation/cache action: the selected profile shows its last-known dashboard values, with explicit Refresh controls available when the user wants fresh calculations.

# DevMonitor — MASTER WORK SHEET

**Project:** DevMonitor / SIMReg Monitor  
**Stable source baseline:** DevMonitor 4.1 Premium / Xiaomi GetApps  
**Current development workstream:** 4.3.5.57 — Isolated Month-to-Month Data Layer  
**Previous milestone:** 4.3.4 — Authentication foundation  
**Status:** Development build; phone build and full device testing still required before calling 4.3.4.1 stable.

---

## 0. CURRENT DEVELOPMENT NOTE — 4.3.5.59

### Final Month-to-Month search/security correction
- The Month-to-Month search is strictly limited to the four dedicated Month-to-Month databases: Previous Month, Previous Month My Devices, This Month, and This Month My Devices.
- The previous 4.3.5.58 implementation that searched the full company database is superseded and must not be revived.
- Device Monitor is only a read-only peek for matching Month-to-Month search results. It may enrich a matching device with a newer observation/Active value, but it never expands the Month-to-Month search population.
- Search remains read-only and cannot change comparison totals, cutoffs, database contents, My Devices, or payment logic.
- Staff search visibility is determined exactly once, on the first Month-to-Month run after installation. The raw profile phone must be exactly 11 digits, all numeric, and start with `0805557`. No formatting normalization is performed.
- A qualifying phone stores `STAFF`; any other value stores `NON_STAFF`. The result is set in stone until a fresh install/app-data reset. Later profile-phone changes do not reclassify the installation.
- Non-staff failure is silent: no alert and no search field. Month-to-Month comparison itself remains available.
- Device Monitor freshness in Month-to-Month comparison continues to use `received_at` versus loaded-report `imported_at`, and when genuinely newer, the Device Monitor **Active** value is used; the Device Monitor MTD field is not used for this comparison.
- Payment calculation, resolver, progression, and payment pathway code remain protected and unchanged by this feature.

## 0. CURRENT DEVELOPMENT NOTE — 4.3.5.57

### Isolated Month-to-Month Data Layer
- Month-to-Month calculator no longer reads the existing normalized company activation database.
- Four dedicated SQLite files hold previous month, previous-month My Devices, current month, and current-month My Devices.
- The live Device Monitor database is only a read-only fifth source at calculation time.
- Filename month controls import routing. Previous month can be replaced by partial reports until a complete filename-containing-`activation` full-month report arrives; that report locks the previous snapshot. Current month remains incremental.
- My Devices projections are rebuilt after report imports and profile changes.
- The current cutoff is the newest valid current-month date from loaded reports or genuinely newer Device Monitor data; the previous side uses the same elapsed day in the previous-month snapshot.
- Payment calculation/pathways remain protected.

### Global Human Date Parser
- All external/report date text should pass through `HumanDateParser`; do not create one-off filename/date regexes for new features.
- Supported families include ISO/YMD, numeric DMY/MDY, compact numeric dates, full/abbreviated month names, ordinals, Roman-numeral months, month/year periods, and mixed-format range endpoints.
- When a numeric date is genuinely ambiguous (for example `03/04/2026`), DevMonitor uses the established day/month convention rather than silently switching interpretation. If one side is greater than 12, the unambiguous interpretation is used.
- External date strings are normalized to canonical ISO `yyyy-MM-dd` before storage/comparison.
- Report filename coverage is now represented as an actual start/end date pair, so a filename such as `SEPT 1-23RD` cannot accidentally become September 30.
- Do not alter payment calculation/pathway code as part of this date-parser work.

## 1. PRODUCT PURPOSE

DevMonitor is a mobile-first operational monitoring and decision-support application for GLO company/partner device codes and partner codes.

It supports:
- SMS-based device/partner monitoring;
- daily and monthly observations;
- SMS recovery and deliberate rechecks;
- Bar 48 / Bar 96 monitoring;
- Active, MTD, Today and flag analytics;
- agents/partners and linked device records;
- payment/incentive monitoring;
- Excel export and file sharing;
- Google Drive private backup/restore;
- guided onboarding;
- Premium/AdMob monetization for the public/GetApps build;
- and, now, intelligent reading of headquarters SIMReg/Activations Excel reports.

**DevMonitor is NOT the company's official accounting, activation-validation, or payment system.**

---

## 2. NON-NEGOTIABLE PAYMENT / AUTHORITY WARNING

Whenever DevMonitor shows payment, incentive, payout, activation-reward, or settlement information, the UI must make this warning prominent:

> **⚠ PAYMENT / INCENTIVE WARNING — MONITORING / ESTIMATION ONLY**  
> DevMonitor cannot validate or certify company payment records. Any payment, activation, incentive, or settlement figure shown by DevMonitor is for monitoring/estimation unless separately confirmed by the company. **The company's official data remains the final authoritative report.**

Purpose: prevent users from treating DevMonitor estimates as a company-certified amount and then creating unnecessary disputes.

This warning belongs around payment information in:
- Device Monitor;
- SIMReg Report;
- Agent/Partner Payment Tracking;
- future payment-cycle screens;
- partner incentive screens;
- exports that contain estimated payout information.

---

## 3. STABLE 4.1 FUNCTIONAL BASELINE — DO NOT REGRESS

### Monitoring
- GLO-GD = company ownership.
- GLO-DD / GLO-FD = partner ownership.
- Standalone non-blank partner codes are supported; partner format is intentionally open.
- User input is case-insensitive and normalized to uppercase for SMS transmission.
- Hyphens are preserved.
- Destination 3030 receives the canonical short GLO device form immediately before transmission.
- Other SMS destinations receive the normalized code as entered.
- No RCS fallback; SMS uses Android `SmsManager`.
- Visible SIM selector supports dual/multi-SIM phones.
- Phone/default active SIM handling is preserved.
- SMS sent/delivery monitoring is preserved; negative delivery can trigger up to two immediate retries before the next query, with visible warning while the batch continues.
- Normal batch queries use the established 2-minute response timeout.
- SMS batch automation supports the established default single send and optional repeat counts.
- SMS permissions are requested in response to the relevant operation and accompanied by disclosure.

### Stable GLO identity
Example:
`GLO-GD-OGN-da3-3GOGN047-666D` → `GLO-GD-666D`

Same canonicalization applies to GLO-DD/GLO-FD. Non-GLO codes remain unchanged.

Canonical identity is used for:
- code entry/import;
- daily observations;
- agent/device links;
- saved-list membership;
- report comparisons;
- Excel export de-duplication.

### Same-day monitoring
- A device may be checked repeatedly on the same calendar day.
- A previous successful result never permanently locks the device.
- Daily key remains `canonical_device_code + calendar_date`.
- Later/cumulative same-day results replace the current daily snapshot while operational history remains traceable.
- This is essential because sales/activity can continue throughout the day.

### SMS recovery/recheck
- Optional READ_SMS recovery reconciles relevant existing SMS after interruption/app closure.
- Recovery is limited to the configured monitoring destination and valid SIMReg responses.
- Direct code matching is preferred.
- Otherwise persisted outbound query attempts are used for timestamp/sequence correlation.
- Ambiguous responses are never silently assigned.
- Query attempts are retained for 14 days and pruned.
- Supported workflows include Recheck this code, Recheck previously checked, Continue unresolved and Recheck all.

### Analytics
Existing observation fields:
- Today
- MTD
- Active
- Bar 48
- Bar 96
- Duplicates
- Monthly Target
- received_at

Existing analytics/flags include:
- company day-1 zero-sales behavior;
- company day-7 zero-sales monitoring rule remains part of the established operational logic;
- company day-15 MTD-below-10 logic;
- consecutive zero-sales-day monitoring;
- Conversion Lost / Bar 48 increases;
- increasing Conversion Lost trend;
- recent-pattern deviation monitoring;
- company/partner summary totals.

The day-15 MTD-below-10 diagnostic flag remains hidden from normal UI by default and can be revealed using the existing diagnostic gesture.

Analytics retention supports up to 60 months through the existing setting.

---

## 4. DEVICE MONITOR PAYMENT / INCENTIVE RULES

**All confirmed payment/incentive rules apply to Device Monitor and the new SIMReg Report workflow through one common rules engine.** There must not be two contradictory calculators.

### Activation vs registration
- A SIM Reg/registration is not automatically an activation.
- The company pays primarily on **activations**, not mere registration.
- Activation qualification involves the company's known rule: at least **₦20 recharge** and the required call/use behavior over the following monitoring period represented operationally by the Bar 48 / Bar 96 process.
- The ₦20 qualification threshold is distinct from the ₦200 minimum used for the separate estimated first-recharge incentive calculation.

### Individual/device reward tiers currently captured
- 30 activations → ₦9,000
- 40 → ₦16,000
- 50 → ₦22,500
- 70 → ₦35,000
- 100 → ₦65,000

### Estimated recharge component
- Minimum recharge basis for the incentive estimate: **₦200**.
- Estimated first-recharge bonus: **₦250 per activation**.
- The report cannot determine the actual recharge class achieved by each activation, so this is an **estimate**, not confirmed payout.

Examples:
- 24 activations → estimated ₦6,000 recharge bonus; no fixed performance tier yet.
- 27 → 3 more to 30 → ₦9,000 fixed tier when reached.
- 38 → 2 more to 40 → ₦16,000 fixed tier when reached.
- 48 → 2 more to 50 → ₦22,500 fixed tier when reached.

Preferred encouragement:
**“Do more. Reach the next level. Earn better.”**

Do not use discouraging wording such as “No performance reward” when someone is below 30; show the attainable next level instead.

### Important implementation boundary
The reward tiers are activation-based. A SIM Reg report alone must not be silently converted into activation counts for payout estimation. When the imported workbook is a SIM Reg report, DevMonitor may show registration performance but must clearly state that payment estimation cannot be certified from registration alone. An Activations report can be used for activation-based monitoring estimates.

### Partner-wide incentive
- Minimum known partner threshold: **500 activations** across the partner portfolio in the applicable payment cycle.
- Some partners use 1,000 or 1,500 thresholds.
- Partner payout amounts/rules vary and are not yet fully specified.
- Partner thresholds and payout rules must therefore be configurable rather than hard-coded as universal facts.
- Partner-wide target and individual device reward position are separate concepts.

---

## 5. PAYMENT CYCLE

Default company/payment cycle:

**21st of previous month → 20th of current month**

Example:
- September payment cycle = August 21 → September 20.

A calendar-month option already exists in the operational payment tracker, but the 21–20 cycle is the default.

Payment-cycle performance is distinct from:
- calendar MTD;
- same-period previous-month comparison;
- Today;
- Bar 48/96.

### Existing payment tracker
The 4.1 baseline already contains:
- Agent database;
- multiple phone numbers;
- linked device/partner codes;
- payment cycles;
- payment records;
- payment-cycle observation records (performance fields only); payment status is not displayed or tracked as a DevMonitor responsibility;
- month-end snapshot scheduling.

### Required future correction/extension
The current payment snapshot stores the latest observation snapshot. A future payment-calculation implementation must calculate **actual activation counts within the 21–20 cycle**, not incorrectly substitute calendar MTD. Preserve the existing tracker while extending it carefully.

---


### 4.2 payment-status boundary
- DevMonitor does not track, display, label, or infer whether a company payment has been made.
- The previous PAID/UNPAID display has been removed from payment-cycle views.
- Payment/incentive figures remain monitoring/estimation only, with the company's official data as the final authority.

### 4.2 HQ report table view
- Imported SIM Reg / Activations search results use an Excel-like horizontal table rather than individual tiles/cards.
- Each device occupies one row so multiple devices can be compared vertically.
- Columns include Device ID, Partner, Trade, Cluster, Region, Territory, Staff, daily columns 01–31, MTD, and GRAND TOTAL.
- The table scrolls horizontally so the full month can be inspected on a phone.
- Search and hierarchy filters continue to reduce the visible rows.

## 6. HEADQUARTERS REPORT INTELLIGENCE

Headquarters currently supplies two report flavors that serve the same monitoring purpose:

### A. SIM Reg as at [date]
Represents registrations/sales recorded at that point in time.

A line can appear here even though it has not yet qualified as an activation.

### B. Activations as at [date]
Represents activation-qualified results.

DevMonitor must accept **either** report flavor.

### Authority rule
Headquarters has the final authoritative data. DevMonitor is a monitoring/operational tool and cannot validate the company's final report.

---

## 7. HEADQUARTERS XLSX STRUCTURE DETECTION

Do NOT assume:
- a fixed filename;
- a fixed sheet name;
- the first sheet;
- the second sheet;
- a fixed column letter.

A workbook may have one sheet or multiple sheets.

The importer should identify the detailed working sheet by structure/content. Strong indicators include:
- Device ID;
- Channel Partner Name;
- Trade Code;
- Cluster;
- Region;
- Territory;
- Staff Name;
- daily date/day columns;
- GRAND TOTAL/Total;
- many individual device records.

The current real headquarters workbook demonstrated this structure with a summary sheet and a detailed GLOZONE device-level sheet. The implementation must generalize beyond those exact names.

---

## 8. HQ REPORT DATA MODEL

Detailed rows may contain:
- Trade Code
- Channel Partner Name
- Device ID
- Cluster
- Region
- Territory
- Staff Name
- daily values (`-01`, `-02`, … or equivalent date/day columns)
- GRAND TOTAL
- additional report-specific columns

Headers must be normalized and found by name.

Preserve the original displayed capitalization and values from the report.

---

## 9. ORGANIZATIONAL HIERARCHY

Current operational hierarchy:

**Cluster → Region → Staff Name → Territory → Device ID**

Partner relationship fields sit alongside the hierarchy:

**Channel Partner Name + Trade Code**

Do not invent a Division level. Do not hard-code current column letters.

---

## 10. REPORT ENTRY / FILTER PATTERNS

One underlying HQ dataset supports different user entry patterns.

### GLO staff
Search by Staff Name and show:
- all devices;
- Device ID;
- Channel Partner Name;
- Trade Code;
- Territory;
- Region;
- Cluster;
- daily values;
- totals;
- relevant additional fields.

### Regional management
Search by Region and reveal subordinate:
- Staff Names;
- Territories;
- Devices;
- partner/trade information;
- daily values/totals.

### Cluster management
Search by Cluster and reveal:
- Regions;
- Staff Names;
- Territories;
- Devices;
- partner/trade information;
- activation/registration information.

### Channel partner
Search by Channel Partner Name or Trade Code and show:
- all associated devices;
- Cluster;
- Region;
- Territory;
- responsible Staff Name;
- device performance;
- partner portfolio total;
- configurable partner target/progress;
- devices approaching individual reward thresholds.

### General device investigation
Search by:
- full Device ID; or
- partial Device ID, including remembered last four characters.

Partial search can return multiple devices. Always display the full Device ID for each match.

Once a device is selected, show its complete associated record.

### Matching rule
All searches are case-insensitive. Examples:
- AYETORO = Ayetoro = ayetoro.
- Device ID case variants match.
- Partner/trade/staff/region/cluster searches are case-insensitive.

---

## 11. REPORT CUTOFF AND MTD

The first practical question after finding a device is:

**“How much has it done up to this point in the month?”**

Rules:
- MTD uses the effective report cutoff.
- Do not blindly use the phone's current date.
- Do not rely on the filename alone.
- Inspect workbook content/metadata/date columns where available.
- HQ reports may lag the phone date by 1–2 days.
- A report cannot legitimately contain future sales beyond the effective reporting date.
- Sum daily values through the effective cutoff.

For a SIM Reg report, call the measure **registration MTD** unless the report explicitly represents activations.

For an Activations report, call the measure **activation MTD**.

---

## 12. MONTH-OVER-MONTH COMPARISON

When comparing current and previous month:
- compare equal elapsed periods;
- current Sep 1–cutoff compares with Aug 1–same day;
- do not compare partial current month against the full previous month;
- use effective report cutoff, not phone date.

Show both:
1. sales/activation pattern;
2. absolute number of sales/activations.

The same comparison engine can later operate at:
- device;
- staff;
- territory;
- region;
- cluster;
- partner.

---

## 13. DEVICE MONITOR ↔ HQ REPORT BRIDGE

Keep the datasets distinct:

**HQ SIMReg:** what headquarters reported.  
**DevMonitor Device Monitor:** what DevMonitor monitored locally.

An optional combined working view compares:
A. devices in the current HQ report;
B. devices saved/monitored locally.

A local device absent from HQ must remain visible in the user's working view because it may still be operationally important, especially when locally monitored activity is zero.

Example combined status:
- HQ SIMReg: Not present
- DevMonitor Monitor: Present
- Latest local result: 0
- Monitoring status: Active

Never destructively merge or overwrite one source with the other.

---

## 14. PRIVATE CROSS-MONTH MISSING-DEVICE ANALYSIS

This is **private/user-only functionality**, not a normal manager alert.

Compare previous completed-month HQ report against current HQ report.

Definitions:
- Listed in current report with MTD 0 → **confirmed zero** (because the device is actually listed).
- Listed previously but absent from current report → **missing/inferred**, NOT proof of zero.

Reason for privacy:
- Devices can be legitimately removed from a user's local database.
- Historical disappearance must not automatically expose deletion history or create routine management questions.

### Private Find Device
For each private missing device:
- use the full canonical Device ID;
- search the entire current HQ workbook, not just the user's current scope;
- determine whether it moved to another Staff, Territory, Region, Cluster, Channel Partner or Trade Code;
- show the current location/ownership context if found;
- leave it unresolved if not found.

Unlock mechanism is intentionally not finalized yet.

---

## 15. HQ REPORT RETENTION

### Current period
Keep a rolling window of the **three most recently uploaded/current-period reports**.

Example:
- Sep 2 → Sep 2
- Sep 4 → Sep 2, Sep 4
- Sep 6 → Sep 2, Sep 4, Sep 6
- Sep 8 → Sep 4, Sep 6, Sep 8; remove Sep 2
- Sep 10 → Sep 6, Sep 8, Sep 10; remove Sep 4

### Full-month historical archives
A completed full-month report is historical reference data and is NOT part of the rolling three-report deletion rule.

Keep three months of completed monthly reports. Once older than the retained three-month archive window, the oldest eligible historical report can be removed.

Retention decisions must use:
- coverage period;
- report period;
- upload/received metadata;
- report type;
not filename alone.

---

## 16. FILES, CLOUD AND SHARING — 4.0 BASELINE

### Google account / Drive
- Optional Google Sign-In.
- Private Google Drive app-data backup/restore.
- Local SQLite remains primary operational storage.
- Nothing is uploaded until the user explicitly chooses Backup.
- Restore replaces the local database only after explicit user choice and reload.
- Uses private `drive.appdata` scope.
- No client secret/service-account credential embedded in APK.

### Files & Analysis
- Attach spreadsheets/reports/reference files.
- Keep associated file names.
- Share last attached file.
- Share last Excel report.
- Android Share sheet can send to WPS Office, email, cloud storage or an available analysis service.

---

## 17. SAVED LISTS

- Saved Lists support Manage.
- Add one or multiple normalized codes.
- Remove selected codes.
- Duplicate additions are ignored.
- GLO canonicalization is preserved.
- Removing a code from a saved list does not delete main device/history data.
- Existing Load/Delete behavior remains.

---

## 18. GUIDED TOUR / ONBOARDING
## 18.1 CURRENT ONBOARDING TOUR REQUIREMENT — IMPLEMENTED

**Status: IMPLEMENTED in the current development package; build verification is pending because the local environment cannot download Gradle 8.7 while offline.**

### A. SMS CHECKER operational guided tour

- Restore the **old Device Monitor guided tour** and attach it to the renamed dashboard action **SMS CHECKER**.
- This is the operational tour for the SMS Checker itself. It is the same established guided-tour flow that previously belonged to Device Monitor/SMS checking, rather than a new generic app tour.
- The same operational tour must remain available from the application menu.
- The tour should explain the SMS Checker controls and workflow, but it does **not** need to force the user through steps that are already established by the way they entered the screen. For example, if SIM selection has already been completed by the entry flow, the tour may skip that part.
- The tour must use the real SMS Checker controls/workflow; it must not simulate SMS sending, results, exports, or other operational actions merely for the tour.
- A first-time visit to SMS CHECKER from either of these routes must be able to start the guided tour:
  1. Dashboard → **SMS CHECKER**.
  2. Dashboard → **CHECK MY DEVICES** when that flow takes the user into SMS Checker.
- The first-time trigger should be based on the user reaching SMS Checker for the first time, not solely on which dashboard button was pressed.
- After the tour has been completed or deliberately skipped, it should not repeatedly auto-launch. The existing manual/restart route from the menu remains available.

### B. New-user dashboard orientation after profile creation

- After a new user successfully creates/saves their profile, the first return to the main dashboard should start a **brief dashboard orientation tour**.
- This dashboard orientation is separate from the SMS CHECKER operational tour and separate from the first-run introduction/profile-building spotlight.
- The dashboard tour should require **no button press to advance**. It automatically moves from one major dashboard section/card to the next.
- Each major dashboard card/section is highlighted in turn with a short plain-language explanation of what that section does and why the user would use it.
- The description should remain visible long enough for a normal person to read and comprehend without feeling rushed. **Approximately 5 seconds per highlighted section** is the initial documented target; this is a UX timing target, not a new background-processing operation.
- The tour should progress through the major dashboard actions, including the current primary areas such as:
  - **BUILD PROFILE** / profile management when applicable;
  - **SMS CHECKER**;
  - **MY DEVICES**;
  - **LOAD REPORT**;
  - **EARNING PROGRESS**;
  - other major dashboard cards that are actually present for the user's role/profile.
- The tour must be role-aware: it should only explain dashboard sections that the user can actually see/use.
- The user should have a clear way to dismiss/skip the orientation rather than being trapped in it.
- This automatic dashboard orientation is a **one-time first-run experience after profile creation**. It must not replay on every dashboard visit.
- Re-editing or rebuilding an existing profile must not restart the dashboard orientation as though the user were a new user.

### C. Relationship to the BUILD PROFILE card

- The prominent **BUILD PROFILE** card remains a first-setup aid while no profile has been successfully built/saved.
- Once a profile is successfully built/saved, that prominent first-setup card disappears from the dashboard.
- The normal profile-management capability remains available through the established profile/settings paths.
- The post-profile dashboard orientation must therefore explain the dashboard in its new post-setup state rather than treating BUILD PROFILE as an outstanding action.

### Implementation notes

- The restored SMS CHECKER tour starts when the user first reaches SMS Checker from the dashboard or from the Check My Devices route, and it can begin at the first relevant operational step instead of forcing an already-completed entry step.
- The existing manual Guided Tour entry remains available from the menu.
- The post-profile dashboard orientation is a separate automatic overlay with approximately 5-second reading intervals and no Next button.
- The dashboard orientation is recorded as completed so it does not replay on subsequent dashboard visits.
- The BUILD PROFILE first-setup card continues to disappear naturally once a profile exists.
- No payment, report, Device Monitor data, Company Skeleton, hierarchy, MOM, or calculation logic was intentionally changed by this onboarding implementation.

### D. Protected boundaries

These onboarding changes are UI/onboarding changes only. They must not modify:

- established payment formulas or progression rules;
- the 21st-to-20th payment cycle;
- Device Monitor/SMS business rules;
- Company Skeleton data model;
- Cluster (Division) → Region → Territory → Staff → Devices / Trade Codes hierarchy;
- two-month authoritative HQ storage;
- atomic Replace-All report import;
- Loaded Report calculation/display rules;
- Month-on-Month architecture;
- explicit-refresh/performance rules.

**Implementation status remains: DOCUMENTED ONLY.**

## 19. SETTINGS / APP EXPERIENCE

Existing Settings includes:
- System default / Light / Dark theme;
- Monitor settings;
- SMS destinations;
- analytics retention;
- Guided Tour Again;
- local data summary;
- Google account/cloud backup/restore;
- Premium controls;
- Files & Analysis;
- About;
- Feedback.

Full left navigation drawer contains:
- Guided Tour;
- About the App;
- Feedback & Suggestions;
- Files & Analysis;
- Settings;
- Open Device Monitor quick access.

Dashboard bottom navigation includes:
- Devices;
- Agents;
- Payments;
- Settings.

---

## 20. AGENT / PARTNER DATABASE

Stores:
- Agent/partner name;
- address;
- multiple phone numbers;
- latitude/longitude;
- linked device/partner codes.

Phone numbers can be selected from Android Contacts.

Location can use present/last-known device location or manually entered coordinates.

Google Maps can be opened for coordinate verification.

---

## 21. MONTH-END AUTOMATION

Existing month-end scheduler:
- checks the last calendar day at approximately 20:30 local time;
- captures the current payment snapshot;
- attempts to reopen/run the normal monitoring workflow;
- preserves the saved snapshot even if Android defers background activity launch.

Do not remove this behavior when extending payment-cycle calculations.

---

## 22. MONETIZATION — 4.1 GETAPPS PREMIUM BASELINE

Xiaomi GetApps Premium build:
- Monthly target: ₦2,000/month.
- Yearly target: ₦20,000/year; store-configured price is authoritative.
- Premium removes banner, interstitial and rewarded ads.
- Premium bypasses rewarded-export restriction.
- Restore Premium and Manage Subscription are available.
- Xiaomi GetApps IAP SDK 1.1.9.
- SKUs:
  - `fieldpulse_remove_ads_monthly`
  - `fieldpulse_remove_ads_yearly`
- Stable obfuscated account ID used for purchase flow.
- Subscription entitlement is rechecked on startup/restore.

Production AdMob IDs are preserved from the established production configuration.

Do not change monetization/toolchain configuration while implementing HQ report intelligence unless necessary.

---

## 23. EXCEL EXPORT BASELINE

Existing export:
- one row per canonical device identity;
- GLO device rows use short form;
- legacy long/short duplicates collapse to one row;
- latest completed result wins;
- report includes Sales Report, Flags and Summary;
- Excel can be opened/shared through Android flows.

Existing rewarded export policy for free/public users remains:
- first 10 successful exports are free;
- after that, completed rewarded ads grant export credits;
- credit is consumed only after successful export;
- Premium bypasses the restriction.

The HQ report importer must remain dependency-light and must not introduce Apache POI.

---

## 24. HQ FOUNDATION PRESENT IN THIS DEVELOPMENT ZIP

Current foundation files include:
- `SimRegReport.kt` — structure-aware HQ XLSX parsing and report UI foundation.
- `PaymentRules.kt` — shared incentive rule definitions.

Foundation behavior:
- identifies detailed sheet by content/structure;
- supports one or multiple sheets;
- reads shared strings and inline values;
- detects SIM Reg vs Activations report text where available;
- extracts report coverage dates from workbook text where available;
- extracts hierarchy/partner/device fields;
- extracts daily columns and totals;
- supports case-insensitive searching;
- calculates report-period MTD through effective cutoff;
- displays prominent payment authority warning.

### Not yet complete
- rolling three-current-report automatic retention;
- three-month full-month archive cleanup;
- private previous/current report comparison;
- private Find Device across the full current workbook;
- complete HQ↔Device Monitor reconciliation screen;
- complete staff/region/cluster/partner scope dashboards;
- configurable partner payout structures;
- exact payment-cycle activation aggregation;
- complete integration of the shared incentive engine into every Device Monitor payment presentation.

These must not be described as finished until implemented and tested.

---

## 25. BUILD ENVIRONMENT — PRESERVE EXACTLY

Established successful phone-build environment:
- Android Code Studio / ARM64 Android phone;
- AGP 8.6.1;
- Gradle 8.7;
- Kotlin 2.0.21;
- Kotlin Compose plugin 2.0.21;
- Java/JDK/JVM target 17;
- compileSdk 36;
- targetSdk 36;
- minSdk 26;
- Gradle workers = 1;
- parallel Gradle execution disabled;
- no Apache POI;
- XLSX handling through internal ZIP/XML APIs.

### ARM64 AAPT2 — critical
The successful phone build does NOT depend on the normal desktop Linux AAPT2 binary.

`build-phone.sh` automatically searches these Android Code Studio/phone locations:
- `$HOME/.androidide/aapt2`
- `$PREFIX/bin/aapt2`
- `/data/data/com.tom.rv2ide/files/usr/bin/aapt2`
- `/data/data/com.tom.rv2ide/files/home/.androidide/aapt2`
- `/data/user/0/com.tom.rv2ide/files/usr/bin/aapt2`
- `/data/user/0/com.tom.rv2ide/files/home/.androidide/aapt2`

It then passes the discovered binary using:
`-Pandroid.aapt2FromMavenOverride="$AAPT2"`

If no ARM-compatible AAPT2 is found, the script stops instead of silently falling back to an incompatible desktop binary.

### Build commands
Debug/release APK:
`sh build-phone.sh assembleRelease`

AAB:
`sh build-phone.sh bundleRelease`

For first validation of a new development build, use:
`sh build-phone.sh assembleDebug --console=plain`

### Gradle properties
- `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8`
- AndroidX enabled;
- one Gradle worker;
- parallel disabled;
- compileSdk 36 compatibility warning suppressed.

Do not change AGP/Gradle/Kotlin versions simply to add the HQ report feature.

---

## 26. DATABASE BASELINE

SQLite database:
`simreg_monitor.db`

Current database version: **9**.

Existing tables/areas include:
- codes;
- records;
- history;
- daily observations;
- saved lists;
- SMS inbox/recovery;
- persisted SMS query attempts;
- agents;
- agent phones;
- agent-device links;
- payment cycles;
- payment records;
- settings.

Migration history includes canonicalization of GLO device identities and SMS recovery tables.

Do not reset or destructively replace existing user data when adding HQ reports.

---

## 27. PRIVACY BOUNDARIES

Normal manager/colleague views must not expose the private missing-device comparison.

Normal report views may show current HQ report additions and operational information needed for the selected scope.

Private missing/disappeared historical-device analysis is deliberately separate.

Do not expose local deletion history as a proxy for HQ disappearance.

Payment estimates must never be presented as company-authoritative.

---

## 28. DEVELOPMENT RULES

1. Preserve all working 4.1 behavior unless a change is intentional.
2. Preserve SMS transmission and recovery behavior.
3. Preserve Saved Lists and membership management.
4. Preserve Google Drive backup/restore.
5. Preserve AdMob and GetApps Premium behavior.
6. Preserve guided tour and onboarding behavior.
7. Avoid dependency/toolchain churn.
8. Do not add Apache POI.
9. Use internal ZIP/XML XLSX processing compatible with the phone build.
10. Test on actual Android Code Studio/ARM64 hardware.
11. Never claim a build is verified unless it actually compiled/tested.
12. Do not treat registration as activation for payment calculations.
13. Keep HQ and Device Monitor datasets distinguishable.
14. Keep private missing-device analysis out of normal manager views.
15. Make payment warnings prominent wherever estimates are displayed.
16. Do not invent partner payout rules.
17. Do not assume report filename/sheet order/column letter.
18. Preserve original report display values while matching case-insensitively.
19. Use full canonical Device ID for private Find Device.
20. Retain enough HQ reports for the defined rolling/current and historical windows.

---

## 29. ACCEPTANCE TESTS — EXISTING 4.1 REGRESSION

- App launches and initial introduction remains separate from guided tour.
- Drawer opens and all established entries work.
- Theme changes persist.
- SIM selection works on multi-SIM phone.
- SMS permissions/disclosure work.
- Normal SMS batch works.
- Delivery monitoring/retry works where supported.
- App-killed SMS recovery works.
- Ambiguous SMS is not guessed.
- Same-day recheck updates the daily snapshot.
- Long/short GLO forms remain one device.
- Non-GLO partner codes remain unchanged.
- Saved List Manage works.
- Excel export works.
- Rewarded export limits work for free users.
- Premium removes ads/export restriction.
- Google backup/restore works when configured.
- Share last report/file works.
- Payment tracker opens and cycle snapshots are preserved.
- Month-end scheduler remains intact.

---

## 30. ACCEPTANCE TESTS — HQ REPORT FOUNDATION

1. Import a multi-sheet workbook with the detailed sheet not first.
2. Import a one-sheet detailed workbook.
3. Import SIM Reg as-at report.
4. Import Activations as-at report.
5. Detect report type from content when available.
6. Detect effective coverage dates from workbook content when available.
7. Find the detailed table structurally rather than by fixed sheet name.
8. Read Device ID, Staff, Territory, Region, Cluster, Partner and Trade Code.
9. Search every supported field case-insensitively.
10. Search partial Device ID and display full matches.
11. Calculate registration MTD for SIM Reg reports.
12. Calculate activation MTD for Activations reports.
13. Do not calculate activation payout from SIM Reg merely because a row has a daily value.
14. Show the prominent payment/authority warning.
15. Verify the same incentive rules are used by the eventual Device Monitor and report payment views.
16. Preserve the current Device Monitor dataset independently from HQ data.
17. Verify local-only devices remain visible in the bridge view.
18. Verify private missing-device analysis is not exposed to ordinary manager views.
19. Verify current-report rolling retention.
20. Verify full-month historical retention.

---

## 31. CONTINUITY NOTE

When continuing this project in a future chat, treat this worksheet and the latest source ZIP as the authoritative development context.

**Do not replace the 4.1 phone-build environment. Do not assume the HQ report is always named or structured the same way. Do not treat DevMonitor payment estimates as company-authoritative.**

## Android Excel “Open With DevMonitor” Integration — 4.2
### Purpose
DevMonitor can now be selected by Android as an application for opening supported Excel workbooks. This provides a natural workflow when HQ sends a report through Downloads, a file manager, Google Drive, WhatsApp/document sharing, or another Android app that exposes the workbook with a compatible MIME type.

### External open flow
1. User taps an `.xlsx` workbook in another Android app.
2. Android may show DevMonitor among the available apps for opening the workbook.
3. DevMonitor receives the workbook URI through `ACTION_VIEW`.
4. DevMonitor shows an explicit **Import Excel sheet?** dialog with the workbook filename.
5. User chooses **Import** or **Cancel**.
6. Import uses the existing `SimRegReportParser`, so the same structure-aware sheet detection, SIM Reg vs Activations detection, coverage-date logic, hierarchy extraction, daily values, and MTD behavior are retained.
7. A successful import opens the SIMReg Report analyzer.

### Safety / behavior
- No external workbook is imported silently.
- Cancel does not modify the workbook or DevMonitor data.
- Filename is display-only; the parser continues to inspect workbook contents rather than trusting the filename.
- Supported external format in 4.2: `.xlsx` (Office Open XML). Legacy binary `.xls` is not claimed as supported.
- Existing in-app **Import SIMReg Report** remains available.
- This is an import/analyze flow, not an editor for modifying the HQ workbook.

### 4.2 Excel Open/Import build correction
The first Excel Open/Import package contained two Kotlin compile-time mistakes that have now been corrected: the parser explicitly returns its `SimRegReport`, and the report screen reads `report.reportType` rather than expecting a `reportType` property on `SimRegReportRow`. No business-rule behavior was changed by this correction.

## 4.2 — Excel report row/column focus refinement
- Device rows are selectable by normal tap.
- The selected device row remains visibly highlighted while horizontally scrolling through daily values, MTD, and TOTAL.
- Daily, MTD, and TOTAL columns can also be selected; the selected column is highlighted across rows for easier vertical comparison.
- A small focus indicator identifies the selected device and selected column.
- Row/column focus is presentation-only and never changes imported HQ data.

## CURRENT DEVELOPMENT PATCH — Excel table interaction repair

### Problem found in 4.2.x
The Excel-style SIMReg table became difficult/unresponsive to scroll after entering the table. The implementation placed `horizontalScroll(tableScroll)` on every device row and also placed transform-gesture detectors on the header and every row. Those nested gesture handlers competed with the outer vertical `LazyColumn`.

### Corrected design
- Device rows are rendered as items in the report screen's main `LazyColumn`, so off-screen rows are not all composed at once.
- Stable `Device ID` keys are supplied to the row items for better Compose reuse/recycling.
- The header and every virtualized device row share the same horizontal `ScrollState`, keeping columns aligned.
- Vertical scrolling remains controlled by the report screen's main `LazyColumn`.
- Pinch zoom is handled only when at least two fingers are down.
- Zoom remains 60%–200%; visible +/- controls and zoom percentage are removed. Pinch is the only zoom control.
- The original workbook data, parsing, filtering, Customize View, focus behavior, and business rules remain unchanged.

### Acceptance test for this patch
1. Open an imported SIMReg/Activations report.
2. Drag vertically through the report and continue smoothly through the table area.
3. Drag horizontally on any table cell/header and verify the entire table follows the same horizontal position.
4. Scroll vertically again without the table becoming stuck.
5. Pinch with two fingers and verify the table zooms smoothly.
6. Confirm there is no visible +/- zoom control or zoom percentage.
7. Confirm one-finger scrolling does not accidentally zoom or freeze.
8. Verify row/column focus still works.
9. Verify Customize View still works.
10. Verify no report values or parsing behavior changed.

### Build status
Source patch prepared in the current development ZIP. The cloud/container environment cannot download the project's Gradle 8.7 distribution, so compilation must be performed in the established Android Code Studio phone environment before release.

## CURRENT DEVELOPMENT PATCH — Pinch zoom compile correction
The first table interaction repair did not compile because the project's Compose version does not expose the imported `calculateZoom()` extension, and the gesture block used an invalid nested restricted coroutine scope.

### Correction
- Pinch zoom now calculates the distance between the first two active pointers directly.
- The gesture handler uses `awaitEachGesture` directly without nesting another `awaitPointerEventScope`.
- Only two-finger events are consumed.
- One-finger horizontal and vertical scrolling remains available to the normal scroll containers.
- Zoom remains 60%–200% with the existing +/- controls.

### Required phone acceptance test
1. Build successfully with Android Code Studio.
2. Open a SIMReg/Activations report.
3. Scroll vertically through the table continuously.
4. Scroll horizontally and verify the whole table moves together.
5. Pinch with two fingers and verify the table zooms smoothly.
6. Confirm there is no visible +/- zoom control or zoom percentage.
7. Release one finger and confirm ordinary scrolling remains responsive.


## CURRENT DEVELOPMENT PATCH — SIMReg table virtualization / crash prevention
The table rendering was changed after reports of freezing/crashing while scrolling an imported Excel workbook. The previous implementation composed up to 300 wide spreadsheet rows inside one regular `Column`, which could create a very large Compose layout/draw workload.

### Performance correction
- The outer report `LazyColumn` now owns the table rows directly through keyed `items(...)`.
- Only rows near the viewport are composed by Compose's lazy list mechanism.
- Header and rows retain a shared horizontal scroll state so horizontal movement remains synchronized.
- Two-finger pinch remains the only zoom mechanism, with the internal 60%–200% limit.
- No parser, workbook persistence, report calculations, or business-rule changes are included.

### Required phone acceptance test
1. Build successfully with Android Code Studio.
2. Import/open a real SIMReg/Activations workbook.
3. Scroll vertically from the top through many rows continuously.
4. Continue scrolling through the table and confirm the UI remains responsive without freezing/crashing.
5. Scroll horizontally on a row/header and confirm the same horizontal position is reflected by the other table rows.
6. Pinch with two fingers and verify the table scales smoothly.
7. Confirm there are no visible zoom buttons or percentage.
8. Confirm row/column focus and Customize View still work.

## 4.2.x — Company SIMReg intelligence consolidation status
The practical HQ-report features discussed for the company SIMReg import are now implemented in the development source:
- report-type-aware SIM REG vs ACTIVATIONS treatment;
- report-cutoff MTD and equal-elapsed previous-report comparison;
- Cluster / Region / Staff / Territory / Partner hierarchy dashboard;
- private full/partial Device ID search and missing/inferred analysis;
- HQ ↔ Device Monitor non-destructive reconciliation summary;
- retained-report-based 21→20 activation-cycle aggregation when source coverage is sufficient;
- shared activation incentive estimation with next-level messaging;
- persisted configurable partner activation target (default 500);
- virtualized Excel-style table with shared horizontal scroll and pinch-only zoom;
- internal workbook persistence and existing retention policy.

Still deliberately not invented because company rules are not fully specified:
- partner payout amounts beyond the configurable activation threshold;
- any claim that DevMonitor can certify company payment status or activation qualification from registration alone.

Phone build and device testing remain mandatory before calling this stable.


---

## 29. 4.3.4 — AUTHENTICATION FOUNDATION

4.3.4 introduced the DevMonitor staff-account authentication model without changing the established monitoring, parser, payment-estimation, SMS, or local SQLite business logic.

### Account identity
- DevMonitor Account ID is separate from the Google email address.
- Google is the identity anchor.
- Firebase Authentication is now the authentication authority for the 4.3.4.1 build.
- The account is intended to be shared conceptually across future Android/Web/PC clients.
- Android installation state must not be treated as the authoritative authorization state.

### Staff-line classification
The known staff-line format is used only as an eligibility/classification signal:
- configured candidate prefix: `0805557`;
- total Nigerian number length: 11 digits;
- final four digits identify the individual line within that known pattern.

A matching pattern is **not** treated as proof that the person is staff. DevMonitor has no authoritative staff registry in the current implementation.

### Staff access and Payment Intelligence
- A successful Google/Firebase authentication followed by successful OTP verification of the configured staff line establishes the user as a DevMonitor staff account.
- A verified staff account is placed in `AUTHORIZED` state and has full access to **all DevMonitor functionality**, including Payment Intelligence and the raw HQ/SIMReg data processed by the app.
- There is no second Payment Intelligence authorization gate for a verified staff account.
- Agent/partner numbers use the separate Device Manager authorization-request path when that path is retained.
- The staff-line pattern is an eligibility filter because DevMonitor does not have access to the authoritative staff registry.

---

## 30. 4.3.4.1 — AUTHENTICATION HARDENING

### Firebase integration
- Added the supplied `google-services.json` for Firebase project `fieldpulse-b3eb3`.
- Android package remains `com.aziitech.simregmonitor`.
- Existing Google Sign-In now exchanges the Google ID token for a Firebase Authentication credential.
- The Firebase UID is associated with the local DevMonitor account.
- Signing out clears both Google Sign-In and Firebase Authentication state.

### Staff-line OTP gate
The paid SMS verification path is deliberately restricted before Firebase is asked to send an OTP:
1. User must first authenticate with Google/Firebase.
2. Main phone must be a valid Nigerian 11-digit number.
3. Main phone must match the configured `0805557xxxx` staff-candidate pattern.
4. Only then may Firebase Phone Authentication request an SMS OTP.
5. The OTP credential is linked to the already authenticated Firebase/Google account.
6. Successful verification records the Firebase UID and phone-verification timestamp locally.
7. Successful staff-line verification sets the account to `AUTHORIZED` and enables full DevMonitor staff access.

Therefore an arbitrary Nigerian number cannot simply be entered and trigger a DevMonitor staff-verification SMS.

### OTP abuse controls
- A 10-minute resend cooldown is enforced in the authentication UI.
- The cooldown applies before a resend request is issued.
- Firebase's own verification throttling and SMS limits remain the final server-side protection.
- Firebase Authentication documentation supports SMS-region policy controls and imposes verification-request/SMS limits; Nigeria should be the only enabled SMS region for this project unless deployment requirements change.
- Do not attempt to defeat Firebase throttling by repeatedly retrying failed requests.

### Important limitation
The `0805557xxxx` rule is not an authoritative staff registry. Without a central staff-line registry, the app cannot independently prove that every number matching the pattern is a current employee. The OTP proves possession of the qualifying line; under the DevMonitor operating model, successful OTP verification is nevertheless the staff-account verification event that grants full app access.

### Database
Authentication schema advanced from version 8 to version 9:
- `firebase_uid`
- `phone_verified_at`

Existing authentication records are migrated in place; the existing database is not reset.

---

## 31. APP NAME / STORE IDENTITY

A current Google Play search shows an unrelated app already published as **DevMonitor** by Flicent Inc., so the Android display name should not remain exactly `DevMonitor` for public store deployment.

For the current build:
- internal project/product name remains **DevMonitor**;
- Android display/store-facing working name is **DevMonitor Monitor**;
- application ID remains `com.aziitech.simregmonitor`;
- Firebase registration remains tied to the existing application ID.

The display-name change does not change the package/application identity or existing local database.

---

## 32. FIREBASE CONSOLE CHECKLIST BEFORE PHONE TEST

The source code alone cannot enable the Firebase-side providers/policies. Before the first real OTP test:

1. Open Firebase project `fieldpulse-b3eb3`.
2. Enable **Google** under Firebase Authentication sign-in providers.
3. Enable **Phone** under Firebase Authentication sign-in providers.
4. Set the Firebase Authentication SMS region policy to **Nigeria only** for this deployment.
5. Confirm the Android app registered in Firebase uses `com.aziitech.simregmonitor`.
6. Add the SHA-1/SHA-256 fingerprints required by the Firebase/Google configuration for the actual signing key(s) used for testing and production.
7. Confirm the web OAuth client used for the Google ID token is present in the Firebase-generated `google-services.json`.
8. Test Google sign-in before testing phone verification.
9. Test one staff-pattern number only after the Google/Firebase sign-in succeeds.
10. Verify that a non-staff-pattern number is rejected locally without any OTP request.
11. Verify resend cooldown and Firebase throttling behavior.

Do not claim OTP is operational until the Firebase console configuration and actual phone test both succeed.

---

## 33. 4.3.4.1 ACCEPTANCE TEST

### Identity
1. Fresh install launches as **DevMonitor Monitor**.
2. Google sign-in succeeds.
3. Firebase Authentication receives the Google credential.
4. A DevMonitor Account ID and Firebase UID are associated.
5. Sign-out clears the Google/Firebase session.

### Staff verification
6. Enter an invalid Nigerian number → no OTP request.
7. Enter a valid Nigerian number outside `0805557xxxx` → no OTP request.
8. Enter a valid `0805557xxxx` number before Google/Firebase sign-in → no OTP request.
9. After Google/Firebase sign-in, enter a `0805557xxxx` number → Firebase OTP request is allowed.
10. Enter the correct OTP → phone is linked to the Firebase account.
11. Verify the local account records the phone verification timestamp.
12. Repeat resend immediately → blocked by the 10-minute cooldown.
13. A successfully OTP-verified staff phone places the account in `AUTHORIZED` and unlocks full DevMonitor access, including Payment Intelligence.

### Existing DevMonitor behavior
14. Existing Device Monitor/SMS workflow remains operational.
15. SIMReg import/parser remains unchanged.
16. Payment calculation rules remain unchanged.
17. Existing SQLite data survives the version-8 → version-9 migration.
18. Google Drive backup/restore remains operational.
19. Ads/billing behavior remains unchanged.
20. Build with the established Android Code Studio phone environment before declaring stable.

---

## 34. 4.3.4.3 — STAFF ACCESS CORRECTION

The 4.3.4.1 hardening build incorrectly retained a second authorization gate after successful staff-line OTP verification. That does not match the established DevMonitor operating model.

For 4.3.4.3:
- successful Google/Firebase sign-in + successful OTP on a qualifying `0805557xxxx` staff line sets the local account to `AUTHORIZED`;
- the verified staff account receives full access to all DevMonitor features;
- Payment Intelligence is available to the verified staff account;
- raw HQ/SIMReg data remains available to the verified staff account according to the existing app functionality;
- no separate central authorization step is required for staff accounts;
- the non-staff/agent authorization path remains separate.

## 35. BUILD / DEVELOPMENT DISCIPLINE FOR 4.3.4.3

- Keep AGP 8.6.1.
- Keep Gradle 8.7.
- Keep Kotlin 2.0.21.
- Keep Java/JDK 17.
- Keep compileSdk/targetSdk 36.
- Keep the ARM-compatible AAPT2 phone-build override.
- Do not replace the phone build with a desktop-only AAPT2 workaround.
- Do not introduce Apache POI.
- Do not reset the SQLite database.
- Do not weaken the staff-pattern OTP gate to make testing easier.
- Treat successful OTP verification of a qualifying staff line as the staff-account authorization event for the current DevMonitor operating model.
- Do not claim the build is stable until it has been compiled and tested on the actual Android Code Studio phone environment.


## 4.3.4.6 — Payment Landing Access Model
- Payment landing page has two primary access paths: **Staff Login** and **Partner Login**.
- Verified staff: Google/Firebase identity + successful qualifying staff-line OTP grants full DevMonitor access, including all Payment Intelligence.
- Partner: enters phone number + Trade Code and submits an approval request to a staff member. Partner payment details remain locked until staff approval.
- Current 4.3.4.6 implementation sends the partner approval request through WhatsApp; a network-backed approval/synchronization mechanism can be added as the next step if required.


### 4.3.4.7.1 — Debug Authentication Fingerprint / Build Environment
- Debug signing report verified successfully with `sh gradlew signingReport`.
- Debug keystore: `/data/user/0/com.tom.rv2ide/files/home/.android/debug.keystore`
- Debug alias: `AndroidDebugKey`
- Debug SHA-1: `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- Debug SHA-256: `1D:BE:EE:61:64:A2:FC:97:55:C3:BD:8A:7B:54:02:4A:68:22:64:69:0E:55:91:15:6D:4D:86:AE:B6:C8:AA:AA`
- Build environment: Android Code Studio on Android phone; Gradle 8.7; AGP 8.6.1; Kotlin 2.0.21; JDK 17; compileSdk/targetSdk 36; ARM-compatible AAPT2 override via `build-phone.sh`.
- Version naming for this authentication workstream remains the `4.3.4.x` family; corrections stay within that family.
- This fingerprint is the debug certificate used by the current phone development build. It must be added to the Firebase Android app configuration before retesting Google sign-in.

### 4.3.4.8 — Firebase Android OAuth Configuration
- Refreshed Firebase `google-services.json` integrated.
- Android OAuth client now present for `com.aziitech.simregmonitor` and matches the debug signing certificate.
- Build environment remains Android Code Studio on Android phone; Gradle 8.7; AGP 8.6.1; Kotlin 2.0.21; JDK 17; compile/target SDK 36; ARM-compatible AAPT2 override through `build-phone.sh`.
- Authentication corrections remain in the `4.3.4.x` family.

## 36. 4.3.4.9 — PARTNER ACCESS ARCHITECTURE (NEXT DEVELOPMENT STEP)

The next authentication/payment-access step is the real shared Partner Login → Staff Approval → Partner Unlock workflow.

### Authoritative partner approval model
- Partner approval must belong to the **partner account + Trade Code**, not to one physical Android device.
- Once staff approves a partner for a Trade Code, that approval remains valid when the partner changes phone, provided the partner authenticates as the same approved partner account.
- The same approved partner account may use the authorized Trade Code from the Android app, PC client, and web client.
- A new device is therefore a new authenticated session/device, not a new staff approval requirement.
- Device/session security remains separate from the underlying partner/Trade Code authorization.
- Staff revocation of the partner authorization must remove access across all platforms/devices using the shared authorization state.

### Access boundary
- Partner identity must be established before payment details are exposed.
- The backend must verify that the authenticated partner account has an active approval for the requested Trade Code.
- Knowing a Trade Code alone must never unlock payment information.
- A different partner account using the same Trade Code must not inherit another partner's approval.
- An approved partner Trade Code must not grant staff-level DevMonitor access.
- Verified staff accounts retain their existing full-access rule; no second Payment Intelligence gate is introduced for staff.

### Shared-platform requirement
The Android app, future PC client, and future web client must use one shared authorization authority. Local SQLite may cache operational state, but it must not become the authoritative source for cross-device partner approval.

The central authorization record should conceptually contain:
- partner account identifier;
- partner phone/contact identifier as applicable;
- Trade Code;
- approval status (`PENDING`, `APPROVED`, `REJECTED`, `REVOKED`);
- approving staff account identifier;
- request/approval/revocation timestamps;
- optional reason/audit information;
- platform/device/session audit information where useful for security.

### Current implementation gap
4.3.4.8 currently has the Partner Login form and WhatsApp approval-request notification path, plus a local authorization audit table. It does **not** yet provide a shared backend approval state that can synchronize staff approval to a partner's Android/PC/web sessions. The next implementation must add this shared authorization layer rather than pretending a WhatsApp message itself is approval.

### Database safety
- Extend the existing SQLite schema through migration only.
- Do not reset the existing database.
- Local audit/history should be preserved.
- Shared authorization identifiers must be stable across Android, PC, and web clients.

### Proposed workflow
1. Partner signs in/identifies the partner account and submits phone + Trade Code + staff approval target.
2. DevMonitor creates a unique authorization request with `PENDING` status in the shared backend.
3. Staff receives the request notification and reviews it while authenticated as a verified DevMonitor staff account.
4. Staff approves or rejects the specific partner account + Trade Code request.
5. The shared backend records the decision and audit information.
6. Partner sessions query/subscribe to the shared authorization state.
7. `APPROVED` unlocks only the authorized Trade Code's partner payment details.
8. Phone/device changes do not invalidate the approval.
9. `REVOKED` or other non-approved states lock the payment details again across platforms.

### Build/environment findings from inspection of DevMonitor 4.3.4.8
The project source still specifies the established phone-build environment:
- AGP 8.6.1
- Gradle 8.7
- Kotlin 2.0.21
- JDK 17
- compileSdk/targetSdk 36
- ARM-compatible AAPT2 supplied through `build-phone.sh`

A compilation attempt in the current non-phone inspection environment did **not** reach Kotlin/Java compilation. `build-phone.sh assembleDebug --console=plain` stopped immediately because this environment has no ARM-compatible AAPT2 at the configured locations. The diagnostic showed:
- `HOME=/home/oai`
- `PREFIX=`
- `ANDROID_HOME=`

A direct Gradle-wrapper check also could not download Gradle 8.7 because this inspection environment has no network access (`UnknownHostException: services.gradle.org`).

Therefore this inspection environment cannot certify a compilation result. The established Android Code Studio phone environment remains the authoritative place to run the actual build.

### Next phone compilation command
From the project root on the Android Code Studio phone:

`sh build-phone.sh assembleDebug --console=plain`

If the phone build reports a real Kotlin/Android compilation error after AAPT2 is found, capture that complete error before making source changes. Do not change AGP/Gradle/Kotlin versions merely to resolve an unrelated compilation problem.


## 37. 4.3.4.9 — SHARED PARTNER AUTHORIZATION FOUNDATION IMPLEMENTED

- Implemented the first working shared authorization layer using Firebase Firestore.
- The authoritative approval identity is **Firebase partner account UID + Trade Code**.
- Physical device is explicitly not the owner of approval. Device model is retained only as request/audit context.
- Partner approvals are designed to survive phone changes and to be usable by Android, future PC, and future web clients that authenticate the same partner account.
- Added shared request lifecycle: `PENDING` → `APPROVED` / `REJECTED`, with `REVOKED` supported for future revocation workflows.
- Added staff approval UI to the Payment Intelligence landing flow for verified staff accounts.
- Partner payment view filters the available payment rows to the approved Trade Code only.
- Partner checks for an existing approved Trade Code before creating a duplicate request.
- Pending request status can update live through a Firestore document listener.
- Added `firestore.rules`; rules require the partner to create/read its own request and require the configured verified staff-line identity for staff review/update.
- The shared backend is now the cross-platform authorization authority; SQLite remains local operational storage and is not authoritative for partner approval.
- Existing DevMonitor database is preserved; no reset or destructive migration was introduced.
- Version advanced to `4.3.4.9` (versionCode 67).
- 4.3.4.8 Firebase `google-services.json` was retained unchanged.

### Build status
- 4.3.4.8 is confirmed compiled and working on the user's Android phone.
- This 4.3.4.9 source was prepared from that confirmed baseline.
- The present inspection environment cannot execute the Gradle build because it cannot download Gradle 8.7 (`UnknownHostException: services.gradle.org`) and lacks the phone ARM AAPT2 binary.
- Therefore the authoritative 4.3.4.9 compilation test must be performed in Android Code Studio on the user's phone.

### Required Firebase console step before shared approval can work
- Enable **Cloud Firestore** in the existing Firebase project `fieldpulse-b3eb3` if it is not already enabled.
- Publish the included `firestore.rules` to the project's Firestore database.
- Do not use permissive/test rules in production.
- The Android app code now expects the collection `partner_authorization_requests`.

## 38. 4.3.4.10 — AUGUST HISTORICAL SEED + SAVED REPORT DELETE

- The confirmed 4.3.4.9 partner-authorization build remains the source baseline.
- The supplied August 2026 full-month SIMReg workbook is bundled at `app/src/main/assets/historical/august_2026_simreg_report.xlsx`.
- It is installed only once into the existing saved SIMReg report library using a stable seed ID, preventing duplicate copies on later launches.
- The source workbook bytes are not rewritten. Because the workbook heading contains an inconsistent date range, the seed metadata deliberately records `2026-08-01` through `2026-08-31` and `fullMonth=true` so historical comparison logic uses August correctly.
- The seed participates in the existing three completed-full-month historical archive retention policy and may eventually age out automatically.
- Saved SIMReg reports now have `Open` and `Delete` actions. Delete requires confirmation and removes only that saved workbook/metadata entry; Device Monitor/SMS data are unaffected.
- Next phone build: DevMonitor 4.3.4.10.
- Phone build command remains: `sh build-phone.sh assembleDebug --console=plain`.

## 39. 4.3.4.11 — AURORA UI REDESIGN

- Visual redesign applied from the confirmed 4.3.4.10 baseline.
- Replaced the former green-dominant palette with a deep navy/aurora palette using blue, cyan and violet accents.
- Added dimensional primary and outlined buttons with restrained elevation/shadow to create a 3D feel without changing button behavior.
- Added animated transitions between the main Dashboard, Devices, Agents, Payments and Settings pages.
- Added selected bottom-navigation icon scale animation.
- Navigation drawer continues to use native Material motion and now inherits the new visual language.
- Redesigned adaptive and legacy launcher artwork with the DevMonitor FP/signal identity.
- Avoided continuous high-cost animations so the redesign does not unnecessarily worsen the previously observed sluggishness.
- No authentication, Firestore authorization, SIMReg, August historical seed, SQLite, SMS or payment business logic was intentionally changed.
- Version advanced to `4.3.4.11` (versionCode 69).
- Phone build command remains: `sh build-phone.sh assembleDebug --console=plain`.

## 40. 4.3.4.12 — AURORA UI BUILD CORRECTION
- Correction build for the 4.3.4.11 Aurora UI source.
- Fixed over-broad Compose control replacement: native TextButton/IconButton calls are restored; intended Button/OutlinedButton calls remain wrapped by DevMonitorButton/DevMonitorOutlinedButton.
- Fixed DevMonitorUi outlined-button colors to use Material 3 ButtonColors/ButtonDefaults.outlinedButtonColors().
- No authentication, Firestore authorization, SIMReg, August seed, SQLite, SMS or payment behavior intentionally changed.
- Next phone compilation command: `sh build-phone.sh assembleDebug --console=plain`.


## 4.3.4.13 correction
- Fixed four Kotlin `return@Button` labels in `Authentication.kt` after the Aurora custom button migration. Changed them to `return@DevMonitorButton`.
- Preserved Firebase authentication configuration and all existing functionality.


## 4.3.4.14 — Aurora UI Polish
- Visual correction from device screenshots: disabled controls no longer carry heavy shadows, light surfaces are blue-white rather than lavender, and Payment Intelligence respects Scaffold insets.


## 4.3.4.15 — AURORA UI COMPOSITION REDESIGN
- This build is the substantive UI redesign following the 4.3.4.13/4.3.4.14 screenshot review.
- Dashboard composition was rebuilt around the Aurora hero + live metric cards + attention centre + batch control + HQ report intelligence.
- Bottom navigation replaced Unicode glyphs with custom vector-like Canvas icons and a dark DevMonitor navigation surface.
- Payment Intelligence landing cards, Agents page and Settings page now share the Aurora glass-panel hierarchy.
- Device Monitor top-level container uses the Aurora panel treatment while its operational controls remain functionally unchanged.
- No reset of SQLite or parser/auth/payment logic.
- Phone build command: `sh build-phone.sh assembleDebug --console=plain`.


## 4.3.4.16 — Aurora Compose Import Fix
- Fixed missing Compose imports in ManagementScreens.kt for background() and RoundedCornerShape().
- No functional/authentication/database/parser changes.

## DEVICE MONITOR ACTIVATION SOURCE — NON-NEGOTIABLE

For Device Monitor:

- **Active is the activation count used by payment/progression.**
- **MTD is display/monitoring information only.**
- Never substitute MTD for Active in payment calculations.
- If Active is unavailable, the activation count is unknown; do not silently fall back to MTD or zero.

Payment flow:
`Device Monitor → Active → activation count → payment-cycle/progression calculation`

This rule applies to all future Device Monitor/payment integrations.


# RECENT MASTER WORK RECORD — 4.3.5.37 THROUGH 4.3.5.51

## 4.3.5.37 — Compile correction
- Corrected Kotlin function-type invocation in `MainActivity.kt` where named arguments were invalid for `beginRun`.
- Calls were changed to positional arguments only.
- No payment calculation/pathway changes were intended.
- Phone/Android Code Studio remains the authoritative build environment.

## 4.3.5.38 — Performance and report-loading stabilization
- Reduced report-screen gesture overhead by using one shared pinch/zoom gesture path instead of per-row gesture detectors.
- Shared horizontal table scrolling and reduced unnecessary Compose recomposition.
- XLSX parsing was made more selective so irrelevant ZIP entries such as drawings/images are not unnecessarily processed.
- Removed the previous giant workbook-to-one-String approach and introduced worksheet preview/targeted parsing.
- Added normalized-report query indexes.
- Avoided unnecessary XLSX byte-array copies.
- Goal: reduce file-loading latency, scrolling stalls, memory pressure and crash risk without changing payment calculations.

## 4.3.5.39 — My Devices primary working database
- Established `my_devices.db` as the user's primary everyday working database.
- Company normalized activation data remains authoritative historical storage.
- Newer imported SIMReg/Activations data replaces older values for the same device/date in normalized storage.
- My Devices is rebuilt from saved device codes and the configured working date window.
- My Devices is shown by default; `Show All Devices` remains the explicit full-company escape hatch.
- Payment/progression reads My Devices first, with company-normalized fallback.
- Migration to My Devices schema v2 was documented/fixed.
- Payment calculation/resolver logic was intentionally protected.

## 4.3.5.40 — Isolated Payment Card Display Fork
- Experimental, isolated display-only fork for showing separate Device Monitor and Loaded Report payment cards.
- No payment calculation, resolver or payment database changes were intended.
- Mainline baseline remains separate unless the fork is explicitly requested for merging.

## 4.3.5.41 — My Devices/date-window and totals refinement
- My Devices working window: 1st–20th uses previous-month 21st through today; 21st onward uses current-month 1st through today.
- Company normalized storage retains configured historical data.
- General device-monitor totals use the labels `CYCLE TOTAL` and `MONTH-TO-DATE`.
- Device ordering no longer applies alphabetical/numerical sorting; parsed/import order is retained.
- No special GLO-GD-first ordering rule is used.

## 4.3.5.42–4.3.5.44 — Initial Month-to-Month implementation and corrections
- Added a persistent Month-to-Month Comparison feature with manual Refresh and retained results.
- The feature is month-based, not payment-cycle-based.
- Current period is current-month data through the effective available-data cutoff.
- Previous period is the previous month through the corresponding day-of-month cutoff.
- Corrected visibility/setup behavior so the Month-to-Month entry is available without auto-calculating.
- Documented the initial My Month-on-Month implementation.

## 4.3.5.45–4.3.5.48 — Month-to-Month/report-aware refinement
- Refined Month-to-Month to use the latest reliable available report/current-month data rather than blindly assuming today's date contains data.
- Comparison cutoff is driven by actual available data and is shared appropriately for the comparison population.
- Device Monitor data remains an eligible source whenever available and newer than loaded report data.
- The feature remains strictly month/report-data based; cycle and activation-cycle concepts must not be introduced into this calculation.

## 4.3.5.49 — Month-to-Month by Device
- Added the Month-on-Month by Device expansion for supported Cluster Manager/Partner views.
- Kept the feature separate from the payment calculation pathway.
- Preserved the report-aware cutoff principle.

## 4.3.5.50 — Fork documentation process
- Added the formal `FORK_DOCUMENTATION.md` process for deferred experiments.
- First documented fork: Historical Device Ownership for Month-to-Month Comparisons.
- Fork remains deferred and must not be merged into mainline without explicit request.
- Future forks should record: problem, intended approach, protected behavior, normalization impact, performance questions, testing, acceptance criteria and merge conditions.

## 4.3.5.51 — Report cutoff and historical-scope correction
- Corrected Month-to-Month scope around the latest available current-month report date and corresponding historical comparison cutoff.
- The current population is the devices currently attributed to the user in the current-month data through the available cutoff.
- The previous population is the devices attributed to the user in the previous month through the same day-of-month cutoff.
- Device populations do not have to be identical between months.
- Staff/device transfers are NOT solved by this release; historical ownership attribution remains a deferred fork.
- Do not introduce cycle-based or activation-based language into Month-to-Month.
- This release continues to protect payment calculation/pathway code from unrelated changes.

## 4.3.5.53 — Month-on-Month cutoff integrity fix
- Root cause identified: the XLSX importer could normalize future/placeholder daily columns that were physically present in a workbook but outside the report's declared coverage window.
- Example: a September 1–23 report may contain columns 24–31 filled with zeros; those cells are not available data and must not become report dates.
- Import normalization now filters daily values to `coverageStart..coverageEnd`.
- Normalized report selection also respects each report's declared `coverage_end`.
- Without a newer Device Monitor observation, the comparison cutoff follows the latest actual report coverage date.
- Verified with supplied AIYETORO data: Sep 1–23 = 1,204; Aug 1–23 = 1,058; expected change +146 (+13.8%), cutoff 2026-09-23.
- The prior 1,155 previous-month value represented August 1–25 and therefore did not satisfy the same-period rule.
- Payment calculation/resolver/progression/pathway logic remains protected.

## 4.3.5.55 — Month-on-Month Device Monitor freshness fix
- Prevented stale/restored Device Monitor observations from extending the current report cutoff.
- A Device Monitor observation can extend a loaded current-month report only when its `received_at` timestamp is strictly newer than that report's `imported_at` timestamp.
- The same freshness gate is applied when choosing the current-month Device Monitor `Active` value, preventing stale monitor rows from overriding newer report data.
- If no current-month report exists, Device Monitor remains eligible to provide the current cutoff.
- Supplied AIYETORO acceptance target remains: cutoff 2026-09-23; current 1,204; previous 1,058; change +146 (+13.8%).
- Payment calculation/resolver/progression/pathway logic remains protected.

## Ongoing non-negotiable rules
- Do not modify payment calculation/resolver/pathway code for unrelated tasks.
- Device Monitor `Active` remains the activation count used by payment/progression; MTD is display/monitoring information only.
- My Devices is the primary everyday working DB; company normalized data remains authoritative historical storage.
- Newer report data replaces older normalized values for the same device/date.
- User-facing import update messaging should remain a single overall notification rather than a detailed per-cell audit UI.
- Month-to-Month is month-based/report-data-based, never cycle-based.
- Deferred forks are documented first and are not merged without explicit instruction.

## 4.3.5.52 — Month-on-Month data-selection correction
- Corrected the remaining Month-on-Month issue where the page could fall back to the phone date instead of the latest actual current-month report data date.
- Current report selection now prefers normalized activation data and uses the newest actual current-month activation date as the cutoff.
- Previous report selection likewise prefers normalized activation data for the previous month.
- Normal STAFF attribution now uses `staff_name` from each month's report rather than substituting territory for ownership.
- Current and previous populations remain independently determined for their respective months.
- Device/hierarchy drill-down calculations are explicitly restricted to their requested codes.
- Added a visible **Refresh Comparison** button inside the Month-on-Month performance card.
- No payment calculation/resolver/progression/database pathway was modified.
- Historical device transfer handling remains deferred to Fork 001.

## 4.3.5.60 refinement
- 4.3.5.60 compile correction: preserved the refinement UI/search behavior while fixing local-function declaration order and routing Month-to-Month search through CompanyActivationStore.
- Cosmetic/interaction: user-scoped notice is now a top, layout-participating banner rather than a bottom Snackbar overlay.
- Partner enquiry: Loaded Report menu accepts Trade Code or Channel Partner Name; name resolves to a unique Trade Code for existing workflows.
- No payment pathway changes.

## 4.5.0 — Sound & Haptics UX layer
- Added a lightweight local feedback layer through `DevMonitorSound` using four bundled PCM tones.
- Meaningful task events can provide sound/haptic feedback: monitoring start, successful task completion, warnings/failures, retry completion, Excel export completion/failure, and explicit dashboard/payment refresh completion.
- Ordinary navigation and routine taps remain silent to avoid notification fatigue.
- Added `Sound & Haptics` controls under Monitor Settings with Event Sounds and Haptic Feedback toggles.
- Sound is local-only; no network audio, streaming, background playback or persistent audio service was introduced.
- Added Android `VIBRATE` permission solely for the optional short haptic confirmations.
- Existing monitoring, payment, report, profile isolation and user-initiated performance rules are unchanged.


## DevMonitor 4.5.3 — Visual Trends
- Added the Phase 1 visual-trends layer using the existing profile-scoped `daily_observations` data.
- Users can inspect 7-day or 30-day charts for SIMReg sales, Active totals and Bar 48/Conversion Lost, plus Company/Partner sales mix.
- Trend range queries are read-only and use the active profile database.
- Heavy trend aggregation is explicitly user initiated through Refresh or range selection; merely opening the trends view never starts a calculation.
- Missing observation days are not converted into zero-sales days, preserving the established monitoring semantics.
- Added Visual Trends entry points from the dashboard and app drawer.
- Payment calculation/resolver/progression, Device Monitor SMS behavior, report authority, Month-to-Month architecture and profile isolation remain protected.


# LOCKED PERFORMANCE BASELINE — DevMonitor 4.5.17

On 2026-09-29 the user explicitly accepted DevMonitor 4.5.17 as the protected performance baseline. The user reported that table scrolling was exceptionally fluid, navigation between sections was fluid, existing data opened intact rather than as an empty app, and a phone release build that had previously taken about 32 minutes completed in about 4 minutes. Future changes must preserve these observed characteristics unless the user explicitly authorizes a new baseline.

## 4.6.0-NEXT fork

The NEXT LEVEL development fork starts from this locked baseline and bundles the mapped Phase 3 and Phase 4 milestones into one integrated experimental build: explicit-refresh advanced trends, deterministic anomaly detection, local-vs-HQ reconciliation, explain-this context, offline/data-freshness status, Sync Centre recovery controls, diagnostics, SQLite optimization and an incremental feature-module registry. Substantial NEXT LEVEL calculations run away from the Compose UI thread and remain user initiated. Payment logic, the 21st-to-20th payment cycle, the four physical Month-on-Month databases, SMS protocol and report authority are preserved.

## v170 — Recovery Base + Floating Loader + Same-Coverage HQ Replacement

This is the advanced recovery package name/version of the same controlled development point. No functional regression or new application feature is implied by the version-number advance; the code remains based on v162.1 with the approved floating waiting UI and same-coverage HQ replacement behavior.

## v165 — Recovery Base + Floating Loader + Same-Coverage HQ Replacement

- Recovery base: v162.1.
- Retained approved post-v162.1 UI improvement: single informative floating waiting window with operation, major step, projected percentage, one progress bar, and concise status.
- Changed HQ import acceptance so same coverage/end date is a valid complete-snapshot replacement rather than a duplicate rejection.
- Preserved older-report rejection and newer-report replacement.
- Current and immediately previous calendar months remain independent physical HQ stores.
- Deliberately did not carry forward the v163-v165 Loaded Report workflow/render-selection experiments; those remain separate work for controlled reimplementation.
- Protected PaymentEngine, payment formulas/progression, Device Monitor/SMS logic, Profile Builder, v162 dashboard/settings/My Devices UI, and release identity.
- Current date testing note: October 2026 current month; September 2026 previous month; August is outside the active two-month HQ window.


## v171 — Historical snapshot safeguards and Loaded Report display recovery (2026-10-01)

- Kept the two-physical-HQ-month architecture: current calendar month and immediately previous calendar month.
- Preserved complete-snapshot replacement, older-coverage rejection, same-coverage replacement, out-of-order month acceptance, and transactional database replacement. Added a pre-write guard so a workbook with no usable device records cannot replace a stored snapshot.
- Refined import semantics to **calculation-isolated, not UI-isolated**: importing does not trigger Device Monitor, payment, MOM, dashboard, or estimate recalculation; the exact parsed report is nevertheless presented immediately in Loaded Report.
- Opening Loaded Report now retrieves the latest stored report directly from the stored-report index instead of routing through the current-month cutoff/filter helper.
- The report viewer explicitly prioritizes the supplied/imported report over the My Devices working set and retains the established automatic table positioning.
- The single app-wide floating waiting window remains visible at 100% until the report table has been positioned and is ready; no duplicate loader or new progress-calculation system was added.
- PaymentEngine, payment formulas, cycle rules, and payment progression were not modified.
- Build versionCode advanced to 171; versionName remains 4.6.0-NEXT.


## v176 — Company Structure Cascade Clarification

**Status: IMPLEMENTED IN v176 SOURCE PACKAGE**

The supplied `GLOZONE - NEW REG` structure is now represented in Profile Builder as:

**Cluster (Division) → Region → Territory → Staff**

The existing internal `division` field is retained for compatibility; the UI explicitly labels it **Cluster (Division)**. The Company Skeleton remains identity-only and is the source for these selectors before activation data exists. Territory is selected before Staff so the final staff list is constrained by all three organisational levels.

Selector-only source variations caused by case or apostrophe typography are deduplicated for display, while the original source values remain stored. No activation, payment, HQ snapshot, or MOM calculation pathway is changed.

## v175 — Company Skeleton / Profile-First Onboarding

**Status: IMPLEMENTED IN v175 SOURCE PACKAGE**

Fresh-install scope now starts from a lightweight Company Skeleton rather than requiring a full activation report before profile construction. The skeleton contains identifiers and organisational relationships only. It is separate from the two authoritative HQ month stores.

Required fields from the supplied company workbook: SN, Trade Code, Channel Partner Name, Device ID, Cluster, Region, Territory, Staff Name. The supplied workbook did not contain a detailed DIVISION column; the parser supports DIVISION for future workbooks without inventing one for the current source.

Profile Builder now searches the skeleton and supports LOAD COMPANY DATA to rebuild the skeleton from another company workbook without importing activation/performance data or triggering downstream calculations.

Dashboard now presents BUILD PROFILE prominently. Fresh installs receive a one-action Build Profile spotlight with Skip. The introduction ends with BUILD PROFILE.

Imported HQ report presentation prioritizes My Devices, then same staff context, region, division when supplied, and the wider company. This is presentation ordering only; authoritative HQ import remains atomic and complete.

Protected: payment logic, Device Monitor business rules, two-month HQ architecture, MOM logic, and explicit-refresh performance culture.

## v179 — SMS CHECKER tour compile correction

**Status: IMPLEMENTED IN v179 SOURCE PACKAGE**

The GitHub cloud build for v178 reached Kotlin compilation and reported one source error at `MainActivity.kt:4598`: the dashboard `LazyColumn` supplied a positional `Modifier` argument after the named `state` argument. The call was corrected to use the named `modifier =` parameter.

No SMS CHECKER tour logic, Device Monitor logic, payment logic, report logic, Company Skeleton logic, or database architecture was changed by this compile correction.

The versionCode is advanced from 178 to 179 so the corrected source package is unambiguous in cloud-build selection.

## v178 — Context-aware static SMS CHECKER guided tour

**Status: IMPLEMENTED IN v178 SOURCE PACKAGE**

The SMS CHECKER tour is now a dashboard-entry tour rather than a general Device Monitor-arrival tour. It automatically launches only when the user presses **SMS CHECKER** on the dashboard for the first time. The Check My Devices route, which can already have established the user's profile, SIM, and device scope, does not launch it.

The tour uses a dedicated `sms_dashboard_tour_completed` state. Existing Device Monitor/Check My Devices usage therefore does not falsely mark the dashboard tour as completed.

The SMS CHECKER tour is context-aware and static/automatic in presentation. It skips setup stages already satisfied by the current state (for example an active selected SIM or already-loaded codes) and does not require a separate Next button. Where a real workflow action is still required, the tour highlights that actual control and advances when the operation reaches the next state.

Manual **Take the Guided Tour Again** remains available and can intentionally restart the tour.

Protected: Check My Devices workflow, SMS protocol, payment logic, HQ report authority, Company Skeleton/profile hierarchy, MOM architecture, and phone-performance rules.


## v180 — Profile onboarding + SMS CHECKER simplification + dashboard tour targeting

**Status: IMPLEMENTED IN v180 SOURCE PACKAGE**

### SMS CHECKER
- Removed the SMS CHECKER guided tour completely.
- SMS CHECKER no longer launches a guided tour from the dashboard, Check My Devices, Device Monitor, the drawer, or Settings.
- Removed the SMS-specific guided-tour state and restart entry points.
- SMS operational behavior, SIM selection, SMS protocol, batch checking and saved-list behavior remain protected.

### Dashboard tour
- Corrected dashboard tour scrolling/target positioning so stages covering **LOAD REPORT** and **EARNING PROGRESS** keep the actual action-card row in view.
- The tour no longer scrolls past those cards to unrelated lower dashboard content such as Company/Partner cards.
- The actual `load_report` and `earning` targets remain the rendered cards themselves.

### Profile Builder
- Prominent **BUILD PROFILE** dashboard card is now shown only while no profile exists. After at least one profile is successfully built, that prominent first-run card is removed.
- Added **Manage Current Profile** access when profiles exist so profile management, including deletion, remains discoverable after multiple profiles are created.
- Added a visible profile verification reminder asking users to confirm that the populated identity, role, organisational scope and selected device accurately describe them before saving.
- When User Type is **Agent**, the selected device is explicitly constrained to one device. The user can search, select one matching device and continue; returned search results are not registered wholesale.
- Agent profile save/rebuild paths use that one selected device as the profile's My Devices scope.

### User-facing terminology
- **Company Skeleton** is retained as an internal engineering/data-store term only.
- User-facing Profile Builder/onboarding language now uses **Company Directory** / company data wording instead.
- No internal `CompanySkeletonStore` architecture or identity-data model was renamed merely for UI wording.

### Device Monitor / Report presentation requirement
- Fresh entry to the Report/Device Monitor table starts with **My Devices only**.
- Additional hierarchy levels are user-initiated through incremental loading controls.
- Expanded table state may remain during the active app session, but a newly opened app/report session starts again at My Devices.
- The full company dataset remains indexed/available for general search even when not rendered in the initial table view.

Protected: PaymentEngine/payment formulas and progression, 21st-to-20th payment cycle, HQ report authority, two-month HQ architecture, SMS protocol, profile isolation, and explicit-refresh performance culture.


## v181 — SMS CHECKER removal hardening + profile/device workflow correction

**Status: IMPLEMENTED IN v181 SOURCE PACKAGE**

- Removed the SMS CHECKER guided-tour implementation without removing the underlying SMS workflow, permissions, SIM discovery, contact/location helpers, or `beginRun` execution path.
- Restored the required SMS helper/launcher declarations after the v180 cleanup accidentally removed their declarations while removing the tour.
- Dashboard orientation tour order is now explicitly: Today's Operations → Your Profile → LOAD REPORT → EARNING PROGRESS → SMS CHECKER → MY DEVICES → PAYMENT CYCLE. The LOAD REPORT and EARNING PROGRESS stages therefore target their own registered dashboard cards.
- BUILD PROFILE remains visible only while no profile exists.
- Agent profile selection remains one-device: search results are choices, and the user selects one device before continuing.
- Profile verification warning remains required before saving.
- Multiple-profile management retains a Delete Profile action for the currently edited profile.
- User-facing Company Skeleton terminology remains replaced by Company Directory/company-data wording.
- My Devices remains the default freshly opened Report/Device Monitor table view; broader hierarchy loading remains explicit and the full indexed company dataset remains available for general search.

**Protected:** payment formulas/progression, 21st–20th payment cycle, SMS protocol, Device Monitor business rules, report authority, database architecture, and existing profile-owned data cleanup rules.

## v182 — Dashboard Loaded Report search crash isolation (2026-10-03)

**Status: IMPLEMENTED IN v182 SOURCE PACKAGE**

### Dashboard Search Source Routing
- Dashboard payment search can return two source-specific results for the same device: **Device Monitor** and **Loaded Report**.
- Tapping **Device Monitor** continues to open the Device Monitor payment/result context.
- Tapping **Loaded Report** now opens a targeted Loaded Report context for the selected device rather than loading the entire HQ snapshot into Compose state.
- The targeted path reads only the selected device's company metadata and activation-day records from the authoritative stored report.
- This prevents a large HQ report from being materialized solely to satisfy a single dashboard search result, addressing the observed wait → freeze → Android process termination behaviour.
- The normal dashboard **LOAD REPORT** action is unchanged and remains the deliberate route for opening the broader stored report viewer.

### Protection
- No payment calculation/progression logic changed.
- No 21st-to-20th payment-cycle rule changed.
- No SMS protocol or SMS CHECKER workflow changed.
- No HQ import/storage authority or two-month database architecture changed.
- No profile or My Devices ownership rules changed.

## v184 — Dashboard Action Centre role visibility

Implemented dashboard visibility rule: the **ACTION CENTRE** card is for Agent/Partner device-monitoring workflows and is hidden for Staff profiles. The active profile is the primary source for the role so switching profiles updates visibility correctly; the stored role setting is only a fallback. This change does not alter the Action Centre alert logic or any payment/SMS/report behaviour.



## v225 — bounded auto-sync retry and standby policy
- Added automatic operational sync while the Phone ↔ PC Sync Bridge screen remains active and pairing settings are valid.
- Each recovery cycle makes one initial attempt plus up to five retries, with backoff delays of 2, 5, 10, 20 and 30 seconds. After a failed cycle, the app waits five minutes before the next reachability/sync attempt.
- After a successful sync, the active screen repeats sync every 30 seconds for near-real-time updates.
- Explicit limitation: this is an active-screen loop, not an always-on Android background service. Android may suspend it when the app is backgrounded; a separately permissioned foreground service / OS-compatible background strategy is still needed for background continuity.
- HQ monthly snapshots, imported HQ reports and payment records remain excluded from sync. Payment calculations and import rules are unchanged.
- GitHub Actions compilation and on-device pairing/reconnect testing remain required before considering this version verified.

## v4.6.0-NEXT v227 — PC-initiated earnings-card handoff
- Added support for receiving PC-prepared PNG cards in the encrypted PC↔Android sync response and opening Android's native share sheet after sync.
- Android acknowledges handled card IDs on the next exchange so Windows can remove completed queue entries.
- Card images are supplied by Windows; Android does not recalculate or reconcile figures. Existing Android-local sharing remains available.
- Payment calculation code and HQ/payment data sync scope unchanged.


## v231 UI and notification update (2026-10-13)
- Main-screen PC connection status: compact icon beside the notification bell; tap to view connection details. Full-width banner removed. Detailed sync controls remain in Next Level → Health.
- Android system notifications: NotificationStore.add now mirrors newly generated local in-app notices to the Android notification shade using the DevMonitor alerts channel. Notification tap opens MainActivity. Android 13+ runtime permission is required.
- Existing in-app inbox preserved. No payment logic changed. Validate permission flow, status freshness, notification click-through, and background delivery on physical devices.


## v233 connection icon action correction (2026-10-13)
- The app-bar PC-link icon now opens Next Level directly on Health so the first visible panel is the Phone ↔ PC Sync Bridge controls and Sync now action.
- No payment calculations, estimates, or thresholds changed.

## v249 refinement — My Partners Flags control
- My Partners no longer displays its own duplicate Flags chip; use the existing top-right app-bar Flags control.
- Original Device Monitor/SMS Checker retains its in-content Flags chip.


## v250 refinement — My Partners partner lookup and shareable results

- Added loaded-report search by partner name or Trade Code with selectable matches that add the official Trade Code to the My Partners input.
- Result cards show partner name, Trade Code, and available report geography, with a branded shareable PNG for the partner identity and latest check result/status.
- Scoped to My Partners only; separate `sms_checker_2.db`, Staff-only access, original SMS Checker and payment logic preserved.
- Version code 250; compile and device validation pending.

## Current release — v251 My Partners search data-source fix
- My Partners search now reads the full retained HQ/company partner directory, not the active My Devices subset, and loads it asynchronously on entering My Partners.
- Search by partner name or Trade Code; tapping a match adds the official Trade Code. Partner result metadata uses the same directory.
- Original SMS Checker and payment engine untouched. Android versionCode 251; compile/device validation pending.


## v252 — My Partners search reliability (2026-10-15)
- My Partners now searches persisted HQ report rows directly for partner name or Trade Code whenever the query changes; it no longer relies on a possibly stale list loaded only on menu entry.
- Partner results are deduplicated by Trade Code and can be selected to populate the My Partners code input. The selected result's current metadata is retained for its result card.
- Added partner-name and Trade-Code indexes with a schema-upgrade path for existing monthly report databases.
- Scope: My Partners only. Original SMS Checker and payment engine unchanged. Source checks done; Kotlin build and physical-device validation still required.

## v253 — My Partners search restored to proven v239 implementation (2026-10-15)
- Replaced My Partners' delayed `searchPartnerDirectory()` suggestion lookup with direct, query-driven filtering of `companyActivations.latestDeviceScopeRows()`, the working strategy inspected in v239.
- Supports partial case-insensitive partner-name and Trade-Code matching, minimum two-character query, deduplication by normalized Trade Code, blank-code exclusion, and up to 12 suggestions.
- Selecting a result continues to add the official Trade Code and preserve partner metadata for result cards.
- Scope limited to My Partners. Original SMS Checker, `sms_checker_2.db`, payment formulas/progression, HQ import/replace rules, and unrelated features preserved by intent.
- Android build identity: `versionCode = 253`, `versionName = 4.6.0-NEXT`.
- Validation status: source review and ZIP integrity checks only; Kotlin compilation, GitHub Actions build, and physical-device behavior remain pending.


## v254 — Earnings Card Tier Progression and Flags UI Cleanup (2026-10-15)
- Shareable payment-card PNGs now include an activation tier progress track using the existing PaymentRules thresholds (30, 50, 70, 100, 150, 200, 250, 300).
- Progress visuals are display-only and do not change payment calculations or source data.
- Removed the duplicate Flags header chip in SMS Checker / My Partners. Keep the app-bar Flags Centre as the canonical entry point; preserve alert/severity context on result cards.
- Partner lookup result images remain non-payment result cards unless trustworthy activation/payment-source data is present; do not estimate payments from lookup metrics.


## v255 follow-up — Share card and partner search behavior
- [x] Recompose Android earnings card closer to the approved promotional flyer reference.
- [x] Make milestone-track fill proportional to activations across the complete configured 0–300 range; next threshold remains distinctly highlighted.
- [x] Decouple My Partners search-result selection from the independent SMS Checker partner-code filter.
- [ ] Verify generated PNG visually on device and run Android build in the normal ARM-compatible phone build environment.

## v256 — Photographic earnings flyer follow-up
- Share-card visual direction now includes a photographic celebration hero, promotional headline, and payment-received badge inspired by the user's reference flyer.
- Existing source figures and payment calculations remain authoritative and unchanged.
- Android build verification remains outstanding.


## v257 share-card correction
- Export canvas background now covers the full tall card, including the bottom footer.
- Embedded hero asset is 1542 × 1545 pixels for improved high-density resampling. Original photo detail is still limited by the source asset.
- Android payment cards display the estimate passed from the selected source calculator; payment rules were not changed.


## v258 — Share-card estimate source-of-truth and resolution
- The SMS Checker share option now receives `deviceMonitorEstimate`, the same estimate object used by the Device Monitor payment card after the payment engine resolves the current cycle. It no longer shares `smsOnlyEstimate`, which can differ when Loaded Report history contributes to the resolved cycle.
- Loaded Report card shares continue to receive `loadedReportEstimate`.
- Android share-card raster output is 2160 × 3620 pixels (2x render scale from the 1080 × 1810 layout). The entire canvas is scaled uniformly, not only the hero photo.
- Rendering is a presentation layer and displays the provided estimate fields; no recalculation was added to the Android card renderer.

## v262 — Payment card share responsiveness
- Share image rendering and PNG compression run off the UI thread to reduce launch hesitation and ANR warnings.
- Share chooser opens only after the image is ready; existing payment estimate remains a presentation-only input.
- Build/runtime verification remains outstanding.


## Shareable payment card — next-tier earnings opportunity (v272, 2026-10-17)
- Android shareable payment cards now compare the existing main payment estimate with the projected main estimate at the next configured activation tier. They show the exact additional activations required and the incremental gain.
- Projection is presentation-only: uses the existing `IncentiveEstimate.nextThreshold`, `nextReward`, current `estimatedSubtotal`, and currently qualified `sundayBonus`; no tier thresholds or payment formula changed. Future Sunday bonus is not assumed.
- FRC cumulative remains visible with “Progressively paid weekly” and is excluded from current and projected main estimate values.
- The card renderer canvas was extended to accommodate the new section and avoid footer overlap.
- Validation: source-level checks; Android compile and on-device PNG inspection pending.


## v280 — Restore partner activation performance (2026-10-19)

- Restored `Fork3ActivationPerformance.kt`, its calculation state and background calculation, and the partner result-card activation-performance section from the v278 source.
- Restored activation-performance values in the partner result share card and its full layout in `ReportExportPack.kt`.
- Removed only the visible `FORK 3` wording from the partner result-card section title and share-card title. The section now reads `ACTIVATION PERFORMANCE`.
- Preserved the v279 welcome-tour persistence safeguard and the removal of the notification test-alert button.
- No payment formulas or MOM/HQ storage logic intentionally changed.
- Android version code: 280.
- Build and device verification remain pending.
