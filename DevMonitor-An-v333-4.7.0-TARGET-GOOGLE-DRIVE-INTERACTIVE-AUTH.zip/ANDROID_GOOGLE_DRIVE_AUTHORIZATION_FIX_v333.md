# Android v333 — Interactive Google Drive App Folder authorisation

## Change
- Replaced the backup/restore flow's reliance on a token exception to launch consent with Google's `AuthorizationClient.authorize()` flow.
- Requests the existing Drive App Folder scope (`drive.appdata`) at the moment the user taps cloud Backup or Restore.
- If Google returns a `PendingIntent`, launches it through `StartIntentSenderForResult`; after approval, parses the authorization result and resumes the exact pending user action once.
- If the scope is already granted, proceeds without showing consent again.
- Handles cancellation, missing resolution, and authorization errors with a visible message and diagnostic log.
- Applies the same authorization path to Settings and Next Level cloud Backup/Restore.

## Preserved
- Existing Drive `appDataFolder` file format and Google Drive API upload/download implementation.
- SQLite checkpointing, validation, and staged restore.
- Offline SAF backup and restore.
- Payment/MOM calculations, snapshots, cycle rules, SMS monitoring, and Windows source are unchanged.

## Version
- Android `versionCode`: 333
- Android `versionName`: `4.7.0-TARGET-GOOGLE-DRIVE-INTERACTIVE-AUTH-V333`

## Validation status
- Source edits and archive integrity checked.
- Gradle compilation could not be run in this environment because the Gradle 8.7 distribution was not cached and outbound download was unavailable (`UnknownHostException: services.gradle.org`).
- Consent-screen display, Drive upload, download, and restore still require GitHub Actions build and physical-device verification.
