# DevMonitor Android v337 — Kotlin Recheck Queue Compile Correction

## Scope
- Base: Android v336.
- Corrected the Kotlin compile error in `MainActivity.kt` at the failed-send branch of the sequential SMS Checker queue.
- The queue processor is a `while` loop, not a `forEachIndexed` lambda. Replaced the stale `return@forEachIndexed` label with `continue`, so a failed SMS send marks that device as failed and advances to the next queued device instead of aborting the queue.
- Advanced Android `versionCode` to 337 and `versionName` to `4.7.0-TARGET-KOTLIN-RECHECK-CONTINUE-FIX-V337`.

## Protected behaviour
- No changes to PaymentEngine, MOM databases/snapshots, payment calculations, SMS destination, repetition count, response timeout, or parsing rules.
- No Windows source or Windows build workflow changes.
- Existing active-run Recheck queue semantics remain sequential; an individual send failure no longer attempts to return through a stale lambda label.

## Validation status
- Source-level correction and ZIP integrity check.
- GitHub Actions Android release compilation/signing and Windows release build are the next validation gates.
- No APK install or physical-device test is claimed until completed.
