# Android v335 — Place new cloud backups in the Drive App Data folder

## Root cause found in v334
The OAuth token handoff was corrected, but the multipart upload metadata created `DevMonitorBackup.db` without setting its parent to `appDataFolder`. The restore/search code explicitly searches `spaces=appDataFolder` and requires `'appDataFolder' in parents`. A newly created file without that parent is therefore not discoverable by DevMonitor's restore flow and is not stored in the intended private app-data location.

## v335 correction
- New backup files are now created with `parents: ["appDataFolder"]`.
- Existing backup files are still updated by file ID and are not moved or re-parented.
- The upload response is checked for a returned Drive file ID before reporting success.
- Existing `drive.appdata` authorization, token handoff, file name, SQLite validation, and restore flow are retained.

## Preserved
- Existing Google Cloud project and OAuth clients.
- Offline backup/restore.
- Online Reports Drive folder/API-key configuration.
- Payment engine, MOM databases and cycle rules, SMS monitoring, and Windows source.

## Validation
- Source-level review and ZIP integrity check are performed.
- Gradle compilation and physical-device Drive upload/restore tests remain required.
