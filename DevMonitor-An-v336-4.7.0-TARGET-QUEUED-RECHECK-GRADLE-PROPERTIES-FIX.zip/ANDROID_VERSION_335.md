# DevMonitor Android v335
Google Drive App Data backup creation now explicitly targets the Drive `appDataFolder` parent so the app's restore query can find the uploaded database. Upload success is only reported after Drive returns a file ID.
