# DevMonitor 4.7.0 Target — v336

## Scope

This release builds on Android v335 and addresses two independently requested issues without changing payment calculations, MOM storage, SMS parsing, SMS destination, repetition count, or the two-minute response timeout.

## SMS Checker: add-to-queue Recheck

- Recheck buttons on result-bearing device and partner cards remain visible while another SMS monitoring operation is running.
- Selecting another device during an active run appends it to a sequential pending Recheck queue; it does not cancel, replace, or restart the in-flight SMS request or its timeout.
- The currently active device and devices already scheduled in the current batch are protected against duplicate queue entries.
- The processing panel displays the number of queued Rechecks.
- The queue is drained after the original requested list, using the existing SMS send/listen/parse/update path for each device.
- Newly queued individual Rechecks use normal recheck attempt numbering, even if the active run was a retry-only pass.
- Stop Batch cancels the active operation and clears pending Rechecks; completed results remain preserved as before.
- The EARNING PROGRESS button remains rendered and usable for devices with an existing result while SMS monitoring is active. It continues to call the existing payment-card navigation function; payment calculations are untouched.

## Build configuration: Online Reports API key

- The confirmed manual configuration file is the project-root `gradle.properties`.
- The phone helper now obtains the API key and writes exactly one `DRIVE_REPORT_API_KEY=...` property to the top-level Gradle properties file before Gradle starts.
- The phone helper makes a private temporary copy of the original properties file and restores it on process exit, including build failure, so the API key is not retained in the source ZIP.
- The GitHub workflow also de-duplicates and writes the API key to the same top-level Gradle property before `assembleRelease`.
- The workflow checks the configured folder ID and compares the API key against the secret without printing the value. It also verifies the generated release `BuildConfig` contains the expected key.
- The phone helper performs the corresponding generated `BuildConfig` check after a successful release build, without printing the key.
- No Google Cloud project, Firebase OAuth client, package name, folder ID, or Drive scope was changed.

## Validation status

- `build-phone.sh` shell syntax check passed (`sh -n`).
- Source-level review completed for the queue and button visibility changes.
- A full Android Gradle compile, signed APK build, and physical-device runtime test have not yet been confirmed. Do not treat this ZIP as a verified installable release until those checks pass.
