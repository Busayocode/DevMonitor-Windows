# v259 — Share card component sharpness

- Increased earnings flyer raster output to 3240 × 5430 (3x) and improved text anti-aliasing, subpixel positioning, linear text rendering, and dithering.
- Kept all text, values, progress layout, and payment estimate binding unchanged.
- Version code: 259. Android build and on-device share validation pending.
