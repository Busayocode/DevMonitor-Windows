## v283 — Online Drive Report Configuration Fix

- Fixed the Android release default for `DRIVE_REPORT_FOLDER_ID` to the established company report folder (`1d2mCmBiFgQXjIYHAvgjXAD_JgSvITbwI`).
- Kept explicit Gradle property overrides supported; the API key remains supplied independently by `DRIVE_REPORT_API_KEY`.
- Addresses release builds where CI injects the API key but omits the folder ID, leaving Online Reports marked unconfigured.
- Does not change workbook parsing, report replacement rules, payment calculations, Target calculations, or profile personalization.

## Android v282 — Partner-profile access and profile personalization (2026-10-19)
- Made the dedicated My Partners workspace available to saved Staff and Partner profiles; Agent profiles remain excluded. Eligibility updates immediately when a profile is created or edited, and the regular SMS Checker remains independent.
- Added a dashboard identity card for the active saved profile, showing the saved name and profile type with a quick Edit action.
- Device payment share cards now prefer the active saved profile name for Agent and Staff profiles, label it as PROFILE, and fall back to the linked agent name/AGENT label when no profile name is available. The existing figures, selected source, and payment engine remain unchanged.
- Advanced Android versionCode to 282. ZIP/source checks only; full Gradle release build and on-device verification remain pending.

## Android v281 — Fix missing first-launch permission setting key (2026-10-19)
- Fixed the GitHub Release Kotlin compilation error: `SETTING_FIRST_LAUNCH_PERMISSION_SETUP_SEEN` was read and written in `MainActivity.kt` but its constant declaration was missing.
- Declared the setting key as `first_launch_permission_setup_seen`, matching the one-time permission-wizard persistence behavior. The wizard can now compile and continue using the same stored key for completion/dismissal.
- Preserved the v280 Fork 3 partner activation-performance restoration and removed visible “Fork 3” wording only; preserved the v279 welcome-tour persistence safeguard and notification test-alert removal.
- Android versionCode advanced to 281. No payment formulas, target calculations, HQ/MOM storage, or report semantics intentionally changed.
- ZIP integrity and source-level checks performed. A full Gradle build is still required; this package is not represented as successfully built.

## Android v278 — First-launch permission setup (2026-10-19)
- Added a one-time permission setup wizard after the existing welcome introduction on fresh installs. Existing installations are not retroactively forced into the wizard.
- Requests permissions in separate, explained steps: SMS send/receive and optional inbox recovery; phone/SIM subscription access; optional location for map helpers; and Android 13+ system notifications.
- Shows current grant status, supports retrying or skipping each step, and lets the user finish without granting optional access. Permission denial does not block opening the app.
- Permission setup is independent of Google Drive / online-report configuration; no Drive checks or values were added to the wizard.
- Android versionCode advanced from 277 to 278. Payment formulas, payment-cycle logic, MOM/HQ stores, report import/download behavior, and Windows build logic are unchanged.
- Source/archive checks performed; full Android compilation and fresh-install device testing still required.

## 4.7 Target refinement — expected-to-date achievement (v277)
- Target achievement percentage is actual activity divided by the expected cumulative target for the same reporting day.
- No shortfall/deficit amount or behind-pace warning is displayed. Full-month target progress remains a separate, neutral percentage.


## Development 4.7 Target — monthly activation targets
- Staff and Partner profiles now require a positive monthly target during profile creation/editing; Agent profiles use the fixed target of 150.
- The profile target is stored with profile metadata and survives app upgrades; legacy Agent profiles default to 150.
- The Month-on-Month performance card shows cumulative current-month activity against the configured target, target-achievement percentage, expected cumulative value by the current day, and whether actual activity is on or behind expected pace.
- Expected pace is calculated proportionally across the actual number of calendar days in the current month. The progress bar caps visually at 100%, while the displayed achievement percentage can exceed 100%.
- Existing report/payment calculations and HQ snapshot semantics are not changed. Source review completed; Android build/runtime verification remains pending.

## Phone release-build configuration — v275 source, app versionCode unchanged (2026-10-17)
- Restored the established Android Code Studio / ARM64 release flow: detect a phone-compatible AAPT2 and pass `android.aapt2FromMavenOverride` to Gradle.
- Restored the hidden interactive Google Drive API-key prompt for release builds when no key is supplied through environment variables. Removed the active placeholder key from `gradle.properties` so it cannot be embedded into the release BuildConfig by mistake.
- Kept release keystore/password handling environment-backed; no secrets or keystore material were added to the archive.
- Updated phone build instructions. App sources, payment logic, strict v275 history gate, and `versionCode = 275` are unchanged.
- Static shell/config/archive checks only; this environment cannot verify a signed APK build on Android Code Studio.

## v275 — Require genuine historical evidence before opening payment cards (2026-10-17)
- Tightened the Device Monitor payment-card visibility gate beyond the calculator's ability to produce a pre-21st estimate.
- Requires device-specific Active evidence in the previous calendar month and current calendar month, from actual Device Monitor observations and/or qualifying Loaded Report activation data.
- After the 21st, additionally requires the calculator to expose a valid cumulative Active baseline date and value through the 20th.
- The gate never queries the Company Directory/Skeleton; directory identity rows, Today-only observations, and placeholder entries cannot satisfy the historical checks.
- Preserved the underlying payment formulas, FRC separation, Sunday bonus qualification, tier projections, and Loaded Report / Device Monitor calculator separation. Android versionCode 275.
- ZIP/source checks only; Android compilation and on-device verification remain pending.

## v274 — Enforce payment-engine eligibility when opening progression cards (2026-10-17)
- Removed the unconditional pre-21st card-opening bypass.
- Card opening now requires the existing Device Monitor payment engine to produce a valid activation progression.
- A `today` observation alone no longer qualifies as historical baseline evidence; the engine requires cumulative Active baseline evidence.
- The card warning uses the payment engine warning where available.
- Payment formulas and source separation are unchanged.

## v273 — Gate payment progression on required historical baseline (2026-10-17)
- Fixed Device Monitor progression after the 21st: if no valid cumulative Active baseline through the 20th can be established from Device Monitor or a qualifying Loaded Report, the payment estimate remains unavailable instead of subtracting an assumed zero.
- This makes the existing payment card and single/batch share-card actions unavailable for that source until the required historical evidence exists. The screen reports what history is missing and how to resolve it.
- Loaded Report calculations remain source-separated and unchanged; current-cycle daily report evidence is not mixed into the Device Monitor total without the required baseline.
- Preserved payment tiers, FRC separation, Sunday bonus rules, next-tier comparison, and all other calculation rules. VersionCode 273.
- Static source/archive checks only; Android compilation and device verification pending.

## v272 — Share-card next-tier earnings opportunity (2026-10-17)
- Enhanced Android-generated shareable earnings cards with the clearly labelled current payment estimate, the exact remaining activation count to the next configured tier, the projected main estimate at that tier, and the incremental gain.
- Projection uses the existing `IncentiveEstimate` tier reward and preserves only the already-qualified Sunday bonus; it does not guess future Sunday bonus eligibility.
- FRC stays visible as a separate weekly-paid cumulative and is excluded from both current and projected main estimates. Existing source selection and payment rules remain unchanged.
- Increased card canvas height to fit the new section without overlapping the existing encouragement and footer.
- Static source/archive checks only; Android build and visual/device verification pending.

## v271 — Exclude weekly-paid FRC from main estimate (2026-10-17)
- Kept the existing FRC cumulative calculation and visible value, now labelled “Progressively paid weekly”.
- Excluded FRC from the main payment estimate total; the total now includes only the established fixed performance reward and qualifying Sunday bonus. FRC is not erased from records or its separate display.
- Applied the same total to payment progression summaries, exported payment-card totals, and spreadsheet summary values through the existing estimate subtotal field.
- Preserved activation tiers, source separation, Sunday qualification, and the underlying FRC cumulative calculation.
- Android versionCode 271. Source checks and ZIP integrity only; build and device verification remain pending.

## v269 — Search responsiveness, payment-estimate hero, partner flyer layout, and cloud backup/restore (2026-10-16)
- Kept the v268 filled, rounded Material 3 search/input fields; the change remains source-implemented and requires on-device light/dark verification.
- Fixed the earnings hero artwork at render time: the source photo contains baked-in “Payment Received!” wording and a sample amount, so the card now masks that badge and clearly labels the area “Payment Estimate”. The actual estimate remains in its existing calculated panel; payment logic and source selection are untouched.
- Improved My Partners name/Trade Code search responsiveness by filtering the already-loaded HQ directory snapshot in memory on `Dispatchers.Default`, with a short debounce. Preserved the v239 match fields, minimum query length, result cap, and code-selection behavior; removed repeated SQLite reads on each keystroke.
- Stabilized the partner result flyer composition by increasing its canvas height and moving the footer below the largest optional Fork 3/details panel. The partner flyer also masks the photo’s baked-in payment-received badge with neutral partner-activity wording.
- Hardened Google Drive app-data backup/restore: validate the local SQLite database before upload, update the existing named backup instead of creating duplicates, apply connection/read timeouts and actionable HTTP errors, validate downloaded SQLite integrity/schema before restore, and stage/rollback the live database replacement to avoid overwriting it with an invalid or partial file.
- Android versionCode 269. Source ZIP and static checks only; Android build and runtime/device verification remain pending.

## v268 — Modern rounded search and input fields (2026-10-16)
- Modernized the app's standard Compose search and input controls by switching the 42 thin outlined text fields to filled Material 3 fields with the existing theme's surface-container colors.
- Applied a consistent 16dp rounded field shape for a softer, more contemporary look across search, form, profile, settings, partner, notes, task, report and bridge inputs.
- Preserved field labels, hints, input transformations, read-only dropdown behavior, validation/error states, search handlers, and all underlying data/payment logic. No search queries or business calculations were changed.
- Android versionCode 268. Source and ZIP checks only; Android compilation and light/dark device visual verification remain pending.

## v267 — Fork 3 partner Activation Performance experiment (2026-10-16)
- Added a read-only Fork 3 calculation for each saved My Partners Trade Code. It maps the partner to the distinct device IDs in the retained HQ device-scope directory, then aggregates the established device-level activation progression outputs.
- Shows two separate values per partner: Device Monitor progression and Loaded Reports progression. The Device Monitor figure uses the existing Device Monitor calculator, including its established baseline/freshness/fallback rules; Loaded Reports uses its own calculator. Neither source's total is added to the other.
- Shows mapped device count, available estimate count, coverage-through date, and an explicit subtotal label when one or more mapped devices lack a valid estimate. Missing values are never silently converted to zero; partners with no mapped devices or no source evidence show unavailable status.
- Adds the Fork 3 values to the partner share-card metrics when available. Existing Today / MTD / B48 / B96 partner-check metrics remain intact and separate.
- No payment formulas, estimate thresholds, partner records, device records, HQ import semantics, or source stores are modified. Calculation is read-only and isolated in `Fork3ActivationPerformance.kt`.
- Android versionCode 267. ZIP integrity and source-level checks only; Android build and device validation remain pending.

## v266 — Preserve checker activity during navigation (2026-10-16)
- Removed the v265 navigation effect that cancelled an active checker run, reset progress, cleared result rows, and discarded pending permission-resume state when moving between My Partners and SMS Checker.
- Navigation is non-destructive again: in-flight work and its progress are allowed to continue in the background as before.
- The previously observed cross-menu activity was intermittent and not reproducible, so no broader lifecycle or workspace-state rewrite was introduced. If it reappears, capture the exact navigation sequence and logs before applying a targeted fix.
- No payment or partner performance calculations changed. Android versionCode 266. Build and on-device regression testing pending.

## v265 — Partner flyer identity, spacing, and checker-route isolation (2026-10-16)
- Fixed partner-card identity lookup to use the same retained HQ partner directory that supplies the visible result row, so the selected partner name and location details carry into the shared flyer.
- Removed the redundant mini status/earnings badge from the photographic hero on both partner and earnings share cards; the key result/amount remains in its main information panel, preventing duplicate hero content from crowding/overlapping.
- Shortened the partner flyer canvas from 1810 to 1320 logical pixels and moved its footer directly below the performance panel, eliminating excessive empty space while accommodating all three optional location rows.
- Hardened navigation isolation between SMS Checker (tab 1) and My Partners (tab 6): when leaving or switching checker routes, cancel the active run and clear pending permission-resume state so late partner-check activity cannot bleed into the regular SMS Checker UI.
- Presentation and route-safety changes only. No payment formulas or partner performance metrics were changed. Android versionCode 265; ZIP/source checks only, compilation and on-device regression testing pending.

## v264 — Partner result flyer-style sharing (2026-10-16)
- Reworked the My Partners result image to follow the approved earnings flyer’s visual language: photographic hero, DM branding, gradient-backed headline, clear partner identity, and prominent performance-value panel.
- Partner cards show partner name, Trade Code, available cluster/region/territory, and the existing Today, MTD, B48, and B96 result values. No earnings tiers or milestone claims are used for partners.
- Rendered at 1.5x scale (1620 × 2715) and moved image rendering/PNG compression off the UI thread; the share chooser opens only after the PNG is ready.
- Presentation-only: no partner performance values are recalculated and no checker/payment data flows are changed. Android versionCode 264.
- ZIP integrity passed. The build script was attempted here but stopped before compilation because this environment lacks an ARM-compatible AAPT2; Android compilation and WhatsApp/device verification remain pending.

## v263 — Smaller payment share-card export (2026-10-15)
- Reduced the full earnings flyer render scale from 3x to 1.5x: output dimensions are now 1620 × 2715 instead of 3240 × 5430.
- Reduces the primary ARGB bitmap from approximately 67 MiB to approximately 17 MiB, before other image buffers, to reduce memory pressure and sharing delay.
- Preserved the flyer layout, estimated-earnings label, provided estimate figures, and source-selection behavior. No payment calculations changed.
- Kept single-card image rendering and PNG compression on the background thread; the share chooser is still opened only after the image is ready.
- Android versionCode 263. Gradle compilation and physical-device sharing tests remain required.

## v261 — Dashboard card consistency and profile-builder launch fix (2026-10-15)
- Restyled the dashboard My Partners entry to use the same vertical label/title/description/action hierarchy as the other dashboard cards while preserving its violet accent and existing navigation destination.
- Fixed profile-builder entry points so they open only the Profile Builder dialog. They no longer also set `showSettings = true`, which caused the Monitor Settings dialog (including its “Open Monitor Settings” content) to appear behind the profile builder on first launch.
- Kept the actual “Open Monitor Settings” button wired to Monitor Settings. No payment rules, data stores, partner visibility rules, or profile-save behavior changed.
- Android `versionCode` 261; `versionName` remains `4.6.0-NEXT`. Source and ZIP checks only; Android build and first-launch device verification pending.

- v260: Changed the photographic hero badge from “Payment Received!” to “Estimated Earnings” so the card clearly communicates that figures are estimates, not confirmed payments. No payment calculations changed.
## v259 — High-definition share-card typography and components (2026-10-15)
- Increased the full earnings flyer export from 2x to 3x render density (3240 × 5430 pixels) while preserving the logical layout and the existing payment estimate object.
- Enabled anti-aliased, subpixel-aware, linear text rendering and dithering for the card canvas so labels, figures, milestone markers, borders, and footer render more cleanly.
- No payment calculations, estimate values, thresholds, or source-selection rules changed.
- Android versionCode 259; build and on-device sharing verification pending.

## v253 — Restore v239 My Partners search behavior (2026-10-15)
- Restored direct filtering of `companyActivations.latestDeviceScopeRows()` for My Partners live search, matching partner name or Trade Code without case sensitivity.
- Preserved v239's minimum two-character query, Trade Code deduplication, blank-code exclusion, and 12-result cap; removed the newer delayed database-search call from this screen.
- Search selection continues to populate the official Trade Code and partner metadata. Original SMS Checker, separate My Partners database, payment engine, and HQ import semantics unchanged.
- Android `versionCode` 253; `versionName` `4.6.0-NEXT`. Source/ZIP validation only; Kotlin build and device test pending.

## v250 — My Partners loaded-report lookup and shareable result cards (2026-10-14)
- Restored a dedicated partner lookup that searches the currently loaded SIMReg/activation report by Channel Partner Name or Trade Code, shows matching full names and trade codes, and lets the user select a result to populate the My Partners code-entry list.
- Personalized My Partners result cards with loaded-report partner name, Trade Code, and available cluster/region/territory details.
- Added a user-triggered “Share partner result as image” action that creates a branded PNG containing partner identity and current available check metrics/status. Image generation is presentation-only and does not calculate or change payment values.
- Kept changes scoped to My Partners; original SMS Checker, payment engine, report import semantics, Staff-only visibility, and `sms_checker_2.db` remain unchanged by intent.
- Advanced Android `versionCode` from 249 to 250; `versionName` remains `4.6.0-NEXT`.
- Verification: source inspection and ZIP integrity; Android compilation and on-device search/share behavior remain pending GitHub Actions/device testing.

## v248 — My Partners device-control and wording correction (2026-10-14)
- Added a hard guard against invoking Zero Devices while My Partners is active; original Device Monitor Zero Devices remains available.
- Guarded My Devices setup action from the My Partners route.
- Refined partner-code examples/help text, changed the heading to “My Partners Result”, and made Quick Check messaging partner-specific.
- Preserved `sms_checker_2.db`, staff-only visibility, and existing payment rules. Version code 248; build/device validation pending.

## v247 — Staff-only partner-code workspace refinement (2026-10-14)
- Made the My Partners dashboard card and drawer entry visible only for the active, successfully saved Staff profile. Eligibility updates only after the profile-save/rebuild flow completes; selecting Staff in an open profile editor does not reveal the card prematurely.
- Kept the My Partners card immediately above MOM and preserved the restored four-card quick-action group.
- Replaced device-oriented input guidance and search labels with partner Trade Code examples and partner-specific result headings.
- Removed Zero Devices and Open My Devices setup actions from My Partners while retaining Zero Devices for the original Device Monitor. Hid device ownership and payment-progression actions in My Partners; partner results can still be rechecked.
- Kept `sms_checker_2.db` as the isolated checker store and guarded SMS recovery from writing partner results into primary Device Monitor observations.
- Advanced Android `versionCode` from 246 to 247; `versionName` remains `4.6.0-NEXT`. Payment calculations and thresholds were not changed.
- Verification: source-level checks and ZIP integrity only. Android build, first-launch stability, and on-device role visibility remain unverified; first-launch crash root cause requires device Logcat to confirm.

## 4.6.0-NEXT v246 — My Partners dashboard placement and naming (2026-10-14)

- Renamed the separate SMS Checker 2 user-facing entry and screen title to **My Partners**.
- Removed that card from the five-card dashboard quick-action group, restoring the original four cards: SMS Checker, My Devices, Load Report, and Earning Progress.
- Added a dedicated **MY PARTNERS** card immediately above **MONTH-ON-MONTH COMPARISON (MOM)** on the dashboard.
- The menu remains routed to its isolated `sms_checker_2.db`; this is a naming/placement refinement, not a database migration. The original SMS Checker remains unchanged.
- Advanced Android `versionCode` from 245 to 246; `versionName` remains `4.6.0-NEXT`.
- No payment formulas, thresholds, report-import rules, or original SMS Checker behavior intentionally changed.
- Verification: source-level checks and ZIP integrity only; GitHub Actions compilation and on-device navigation/data-isolation tests remain pending.

## 4.6.0-NEXT v245 — SMS Check 2 compile fix (2026-10-14)

- Fixed Kotlin declaration order in `SimRegMonitorApp`: `selectedTab` is now declared before the independent checker store selection and tab-driven reload effect use it.
- Preserved the SMS Checker 2 database selection (`sms_checker_2.db`) and existing original checker behavior.
- No payment formulas or unrelated feature behavior intentionally changed.
- Compilation and device verification pending GitHub Actions.

## 4.6.0-NEXT v244 — Independent SMS Check 2
- Added the SMS CHECK 2 dashboard card and routed the existing SMS checker screen to a dedicated `sms_checker_2.db` store while that menu is active.
- Separated current codes/results, saved lists, archives, history, and SMS query-attempt records from the primary checker database.
- Preserved the original SMS Checker and shared phone/SIM capability. No payment formula changes intended.
- Build/device verification pending.
## 4.6.0-NEXT v243 — SMS Checker 2 menu

- Added a distinct SMS Checker 2 navigation-drawer item that opens the full SMS Checker screen and existing feature set.
- Kept the original SMS Checker entry intact. The two entries intentionally share existing checker data/results and engine for parity and safety.
- No payment calculation, report-import, notification, or My Partner-removal behavior intentionally changed.
- Build/device verification pending.

## 4.6.0-NEXT v242 — Fix dangling My Partner reference
- Removed the obsolete `myPartnerStore.saveCheck(...)` call left in the separate Partner Summary SMS flow after removing the My Partner menu.
- Kept Partner Summary SMS parsing and result display intact; removed only its write to the deleted menu's history store.
- Advanced Android `versionCode` from 241 to 242; `versionName` remains `4.6.0-NEXT`.
- No payment formulas, report imports, notification triggers, or device observation logic intentionally changed.
- Verification: source-level checks and ZIP integrity; GitHub Actions build pending.

## 4.6.0-NEXT v241 — Remove My Partner menu
- Removed the My Partner drawer item and standalone partner-management dialog, including its search and menu-local controls.
- Preserved the existing partner summary and My Devices flows outside that menu.
- Advanced Android `versionCode` from 240 to 241; `versionName` remains `4.6.0-NEXT`.
- No payment formulas, payment progression rules, HQ report imports, or notification behavior intentionally changed.
- Verification: source-level removal checks and ZIP integrity only; run GitHub Actions and device tests before release.

## v240 — My Partner SMS stays in its menu
- Check by SMS no longer closes My Partner or changes the main app tab before SIM selection.
- Partner summary remains associated with the selected partner trade code and is stored in separate My Partner history.
- No earnings-card image or payment calculation changes.

## 4.6.0-NEXT v239 — My Partner search fix

- Fixed search input incorrectly mirroring text into Partner name.
- Result selection remains responsible for filling the actual partner name and trade code.
- Preserved v238 permission callback fix and notification work. No payment formula changes.

## 4.6.0-NEXT v238 — Android permission callback compile fix
- Corrected `MainActivity.onRequestPermissionsResult` to use the exact `Array<String>` parameter type required by the Android Activity override, resolving the reported “overrides nothing” and superclass argument-type errors.
- Kept the existing permission-granted behaviour: flush the pending system notification and show the enabled confirmation.
- Advanced Android `versionCode` from 237 to 238; `versionName` remains `4.6.0-NEXT`.
- No payment rules, calculations, report import behaviour, database schemas, or notification event logic changed.
- Verification: source-level signature/version checks and ZIP integrity only; GitHub Actions Android compilation still needs to confirm the fix.

## 4.6.0-NEXT v237 — App-wide Android notification delivery fix
- Fixed the permission-first-event gap: when Android 13+ asks for notification permission while an event is being created, DevMonitor now preserves that event and posts it immediately after permission is granted.
- Added a manual **Test alert** action in Notifications & Inbox so users can verify delivery to Android's notification shade without waiting for a real operational event.
- Preserved the in-app notification inbox and existing event triggers for monitoring completion/failure, report imports, export completion/failure, payment-cycle reminder, and version checks.
- Notification permission remains user-controlled; Android system settings can still block alerts even when the app stores an in-app notification.
- No payment calculations, payment progression rules, SMS logic, report import logic, or database schemas changed.
- Verification: source/ZIP integrity checks only; Android compilation and physical-device notification delivery remain to be confirmed by GitHub Actions and device testing.

## 4.6.0-NEXT v236 — Standalone My Partner SMS Checker
- Replaced the compact My Partner dialog with a full-screen partner workspace inspired by SMS Checker.
- Added loaded-report partner search with automatic partner name and Trade Code autofill, while preserving manual entry.
- Added a dedicated SQLite database (`my_partner.db`) for profile-scoped partner records and independent partner check history.
- Partner SMS results and loaded-report summary outcomes are recorded only in My Partner storage; no payment progression or normal Device Monitor observations are written by this feature.
- No payment calculations, thresholds, cycle rules, or formulas changed.
- Verification status: source/ZIP integrity only; Android compile and on-device behaviour remain to be confirmed by GitHub Actions.

## 4.6.0-NEXT v234 — Staff My Partner menu
- Added a separate staff-only My Partner entry in the app drawer.
- Added profile-scoped partner list storage independent of My Devices. Partner codes are entered manually after profile creation; no code is generated during profile setup.
- Added add/edit/remove actions and source actions for the existing SMS Checker flow and Loaded Report viewer. SMS checks use the established permission and query path; they do not add partner codes to My Devices.
- Kept the initial layout deliberately close to the SMS Checker style; a dedicated performance table is deferred for later tuning.
- No payment calculations or formulas changed.

## v233 — Connection icon action fix (2026-10-13)
- Connection icon opens Next Level directly on Health / Phone ↔ PC Sync Bridge instead of the unrelated Trends section.
- Payment formulas and thresholds unchanged.

## v232 — App-bar connection icon placement and promotional earnings flier (2026-10-13)

- Relocated the PC-link status indicator out of the DevMonitor branding/title column into the top app-bar action row, immediately beside the notification bell and before the profile/flag controls.
- Kept the icon compact and colour-coded for connected, reconnecting/awaiting sync, and disconnected/not configured states; tapping it opens connection details.
- Redesigned the existing **Share this card as image** PNG output as a portrait promotional flier with branded gradient header, prominent estimate total, source/period pill, clean component rows, reach-step-specific encouragement, and monitoring-only disclaimer.
- The card renders the selected `IncentiveEstimate` as supplied. No payment formula, threshold, cycle, or source-selection behaviour was changed.
- Verification: source and ZIP integrity checks only; Android compilation and on-device appearance still require GitHub Actions and device testing.

## v230 — Earnings flier and reach-step-specific encouragement (2026-10-12)

- Refined earnings-card presentation toward the approved promotional flier concept.
- Encouragement now varies by the existing activation reach step; wording selection does not recalculate earnings or alter thresholds.
- Preserved exact source figures, selected-source isolation, and PC–Android connection visibility.
- Build status: not compiled in this environment.

## 4.6.0-NEXT v229 — Version identity advance (2026-10-12)
- Advanced Android `versionCode` from 228 to 229 so this package is distinguishable from the prior v228 flier/connection-status build.
- Carried forward the earnings-flier and persistent PC-link status UI from v228 without intended feature or payment-logic changes.
- Payment calculations, thresholds, payment-cycle boundaries, HQ import behaviour and sync protocol are unchanged.
- Build and paired-device behaviour still require GitHub Actions and device testing.

## 4.6.0-NEXT v226 — Source-faithful earnings-card sharing and agent/device links (2026-10-12)
- Added **Share this card as image** to the existing device payment estimate cards. PNG cards carry the agent/device identity, selected/displayed source, payment-cycle label, date, existing displayed estimate fields, and monitoring-only warning.
- Added **Batch Share Earnings Cards** in Agent / Partner Database. Users select exactly one source (SMS Checker or Loaded Report) and agents; linked devices produce individual images in one Android share-sheet handoff. Missing source figures are skipped and reported instead of filled from the other source.
- Added a direct My Devices code linking/unlinking list within each agent record, while retaining manual linking for codes outside the visible My Devices list. A device is unlinked from any prior agent before assigning it to a new one through this UI.
- Reused the existing PaymentEngine / PaymentRules for source-specific batch cards; no new payment formula or mixed-source fallback was added to batch export. Per-card sharing exports the estimate already rendered in that card.
- WhatsApp delivery remains user-confirmed through Android's share sheet; the app does not silently send messages.
- Payment formulas, thresholds, payment-cycle boundaries, HQ import behavior, and five-minute sync standby checks are unchanged.
- Build verification status: source ZIP updated; compile/build must still be confirmed by the project's GitHub Actions workflow.

# v223 — Analytics / Sync Bridge Continuation and Unambiguous Build Identity

- Advanced Android `versionCode` from 222 to 223; `versionName` remains `4.6.0-NEXT`.
- Carried forward the v222 Firebase Analytics / Crashlytics and app-version awareness integration.
- Carried forward the encrypted, user-triggered Phone ↔ PC Sync Bridge and its operational archive/tombstone support.
- No payment calculation, payment-cycle, HQ report import, Month-on-Month formula, or sync protocol changes were intentionally made.
- Windows-native analytics parity remains a separate integration task; this ZIP is the Android source project.
- Full Gradle release build/signing and real-device sync tests remain pending GitHub Actions/runtime validation.

# v196 — Loaded Report Waiting States

- Added an explicit waiting overlay for Loaded Report operations that can take time, including saved-report resolution, My Devices preparation, table preparation, and Show All loading.
- Prevented the Loaded Report screen from briefly presenting an empty table while My Devices data is still being prepared.
- My Devices can still become the first visible working set while the complete saved HQ report finishes resolving in the background.
- Added clear operation-specific waiting messages so the user can see what DevMonitor is doing instead of interpreting a temporarily empty table as missing data.
- Preserved incremental Show more rendering, complete HQ report/search behavior, and targeted device lookup.
- PaymentEngine and payment-cycle logic unchanged.

# v195 — Loaded Report Immediate Navigation & My Devices Startup

- Loaded Report now navigates to its viewer immediately instead of waiting for the complete HQ report to be reconstructed.
- The complete saved HQ report is still loaded in the background and remains the authoritative indexed dataset for search, processing, and the full report view.
- My Devices working-set data can render while the HQ snapshot is being reconstructed, preserving the My Devices-first presentation.
- Added an explicit saved-report checking state so a temporary empty database query is never presented as “No saved company report records found.”
- Dashboard single-device opening still uses the targeted `loadReportForDevice()` path.
- Existing Show more/incremental table rendering remains unchanged.
- PaymentEngine and payment-cycle logic unchanged.

# v194 — Online Reports Release Configuration Fix

- Fixed the release build path so the Google Drive Online Reports API key is passed explicitly to Gradle from the GitHub Actions secret.
- Added a release-build verification step so Online Reports configuration cannot silently be omitted from the APK.
- Preserved the existing Google Drive report folder ID.
- Preserved the v193 Month-on-Month device-card bulk calculation fix.
- PaymentEngine and payment-cycle logic unchanged.

## v193 — MOM Device Card Bulk Calculation Fix
- Fixed Month-on-Month device-card loading that could remain at 70% while calculating each device independently.
- Device comparisons now use a bulk two-month HQ data pass instead of repeating the full database calculation for every card.
- Preserved Device Monitor newer-data enrichment and existing MOM comparison rules.
- Staff MOM summary path is unchanged.
- PaymentEngine and payment-cycle logic unchanged.

## v192 — Loaded Report Compile Fix
- Fixed Kotlin declaration-order error in `SimRegReport.kt` by moving the report-ready effect below `filtered` and `preparingTable` declarations.
- Preserves v191 My Devices-first incremental table rendering.
- Complete imported workbook remains authoritative for search and processing.
- PaymentEngine and payment-cycle logic unchanged.


## v191 — My Devices First Incremental Table Rendering
- Complete imported workbook remains the authoritative indexed dataset for search and processing.
- Default table rendering starts with all My Devices (whether 1 device or the full My Devices set).
- Added a bottom-of-table `Show more` action that renders the remaining company rows incrementally in 100-row batches.
- No database rows are removed or hidden from search; only the initial UI rendering window is bounded.
- PaymentEngine and payment-cycle logic unchanged.
# DevMonitor — CHANGE LOG

## DevMonitor 4.6.0-NEXT v187 — Loaded Report startup performance correction

**Status: IMPLEMENTED IN v187 SOURCE PACKAGE**

- Opening a saved **Loaded Report** no longer calls the full `loadReport()` path before the viewer appears. This prevents the entire HQ device list and all daily activation rows from being materialized during screen entry.
- Loaded Report now opens on the bounded **My Devices working set** when a My Devices profile is available.
- A dashboard/search result that targets one device still uses the existing targeted `loadReportForDevice()` path, preserving exact result behaviour without loading the whole report.
- **Show All** remains an explicit user action for the wider HQ dataset.
- The report table now uses explicit incremental expansion: 100 rows initially, then **Load next 100 rows** at the bottom as needed, instead of eagerly presenting the first 300 rows.
- Search/filter behaviour remains unchanged; the incremental limit applies only to presentation.

Protected: PaymentEngine, payment formulas, 21st–20th payment cycle, Device Monitor/SMS logic, My Devices ownership, report storage/import schema, Staff/Agent/Partner payment-card visibility, and Quick Check behaviour.

## DevMonitor 4.6.0-NEXT v186 — Staff dashboard/payment visibility + Quick Check label

**Status: IMPLEMENTED IN v186 SOURCE PACKAGE**

- Corrected the dashboard role visibility rule: the entire **PAYMENT CYCLE** card is now visible only for **Agent** and **Partner** profiles and is hidden for **Staff** profiles.
- The role check follows the active profile and retains the existing stored-profile setting as fallback.
- Renamed the Device Monitor / SMS Checker one-off enquiry button from **“Check Now — don't add to My Devices”** to **“Quick Check”**.
- The Quick Check behaviour is unchanged: entered device code(s) are checked immediately without adding them to My Devices.
- Updated the supporting explanatory text to use the same **Quick Check** terminology.

Protected: payment formulas/calculation logic, payment-cycle rules, SMS workflow, Device Monitor business logic, My Devices ownership, report storage/import, and existing Agent/Partner Action Centre behaviour.

## DevMonitor 4.6.0-NEXT v185 — Dashboard Action Centre build correction

**Status: IMPLEMENTED IN v185 SOURCE PACKAGE**

- Corrected the targeted Loaded Report device row introduced for dashboard search: the `daily` field now uses the established `Map<Int, Int>` day-of-month contract, while exact `LocalDate` values are retained in `dailyByDate`.
- This resolves the GitHub Actions Kotlin compilation error in `CompanyActivationStore.kt` without changing the dashboard Action Centre staff-visibility rule.
- v184 behaviour remains: Action Centre is visible to Agent/Partner profiles and hidden from Staff profiles.

Protected: payment logic, payment cycle, SMS workflow, report import/storage, profile ownership, Device Monitor calculations, and the v182 targeted Loaded Report behaviour.


## DevMonitor 4.6.0-NEXT v183 — Remove post-profile dashboard guided tour

**Status: IMPLEMENTED IN v183 SOURCE PACKAGE**

- Removed the static/automatic main Dashboard guided tour after profile creation.
- Removed its dashboard tour presentation/scrolling behaviour from the normal post-profile dashboard experience.
- BUILD PROFILE remains visible only while no profile exists.
- SMS CHECKER has no guided tour.

Protected: payment formulas/progression, 21st–20th payment cycle, SMS workflow, dashboard search routing, HQ report authority, profile ownership rules, and Device Monitor business logic.

## DevMonitor 4.6.0-NEXT v184 — Staff dashboard Action Centre visibility

**Status: IMPLEMENTED IN v184 SOURCE PACKAGE**

- The dashboard **ACTION CENTRE** card is now explicitly role-gated from the active profile.
- **Agent:** visible.
- **Partner:** visible.
- **Staff:** hidden.
- Profile switching is respected immediately because the active profile is checked before the card is rendered, with the stored user type retained as fallback.
- No Action Centre functionality or alert logic was changed; this is a dashboard-visibility rule only.

Protected: payment logic, payment cycle, SMS workflow, report import/storage, profile data, and Device Monitor calculations.

## DevMonitor 4.6.0-NEXT — Onboarding tours implemented

- **v177 cloud-build correction:** fixed the SMS CHECKER tour's local SIM lookup scope and the dashboard tour's Compose color access inside `Canvas`; these are compile-only corrections with no business-rule changes.
- Restored the established Device Monitor operational guided tour under the renamed **SMS CHECKER** workflow.
- SMS CHECKER tour remains available from the application menu and can start from the first relevant operational step, skipping entry steps already established by the route.
- First-time arrival at SMS CHECKER can trigger the tour from either the dashboard SMS CHECKER action or the Check My Devices route.
- Added a separate automatic post-profile dashboard orientation: major dashboard sections are highlighted with concise explanations for approximately five seconds each and advance automatically without requiring a Next button.
- The dashboard orientation can be skipped and is persisted as completed so it does not replay.
- The prominent BUILD PROFILE first-setup card still disappears after successful profile creation.
- Re-editing an existing profile does not start the new-user dashboard orientation.
- Protected payment, HQ report, Device Monitor/SMS, Company Skeleton, hierarchy, MOM and performance rules.
- **Build status:** source implementation completed; local build verification is pending because the environment could not resolve `services.gradle.org` to download the Gradle 8.7 distribution.


# DevMonitor — CHANGE LOG

## DevMonitor 4.6.0-NEXT v178 — Context-aware static SMS CHECKER tour

- Changed the SMS CHECKER automatic-tour trigger so it launches only from the **dashboard SMS CHECKER** action on its first dashboard use.
- CHECK MY DEVICES, bottom navigation to Device Monitor, and ordinary Device Monitor entry no longer launch the automatic SMS CHECKER tour.
- Added a dedicated persisted `sms_dashboard_tour_completed` state so previous Device Monitor/Check My Devices activity does not incorrectly consume the dashboard tour.
- Converted the SMS CHECKER tour presentation toward the same static/automatic style used by the dashboard orientation: no Next/Start/Continue requirement for the user; the tour advances automatically through informational stages and waits only for the real workflow action it is highlighting.
- Made the tour context-aware: an existing SIM selection, already-loaded codes, an already-running operation, and existing results are used to skip setup steps that have already been completed.
- The Check My Devices workflow remains uninterrupted: an established profile/device scope can proceed directly into its real SMS operation without a tour collision.
- Manual **Take the Guided Tour Again** remains available and deliberately forces the tour without changing normal navigation behaviour.
- No payment, HQ report, Company Skeleton, Profile Builder, MOM, Device Monitor business-rule or SMS protocol logic was changed.
- VersionCode advanced to 178.

## DevMonitor 4.6.0-NEXT v176 — Company Skeleton compile correction
- Fixed two Kotlin compilation errors in `CompanyActivationStore.kt` at the `loadMyDevicesReport` and `loadContinuousReport` row-construction calls.
- The `SimRegReportRow` constructor expects `division: String` before `dailyByDate: Map<LocalDate, Int>`; the affected calls were passing the map into the String slot.
- Explicitly supplied the empty division string while preserving the existing daily-by-date activation map.
- No business logic, payment logic, HQ import/storage rules, Company Skeleton structure, or profile hierarchy was changed.

## DevMonitor 4.6.0-NEXT v173 — Device Monitor compact cards + EARNING PROGRESS cleanup
- Compactified Device Monitor / My Devices result cards to reduce scrolling while retaining the existing result information.
- Device code remains prominent; ownership, status, flags, Today, MTD, B48, B96, errors and recheck actions remain available.
- Added subtle alternating Aurora accents to successive unflagged cards.
- Removed the duplicate payment-progression viewer from inside the result card.
- Renamed the remaining payment-navigation action to **EARNING PROGRESS**.
- No payment formulas, progression thresholds, SMS behavior, report logic or data pathways were changed.

## DevMonitor 4.6.0-NEXT v172 — Historical + Loaded Report carry-forward
- Carried forward the non-conflicting documented fixes from the historical development line.
- Preserved Profile Builder scrolling, profile deletion, MOM search/detail, payment freshness protection, targeted payment search, and the unified floating processing window.
- Dashboard search now opens the context corresponding to the selected source instead of always routing to Device Monitor.
- Simplified Payment page search-result context by removing unnecessary unavailable placeholders and the large technical authorization paragraph.
- Retained the v171 exact Loaded Report display workflow and calculation-isolated import behavior.

## 2026-10-01 — DevMonitor 4.6.0-NEXT v170 Recovery Package Advance

- Advanced the current recovery package identity from v165 to v170 to avoid GitHub filename/version collisions.
- No application logic, payment logic, or report workflow was changed by this naming/version advance.
- The PC, cloud, and phone build documentation remains aligned to the same recovery code base.

# DevMonitor 4.6.0-NEXT v161 — Two-Month Authoritative HQ Architecture

## 2026-09-30
- Replaced the continuous rolling three-month HQ activation database with **two physical monthly SQLite stores**: current calendar month and previous calendar month.
- HQ report import is now an atomic **Replace All for the report month** because each HQ file is an authoritative export of the company's database for that month. Missing devices are intentionally removed from the stored monthly snapshot.
- Added month-local ordering protection: older reports for a month are rejected; equal coverage-end reports are treated as duplicates; newer reports replace the month. Out-of-order month imports remain valid, so an August report can be imported after September data exists.
- Removed import-time Month-on-Month duplication, My Devices rebuilding and other derived calculations. Import now parses, validates and stores only.
- Reworked Month-on-Month to read the same two authoritative monthly HQ stores instead of maintaining four duplicate physical databases.
- Updated Loaded Report/payment data access methods to route by calendar month while preserving the existing payment calculation formulas and payment-cycle rules.
- Added one-time migration from the former `fieldpulse_company_activations.db` and removal of obsolete four-database Month-on-Month caches.
- Incremented Android `versionCode` from 160 to 161; versionName remains `4.6.0-NEXT`.

---

# DevMonitor 4.5.13 — Release Correction

- Fixed physical Month-on-Month rollover so the completed current month replaces the old previous month even when the old previous database was locked.
- Preserved four physically separate Month-on-Month SQLite databases.
- Xiaomi GetApps remains the sole billing implementation for the current release store.
- Preserved Device Monitor Active as the live current-month source when newer than Loaded Report data.

## 2026-09-29 — DevMonitor 4.5.4

## 4.5.5 — 2026-09-29 — NL-P1-09 Loading / Empty / Error / Offline States
- Standardized major-screen loading, empty, error and offline states.
- Added actionable empty/retry states without changing existing business logic.
- Payment calculator and payment rules remain frozen.

### NL-P1-08 — Device-card redesign
- Redesigned the Device Monitor "My Devices Results" cards for faster field scanning.
- Added clearer ownership/status hierarchy, compact Today/MTD/Bar 48/Bar 96 metric blocks, payment-progression entry, and stronger Payment Estimate/Recheck actions.
- Preserved existing flags and error messaging.
- **No payment calculator, payment rules, payment-cycle resolver, progression logic, or payment data pathway was changed.**
- No new background/heavy processing was introduced.

## 4.5.2.1 — Notification & Inbox compile correction / cloud build preparation
- Fixed nullable `activeProfileId` arguments in the new Notification & Inbox code.
- Fixed the Compose notification drawer `Text()` modifier argument.
- Added GitHub Actions cloud-build workflow using Java 17 and Gradle 8.7.
- Added `CLOUD_BUILD.md` with phone-only repository/build instructions.
- No intentional change to payment, SMS, reporting, profile isolation, or background-work policy.

## 4.5.2 — NEXT LEVEL Notification & Inbox
- Added profile-scoped in-app Notifications & Inbox.
- Added unread badge and drawer/top-bar access.
- Added local notices for monitoring completion/failure, report imports, exports, and month-end reminder.
- Added read/mark-all-read controls.
- No background monitoring or heavy notification generation was introduced.
- Kept profile switching and screen entry calculation-free.


## 4.5.1 — Appearance / Theme Evolution

- Began the next appearance phase from the compile-fixed Sound & Haptics baseline.
- Extended Aurora with emerald, mint and deep-green variations.
- Refined shared Aurora background/card treatments with subtle green influence.
- Added selective green accents to dashboard quick actions, payment cycle and performance metrics.
- Preserved existing blue, cyan and violet accents for visual balance.
- No functional/business logic changes were intended in this phase.

## 4.5.0 — Sound & Haptics build correction / next-theme planning
- Fixed a compile regression in `MainActivity.kt`: the monitoring completion path called `refreshDashboard()` from a scope where the later local function was not visible.
- Moved cached dashboard state and the explicit refresh function to the parent `SimRegMonitorApp()` scope and made refresh state exception-safe.
- Preserved the user-initiated performance model: profile changes remain display-only, while dashboard calculation requires explicit Refresh.
- No payment, profile-isolation, SMS, report, or Month-to-Month logic changed.
- Recorded the agreed next appearance direction: overall theme may evolve freely, with green/emerald/mint used selectively as additional visual variation rather than replacing the whole theme.
- Theme work remains planned and is not implemented in this correction.

## 4.5.0 — NEXT LEVEL performance-policy correction
### DevMonitor product identity + phone-performance build culture
- Standardized the current product name to **DevMonitor** across the active UI, NEXT LEVEL roadmap/tracker, master sheet and change log.
- Retained legacy lowercase storage/database/Firebase/billing identifiers where changing them would risk existing data or store compatibility.
- Removed automatic dashboard recalculation on profile/code changes. Dashboard intelligence is now user-refresh driven.
- Added explicit dashboard refresh state so users can see when the dashboard was last calculated.
- Changed dashboard payment progression from automatic calculation to explicit **Refresh Progression**.
- Disabled automatic month-end background monitoring and made the legacy scheduler/receiver a cancellation/inert compatibility path.
- Added a lightweight 18th–20th month-end dashboard reminder; it only prompts the user to decide when to refresh/review and never launches operational work.
- Confirmed profile switching remains cache/display-only; each profile shows its last-known dashboard values until the user explicitly refreshes.
- A dashboard refresh may follow a completed user-started monitoring pass because it is the natural immediate next step; no independent background workload is introduced.
- No payment rules, payment-cycle boundaries, profile isolation or authoritative report logic were changed.

# DevMonitor — CHANGE LOG

## DevMonitor 4.5.0 — NEXT LEVEL Phase 1 dashboard transformation
- Added `NEXT_LEVEL_ROADMAP.md` containing the complete multi-phase product evolution plan.
- Added `NEXT_LEVEL_TRACKER.md` as the incremental implementation tracker for future upgrades.
- Transformed the dashboard into a command-centre layout.
- Added active-profile global device/alert search.
- Added dashboard quick actions for Device Monitor, My Devices, SIMReg Reports and Payments.
- Added live payment-cycle progression on the dashboard using the existing payment calculation pathways.
- Added Action Centre with alert summaries and drill-down actions.
- Preserved profile-scoped Device Monitor storage and existing 21st-to-20th payment-cycle rules.
- No duplicate payment calculation engine or new operational data source was introduced.

## 4.4.2 — Dashboard Month-on-Month Card & Payment Wording
- Expanded the dashboard Month-on-Month section into a full-size Aurora card.
- The card now displays the currently available comparison result directly on the dashboard, including current MTD, same-period-last-month total, change/percentage and as-of date.
- Added Refresh and Open Full Comparison actions without changing the existing Month-on-Month calculation/data layer.
- Renamed the payment estimate primary activation label from **Activations used** to **Current Activation Achieved**.
- No payment calculation or progression logic was changed.

## 4.4.1 — One-off Device Enquiry
- Added a separate **Check Now — don't add to My Devices** action to Device Monitor.
- Manually entered/new device codes can now be queried immediately without being appended to the persistent My Devices working queue.
- One-off enquiry results are displayed separately from My Devices results and can still open the normal payment estimate/progression card and be rechecked.
- One-off SMS observations continue to feed the existing Device Monitor history/payment data pathways; the code is not added to the My Devices working set.
- Existing **Add list**, **Replace**, **Start / Refresh All**, **Continue**, and **Retry** behavior remains unchanged.
- Payment calculation, payment-cycle resolver, Month-to-Month data layer, report processing, and My Devices database architecture were not changed.

## 4.3.5.59 — Final Month-to-Month Search Scope & Staff Classification
- Corrected the 4.3.5.58 Month-to-Month search so it no longer searches the full company database.
- Search now reads only the four dedicated Month-to-Month databases: Previous Month, Previous Month My Devices, This Month, and This Month My Devices.
- Device Monitor is a read-only peek only for matching Month-to-Month results; it can enrich a matching device with newer observation information but cannot introduce a Device Monitor-only search result.
- Added the requested one-time staff type check on first Month-to-Month run. The raw saved profile phone must be exactly 11 numeric digits beginning with `0805557`. No normalization or formatting stripping is performed.
- Classification is persisted as STAFF or NON_STAFF until a fresh install/app-data reset. A non-staff result is silent and hides the search field.
- Month-to-Month Device Monitor freshness now uses the newer observation's **Active** value, never MTD.
- Updated MASTER_WORK_SHEET.md for the final architecture.
- Payment calculation/resolver/progression/pathway code was not changed.


## 4.3.5.58 — Full-Database Search from Month-to-Month
- Added a staff-only search field on the Month-to-Month Comparison page.
- Search is intentionally outside the four Month-to-Month working stores: it searches the full company device/hierarchy database so a logged-in staff user can check devices, partners or staff members that are outside the current My Devices comparison scope.
- Search matching follows the established case-insensitive/contains route already used by the app: canonical/raw Device ID, partner name/trade code, and staff name.
- Search results are informational only and do not alter the Month-to-Month calculation, its cutoff, populations, or isolated databases.
- Payment calculation/resolver/progression/pathway code was not changed.


## 4.3.5.57 — Isolated Month-to-Month Databases
- Replaced the Month-to-Month calculator's dependency on the existing company normalized database.
- Added four dedicated SQLite databases: previous-month full snapshot, previous-month My Devices projection, current-month incremental snapshot, and current-month My Devices projection.
- Report routing is controlled by the report filename month; unrelated month files cannot update a comparison month.
- Partial previous-month reports remain replaceable until a full-month **Activation** filename/report is supplied; that full previous-month activation snapshot is then locked.
- Current-month data is maintained incrementally and replaced by newer reports for the same filename month.
- At month rollover, the current incremental month becomes the previous-month working snapshot unless a locked full activation snapshot already exists.
- Month-to-Month calculation reads only the four isolated databases plus a read-only peek at the live Device Monitor database.
- Device Monitor MTD data can supersede loaded-report data for a saved My Device when its observation was received after the current report snapshot.
- Previous-month comparison uses the same elapsed day-of-month cutoff against the previous-month snapshot.
- Existing payment calculation/resolver pathways were not modified.

## 4.3.5.56 — Global Human Date Parser
- Added one centralized `HumanDateParser` for external/report date text.
- Accepts broad human date families: ISO, numeric DMY/MDY, compact numeric, full/short month names, ordinals (`1st`, `2nd`, `3rd`, `4th` and common locale ordinal suffixes), Roman-numeral months, month/year forms, and mixed-format ranges.
- Range endpoints are parsed independently, so forms such as `Sep 1st - 23rd September 2026` are valid.
- The exact `SEPT 1-23RD` filename is now interpreted as September 1–23 rather than September 1–30.
- Internal database dates remain canonical ISO `yyyy-MM-dd`; presentation formatting now uses the same central date policy.
- No payment calculation/resolver logic changed.
- Month-on-Month calculation logic was not changed.



## 4.3.5.55 — Month-on-Month Device Monitor Freshness Fix
- Prevent stale/restored Device Monitor observations from extending a loaded report's Month-on-Month cutoff.
- A Device Monitor observation can supersede the report cutoff only when its received timestamp is newer than the selected report import timestamp.
- Current-month Device Monitor totals use the same freshness rule.
- Payment logic/cycle logic unchanged.


## 4.3.4.21 — Aurora touch feedback hotfix
- Fixed missing/inconsistent pressed/ripple feedback on Aurora primary and outlined buttons.
- Baseline: 4.3.4.20 Aurora Gradient Buttons.
- No business-logic or dependency changes.


## 4.3.4.20 — Aurora Gradient Button Redesign
- Reworked shared DevMonitor action controls into modern pill-shaped Aurora gradient buttons inspired by the supplied visual references.
- Primary actions now use blue/cyan gradients with restrained glow; secondary actions use soft gradient-tinted pills and colored outlines.
- Preserved all existing functionality and the established phone build environment.

# DevMonitor 4.3.4.17 — Complete Aurora UI Redesign

- Reworked the reusable Compose presentation layer into a consistent DevMonitor Aurora design system.
- Replaced heavy Material button elevation/shadows with clean Aurora primary and outlined actions.
- Added animated live indicators, glass surfaces, accent borders, status pills, icon badges and reusable list-row styling.
- Redesigned dashboard hero/metrics and modernized Device Monitor result/progress surfaces.
- Redesigned the Settings cards for a cleaner account, monitor, storage and app-experience hierarchy.
- Modernized Payment/Partner management surfaces using the same Aurora visual language.
- Refreshed the top app bar branding with the DevMonitor launcher mark and cleaner profile treatment.
- Preserved Firebase authentication, Firestore authorization, SMS, SIMReg, payment, backup and existing business logic.
- Preserved the phone build environment, Gradle 8.7 wrapper, AGP 8.6.1, Kotlin 2.0.21 and mobile AAPT2 override workflow.
- No new dependencies were introduced.


## DevMonitor 4.3.4.5 — Google Sign-In compile/runtime callback fix
- Fixed Kotlin compilation errors in `MainActivity.kt` caused by unsupported `exceptionOrNull()` usage and incorrect `AuthStateListener` lambda typing.
- Google sign-in result handling now uses explicit `ApiException`/`Exception` handling.
- Firebase auth-state listener now correctly reads `auth.currentUser`.
- Google profile name, email, and photo continue to populate the top app identity area after successful sign-in.
- No change to the staff authentication rule: successful qualifying OTP establishes full staff access.


## DevMonitor 4.3.4.4 — Google Sign-In & Profile UI Fix
- Hardened Google sign-in result handling so cancellation/API failures and Firebase failures are surfaced instead of appearing to do nothing.
- Captures the signed-in Google display name and profile photo URL alongside email/Firebase UID.
- Added a persistent Google profile placeholder in the main top bar when signed in.
- Added Google profile details to Settings → Account & Cloud Backup.
- Clears Google profile information on sign-out.
- Added Coil image loading for the Google profile picture.
- Staff authentication/access model remains unchanged: successful qualifying staff OTP verification grants full DevMonitor access.


## DevMonitor 4.3.4.3 — Staff access correction
- Corrected the authentication state after successful OTP verification of a qualifying `0805557xxxx` staff line.
- Successful staff-line OTP now sets the DevMonitor account to `AUTHORIZED`.
- Verified staff accounts now have full access to all DevMonitor functionality, including Payment Intelligence and raw HQ/SIMReg data processed by the app.
- Removed the unintended second authorization gate for verified staff accounts.
- Preserved the separate non-staff/agent authorization path.

## DevMonitor 4.2.6.3 — SIMReg Loading & Back Navigation

- Added a visible loading/opening state when opening a saved Company SIMReg workbook, with progress messaging so the app does not appear unresponsive during workbook parsing.
- Renamed the user-facing SIMReg loading/import action to **Load SIMReg Report File** / **Load Company SIMReg Report**; the operation remains the same and the original workbook is still preserved internally.
- Added application back navigation: swiping/pressing Back from Device Monitor, SIMReg, Agents, Payments, Settings, and other app sections now returns to the initial dashboard instead of closing DevMonitor. Back from the initial dashboard remains the normal app-exit action.
- Preserved the phone-exclusive build environment, ARM-compatible AAPT2 override, existing monetization/ads, SIMReg intelligence, saved-workbook persistence, virtualized table, and pinch-to-zoom behavior.
# DevMonitor — CHANGE LOG

## DevMonitor 4.3.1 — Payment Intelligence landing page compile fix
- Fixed missing `Alignment` import in `ManagementScreens.kt`, which caused Kotlin compilation errors in the Payment screens.
- No payment rules, parser behavior, or Master Work Sheet logic changed.

## DevMonitor 4.3.0 — Payment Intelligence landing page
- Promoted Payments to a dedicated full-page destination.
- Added the supplied company payment-structure flyer as the visual introduction to the Payments landing page.
- Direct Payments landing page starts empty of payment results until the user chooses a search path and enters a search.
- Added separate **AGENT / DEVICE TAG** and **PARTNER** search paths.
- Agent/device searches use the imported HQ SIMReg/Activations data when available and local Device Monitor records as an estimation source.
- Partner searches use partner name/trade code information from the imported HQ report and available agent/partner records.
- Added full-page Device Payment Card drill-down using the existing DevMonitor payment progression/estimation rules.
- Preserved the distinction between HQ activation evidence, SIM Reg registration data, and Device Monitor estimation evidence.
- Added Device ID links in the imported Master Work Sheet table that open the same Device Payment Card.
- Back from a Device Payment Card opened from the Master Work Sheet returns directly to the table without discarding its table state.
- Partner overview lists matching devices with payment category/progression and allows drill-down to an individual Device Payment Card.
- Kept the existing payment/incentive monitoring-only warning and company-authority boundary.
- No changes to the existing SIMReg parser or report structure rules.


## Historical baseline

### 2.0 / 2.0.1 — Monitoring reliability and multi-SIM
- Calendar daily and MTD observations.
- Company/partner ownership distinction.
- Company-first report priority.
- Zero-sales and day-15 MTD monitoring.
- Consecutive zero-sales monitoring.
- Bar 48 / Conversion Lost monitoring.
- Recent-pattern deviation monitoring.
- Analytics retention.
- Visible SIM selector for dual/multi-SIM phones.
- Android SmsManager-only SMS transmission.
- Optional sent/delivery reports and immediate retry behavior.
- Month-end payment snapshot scheduling.

### 2.1.x — Product polish, onboarding and compliance readiness
- First-launch introduction and interactive guided tour.
- About/profile presentation.
- File attachment/link area.
- Clear input examples/placeholders.
- GLO long-form → short-form conversion immediately before 3030 transmission.
- SMS permission disclosure and Play SMS-permission readiness.
- Production reporting/export polish.

### 2.2.x — Distribution/update work
- Remote update checker.
- Optional direct APK download/install flow for applicable sideload builds.
- Samsung/Galaxy Store compliance fork removed sideload auto-update mechanism.
- AdMob test/prod configuration work retained according to release.

### 2.3.0 — Public monetization fork
- First 10 successful Excel exports free.
- Rewarded ads grant export credits after free allowance.
- Premium removes ads/export limits.
- Day-15 diagnostic flag hidden by default with diagnostic gesture.
- Public and personal fork concept established.

### 2.3.1 — Premium and feedback
- Monthly/yearly Premium handling.
- Premium entitlement refreshed from store state.
- Feedback form and configurable Google Apps Script/Sheets endpoint.
- Interstitial frequency and rewarded-export behavior tuned.

### 2.3.2 / 2.3.2.1 / 2.3.3 — Device identity and input normalization
- Same-day recheck allowed.
- Stable GLO canonical identity.
- Long/short GLO records merged by device/date.
- Export de-duplicates long/short forms.
- Agent/device links use canonical identity.
- Case-insensitive code input.
- Uppercase immediately before SMS transmission.
- Open partner-code format; company/server determines validity.
- Excel import follows open partner-code behavior.

### 2.3.4 — Interactive first-operation guided tour
- Guided tour follows real Device Monitor → SMS → report → export actions.
- Save-list hint added after tour.
- Tour does not simulate SMS/export actions.

### 2.3.5 — Full left navigation drawer
- Replaced cramped three-dot app menu with Material 3 left drawer.
- Guided Tour, About, Feedback, Files & Analysis and Settings.
- Open Device Monitor quick access.
- Existing introduction remains separate from optional guided tour.

### 2.3.6 / 2.3.7 — Settings and onboarding refinement
- System/Light/Dark theme preference.
- Monitor settings preserved separately.
- Local data/storage summary.
- Guided Tour Again.
- Introduction remains normal first-launch entry.
- Guided tour is triggered from Device Monitor entry for eligible users.
- Scrollable introduction and clearer Next/Explore behavior.

### 2.3.8 — SMS Recovery + User-Controlled Recheck
- READ_SMS recovery of relevant existing SMS.
- Persisted outbound query attempts.
- Direct and timestamp/sequence correlation.
- Ambiguous responses remain unresolved.
- Recheck previously checked.
- Continue unresolved.
- Per-code Recheck.
- Same-day later results refresh current daily snapshot.
- Database version 7.
- Query attempts retained for 14 days.

### 2.3.9 — Guided Tour fixes
- Active target stays visible while typing.
- Next actionable target pulses.
- Skip persists dismissal.
- Manual restart remains available from Settings.

### 2.3.10 — Flexible code input
- Short code, comma, tab/Excel, semicolon and multi-line input.
- Duplicate removal.
- Canonical short GLO query to 3030.
- Partner codes remain open-format.

### 2.3.11 — Guided Tour SIM selection
- Explicit SIM-selection tour step when multiple active SIMs exist.
- Default/first-active fallback retained.
- Single-SIM phones skip unnecessary selection step.

### 3.0 — Saved List Membership Management
- Manage existing saved lists.
- Add/remove multiple normalized codes.
- Duplicate additions ignored.
- Saved-list changes do not delete device/history data.
- Existing Load/Delete behavior preserved.

### 4.0 — Google Account, Cloud Backup & File Sharing
- Optional Google Sign-In.
- Private Google Drive app-data backup/restore.
- Local SQLite remains primary storage.
- Backup only after explicit user action.
- Restore requires explicit choice and reload.
- Android Share sheet for attached files and last Excel report.
- Existing SMS, recovery, normalization, daily snapshot, guided tour and Saved Lists preserved.

### 4.2.3 — SIMReg customizable working view

- Added **Customize View** for the Excel-style SIMReg table.
- Columns can be individually hidden or restored without changing the imported workbook.
- Device ID remains visible by default, while all identity, hierarchy, daily, MTD and total columns are configurable.
- Added row view filters: **All rows**, **Only rows with activity**, and **Only zero rows**.
- Row/column focus now follows the currently visible table layout.
- Added **Reset view** to restore all columns and all rows.
- View customization is scoped to the currently opened report and does not modify saved source data.

### 4.2.1 — SIMReg report persistence, zoom and import progress
- Labels the selected report MTD using the report month, e.g. **August MTD**, so it is clearly tied to the report period rather than the current phone month.
- Added Excel-style table zoom from 60% to 200%, with pinch-to-zoom and +/- controls.
- Preserved device row focus and column focus while zooming and scrolling.
- Added automatic internal storage of the complete imported `.xlsx` workbook.
- Added a Saved SIMREG Reports library with reopen support.
- Added separate retention of the three newest current-period reports and three newest full-month archives.
- Retention uses report coverage dates, not workbook filenames.
- Moved Excel reading/parsing/saving off the main UI thread and added an explicit importing/busy state so the app no longer appears frozen during import.
- Bumped development build to version 4.2.1 / versionCode 56.

### 4.1 — Xiaomi GetApps Premium
- Monthly and yearly Premium choices restored.
- Monthly target ₦2,000.
- Yearly target ₦20,000; store price authoritative once configured.
- Premium removes banner/interstitial/rewarded ads.
- Premium bypasses rewarded-export restriction.
- Restore Premium and Manage Subscription.
- Xiaomi GetApps IAP SDK 1.1.9.
- SKUs `fieldpulse_remove_ads_monthly` and `fieldpulse_remove_ads_yearly`.
- Stable obfuscated account ID for purchase flow.
- Subscription state rechecked on startup/restore.
- Production AdMob IDs preserved.
- Xiaomi 1.1.9 compile compatibility bridge retained.

### 4.1 — Guided Tour keyboard fix
- Keyboard is cleared/hidden before the Start Sending SMS guided-tour step.
- Prevents keyboard from covering the highlighted action.
- No SMS, billing, AdMob or other tour behavior intentionally changed.

---

# 4.2 — Headquarters SIMReg Report Intelligence Foundation

**Status:** Development foundation. Must be built and tested on the actual Android Code Studio/ARM64 environment before release designation.

## 4.2 business rules added

### Two valid HQ report flavors
Headquarters can provide either:
1. **SIM Reg as at [date]** — registration/sales recorded at that point.
2. **Activations as at [date]** — activation-qualified results.

Both are valid monitoring inputs.

**Registration is not automatically activation.**

The company pays primarily on activation performance, not registration alone.

### Activation qualification rule recorded
The known company rule requires:
- at least **₦20 recharge**;
- required call/use behavior during the following activation-monitoring period represented operationally by Bar 48 / Bar 96.

The ₦20 qualification threshold is distinct from the separate ₦200 minimum used for the estimated first-recharge incentive calculation.

### Authority rule
DevMonitor cannot validate the company's final records.

**Company data remains the final authoritative report.**

All DevMonitor payment/incentive numbers are monitoring/estimation unless independently confirmed by the company.

### Prominent payment warning
Payment/incentive UI must visibly state that figures are for monitoring/estimation only and that the company's official data is authoritative.

This warning applies to:
- Device Monitor;
- SIMReg Report;
- Agent/Partner Payment Tracking;
- future payout screens;
- partner incentive screens;
- payment-related exports.

## 4.2 shared payment rules recorded

The same incentive rules apply to **Device Monitor and SIMReg Report**; they must use one shared calculation engine.

Current individual/device tiers:
- 30 → ₦9,000
- 40 → ₦16,000
- 50 → ₦22,500
- 70 → ₦35,000
- 100 → ₦65,000

Estimated recharge component:
- ₦200 minimum recharge basis for the estimate.
- ₦250 estimated bonus per activation.
- Not confirmed because report data does not identify the recharge class per activation.

Positive next-level messaging:
- 27 → 3 more to 30 → ₦9,000.
- 38 → 2 more to 40 → ₦16,000.
- 48 → 2 more to 50 → ₦22,500.
- Preferred wording: **“Do more. Reach the next level. Earn better.”**

Partner:
- 500 is the minimum known portfolio activation threshold.
- 1,000/1,500 variants exist.
- Partner payout rules remain configurable/future work.

## 4.2 HQ workbook intelligence

Added structure-aware parsing foundation.

The importer must not rely on:
- filename;
- sheet 1/2 position;
- exact sheet name;
- fixed column letters.

It identifies the detailed device-level sheet by structural/content indicators including:
- Device ID;
- Channel Partner Name;
- Trade Code;
- Cluster;
- Region;
- Territory;
- Staff Name;
- daily columns;
- total columns;
- individual device rows.

Supports one-sheet and multi-sheet workbooks.

### Data hierarchy
**Cluster → Region → Staff Name → Territory → Device ID**

Partner fields:
**Channel Partner Name + Trade Code**

### Search
Case-insensitive across:
- Staff Name;
- Region;
- Cluster;
- Territory;
- Channel Partner Name;
- Trade Code;
- full Device ID;
- partial Device ID.

Partial Device ID results always display full IDs.

### MTD
Use the report's effective cutoff, not the phone's current date and not filename alone.

SIM Reg reports show registration MTD; Activations reports show activation MTD.

Payment estimation must not silently turn registration into activation.

## 4.2 Device Monitor ↔ HQ distinction

Two sources remain distinct:
- HQ SIMReg = official report input for monitoring.
- DevMonitor Device Monitor = local monitoring evidence.

A future bridge compares both without destructive merging.

Local-only devices remain visible because local monitoring can reveal important zero activity even when HQ omits the device.

## 4.2 private analysis

Private previous/current HQ comparison is defined:
- current listed + MTD 0 = confirmed zero;
- previous listed + current absent = missing/inferred, not proof of zero.

Private Find Device searches the entire current HQ workbook using full canonical Device ID and can reveal a moved staff/territory/region/cluster/partner context.

This must not become a normal manager alert or expose local deletion history.

## 4.2 report retention

Current period:
- keep rolling three most recently uploaded reports.

Completed full-month archives:
- retain three months;
- not subject to rolling three-report deletion.

Use report coverage/period and upload metadata, not filename alone.

## 4.2 current foundation files
- `SimRegReport.kt`
- `PaymentRules.kt`
- updated `MASTER_WORK_SHEET.md`
- updated `CHANGE_LOG.md`

## 4.2 intentionally unfinished
- automatic three-current-report retention;
- three-month full-month archive cleanup;
- private cross-month comparison UI;
- private Find Device;
- full HQ↔Device Monitor reconciliation UI;
- complete hierarchy dashboards;
- configurable partner payout structures;
- exact 21–20 cycle activation aggregation;
- complete Device Monitor integration of shared incentive calculations.

These are planned work, not completed functionality.

---

## Build/change safety note

The 4.1 successful phone-build environment is authoritative:
- AGP 8.6.1;
- Gradle 8.7;
- Kotlin 2.0.21;
- Java/JDK 17;
- compileSdk/targetSdk 36;
- minSdk 26;
- one Gradle worker;
- parallel disabled;
- ARM64-compatible Android Code Studio AAPT2 override through `build-phone.sh`;
- no Apache POI.

Do not call a development ZIP a stable release until it compiles and is tested on the actual phone.

## 4.2 — Android Excel Open/Import Integration
- Added Android `ACTION_VIEW` handling for `.xlsx` Excel workbooks.
- DevMonitor now appears as an Android app option when a compatible Excel workbook is opened from a file manager, Downloads, Google Drive, or another file/document app that exposes the workbook to Android.
- Opening an Excel workbook in DevMonitor does **not** import it silently. DevMonitor presents an explicit **“Import Excel sheet?”** confirmation dialog showing the workbook name.
- **Import** sends the workbook through the existing structure-aware SIMReg/Activations parser and opens the report analyzer.
- **Cancel** leaves the workbook untouched and returns to the app.
- The same existing parser is used for both the in-app picker and external Android open flow, avoiding a second Excel-reading implementation.
- Supported external format in this release: modern Excel `.xlsx` workbooks. Legacy binary `.xls` is not claimed as supported.
- App version advanced to development **4.2 / versionCode 55**.

## 4.2 — Excel Open/Import compile correction
- Corrected `SimRegReportParser.parse()` to explicitly return the constructed `SimRegReport`.
- Corrected the report-type reference in `SimRegReportScreen` to use the imported report's `reportType` rather than a non-existent row property.
- These were source-level Kotlin compile errors in the first Excel Open/Import package; no intended feature behavior was changed.


## 4.2 — Payment-status boundary and Excel-style report table
- Removed the PAID/UNPAID payment-status display from payment-cycle results.
- DevMonitor does not present company payment status as a tracked operational responsibility.
- Kept the existing payment/incentive monitoring warning and estimation boundary.
- Replaced imported HQ SIMReg/Activations result cards with an Excel-like row-and-column table.
- Each device is displayed as one row for easier side-by-side comparison.
- Added horizontal scrolling across Device ID, Partner, Trade, Cluster, Region, Territory, Staff, daily columns 01–31, MTD, and GRAND TOTAL.
- Search and filters continue to operate against the same report rows.

## 4.2 — Excel table row/column focus
- Added persistent device-row focus: tapping any cell in a device row highlights that entire device row while the user horizontally scrolls through the month.
- Added persistent column focus: tapping a daily/MTD/TOTAL header or value highlights that column across the visible device rows.
- Added a compact focus indicator showing the selected device and selected column.
- Horizontal table scrolling remains synchronized between the header and all device rows, allowing the focused row/column to be followed across the full month.
- This is visual navigation/focus only; it does not alter report data.

## 4.2.x — Excel table scrolling/zoom interaction correction (current development patch)
- Removed per-row horizontal scroll containers from the Excel-style SIMReg table. Per-row horizontal scrolling was competing with the outer vertical `LazyColumn` and could make vertical scrolling appear unresponsive after entering the table.
- The table now has **one shared horizontal scroll container** for the header and all visible device rows. Horizontal position remains synchronized across the entire table.
- Vertical scrolling remains owned by the main report screen, so vertical page scrolling and horizontal table scrolling are independent rather than nested on every row.
- Removed `detectTransformGestures` from individual rows/header. This was consuming ordinary one-finger gestures and contributing to the scrolling lock-up.
- Reimplemented pinch-to-zoom so zoom processing activates only when two or more pointers are present. One-finger gestures are deliberately not consumed by the zoom handler.
- Zoom range remains 60%–200%; visible +/- controls and zoom percentage are removed. Pinch is the only zoom control.
- This patch is specifically intended to restore responsive vertical scrolling, responsive horizontal table scrolling, and real pinch-to-zoom without changing report parsing or business rules.
- Phone compilation and device testing are still required before calling this a stable release.


## 4.2.x — SIMReg table virtualization / scrolling stability correction
- Reworked the Excel-style SIMReg table so device rows are rendered through the screen's `LazyColumn` instead of a regular `Column` that composed up to 300 rows at once.
- Added stable row keys using `Device ID` so Compose can efficiently reuse/recycle off-screen row content.
- Preserved one shared horizontal `ScrollState` for the header and every virtualized device row, keeping all columns aligned while scrolling.
- Preserved two-finger pinch zoom at 60%–200%; visible +/- zoom controls and zoom percentage remain removed.
- One-finger vertical scrolling remains owned by the report screen's main `LazyColumn`; one-finger horizontal movement uses the shared table scroll state.
- No changes to SIMReg/Activations parsing, saved-report persistence, filtering, Customize View, row/column focus, or business rules.
- This is a performance/stability correction intended to prevent UI freezes and crashes caused by composing hundreds of wide spreadsheet rows simultaneously.
- Phone compilation and device testing are required before treating this as stable.

## 4.2.x — Pinch gesture compile correction
- Corrected the table pinch-to-zoom implementation after the first scroll/zoom repair produced Kotlin compile errors in `SimRegReport.kt`.
- Removed the unavailable `calculateZoom()` extension and replaced it with direct two-pointer distance calculation, compatible with the project's Compose dependency set.
- Removed the nested `awaitPointerEventScope` pattern that caused the restricted-suspending-function compiler error.
- One-finger scrolling remains unconsumed; only active two-finger gestures are consumed for zoom.
- No report parsing, import, saved-report, row/column customization, or business-rule behavior was changed.

## 4.2.x — Company SIMReg intelligence consolidation / performance build
- Consolidated the HQ company-report workflow around the imported `.xlsx` as the source workbook while keeping DevMonitor Device Monitor data separate.
- Added report-type-aware treatment: SIM REG is displayed as registration performance and is never silently converted to activation payout; ACTIVATIONS is eligible for monitoring-only incentive estimation.
- Added equal-elapsed-period current-vs-previous report comparison using the report cutoff rather than the phone's current date.
- Added HQ hierarchy dashboard views for Cluster, Region, Staff, Territory and Channel Partner, with device counts and report totals.
- Added a private on-device analysis area with full/partial Device ID search across the entire current HQ report and previous/current missing-device comparison.
- Added explicit distinction between confirmed zero (device is listed with MTD 0) and missing/inferred (device existed previously but is absent from the current report).
- Added HQ ↔ Device Monitor reconciliation summary without destructive merging or overwriting; local-only devices remain visible.
- Added 21st→20th activation-cycle aggregation from retained activation reports when sufficient month coverage exists; otherwise the UI reports that retained data is insufficient instead of guessing.
- Reused the shared `PaymentRules` incentive engine for activation report/device estimates and added positive next-threshold messaging.
- Added persisted local configuration for the working partner activation target; the minimum known 500 threshold is the default, while 1,000/1,500 arrangements remain configurable and company-authoritative.
- Preserved the prominent payment/incentive monitoring-only warning and company-authority boundary.
- Kept the original imported workbook saved internally and retained the existing rolling current-report / three-month full-month archive policy.
- Reworked the report table so rows are virtualized by the main `LazyColumn`; one shared horizontal scroll state keeps the header and visible rows aligned.
- Pinch-to-zoom remains the only visible interaction for zoom, limited to 60%–200%; one-finger scrolling is not consumed by the pinch handler.
- Improved report date extraction to prefer explicit as-at/report-date wording and support common numeric and month-name date formats.
- This remains a development build until phone compilation and full device testing confirm import, scrolling, pinch zoom, comparison and reconciliation behavior.

## 4.2.5 SIMReg table interaction refinement
- SIMReg report uses the short month label for MTD (for example, `Sep MTD`) instead of the full month name.
- The navigation drawer swipe gesture is disabled while the SIMReg report screen is active, preventing horizontal table scrolling from being mistaken for a drawer pull. The drawer remains accessible from the menu button.
- The virtualized table and pinch-only zoom architecture are retained.

## DevMonitor 4.2.6.2
- Corrected the saved Company SIMReg report reopen path with persisted-workbook validation and buffered loading.
- Added diagnostic reporting for missing, empty, or unreadable saved workbooks instead of masking the underlying error.
- Preserved the phone-exclusive AAPT2/build configuration and advertising behavior.

## DevMonitor 6 — Master Work Sheet sticky header correction
- Preserved the known-working 4.2.6.3 build environment as the base.
- Kept the Master Work Sheet horizontal table behavior from the previous change.
- Replaced the unsupported Compose `stickyHeader` API with a custom sticky-header implementation using the existing `LazyColumn`/scroll infrastructure.
- Column headers remain visible after the header row scrolls off-screen during vertical scrolling.
- Device ID remains pinned while the other columns use the shared horizontal scroll state.
- No Gradle/dependency upgrades were introduced.


- DevMonitor 4.2.7: fixed an extra closing brace in SimRegReport.kt that caused cascading Kotlin parser errors after the phone-compatible AAPT2 fix.

## 4.3.4 Authentication
- Added DevMonitor Account identity and protected Payment Intelligence gate.
- Added Google identity association, Nigerian phone profile, staff-candidate classification and agent/partner authorization-request flow.
- Added authorization request IDs and audit-event storage.
- Added SQLite migration from DB version 7 to 8.
- Kept authorization account-based so future Android/Web/PC clients can share the same identity and authorization contract.
- No payment calculation or parser logic changed.


## DevMonitor 4.3.4.1 — Authentication hardening
- Added Firebase Authentication using the supplied Firebase configuration.
- Existing Google Sign-In now establishes the Firebase identity anchor through the Google ID token.
- Added Firebase UID and phone-verification timestamp to the local account schema.
- Added real Firebase phone verification linked to the already authenticated Google/Firebase account.
- Restricted paid OTP requests to the configured `0805557xxxx` Glo staff-candidate pattern.
- Non-staff-pattern numbers are rejected locally and do not trigger Firebase OTP.
- Added a 10-minute resend cooldown in the authentication UI.
- Preserved the rule that staff-pattern detection and phone ownership do not themselves grant Payment Intelligence authorization.
- Preserved the separate Device Manager authorization path for agent/partner accounts.
- Advanced the authentication database schema from version 8 to version 9 without resetting existing user data.
- Changed the Android display name from `DevMonitor` to `DevMonitor Monitor` because an unrelated Google Play app already uses the exact `DevMonitor` name.
- Preserved the established AGP 8.6.1 / Gradle 8.7 / Kotlin 2.0.21 / JDK 17 / ARM AAPT2 phone-build environment.


## DevMonitor 4.3.4.6 — Payment Landing / Partner Access
- Payment landing page now presents two primary paths: Staff Login and Partner Login.
- Staff Login unlocks the complete DevMonitor application after the existing Google + qualifying staff-line OTP verification.
- Partner Login collects partner phone number and Trade Code, then sends an approval request to a selected staff member through WhatsApp.
- Partner payment details remain locked pending staff approval.
- Existing staff payment search remains available after staff authentication.


### 4.3.4.7.1 — Debug Authentication Fingerprint / Build Environment
- Debug signing report verified successfully with `sh gradlew signingReport`.
- Debug keystore: `/data/user/0/com.tom.rv2ide/files/home/.android/debug.keystore`
- Debug alias: `AndroidDebugKey`
- Debug SHA-1: `4B:41:36:12:EA:4C:9F:ED:93:46:1E:C6:68:77:45:7B:65:59:E0:02`
- Debug SHA-256: `1D:BE:EE:61:64:A2:FC:97:55:C3:BD:8A:7B:54:02:4A:68:22:64:69:0E:55:91:15:6D:4D:86:AE:B6:C8:AA:AA`
- Build environment: Android Code Studio on Android phone; Gradle 8.7; AGP 8.6.1; Kotlin 2.0.21; JDK 17; compileSdk/targetSdk 36; ARM-compatible AAPT2 override via `build-phone.sh`.
- Version naming for this authentication workstream remains the `4.3.4.x` family; corrections stay within that family.
- This fingerprint is the debug certificate used by the current phone development build. It must be added to the Firebase Android app configuration before retesting Google sign-in.

### 4.3.4.8 — Firebase Android OAuth Configuration
- Integrated the refreshed `google-services.json` containing the Android OAuth client for `com.aziitech.simregmonitor`.
- Android OAuth certificate hash matches the DevMonitor debug SHA-1.
- Preserved the existing authentication, OTP, payment landing, database, and DevMonitor functionality.
- Version remains within the `4.3.4.x` authentication family.

## DevMonitor 4.3.4.9 — Partner Access Architecture / Build Inspection
- Updated the master work sheet to define the next Partner Login → Staff Approval → Partner Unlock architecture.
- Partner authorization is now specified as account + Trade Code based rather than permanently bound to one physical phone.
- Approval is intended to survive partner phone changes and work consistently across future Android, PC, and web clients.
- Device/session security is kept separate from the underlying partner/Trade Code authorization.
- Staff revocation is intended to propagate through the shared authorization authority across platforms.
- The current 4.3.4.8 implementation gap is recorded: WhatsApp notification and local authorization audit exist, but shared cross-device approval synchronization does not yet exist.
- No code or database-reset change was made in this documentation/planning update.
- Build inspection confirmed the established AGP 8.6.1 / Gradle 8.7 / Kotlin 2.0.21 / JDK 17 / SDK 36 / ARM AAPT2 environment remains configured.
- The current container could not compile the project because it lacks the ARM-compatible AAPT2 binary and cannot download Gradle 8.7; actual compilation must be performed in Android Code Studio on the phone.


### 4.3.4.9 — Shared Partner Authorization Foundation
- Added Firebase Firestore-backed shared partner authorization records.
- Partner approval is tied to Firebase partner account UID + Trade Code, not a physical device.
- Existing approval can therefore survive phone/device changes and can be consumed by future Android, PC and web clients using the same account identity.
- Added pending/approved/rejected/revoked status model and staff review/decision UI.
- Partner payment view is restricted to the approved Trade Code only.
- Device model is recorded as audit context only; it is not the authority for approval.
- Added Firestore security rules requiring authenticated partner ownership for request creation/reading and qualifying verified staff identity for staff review/update.
- Existing SQLite data is preserved; no destructive database reset was introduced.
- Firebase configuration remains the confirmed 4.3.4.8 authentication configuration.

## 4.3.4.10 — AUGUST HISTORICAL SEED + SAVED REPORT DELETE
- Added the supplied August 2026 full-month SIMReg workbook as a one-time bundled historical seed.
- Seed metadata is explicitly August 1-31, 2026 and marked full-month so historical/payment/progression comparisons use the intended period.
- The source workbook bytes are preserved without rewriting the workbook.
- Seed remains subject to the existing three completed-full-month archive retention policy.
- Added Delete beside Open for saved SIMReg reports with confirmation.
- Deletion removes only the saved workbook and metadata; unrelated Device Monitor/SMS records remain intact.
- Preserved 4.3.4.9 authentication and shared partner authorization behavior.

## DevMonitor 4.3.4.11 — Aurora UI Redesign
- Redesigned the app's visual language away from default green into a deep navy/aurora system with blue, cyan and violet accents.
- Added dimensional/3D-feel elevation to primary and outlined buttons while preserving their existing behavior and call sites.
- Added animated page transitions between the main app sections.
- Added selected bottom-navigation icon motion.
- Preserved native drawer/dialog motion and all existing functional workflows.
- Redesigned adaptive and legacy launcher icons around a DevMonitor FP/signal mark.
- Avoided continuous heavyweight animations because the current build was reported as slightly sluggish.
- Preserved authentication, Firestore partner authorization, historical SIMReg seed, SQLite data, SMS workflows and payment logic.

## DevMonitor 4.3.4.12 — Aurora UI Build Correction
- Corrected accidental global Compose button-name replacements introduced by 4.3.4.11.
- Restored native TextButton and IconButton controls and corrected the custom outlined-button color type for the project's Material 3 API.
- Preserved the Aurora UI redesign and all existing DevMonitor business/authentication/report functionality.
- Version advanced to 4.3.4.12 (versionCode 70).


## 4.3.4.13 correction
- Fixed four Kotlin `return@Button` labels in `Authentication.kt` after the Aurora custom button migration. Changed them to `return@DevMonitorButton`.
- Preserved Firebase authentication configuration and all existing functionality.


## 4.3.4.14 — Aurora UI Polish
- Visual correction from device screenshots: disabled controls no longer carry heavy shadows, light surfaces are blue-white rather than lavender, and Payment Intelligence respects Scaffold insets.


## 4.3.4.15 — AURORA UI COMPOSITION REDESIGN
- Reworked the visible app composition rather than only recoloring existing Material surfaces.
- Dashboard now uses an aurora hero, compact live metrics, attention centre, batch-control panel and HQ report intelligence card hierarchy.
- Main bottom navigation now uses custom-drawn DevMonitor icons on a dark navigation rail with a restrained selected indicator instead of Unicode glyphs.
- Top app bar now uses the DevMonitor deep-navy identity consistently.
- Device Monitor, Agents, Settings and Payment Intelligence landing surfaces now use the same glass-panel visual language while preserving existing workflows and controls.
- Primary actions retain restrained elevation; disabled controls are not given oversized shadows.
- Preserved Firebase authentication, Firestore partner authorization, August historical seed, SQLite migrations, SIMReg parsing, SMS recovery/recheck, payment logic and existing navigation behavior.
- Version advanced to 4.3.4.15 (versionCode 73).


## 4.3.4.16 — Aurora Compose Import Fix
- Fixed missing Compose imports in ManagementScreens.kt for background() and RoundedCornerShape().
- No functional/authentication/database/parser changes.

## 4.3.4.19 — Aurora UI refinement
- Refined Aurora action buttons so primary actions render with white content and outlined actions use Aurora blue content.
- Reduced the vertical density of Device Monitor batch controls with grouped action rows.
- Preserved authentication, SMS, SIMReg, reporting and storage logic.


# CHANGE LOG UPDATE — DEVMonitor 4.3.5.37–4.3.5.51

## 4.3.5.37
- Fixed invalid named arguments passed to the function-typed `beginRun` callback in `MainActivity.kt`.
- Payment calculation/pathway logic was not intentionally changed.

## 4.3.5.38
- Reduced report-screen Compose gesture/recomposition overhead.
- Improved shared table scrolling.
- Optimized XLSX parsing and reduced unnecessary workbook/string and byte-array memory use.
- Added normalized-report query indexes.
- Targeted sluggish loading, scrolling and crash risk without changing payment calculations.

## 4.3.5.39
- Added/strengthened `my_devices.db` as the primary everyday working database.
- Rebuilds My Devices from company-normalized data and saved device selections.
- Added date-window handling and My Devices-first lookup behavior.
- Preserved company normalized data as historical authority.
- Protected payment calculation/resolver behavior.

## 4.3.5.40 — Isolated fork
- Added an experimental display-only payment-card fork.
- Intended to show Device Monitor and Loaded Report payment cards independently.
- No payment calculation/resolver/database pathway changes were intended.
- Fork remains isolated from mainline.

## 4.3.5.41
- Refined My Devices working date window.
- Retained import/parsed device order instead of applying alphabetical/numerical sorting.
- General Device Monitor totals use `CYCLE TOTAL` and `MONTH-TO-DATE` labels.

## 4.3.5.42
- Added persistent Month-to-Month Comparison with manual Refresh.
- Initial comparison uses current-month data through an effective available-data date and previous-month data through the corresponding day cutoff.

## 4.3.5.43
- Added centralized active-internet validation for network-dependent operations.
- Added the user-facing offline message: `Internet connection required. Please turn on Wi-Fi or mobile data and try again.`
- Local Device Monitor, SMS, local report import, normalized DB, My Devices and Month-to-Month operations remain usable without internet.
- Payment calculations were not intentionally changed.

## 4.3.5.44
- Documented/refined the My Month-on-Month workflow.
- Kept the feature independent from payment-cycle calculation.

## 4.3.5.45
- Refined the Month-on-Month card/workflow while retaining manual Refresh and stored results.

## 4.3.5.46
- Continued Month-on-Month/report-aware refinement.
- Preserved month-based semantics and payment-logic protection.

## 4.3.5.47
- Made Month-on-Month selection more data-aware so the calculation follows actual available current-month report data rather than assuming today's data exists.
- Corrected historical/report scope handling.

## 4.3.5.48
- Further refined report-aware Month-to-Month cutoff handling.
- Comparison uses the latest reliable available current-month data and an appropriate common historical cutoff.
- Device Monitor remains eligible as a source when its data is available and newer.

## 4.3.5.49
- Added Month-on-Month by Device expansion for supported Cluster Manager/Partner views.
- Preserved report-aware cutoff behavior.

## 4.3.5.50
- Added the formal deferred-fork documentation process.
- Documented the Historical Device Ownership for Month-on-Month Comparisons fork.
- Fork addresses mid-month staff/device transfers but is deferred and not part of mainline behavior.

## 4.3.5.51
- Corrected Month-to-Month report cutoff and historical scope.
- Current month uses the latest available current-month data date, not simply today's date.
- Previous month uses the same day-of-month cutoff.
- Current and previous device populations are independently determined from their respective month data; identical populations are not required.
- Device transfer/historical ownership remains a deferred experiment.
- Explicitly preserved the rule that Month-to-Month is month/report-data based, not cycle based and not activation-cycle based.
- Payment calculation/resolver/pathway code remains protected from this unrelated feature work.

## 4.3.5.53
### Month-on-Month cutoff integrity fix
- Found the deeper source of the remaining wrong comparison: XLSX daily columns beyond a report's declared cutoff could be normalized as if they were available data.
- A September 1–23 workbook can contain zero/placeholder columns for days 24–31; those columns must not move the normalized data frontier or comparison cutoff.
- Normalized import now filters daily values to the report's declared coverage window.
- Normalized report selection also respects each report's declared `coverage_end`.
- With no newer Device Monitor observation, a September 1–23 report now produces a September 23 cutoff and the previous side uses August 1–23.
- Verified against the supplied AIYETORO test data: September 1–23 = 1,204; August 1–23 = 1,058; change = +146 (+13.8%).
- No payment calculation/resolver/progression/pathway code was changed.

## 4.3.5.54
### Month-on-Month current-report selection correction
- Corrected the remaining cutoff selection bug exposed by the supplied AIYETORO test.
- The previous displayed value **1,155** is exactly the August 1–25 total; the requested September cutoff is September 23, so the previous side must be August 1–23 = **1,058**.
- Current-month report selection now anchors the cutoff to the newest imported current-month report whose declared coverage is available by the comparison date, before consulting normalized-row fallback.
- This prevents an older/restored normalized report with a later physical or placeholder date from moving the comparison cutoff forward.
- Normalized activation values remain the authoritative daily values; this change does not alter report import normalization or payment logic.
- Expected AIYETORO result with the supplied August and September reports: September 1–23 = **1,204**, August 1–23 = **1,058**, change **+146 (+13.8%)**.
- No payment calculation/resolver/progression/pathway code was changed.

## Documentation/working rules now carried forward
- Every DevMonitor ZIP should include the current `MASTER_WORK_SHEET.md` and `CHANGE_LOG.md`.
- Every DevMonitor ZIP should include `FORK_DOCUMENTATION.md` once the fork-documentation process has been established.
- Future changes must update the master sheet and change log in the same ZIP rather than leaving the documentation behind.

## 4.3.5.52
### Month-on-Month data-selection correction
- Fixed the remaining Month-on-Month cutoff problem: the calculation now prefers the latest actual normalized current-month data date instead of falling back to the phone date when report metadata selection is incomplete.
- Previous-month report selection now also prefers the report that actually contains the latest normalized data for the comparison window.
- Corrected normal STAFF attribution to use `staff_name` in each month's report; territory is not treated as ownership.
- Kept current and previous device populations independent, as required by the month-on-month specification.
- Fixed drill-down calls so a single device or hierarchy group does not expand back to the full report population.
- Added a visible **Refresh Comparison** button on the same Month-on-Month performance card/page.
- Strictly month-based/report-data-based; no cycle or payment-progression logic introduced.
- Payment calculation/resolver/pathway code was not changed.

## Version 4.3.5.60 — UI warning + partner name enquiry refinement
- Reworked the user-scoped notice from a bottom Snackbar into a compact top banner below the app bar. The banner participates in normal layout, so it does not block/consume taps on controls underneath it.
- Added a Dismiss action and a short auto-hide period while retaining the existing one-time notice setting.
- In the partner enquiry source menu, lookup now accepts either Trade Code or Channel Partner Name.
- Channel Partner Name resolution is read-only and resolves to the unique Trade Code before Device Monitor/30-30 requests. Ambiguous names require the Trade Code.
- Loaded Report partner enquiries support the same Trade Code/Channel Partner Name input.
- Existing payment calculation, resolver, progression, Month-to-Month calculation and four-database architecture were not changed.

## 4.3.5.60 — Phone Release Build Helper Reconstruction
- Recreated `build-phone.sh` for the established Android Code Studio / ARM64 phone build path.
- Preserved automatic ARM-compatible AAPT2 discovery and `android.aapt2FromMavenOverride`.
- Added the established release keystore path and alias: `fieldpulse-release.jks` / `fieldpulse-release`.
- Release keystore and key passwords are entered interactively and are not stored in project files.
- Drive report folder ID is supplied by the helper; the Drive API key remains local/private and may be supplied by environment or interactive prompt.
- No application, payment, Month-to-Month, database, or resolver logic changed.

## 4.4 — Public Release Metadata
- Set Android `versionName` to `4.4`.
- Set Android `versionCode` to `131`.
- This is a release-metadata-only change from the tested 4.3.5.60 release candidate.
- No payment calculation, resolver, progression, Month-to-Month, database, or report-processing logic changed.

## DevMonitor 4.5.0 — Sound & Haptics UX layer
- Added four short bundled local sound cues for meaningful operational events.
- Added optional haptic confirmation alongside important feedback events.
- Added **Sound & Haptics** controls to Monitor Settings so users can independently disable event sounds or haptics.
- Monitoring start, task completion, retry completion, export result and explicit dashboard/payment refresh completion now provide restrained feedback.
- Ordinary navigation remains silent; no continuous/background audio was introduced.
- Added the Android `VIBRATE` permission for optional haptic feedback.
- No payment calculation, profile isolation, report authority, SMS protocol or user-initiated performance behavior was changed.


## 2026-09-28 — DevMonitor 4.5.3
### NL-P1-07 Visual Trends
- Added profile-scoped 7-day and 30-day visual trend charts.
- Added sales, Active, Bar 48/Conversion Lost and Company/Partner sales-mix views.
- Added explicit Refresh control and 7/30-day range controls.
- Trend calculations are user initiated; opening the trends screen does not run heavy aggregation.
- Missing observation days remain missing rather than being treated as zero.
- Added dashboard and drawer entry points.
- Added a date-range observation query to the existing SQLite analytics layer.
- Updated roadmap/tracker/master documentation and removed the duplicate NL-P1-13 Visual Trends tracker entry.
- Payment, SMS, report, Month-to-Month and background-processing behavior remains unchanged.


## 4.5.6 — NL-P1-10 Motion / Accessibility Polish
- Added reduced-motion handling and accessibility semantics to reusable UI components.
- Payment calculator and payment-cycle logic remained untouched.


## 4.5.8 — NL-P2-02 Notes

- Added a lightweight persistent **Notes** workspace for device, partner and staff operational context.
- Notes support optional title, note body, optional link, pin-to-top, search, edit and delete.
- Notes are profile-local and stored in the existing SQLite architecture; database version increased from 12 to 13.
- Added a drawer entry and modal notes workspace without automatic heavy processing.
- No background reminders, monitoring, aggregation or payment recalculation was introduced.
- **Payment calculator, PaymentRules, PaymentCycleResolver and payment progression logic remain unchanged.**


## 4.5.7 — NL-P2-01 Tasks & Follow-ups

- Added a lightweight persistent Tasks & Follow-ups workspace.
- Tasks can be linked to a device, partner, or staff member.
- Added optional due date and Low/Normal/High priority.
- Added manual open/done, edit, delete, and completed-task filtering.
- Tasks are stored in the active profile database.
- No automatic task generation or heavy background processing was introduced.
- Payment calculation and payment-cycle logic remain unchanged.


## DevMonitor 4.5.9 — NL-P2-03 Device Activity Timeline + Sign-In diagnostics
- Added a unified, user-initiated Device Activity Timeline showing SIMReg observations, query results, linked tasks, and linked notes for the selected device.
- Added Device Activity Timeline to the app drawer.
- Improved the Action Center quick-action layout so “Check My Devices” is fully readable on narrow screens instead of being compressed into the small four-card row.
- Hardened Google Sign-In failure diagnostics by recording the exact Google API status code and the installed build signing certificate SHA-1/SHA-256.
- Added the installed SHA-1 to the account area when Google is not connected, making Firebase/Google OAuth certificate mismatches directly diagnosable on the actual APK.
- No payment calculation, payment-cycle, PaymentRules, or PaymentCycleResolver logic changed.


## DevMonitor 4.5.10 — NL-P2-04 + NL-P2-05 Reporting & Sharing Pack
- Added user-triggered Daily Snapshot sharing as PNG image or PDF.
- Added Intelligent Export choices: Quick, Detailed, Payment, Exceptions, HQ and Full.
- Existing Excel export engine retained; selection filters the existing report data only.
- Added Android FileProvider for secure report sharing.
- PaymentRules.kt and PaymentCycleResolver.kt remain unchanged.

## 2026-09-29 — DevMonitor 4.6.0-NEXT fork
### NEXT LEVEL Phase 3/4 incremental implementation
- Forked from the locked 4.5.17 performance baseline; baseline files and behaviour are preserved as the starting point.
- Added `NextLevelEngine` with explicit-refresh advanced 7/30-day trends, deterministic anomaly signals, and local-vs-HQ reconciliation against the latest Loaded Report.
- Added explicit offline/data-freshness health, SQLite integrity inspection, storage headroom reporting, SMS observation counts and user-triggered SQLite optimization.
- Added a Next Level Centre surface containing Trends, Anomalies, HQ Reconciliation and Health/Sync Centre workflows.
- Added explain-this context so local observations, Loaded Report/HQ evidence and differences are visible rather than silently corrected.
- Added explicit Google Drive Backup/Restore entry points to the Sync Centre; no automatic cloud sync or background heavy work was introduced.
- Added the first incremental modular-architecture boundary through `FeatureModuleRegistry`; existing MainActivity flows remain compatible while new feature surfaces can be migrated independently.
- Advanced processing remains foreground/user initiated and limited to one substantial operation at a time.
- Version fork: `4.6.0-NEXT`, versionCode `150`.
- Android build verification could not be executed in this environment because the Gradle 8.7 distribution was not cached and outbound access to services.gradle.org was unavailable. Phone/Cloud build remains the required final compile gate.


## 2026-09-29 — DevMonitor 4.6.0-NEXT full milestone integration correction
- Clarified that 4.6.0-NEXT is the complete integrated NEXT LEVEL fork, not merely a cloud-build experiment.
- Bundles NL-P3-01 through NL-P4-05 in the same experimental build.
- Moved substantial Next Level trend, anomaly, reconciliation and diagnostics work off the Compose UI thread while retaining explicit user initiation and one-operation-at-a-time behaviour.
- Fixed the Next Level Health/optimization screen integration so the database reference is passed explicitly and empty-state Refresh actions actually invoke the selected calculation.
- Cloud build remains `assembleDebug` through GitHub Actions; no release signing credentials are required for this fork.
- Protected 4.5.17 payment, Month-on-Month, SMS, Loaded Reports authority and database pathways remain unchanged.


## 2026-10-01 — DevMonitor 4.6.0-NEXT v165 Recovery / Build-Environment Alignment
- Kept v162.1 as the recovery code base while retaining the approved post-v162.1 floating waiting-window UI.
- Superseded the old same-coverage duplicate rule: a valid report with the same coverage date now replaces the stored complete monthly snapshot.
- Kept current and previous calendar-month HQ storage independently addressable and import-order independent.
- Added an explicit `BUILD_FOR_PC.md` for the desktop/PC-oriented development branch.
- PC builds use the normal desktop Android SDK/AAPT2 toolchain; the ARM-compatible AAPT2 override remains phone-only.
- Aligned PC, cloud and phone build documentation with the v165 recovery architecture.
- No PaymentEngine/payment formula, Device Monitor/SMS, Profile Builder or release-identity changes were introduced by this documentation/build-path update.


## v171 — Historical safeguards + Loaded Report workflow (2026-10-01)
- Prevent empty/no-device workbooks from replacing an existing HQ monthly snapshot.
- Loaded Report import is calculation-isolated but not UI-isolated: display the exact imported report immediately without auto-refreshing derived systems.
- Open Loaded Report directly from the newest stored report; do not apply the current-month display cutoff to this explicit viewer action.
- Make the supplied report take precedence over the My Devices table and keep the single floating loader visible until report-table positioning completes.
- Preserved the two-month snapshot architecture, same-coverage replacement, older-report rejection, out-of-order month import, and protected payment engine.
- Set Android versionCode to 171.


## 4.6.0-NEXT v176 — Company Structure Cascade Clarification

- Profile Builder now follows the supplied company's actual identity hierarchy: **Cluster (Division) → Region → Territory → Staff**.
- Cluster remains the app's existing internal `division` field so payment/HQ/business logic is not rewritten.
- Profile identity selectors now come from the lightweight Company Skeleton even before activation data is loaded.
- Territory is selected before Staff, so the selected three-level organisational scope narrows the staff list correctly.
- Source-only case/typographic variations such as `AFIKPO`/`Afikpo`, `KAMBA`/`Kamba`, `MOWO`/`MoWO`, and straight/curly apostrophe forms are collapsed to one selector option without altering stored source records.
- Existing Company Skeleton search, LOAD COMPANY DATA, My Devices-first population and activation/payment pathways remain unchanged.
- No activation values, payment formulas, HQ snapshot rules or MOM database architecture were changed.

## 4.6.0-NEXT v175 — Company Skeleton & Profile-First Onboarding

- Added embedded lightweight Company Skeleton from the supplied company workbook.
- Added skeleton search and profile pre-fill in Profile Builder.
- Added LOAD COMPANY DATA to rebuild skeleton without importing activation values.
- Added prominent BUILD PROFILE dashboard entry and first-run spotlight with Skip.
- Reworked introduction flow so profile construction is the explicit first setup path.
- Added My Devices/staff/region/division presentation priority for validated HQ report tables.
- Added parser support for a DIVISION field when present in future detailed workbooks.
- Preserved atomic HQ snapshots and all protected payment/Device Monitor/MOM pathways.


## 4.6.0-NEXT v179 — SMS CHECKER tour compile correction (2026-10-02)
- Fixed the GitHub Kotlin compilation error at `MainActivity.kt:4598`.
- Corrected the dashboard `LazyColumn` call to use the named `modifier =` parameter after the named `state` parameter.
- No SMS CHECKER tour behaviour or other application business logic was changed.
- Advanced Android `versionCode` from 178 to 179 for an unambiguous cloud-build package.
- Cloud build remains the final verification gate.

## 2026-10-02 — DevMonitor 4.6.0-NEXT v180 — Profile + SMS CHECKER cleanup
- Removed the SMS CHECKER guided tour completely, including its automatic dashboard entry, Device Monitor/drawer launch path, Settings restart action and SMS-specific guided-tour state.
- Corrected Dashboard Guided Tour scrolling so LOAD REPORT and EARNING PROGRESS highlight their actual action cards rather than unrelated lower dashboard cards.
- Restricted the prominent BUILD PROFILE dashboard card to the no-profile state; it disappears after a profile is successfully built.
- Added Manage Current Profile access when profiles exist so Delete Profile remains discoverable after multiple profiles are created.
- Added a Profile Builder verification warning asking users to confirm identity, role, organisational scope and selected device before saving.
- Agent profiles now save exactly one selected device. Search results are selectable choices; selecting one device is sufficient to continue as Agent.
- Replaced user-facing "Company Skeleton" wording with professional Company Directory/company-data wording while retaining the internal CompanySkeletonStore architecture.
- Preserved the full company identity dataset for search; this UI terminology change does not alter the underlying company-directory data model.
- Preserved the My Devices-first table-loading requirement: fresh Report/Device Monitor entry renders My Devices, while broader hierarchy data is loaded only by explicit user action and remains indexed for search.
- VersionCode advanced from 179 to 180; versionName remains 4.6.0-NEXT.


## v189 — Loaded Report 100% Rendering Freeze Fix
- Normal Loaded Report table no longer falls back to the complete imported HQ report.
- Initial table is strictly the bounded My Devices working set.
- Full HQ database remains intact and is available through explicit Show All / targeted search paths.
- Prevents Compose filtering/sorting of the entire HQ snapshot before the visible 100-row limit is applied.
- PaymentEngine and payment-cycle logic unchanged.


## v190 — Loaded Report contract restoration / My Devices presentation priority
- Restored the proven complete-report Loaded Report path: the authoritative HQ report is loaded normally instead of being replaced by a bounded 100-row working view.
- My Devices is presentation priority only: My Devices rows appear first in the complete report, while the rest of the HQ report remains available by normal scrolling and search.
- Removed the newly introduced 100-row UI limit/load-next behavior. The existing LazyColumn virtualization remains responsible for rendering stability.
- Restored Open Loaded Report to load the stored complete report; dashboard one-device enquiries continue to use the targeted single-device lookup.
- Kept the full HQ database intact and searchable.
- PaymentEngine/payment-cycle logic unchanged.


## v190 — Async Loaded Report table preparation
- Moved the expensive Loaded Report filtering/priority sorting off the Compose main/UI thread onto Dispatchers.Default.
- The loader no longer declares 100% merely because the database import finished; it reaches ready only after the visible table dataset has been prepared.
- Kept the complete HQ report in memory, with My Devices first as presentation priority and all other devices still available through normal table scrolling/search.
- Added defensive table positioning so an unavailable scroll target cannot strand the loading state.
- PaymentEngine/payment-cycle logic unchanged.


## v197 — Settings Profile Boundary + Online Reports Fix
- Removed the Manage My Profile shortcut from the Check My Devices action menu so profile management stays within Settings.
- Kept the existing Settings → My Devices → Manage My Profile entry as the dedicated profile-management path.
- Corrected the Google Drive report folder ID mismatch between the cloud release configuration, gradle.properties and phone build helper.
- Broadened the online report folder listing to recognize supported Excel/CSV workbook filenames instead of depending on one exact Drive MIME type.
- Preserved online-report loading/download architecture and existing Loaded Report behavior.
- PaymentEngine and payment-cycle logic unchanged.
- VersionCode advanced from 196 to 197.
## v198 — Profile Management Location Fix
- Removed the persistent “Manage My Profile” button from the dashboard/profile header area.
- Profile management remains available from Settings → My Devices only.
- Preserved the v197 online-report configuration and importer fixes.
- PaymentEngine and payment-cycle logic unchanged.

## v224 build hotfix
- Fixed root `build.gradle.kts`: moved Firebase Crashlytics plugin declaration inside `plugins {}` so Gradle Kotlin DSL can compile the build script.
- Advanced Android versionCode to 224. No payment/report business logic changed.


## 4.6.0-NEXT v225 — Phone/PC auto-sync retry policy
- Added bounded auto-sync retries on the Phone ↔ PC Sync Bridge screen.
- One initial attempt plus up to five retries per cycle use 2/5/10/20/30-second backoff delays; exhausted cycles enter standby for five minutes before the next check.
- Successful syncs repeat every 30 seconds while the screen remains active.
- UI text clearly discloses that Android background suspension can pause this screen-scoped loop; this release does not claim an always-on background connection.
- Preserved the operational-only sync boundary: HQ snapshots and payment data are not transferred; payment logic is untouched.

## v4.6.0-NEXT v227 — PC-initiated earnings-card handoff
- Added support for receiving PC-prepared PNG cards in the encrypted PC↔Android sync response and opening Android's native share sheet after sync.
- Android acknowledges handled card IDs on the next exchange so Windows can remove completed queue entries.
- Card images are supplied by Windows; Android does not recalculate or reconcile figures. Existing Android-local sharing remains available.
- Payment calculation code and HQ/payment data sync scope unchanged.


## Version 4.6.0-NEXT v231 — Connection icon and Android system notifications (2026-10-13)
- Removed the persistent full-width PC-link banner from the main content area. Connection state is now represented by a compact coloured status icon beside the notification bell; tapping it opens Next Level for connection details (the Health area remains the location for sync controls).
- Connection icon uses green for a recent verified link, amber for reconnecting/awaiting/retry-scheduled states, and red for unconfigured/offline/no-recent-sync states.
- Local in-app notification creation now also posts an Android system notification with a notification channel, tap-to-open behaviour, and expanded message text. Android 13+ notification permission is requested when an event first attempts to post and permission is missing. A denied permission means system notifications remain unavailable until enabled in Android settings.
- Existing in-app notification inbox remains intact. No payment formulas or calculations changed.
- Build/device verification still required; notification delivery while the app is fully closed and OEM battery restrictions require device testing.


## 4.6.0-NEXT v235 — My Partner visibility fix
- Added a dedicated My Partner card to the main dashboard for staff, so the feature is visible without needing to discover it in the navigation drawer.
- Made staff detection fall back to the persisted user type when the active profile type is blank or temporarily unavailable.
- Kept partner records separate from My Devices and did not change payment calculations.

## v249 — My Partners duplicate Flags control removal (2026-10-14)
- Removed the duplicate Flags chip from the My Partners menu; the global app-bar Flags Centre remains the entry point.
- Preserved the Flags chip in the original Device Monitor/SMS Checker view.

## v251 — My Partners search data-source fix (2026-10-15)
- Fixed the My Partners loaded-report search to query the full retained HQ partner directory, rather than the active My Devices-filtered report. This resolves cases where the search field accepted text but produced no partner matches.
- Partner metadata on result cards is now resolved from that same directory.
- Original SMS Checker and payment calculations unchanged. Build/device verification pending.


## v252 — My Partners live loaded-report search (2026-10-15)
- Reworked My Partners search to query the persisted current/previous-month HQ report tables directly on each search change, instead of filtering an in-memory directory snapshot captured only when the menu opened.
- Search matches partner name or Trade Code and collapses repeated device rows into partner-level results. Selecting a result refreshes the displayed partner metadata from that current result.
- Added database indexes for partner name and Trade Code, including an upgrade path for existing installed databases.
- Original SMS Checker, payment calculations, and payment thresholds unchanged. Build/device validation pending.

## v254 — Earnings Card Tier Progression and SMS Checker Flags Cleanup (2026-10-15)
- Updated exported payment-card artwork with a clear activation-tier progression track based on the existing 30/50/70/100/150/200/250/300 activation thresholds.
- The card highlights reached tiers, the next tier, and remaining activations while retaining the existing estimate values and calculation engine unchanged.
- Removed the redundant Flags chip from the SMS Checker / My Partners header; the global Flags Centre remains available from the app-bar flag icon and existing result severity indicators remain intact.
- Partner result cards remain result summaries because that data source does not necessarily contain payment activation evidence; no payment amount is inferred from partner lookup metrics.


## v255 — Earnings-card composition and My Partners selection isolation (2026-10-15)
- Redesigned the Android shareable earnings PNG with a compact DevMonitor flyer header, prominent agent identity and earnings hero, clear activation milestones, green encouragement panel, and branded footer.
- Corrected activation progress fill to use the full 0–300 activation scale; it no longer fills a misleading fraction of the bar based only on the next threshold.
- Fixed My Partners report-search selection so selecting/adding a partner does not write that partner code into the separate SMS Checker “Find partner’s code” filter. Existing filter text is preserved.
- Preserved the existing estimate engine and source isolation; card layout changes do not recalculate monetary values.

## v256 — Photographic earnings flyer
- Added a generated photographic hero asset and a promotional top section to shareable payment cards.
- Preserved source-specific figures and existing payment calculations; activation progression remains presentation-only.
- Kept My Partners partner selection separate from the SMS Checker list-filter state.
- Build not verified in this environment.


## v257 — Share image resolution and estimate parity
- Prepared the embedded photo asset at 3× dimensions for cleaner exported-card resampling.
- Fixed the exported card background height so the complete translated footer stays inside the rounded card.
- Preserved the source-specific existing estimate passed into Android share cards; no payment logic changed.
- Build verification pending.


## v258 — Payment-card estimate binding and full-card high-resolution export
- Fixed SMS Checker sharing to use the exact Device Monitor payment-cycle estimate shown in the app (the merged cycle resolution), rather than the SMS-only intermediate estimate.
- Loaded Report sharing continues to use the existing Loaded Report estimate object.
- Share-card drawing remains presentation-only; no payment formula was added to the Android renderer.
- Exported the entire Android card at 2x pixel density so typography, icons, progress track, labels, and footer are sharper as well as the photographic hero.
- Validation pending: Android build requires ARM-compatible AAPT2 in the build environment.

## v262 — Payment share-card responsiveness
- Render payment share-card bitmap and PNG in a background thread to prevent UI freezes / Android Application Not Responding warnings when tapping Share.
- Launch Android share chooser on the main thread after the image is ready; report failures gracefully.
- No payment calculations, selected-source rules, or card figures changed.


## v280 — Restore partner activation performance (2026-10-19)

- Restored `Fork3ActivationPerformance.kt`, its calculation state and background calculation, and the partner result-card activation-performance section from the v278 source.
- Restored activation-performance values in the partner result share card and its full layout in `ReportExportPack.kt`.
- Removed only the visible `FORK 3` wording from the partner result-card section title and share-card title. The section now reads `ACTIVATION PERFORMANCE`.
- Preserved the v279 welcome-tour persistence safeguard and the removal of the notification test-alert button.
- No payment formulas or MOM/HQ storage logic intentionally changed.
- Android version code: 280.
- Build and device verification remain pending.
