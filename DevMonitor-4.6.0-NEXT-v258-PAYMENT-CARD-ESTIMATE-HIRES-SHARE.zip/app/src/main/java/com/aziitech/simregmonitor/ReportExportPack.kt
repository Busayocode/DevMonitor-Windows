package com.aziitech.simregmonitor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight, user-triggered reporting helpers. Does not calculate or alter payment rules. */
data class PaymentCardSharePayload(
    val agentName: String, val deviceCode: String, val source: String, val period: String,
    val asOf: String, val estimate: IncentiveEstimate, val activationDetail: String = ""
)

object ReportExportPack {
    /** Shares the existing displayed estimate as a PNG; this is presentation only. */
    fun sharePaymentCard(context: Context, payload: PaymentCardSharePayload): Boolean =
        sharePaymentCards(context, listOf(payload))

    /** Creates one exact-source image per device and hands all images to the Android share sheet. */
    fun sharePaymentCards(context: Context, payloads: List<PaymentCardSharePayload>): Boolean {
        if (payloads.isEmpty()) return false
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val files = payloads.mapIndexed { index, payload -> createPaymentCardImage(context, payload, "${stamp}_$index") }
            val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it) })
            val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris.first()) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, if (payloads.size == 1) "${payloads.first().agentName} — DevMonitor earnings progression (${payloads.first().source})" else "DevMonitor earnings progression cards — ${payloads.size} device card(s). Please review each card's source and period.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, if (payloads.size == 1) "Share Earnings Card" else "Batch Share Earnings Cards"))
            true
        }.getOrDefault(false)
    }

    /** Opens PC-prepared PNG cards after a user-initiated sync. The PC supplies the exact figures; Android only presents them. */
    fun sharePreparedPngs(context: Context, cards: List<org.json.JSONObject>): List<String> {
        if (cards.isEmpty()) return emptyList()
        return runCatching {
            val files = cards.take(20).mapIndexedNotNull { index, item ->
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
                val encoded = item.optString("pngBase64")
                if (encoded.isBlank()) return@mapIndexedNotNull null
                val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                if (bytes.size > 2_000_000 || !bytes.take(8).toByteArray().contentEquals(byteArrayOf(0x89.toByte(),0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a))) return@mapIndexedNotNull null
                val file = File(context.cacheDir, "DevMonitor_PC_Share_${id.replace(Regex("[^A-Za-z0-9_-]"), "_")}.png")
                FileOutputStream(file).use { it.write(bytes) }
                id to file
            }
            if (files.isEmpty()) return@runCatching emptyList()
            val uris = ArrayList<Uri>(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it.second) })
            val caption = cards.firstOrNull()?.optString("caption")?.takeIf { it.isNotBlank() } ?: "DevMonitor earnings cards prepared on Windows"
            val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/png"
                if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris.first()) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, if (uris.size == 1) "Share PC Earnings Card" else "Share PC Earnings Cards").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            files.map { it.first }
        }.getOrDefault(emptyList())
    }

    /** Creates and shares a personalized partner-code result image. Display-only; does not alter checker or payment data. */
    fun sharePartnerResultCard(
        context: Context,
        partnerName: String,
        tradeCode: String,
        cluster: String,
        region: String,
        territory: String,
        metrics: String
    ): Boolean = runCatching {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = createPartnerResultImage(context, partnerName, tradeCode, cluster, region, territory, metrics, stamp)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "DevMonitor My Partners result — ${partnerName.ifBlank { tradeCode }} ($tradeCode)")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Partner Result"))
        true
    }.getOrDefault(false)

    private fun createPartnerResultImage(
        context: Context, partnerName: String, tradeCode: String, cluster: String,
        region: String, territory: String, metrics: String, stamp: String
    ): File {
        val width = 1080; val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = android.graphics.LinearGradient(0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFF071B36.toInt(), 0xFF075B60.toInt(), 0xFF0D9E78.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        canvas.drawCircle(1010f, 65f, 240f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x3328D7C2 })
        canvas.drawRoundRect(36f, 36f, 1044f, 1314f, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF8FBFF.toInt() })
        canvas.drawRoundRect(36f, 36f, 1044f, 310f, 48f, 48f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0B2946.toInt() })
        canvas.drawRect(36f, 250f, 1044f, 310f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0B2946.toInt() })
        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = -1; typeface = Typeface.DEFAULT_BOLD }
        canvas.drawRoundRect(76f, 76f, 218f, 218f, 30f, 30f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0D9E89.toInt() })
        canvas.drawText("DM", 98f, 165f, Paint(white).apply { textSize = 54f })
        canvas.drawText("DevMonitor", 252f, 120f, Paint(white).apply { textSize = 52f })
        canvas.drawText("MY PARTNERS • CODE RESULT", 254f, 178f, Paint(white).apply { textSize = 25f; color = 0xFF7EF3D0.toInt() })
        canvas.drawText("PARTNER PROFILE", 76f, 275f, Paint(white).apply { textSize = 22f; color = 0xFFDDECF7.toInt() })
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF102944.toInt(); textSize = 42f; typeface = Typeface.DEFAULT_BOLD }
        val safeName = partnerName.ifBlank { "Partner details unavailable" }.take(42)
        canvas.drawText(safeName, 76f, 390f, title)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF21344B.toInt(); textSize = 30f }
        val label = Paint(body).apply { color = 0xFF607286.toInt(); textSize = 23f }
        canvas.drawRoundRect(72f, 430f, 1008f, 520f, 22f, 22f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFEAF5F2.toInt() })
        canvas.drawText("TRADE CODE", 98f, 466f, Paint(label).apply { color = 0xFF087F5B.toInt(); typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText(tradeCode.take(35), 98f, 503f, Paint(body).apply { typeface = Typeface.DEFAULT_BOLD })
        var y = 575f
        listOf("Cluster" to cluster, "Region" to region, "Territory" to territory).filter { it.second.isNotBlank() }.forEach { (k, v) ->
            canvas.drawText(k.uppercase(Locale.US), 82f, y, Paint(label).apply { typeface = Typeface.DEFAULT_BOLD })
            canvas.drawText(v.take(48), 300f, y, body)
            y += 58f
        }
        val metricTop = maxOf(760f, y + 28f)
        canvas.drawRoundRect(72f, metricTop, 1008f, metricTop + 300f, 30f, 30f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0D9B78.toInt() })
        canvas.drawText("LATEST CHECK RESULT", 106f, metricTop + 58f, Paint(white).apply { textSize = 27f; color = 0xFFD8FFF1.toInt() })
        var my = metricTop + 112f
        metrics.split("\n").take(4).forEach { line ->
            canvas.drawText(line.take(58), 106f, my, Paint(white).apply { textSize = 29f })
            my += 48f
        }
        canvas.drawText("Generated ${SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())}", 78f, 1248f, Paint(label).apply { textSize = 21f })
        val file = File(context.cacheDir, "DevMonitor_Partner_Result_$stamp.png")
        FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
        bitmap.recycle()
        return file
    }

    private fun createPaymentCardImage(context: Context, d: PaymentCardSharePayload, stamp: String): File {
        // Flyer-like share card inspired by the approved reference. All monetary figures remain
        // the already-computed estimate supplied by the selected source; this function is display-only.
        val width = 1080; val height = 1810
        // Render the complete flyer at 2x pixel density. Text, icons, borders, gradients and the
        // photo are all drawn through the same scaled canvas, avoiding a sharp hero over a soft UI.
        val outputScale = 2
        val bitmap = Bitmap.createBitmap(width * outputScale, height * outputScale, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(outputScale.toFloat(), outputScale.toFloat())
        val anti = Paint(Paint.ANTI_ALIAS_FLAG)
        val background = Paint(anti).apply {
            shader = android.graphics.LinearGradient(0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFFEAF4FC.toInt(), 0xFFF9FCFF.toInt(), 0xFFE4F7EE.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), background)
        canvas.drawCircle(1030f, 70f, 230f, Paint(anti).apply { color = 0x2229C6B2 })
        canvas.drawRoundRect(28f, 28f, 1052f, (height - 28).toFloat(), 46f, 46f, Paint(anti).apply { color = 0xFFF9FCFF.toInt() })

        // Photographic hero section: high-density embedded celebration photo sits to the right.
        // The drawable is stored at 3x pixel dimensions for clean downsampling on exported PNGs.
        val hero = runCatching { android.graphics.BitmapFactory.decodeResource(context.resources, R.drawable.earnings_hero_photo) }.getOrNull()
        if (hero != null) {
            val dst = android.graphics.RectF(420f, 28f, 1052f, 610f)
            canvas.drawBitmap(hero, null, dst, Paint(anti).apply { isFilterBitmap = true })
            hero.recycle()
        }
        canvas.drawRect(28f, 28f, 500f, 610f, Paint(anti).apply {
            shader = android.graphics.LinearGradient(28f, 0f, 540f, 0f,
                intArrayOf(0xFFF9FCFF.toInt(), 0xFFF9FCFF.toInt(), 0x00F9FCFF), floatArrayOf(0f, .62f, 1f), android.graphics.Shader.TileMode.CLAMP)
        })
        val white = Paint(anti).apply { color = 0xFFFFFFFF.toInt(); typeface = Typeface.DEFAULT_BOLD }
        canvas.drawRoundRect(62f, 62f, 202f, 202f, 32f, 32f, Paint(anti).apply { color = 0xFF0D9E89.toInt() })
        canvas.drawText("DM", 82f, 148f, Paint(white).apply { textSize = 50f })
        canvas.drawText("DevMonitor", 230f, 106f, Paint(anti).apply { color = 0xFF0B2946.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Monitor  •  Track  •  Earn", 232f, 158f, Paint(anti).apply { color = 0xFF24518A.toInt(); textSize = 22f })
        canvas.drawText("EARNINGS PROGRESSION", 64f, 250f, Paint(anti).apply { color = 0xFF5C7FB5.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Your hard work", 64f, 316f, Paint(anti).apply { color = 0xFF0B1638.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("is paying off!", 64f, 370f, Paint(anti).apply { color = 0xFF0B1638.toInt(); textSize = 48f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Another step closer", 64f, 420f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 26f })
        canvas.drawText("to your next milestone.", 64f, 456f, Paint(anti).apply { color = 0xFF365981.toInt(); textSize = 26f })
        canvas.drawRoundRect(680f, 440f, 1010f, 530f, 24f, 24f, Paint(anti).apply { color = 0xFFF0FFF7.toInt() })
        canvas.drawCircle(720f, 485f, 25f, Paint(anti).apply { color = 0xFF19A85B.toInt() })
        canvas.drawText("✓", 705f, 495f, Paint(white).apply { textSize = 30f })
        canvas.drawText("Payment Received!", 756f, 475f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })
        val heroAmount = "₦${String.format(Locale.US, "%,d", d.estimate.estimatedSubtotal)}"
        canvas.drawText(heroAmount, 756f, 510f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 28f; typeface = Typeface.DEFAULT_BOLD })

        // Move the variable-data panel below the photographic hero. This is still only a layout
        // translation: figures and the established payment engine are untouched.
        canvas.save()
        canvas.translate(0f, 235f)
        val navy = 0xFF102944.toInt()
        val label = Paint(anti).apply { color = 0xFF607286.toInt(); textSize = 22f }
        val bold = Paint(anti).apply { color = navy; typeface = Typeface.DEFAULT_BOLD }
        // Agent identity row with avatar and a clear linked-agent treatment.
        canvas.drawCircle(112f, 336f, 52f, Paint(anti).apply { color = 0xFF367FE2.toInt() })
        canvas.drawCircle(112f, 320f, 17f, Paint(anti).apply { color = 0xFFFFFFFF.toInt() })
        canvas.drawOval(82f, 342f, 142f, 374f, Paint(anti).apply { color = 0xFFFFFFFF.toInt() })
        canvas.drawText("AGENT", 190f, 314f, Paint(label).apply { textSize = 21f; color = 0xFF7890B0.toInt() })
        val namePaint = Paint(bold).apply { textSize = 36f }
        var name = d.agentName.ifBlank { "Unlinked agent" }
        while (namePaint.measureText(name) > 570f && name.length > 8) name = name.dropLast(2) + "…"
        canvas.drawText(name, 190f, 360f, namePaint)
        canvas.drawText("DEVICE  ${d.deviceCode.take(32)}", 192f, 397f, Paint(label).apply { textSize = 19f })
        canvas.drawRoundRect(754f, 315f, 1006f, 374f, 30f, 30f, Paint(anti).apply { color = 0xFFE4F7EC.toInt() })
        canvas.drawText("✓  ${if (d.agentName.isBlank()) "Device card" else "Linked Agent"}", 775f, 351f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })

        canvas.drawRoundRect(64f, 420f, 1016f, 476f, 22f, 22f, Paint(anti).apply { color = 0xFFEAF5F2.toInt() })
        val sourceLine = "${d.period.take(28)}  •  SOURCE: ${d.source.take(22)}"
        canvas.drawText(sourceLine, 86f, 455f, Paint(anti).apply { color = 0xFF087F5B.toInt(); textSize = 21f; typeface = Typeface.DEFAULT_BOLD })

        // Prominent earnings hero: no amount is recalculated here.
        canvas.drawRoundRect(64f, 496f, 1016f, 690f, 30f, 30f, Paint(anti).apply { color = 0xFF0D9B78.toInt() })
        canvas.drawText("ESTIMATED EARNINGS", 98f, 542f, Paint(anti).apply { color = 0xFFD8FFF1.toInt(); textSize = 23f; typeface = Typeface.DEFAULT_BOLD })
        val total = "₦${String.format(Locale.US, "%,d", d.estimate.estimatedSubtotal)}"
        var totalSize = 78f
        val totalPaint = Paint(anti).apply { color = -1; typeface = Typeface.DEFAULT_BOLD; textSize = totalSize }
        while (totalPaint.measureText(total) > 850f && totalSize > 48f) { totalSize -= 2f; totalPaint.textSize = totalSize }
        canvas.drawText(total, 98f, 628f, totalPaint)
        canvas.drawText("Monitoring estimate • official company payment remains final", 100f, 662f, Paint(anti).apply { color = 0xFFE0FFF5.toInt(); textSize = 18f })

        // Tier milestones: progress fill is proportional to the full 0–300 scale, not to the next tier.
        val tiers = listOf(30, 50, 70, 100, 150, 200, 250, 300)
        val reached = d.estimate.activations.coerceAtLeast(0)
        val nextTier = tiers.firstOrNull { reached < it }
        canvas.drawRoundRect(64f, 710f, 1016f, 948f, 28f, 28f, Paint(anti).apply { color = 0xFFF0F7F4.toInt() })
        canvas.drawText("ACTIVATION TIER PROGRESSION", 90f, 750f, Paint(bold).apply { textSize = 24f })
        canvas.drawText("${reached} activations achieved", 90f, 780f, Paint(label).apply { textSize = 18f })
        val left = 110f; val right = 970f; val trackY = 826f
        canvas.drawRoundRect(left, trackY - 6f, right, trackY + 6f, 6f, 6f, Paint(anti).apply { color = 0xFFD4DEEA.toInt() })
        val fraction = (reached.toFloat() / tiers.last().toFloat()).coerceIn(0f, 1f)
        if (fraction > 0f) canvas.drawRoundRect(left, trackY - 6f, left + (right - left) * fraction, trackY + 6f, 6f, 6f, Paint(anti).apply { color = 0xFF19A85B.toInt() })
        tiers.forEachIndexed { index, threshold ->
            val x = left + (right - left) * index / (tiers.size - 1)
            val done = reached >= threshold
            val isNext = threshold == nextTier
            val c = if (done) 0xFF19A85B.toInt() else if (isNext) 0xFF2674E8.toInt() else 0xFFB9C6D8.toInt()
            canvas.drawCircle(x, trackY, if (isNext) 17f else 13f, Paint(anti).apply { color = c })
            val p = Paint(anti).apply { color = if (done || isNext) c else 0xFF718096.toInt(); textSize = 18f; typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(threshold.toString(), x - p.measureText(threshold.toString()) / 2f, 860f, p)
        }
        val progression = when {
            nextTier == null -> "All activation tiers reached — maintain the momentum!"
            else -> "${(nextTier - reached).coerceAtLeast(0)} more activations to reach the ${nextTier}-activation tier."
        }
        canvas.drawText(progression.take(78), 90f, 914f, Paint(bold).apply { textSize = 19f; color = 0xFF24518A.toInt() })

        val rows = listOf(
            "Activations achieved" to String.format(Locale.US, "%,d", d.estimate.activations),
            "Fixed performance reward" to "₦${String.format(Locale.US, "%,d", d.estimate.fixedReward)}",
            "Estimated FRC component" to "₦${String.format(Locale.US, "%,d", d.estimate.estimatedRechargeBonus)}",
            "Sunday bonus" to "₦${String.format(Locale.US, "%,d", d.estimate.sundayBonus)}"
        )
        var y = 986f
        rows.forEachIndexed { i, pair ->
            canvas.drawRoundRect(64f, y - 28f, 1016f, y + 28f, 16f, 16f, Paint(anti).apply { color = if (i % 2 == 0) 0xFFF0F5F9.toInt() else 0xFFFFFFFF.toInt() })
            canvas.drawText(pair.first, 88f, y + 7f, Paint(label).apply { textSize = 21f })
            val valuePaint = Paint(bold).apply { textSize = 23f }
            canvas.drawText(pair.second, 986f - valuePaint.measureText(pair.second), y + 7f, valuePaint)
            y += 62f
        }
        val reachMessage = when {
            reached >= 300 -> "TOP REACH STEP! Sustain the momentum and keep service quality high."
            reached >= 250 -> "EXCELLENT REACH! Keep building toward the 300-activation milestone."
            reached >= 200 -> "STRONG PROGRESS! Your next reach step is 250 activations."
            reached >= 150 -> "GOOD MOMENTUM! Keep moving toward the 200-activation step."
            reached >= 100 -> "YOU'RE BUILDING REACH! Aim for the 150-activation step next."
            reached >= 70 -> "NICE PROGRESS! Keep connecting toward 100 activations."
            reached >= 50 -> "YOU'RE GAINING GROUND! The 70-activation step is next."
            reached >= 30 -> "GOOD START! Grow toward the 50-activation step."
            else -> "EVERY CONNECTION COUNTS. Build toward the 30-activation step."
        }
        canvas.drawRoundRect(64f, 1262f, 1016f, 1372f, 24f, 24f, Paint(anti).apply { color = 0xFFE4F8EC.toInt() })
        canvas.drawCircle(112f, 1317f, 29f, Paint(anti).apply { color = 0xFF0D9B4D.toInt() })
        canvas.drawText("✓", 98f, 1328f, Paint(anti).apply { color = -1; textSize = 32f; typeface = Typeface.DEFAULT_BOLD })
        canvas.drawText("Keep going!", 160f, 1309f, Paint(anti).apply { color = 0xFF087F3D.toInt(); textSize = 27f; typeface = Typeface.DEFAULT_BOLD })
        drawWrapped(canvas, reachMessage, 160f, 1342f, 810f, Paint(anti).apply { color = 0xFF24516B.toInt(); textSize = 19f }, 23f, 2)
        canvas.drawText("As of ${d.asOf.take(32)}", 70f, 1420f, Paint(label).apply { textSize = 18f })
        canvas.drawText("FOR MONITORING / ESTIMATION ONLY", 70f, 1460f, Paint(anti).apply { color = 0xFFB42332.toInt(); textSize = 19f; typeface = Typeface.DEFAULT_BOLD })
        if (d.activationDetail.isNotBlank()) canvas.drawText(d.activationDetail.take(82), 70f, 1492f, Paint(label).apply { textSize = 15f })
        canvas.drawRoundRect(64f, 1510f, 1016f, 1540f, 12f, 12f, Paint(anti).apply { color = 0xFF0B2946.toInt() })
        canvas.drawText("DevMonitor   •   MONITOR  •  TRACK  •  EARN", 86f, 1531f, Paint(anti).apply { color = -1; textSize = 16f; typeface = Typeface.DEFAULT_BOLD })
        canvas.restore()

        val file = File(context.cacheDir, "DevMonitor_Earnings_Flier_${stamp}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private fun drawWrapped(canvas: Canvas, text: String, x: Float, baseline: Float, maxWidth: Float, paint: Paint, lineHeight: Float, maxLines: Int) {
        val words = text.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var current = ""
        for (word in words) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (paint.measureText(candidate) <= maxWidth || current.isEmpty()) current = candidate
            else { lines += current; current = word }
            if (lines.size >= maxLines) break
        }
        if (lines.size < maxLines && current.isNotEmpty()) lines += current
        lines.take(maxLines).forEachIndexed { i, line -> canvas.drawText(line, x, baseline + i * lineHeight, paint) }
    }
    fun shareDailySnapshot(context: Context, dashboard: DashboardSummary, format: SnapshotFormat): Boolean {
        return runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val file = when (format) {
                SnapshotFormat.IMAGE -> createImage(context, dashboard, stamp)
                SnapshotFormat.PDF -> createPdf(context, dashboard, stamp)
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (format == SnapshotFormat.IMAGE) "image/png" else "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "DevMonitor Daily Snapshot — ${dashboard.date}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Daily Snapshot"))
            true
        }.getOrDefault(false)
    }

    private fun createImage(context: Context, d: DashboardSummary, stamp: String): File {
        val width = 1080
        val height = 1320
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(0xFFF7FAFD.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 34f; typeface = Typeface.DEFAULT }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor", 64f, 82f, bold.apply { textSize = 48f; color = 0xFF00843D.toInt() })
        canvas.drawText("Daily Operational Snapshot", 64f, 130f, paint.apply { textSize = 30f; color = 0xFF40546A.toInt() })
        canvas.drawText(d.date, 64f, 178f, paint.apply { textSize = 26f })
        var y = 250f
        val metrics = listOf(
            "Devices observed" to d.deviceCount.toString(),
            "Today's SIMReg" to d.todayTotal.toString(),
            "MTD SIMReg" to d.mtdTotal.toString(),
            "Active" to d.activeTotal.toString(),
            "Bar 48" to d.bar48Total.toString(),
            "Bar 96" to d.bar96Total.toString(),
            "Company today / MTD" to "${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD" to "${d.partnerToday} / ${d.partnerMtd}",
            "Active flags" to d.flags.size.toString()
        )
        for ((label, value) in metrics) {
            canvas.drawRoundRect(54f, y - 34f, width - 54f, y + 28f, 18f, 18f, Paint(paint).apply { color = 0xFFFFFFFF.toInt() })
            canvas.drawText(label, 82f, y + 5f, paint.apply { textSize = 24f; color = 0xFF40546A.toInt() })
            canvas.drawText(value, 800f, y + 5f, bold.apply { textSize = 26f; color = 0xFF12233A.toInt() })
            y += 88f
        }
        y += 28f
        canvas.drawText("Exceptions", 64f, y, bold.apply { textSize = 30f; color = 0xFFD14B5B.toInt() })
        y += 48f
        val flags = d.flags.take(8)
        if (flags.isEmpty()) canvas.drawText("No active flags recorded.", 64f, y, paint.apply { textSize = 24f })
        else flags.forEach { flag ->
            val line = "• ${flag.code}: ${flag.reason}"
            canvas.drawText(line.take(78), 70f, y, paint.apply { textSize = 21f; color = 0xFF40546A.toInt() })
            y += 38f
        }
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private fun createPdf(context: Context, d: DashboardSummary, stamp: String): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(612, 792, 1).create())
        val canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF12233A.toInt(); textSize = 14f }
        val bold = Paint(paint).apply { typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("DevMonitor — Daily Operational Snapshot", 36f, 48f, bold.apply { textSize = 20f; color = 0xFF00843D.toInt() })
        canvas.drawText("Date: ${d.date}", 36f, 72f, paint)
        val lines = listOf(
            "Devices observed: ${d.deviceCount}", "Today's SIMReg: ${d.todayTotal}", "MTD SIMReg: ${d.mtdTotal}",
            "Active: ${d.activeTotal}", "Bar 48: ${d.bar48Total}", "Bar 96: ${d.bar96Total}",
            "Company today / MTD: ${d.companyToday} / ${d.companyMtd}",
            "Partner today / MTD: ${d.partnerToday} / ${d.partnerMtd}", "Active flags: ${d.flags.size}"
        )
        var y = 110f
        lines.forEach { canvas.drawText(it, 42f, y, paint); y += 25f }
        y += 12f
        canvas.drawText("Exceptions", 36f, y, bold.apply { textSize = 16f; color = 0xFFD14B5B.toInt() }); y += 25f
        d.flags.take(14).forEach { flag ->
            val text = "${flag.code} — ${flag.reason}"
            canvas.drawText(text.take(92), 42f, y, paint.apply { textSize = 10f; color = 0xFF40546A.toInt() }); y += 17f
            if (y > 750f) return@forEach
        }
        doc.finishPage(page)
        val file = File(context.cacheDir, "DevMonitor_Daily_Snapshot_$stamp.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}

enum class SnapshotFormat { IMAGE, PDF }
