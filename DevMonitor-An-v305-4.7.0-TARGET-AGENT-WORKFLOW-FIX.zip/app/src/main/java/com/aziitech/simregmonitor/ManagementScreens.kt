package com.aziitech.simregmonitor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.CopyrightOverlay
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.YearMonth
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AgentManagementDialog(
    store: DatabaseStore,
    codes: List<String>,
    onDismiss: () -> Unit,
    onPickContact: (Long?) -> Unit,
    onPickPhoto: (Long) -> Unit = {},
    refreshToken: Int = 0,
    onGetLocation: () -> Pair<Double, Double>?,
    onOpenMaps: (Double?, Double?) -> Unit,
    onBatchShare: (String, List<Agent>) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var search by remember { mutableStateOf("") }
    var agents by remember { mutableStateOf(store.agents()) }
    var editing by remember { mutableStateOf<Agent?>(null) }
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var lat by remember { mutableStateOf("") }
    var lon by remember { mutableStateOf("") }
    var locationLookupStatus by remember { mutableStateOf("") }
    var showOpenStreetMapPicker by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }
    var selectedAgent by remember { mutableStateOf<Agent?>(null) }
    var linkCode by remember { mutableStateOf("") }
    var showBatchShare by remember { mutableStateOf(false) }
    var batchSource by remember { mutableStateOf("SMS Checker") }
    var batchAgentIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    LaunchedEffect(refreshToken) { agents = store.agents(search); selectedAgent = selectedAgent?.let { selected -> agents.firstOrNull { it.id == selected.id } } }

    fun newAgent() {
        editing = null
        name = ""
        address = ""
        lat = ""
        lon = ""
        showEditor = true
    }
    fun editAgent(a: Agent) {
        editing = a
        name = a.name
        address = a.address
        lat = a.latitude?.toString() ?: ""
        lon = a.longitude?.toString() ?: ""
        showEditor = true
    }

    if (showEditor) {
        AlertDialog(
            onDismissRequest = { showEditor = false },
            title = { Text(if (editing == null) "New Agent / Partner" else "Edit Agent / Partner") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DevMonitorOutlinedButton(onClick = { showEditor = false; onPickContact(editing?.id) }, modifier = Modifier.fillMaxWidth()) { Text("Import contact details") }
                    Text("Choose a saved contact to prefill the name, address, phone numbers and emails before saving.", style = MaterialTheme.typography.bodySmall)
                    TextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Agent name") }, placeholder = { Text("e.g. AAGENCY079") })
                    TextField(address, { address = it }, Modifier.fillMaxWidth(), label = { Text("Address") }, placeholder = { Text("e.g. Ayetoro, Ijebu North, Ogun State") }, minLines = 2)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextField(lat, { lat = it }, Modifier.weight(1f), label = { Text("Latitude") }, placeholder = { Text("e.g. 6.9018") })
                        TextField(lon, { lon = it }, Modifier.weight(1f), label = { Text("Longitude") }, placeholder = { Text("e.g. 3.3154") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DevMonitorOutlinedButton(onClick = {
                            val p = onGetLocation()
                            if (p != null) { lat = p.first.toString(); lon = p.second.toString(); locationLookupStatus = "Current location loaded; save to keep it on this agent." }
                            else locationLookupStatus = "Location unavailable. Grant location permission or enter coordinates manually."
                        }) { Text("Present location") }
                        DevMonitorOutlinedButton(onClick = { showOpenStreetMapPicker = true }) { Text("Select location on map") }
                    }
                    DevMonitorOutlinedButton(onClick = {
                        if (address.isBlank()) {
                            locationLookupStatus = "Enter a postal address or place name first."
                        } else {
                            locationLookupStatus = "Searching address…"
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val geocoder = android.location.Geocoder(context, java.util.Locale.getDefault())
                                        if (!android.location.Geocoder.isPresent()) null else {
                                            @Suppress("DEPRECATION")
                                            geocoder.getFromLocationName(address, 1)?.firstOrNull()
                                        }
                                    }.getOrNull()
                                }
                                if (result != null) {
                                    lat = result.latitude.toString(); lon = result.longitude.toString()
                                    locationLookupStatus = "Found a coordinate for this address. Review it, then tap Save Agent to store it."
                                } else locationLookupStatus = "No coordinate found. Check the address/network or enter latitude and longitude manually."
                            }
                        }
                    }, Modifier.fillMaxWidth()) { Text("Find coordinates from address") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DevMonitorOutlinedButton(onClick = { lat = ""; lon = ""; locationLookupStatus = "Saved map location will be cleared when you save this agent." }) { Text("Clear saved location") }
                    }
                    if (locationLookupStatus.isNotBlank()) Text(locationLookupStatus, style = MaterialTheme.typography.bodySmall)
                    Text("The postal address and map pin are separate. Tap the map to place the pin, or drag the marker to adjust it. Confirm the pin, then Save Agent to persist its coordinates.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        val id = store.saveAgent(Agent(editing?.id ?: 0L, name, address, lat.toDoubleOrNull(), lon.toDoubleOrNull(), editing?.createdAt ?: System.currentTimeMillis(), System.currentTimeMillis(), editing?.photoPath))
                        selectedAgent = store.agents().firstOrNull { it.id == id }
                        agents = store.agents(search)
                        showEditor = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Cancel") } }
        )
    }

    if (showOpenStreetMapPicker) {
        OpenStreetMapAgentPinPicker(
            initialLatitude = lat.toDoubleOrNull(),
            initialLongitude = lon.toDoubleOrNull(),
            onConfirm = { point -> lat = point.latitude.toString(); lon = point.longitude.toString(); locationLookupStatus = "OpenStreetMap pin confirmed. Tap Save Agent to store this location."; showOpenStreetMapPicker = false },
            onDismiss = { showOpenStreetMapPicker = false }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agent / Partner Database") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextField(search, { search = it; agents = store.agents(it) }, Modifier.fillMaxWidth(), label = { Text("Search agent") }, placeholder = { Text("e.g. Sunnetik") }, singleLine = true)
                DevMonitorButton(onClick = { newAgent() }, Modifier.fillMaxWidth()) { Text("Add agent or partner") }
                Text("Saved agents and partners", fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.heightIn(min = 120.dp, max = 360.dp)) {
                    items(agents, key = { it.id }) { a ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Column(Modifier.padding(8.dp)) {
                                Text(a.name, fontWeight = FontWeight.Bold)
                                if (a.address.isNotBlank()) Text(a.address)
                                Text("Location: ${a.latitude ?: "-"}, ${a.longitude ?: "-"}")
                                if (!a.photoPath.isNullOrBlank()) Text("Profile photo saved")
                                Text("Linked devices: ${store.devicesForAgent(a.id).joinToString().ifBlank { "None yet" }}", style = MaterialTheme.typography.bodySmall)
                                DevMonitorOutlinedButton(onClick = { selectedAgent = a }, modifier = Modifier.fillMaxWidth()) { Text("Details & device links") }
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    TextButton(onClick = { editAgent(a) }) { Text("Edit") }
                                    TextButton(onClick = { onPickContact(a.id) }) { Text("Import contact") }
                                    TextButton(onClick = { onPickPhoto(a.id) }) { Text("Photo") }
                                    TextButton(onClick = { store.deleteAgent(a.id); agents = store.agents(search); if(selectedAgent?.id==a.id) selectedAgent=null }) { Text("Delete") }
                                }
                                if (!a.photoPath.isNullOrBlank()) TextButton(onClick = { store.saveAgent(a.copy(photoPath = null)); agents = store.agents(search); selectedAgent = store.agents(search).firstOrNull { it.id == a.id } }) { Text("Clear saved photo") }
                            }
                        }
                    }
                }
                if (agents.isEmpty()) Text("No agents or partners saved yet. Add one below, or import a contact to create one faster.", style = MaterialTheme.typography.bodySmall)
                DevMonitorOutlinedButton(onClick = { batchAgentIds = agents.map { it.id }.toSet(); showBatchShare = true }, modifier = Modifier.fillMaxWidth()) { Text("Batch share earnings cards") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )

    if (showBatchShare) {
        AlertDialog(
            onDismissRequest = { showBatchShare = false },
            title = { Text("Batch share earnings cards") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose one source only. Each linked device gets its own image; devices without figures in that source are skipped and reported.", style = MaterialTheme.typography.bodySmall)
                    listOf("SMS Checker", "Loaded Report").forEach { option ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = batchSource == option, onClick = { batchSource = option })
                            Text(option, modifier = Modifier.clickable { batchSource = option })
                        }
                    }
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(agents, key = { it.id }) { agent ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = agent.id in batchAgentIds, onCheckedChange = { checked -> batchAgentIds = if (checked) batchAgentIds + agent.id else batchAgentIds - agent.id })
                                Column(Modifier.weight(1f)) { Text(agent.name, fontWeight = FontWeight.SemiBold); Text("${store.devicesForAgent(agent.id).size} linked device(s)", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { val chosen = agents.filter { it.id in batchAgentIds }; showBatchShare = false; onBatchShare(batchSource, chosen) }) { Text("Prepare cards") } },
            dismissButton = { TextButton(onClick = { showBatchShare = false }) { Text("Cancel") } }
        )
    }

    selectedAgent?.let { a ->
        val phones = store.phonesForAgent(a.id)
        AlertDialog(
            onDismissRequest = { selectedAgent = null },
            title = { Text(a.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Phone numbers", fontWeight = FontWeight.Bold)
                    phones.forEach { p ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${p.phone} ${p.label}")
                            TextButton(onClick = { store.deleteAgentPhone(p.id); selectedAgent = a.copy() }) { Text("Remove") }
                        }
                    }
                    DevMonitorOutlinedButton(onClick = { onPickContact(a.id) }) { Text("Import contact details") }
                    var newEmail by remember(a.id) { mutableStateOf("") }
                    Text("Email addresses", fontWeight = FontWeight.Bold)
                    store.emailsForAgent(a.id).forEach { e -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(e.email, modifier = Modifier.weight(1f)); TextButton(onClick = { store.deleteAgentEmail(e.id); selectedAgent = a.copy(updatedAt = System.currentTimeMillis()) }) { Text("Remove") } } }
                    Row(verticalAlignment = Alignment.CenterVertically) { TextField(newEmail, { newEmail = it }, Modifier.weight(1f), label = { Text("Add email") }, singleLine = true); TextButton(onClick = { store.addAgentEmail(a.id,newEmail);newEmail="";selectedAgent=a.copy(updatedAt=System.currentTimeMillis()) }) { Text("Add") } }
                    Text("Link devices from My Devices", fontWeight = FontWeight.Bold)
                    if (codes.isEmpty()) Text("No My Devices codes are available in this profile.", style = MaterialTheme.typography.bodySmall)
                    codes.take(250).forEach { deviceCode ->
                        val linkedHere = store.agentForCode(deviceCode) == a.id
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(deviceCode, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { if (linkedHere) store.unlinkDeviceFromAgent(a.id, deviceCode) else { store.agentForCode(deviceCode)?.let { store.unlinkDeviceFromAgent(it, deviceCode) }; store.linkDeviceToAgent(a.id, deviceCode) }; selectedAgent = a.copy(updatedAt = System.currentTimeMillis()) }) { Text(if (linkedHere) "Unlink" else "Link") }
                        }
                    }
                    TextField(linkCode, { linkCode = it }, Modifier.fillMaxWidth(), label = { Text("Other device/partner code") }, placeholder = { Text("Enter a code not listed above") })
                    DevMonitorButton(onClick = { if(linkCode.isNotBlank()){store.agentForCode(linkCode.trim())?.let { store.unlinkDeviceFromAgent(it, linkCode.trim()) }; store.linkDeviceToAgent(a.id,linkCode.trim().uppercase());linkCode=""} }) { Text("Link code") }
                }
            },
            confirmButton = { TextButton(onClick = { selectedAgent=null }) { Text("Close") } }
        )
    }
}

@Composable
fun DevicePaymentCardScreen(
    row: SimRegReportRow?,
    localRecord: QueryRecord?,
    reportIsActivation: Boolean,
    reportMonth: YearMonth? = null,
    reportCutoffDay: Int? = null,
    companyActivations: CompanyActivationStore? = null,
    myDevicesStore: MyDevicesStore? = null,
    deviceMonitorStore: DatabaseStore? = null,
    deviceMonitorMode: Boolean = false,
    showBothSources: Boolean = false,
    paymentDataRevision: Long = 0L,
    profileDisplayName: String = "",
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val codeForPayment = row?.deviceId ?: localRecord?.code
    var companyCycleTotal by remember(codeForPayment) { mutableStateOf<Int?>(null) }
    var companyCycleContributions by remember(codeForPayment) { mutableStateOf<List<CompanyActivationStore.CycleContribution>>(emptyList()) }
    var companySundayTotal by remember(codeForPayment) { mutableIntStateOf(0) }
    var paymentCycleResolution by remember(codeForPayment) { mutableStateOf<PaymentEngine.Progression?>(null) }
    var smsOnlyEstimate by remember(codeForPayment) { mutableStateOf<IncentiveEstimate?>(null) }
    var shareSource by remember(codeForPayment) { mutableStateOf(if (deviceMonitorMode) "SMS Checker" else "Loaded Report") }

    LaunchedEffect(codeForPayment, companyActivations, deviceMonitorMode, showBothSources, paymentDataRevision) {
        if (codeForPayment == null) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            val loaded = companyActivations?.let { companyStore -> PaymentEngine.LoadedReports.calculate(
                deviceId = codeForPayment,
                asOfRequested = PaymentRules.currentAwareDate(),
                companyStore = companyStore
            ) }
            val monitor = if (deviceMonitorStore != null) {
                PaymentEngine.DeviceMonitor.calculate(
                    deviceId = codeForPayment,
                    asOfRequested = PaymentRules.currentAwareDate(),
                    deviceStore = deviceMonitorStore,
                    companyStore = companyActivations
                )
            } else null
            val smsOnly = if (deviceMonitorStore != null) PaymentEngine.DeviceMonitor.calculate(
                deviceId = codeForPayment,
                asOfRequested = PaymentRules.currentAwareDate(),
                deviceStore = deviceMonitorStore,
                companyStore = null
            ).estimate else null
            withContext(Dispatchers.Main.immediate) {
                companyCycleTotal = loaded?.activations
                companySundayTotal = companyActivations?.cycleSundayActivations(codeForPayment) ?: 0
                companyCycleContributions = companyActivations?.cycleContributions(codeForPayment) ?: emptyList()
                paymentCycleResolution = monitor
                smsOnlyEstimate = smsOnly
            }
        }
    }

    val liveDate = PaymentRules.currentAwareDate()
    val livePaymentCycle = PaymentRules.paymentCycleForDate(liveDate)

    // Device Monitor payment progression is reconstructed by calendar-month segment.
    // Loaded Reports seed historical dates; SMS Active snapshots override those dates
    // once available and are converted from month-to-date cumulative values into
    // payment-cycle contributions. Future report dates never participate.
    val resolvedCycle = paymentCycleResolution
    val livePaymentCycleTotal = if (deviceMonitorMode || showBothSources) resolvedCycle?.activations else null
    val deviceMonitorEstimate = resolvedCycle?.estimate
    val loadedReportEstimate = companyCycleTotal?.let { PaymentRules.estimate(it, companySundayTotal) }
    val deviceMonitorAvailable = deviceMonitorEstimate != null
    val loadedReportAvailable = loadedReportEstimate != null

    val partner = row?.partnerName.orEmpty().ifBlank { "-" }
    val trade = row?.tradeCode.orEmpty().ifBlank { "-" }
    val staff = row?.staffName.orEmpty().ifBlank { "-" }
    val territory = row?.territory.orEmpty().ifBlank { "-" }
    val region = row?.region.orEmpty().ifBlank { "-" }
    val cluster = row?.cluster.orEmpty().ifBlank { "-" }
    val code = row?.deviceId ?: localRecord?.code ?: "-"

    @Composable
    fun EstimateBlock(
        title: String,
        source: String,
        estimate: IncentiveEstimate,
        showSunday: Boolean,
        monitorSource: Boolean
    ) {
        AuroraGlassCard(Modifier.fillMaxWidth(), if (monitorSource) AuroraBlue else AuroraCyan) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                Text("Evidence source: $source", style = MaterialTheme.typography.bodySmall)
                Text("Current Activation Achieved: ${estimate.activations}", fontWeight = FontWeight.Bold)
                if (!monitorSource) {
                    val liveDate = PaymentRules.currentAwareDate()
                    Text("Payment cycle: ${PaymentRules.paymentCycleLabel(liveDate)}", fontWeight = FontWeight.Bold)
                    Text("Progression as of: $liveDate (future-dated report rows are ignored)", style = MaterialTheme.typography.bodySmall)
                }
                val currentTier = when {
                    estimate.activations >= 300 -> "300+ activation tier"
                    estimate.activations >= 250 -> "250 activation tier"
                    estimate.activations >= 200 -> "200 activation tier"
                    estimate.activations >= 150 -> "150 activation tier"
                    estimate.activations >= 100 -> "100 activation tier"
                    estimate.activations >= 70 -> "70 activation tier"
                    estimate.activations >= 50 -> "50 activation tier"
                    estimate.activations >= 30 -> "30 activation tier"
                    else -> "Below 30 activation tier"
                }
                Text("Current payment category: $currentTier")
                Text("Fixed performance reward: ₦${estimate.fixedReward.formatNaira()}")
                Text("FRC cumulative: ₦${estimate.estimatedRechargeBonus.formatNaira()} — Progressively paid weekly")
                if (monitorSource) {
                    val liveDate = PaymentRules.currentAwareDate()
                    Text("Device Monitor as of: $liveDate", fontWeight = FontWeight.Bold)
                    Text("Payment cycle: ${PaymentRules.paymentCycleLabel(liveDate)}", fontWeight = FontWeight.Bold)
                    Text("Current payment-cycle activations: ${livePaymentCycleTotal ?: 0}", fontWeight = FontWeight.Bold)
                    if (resolvedCycle != null) {
                        Text("Data available from: ${resolvedCycle.availableThrough ?: "not established"}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            if (resolvedCycle.complete) "Cycle coverage is complete through today."
                            else resolvedCycle.warning ?: "Cycle coverage is incomplete; missing dates are not invented.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Sources: ${resolvedCycle.source.ifBlank { "none" }}", style = MaterialTheme.typography.bodySmall)
                    }
                    resolvedCycle?.warning?.let { warning ->
                        Text(warning, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                }
                if (showSunday && estimate.sundayBonus > 0) {
                    Text("Sunday bonus: ₦${estimate.sundayBonus.formatNaira()} (${estimate.sundayActivations} qualifying Sunday activations)", fontWeight = FontWeight.Bold)
                } else if (showSunday) {
                    Text("Sunday bonus: ₦0 (each Sunday must reach ${PaymentRules.SUNDAY_MIN_ACTIVATIONS}+ qualifying activations)")
                }
                Text("Estimated total: ₦${estimate.estimatedSubtotal.formatNaira()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                if (estimate.nextThreshold != null) {
                    LinearProgressIndicator(
                        progress = { (estimate.activations.toFloat() / estimate.nextThreshold!!.toFloat()).coerceIn(0f, 1f) },
                        Modifier.fillMaxWidth()
                    )
                    Text("${estimate.activationsToNext} more activation${if (estimate.activationsToNext == 1) "" else "s"} to ${estimate.nextThreshold} → ₦${estimate.nextReward?.formatNaira() ?: "-"}")
                    Text(
                        when {
                            estimate.activations >= 300 -> "Top reach step achieved! Keep your service quality high and sustain the momentum."
                            estimate.activations >= 250 -> "Excellent reach! Keep building toward the 300-activation milestone."
                            estimate.activations >= 200 -> "Strong progress! Your next reach step is 250 activations."
                            estimate.activations >= 150 -> "Good momentum! Keep going toward the 200-activation step."
                            estimate.activations >= 100 -> "You're building reach! Aim for the 150-activation step next."
                            estimate.activations >= 70 -> "Nice progress! Keep connecting to reach the 100-activation step."
                            estimate.activations >= 50 -> "You're gaining ground! The 70-activation step is your next target."
                            estimate.activations >= 30 -> "Good start! Keep growing toward the 50-activation step."
                            else -> "Every connection counts. Keep building toward the 30-activation step."
                        }, fontWeight = FontWeight.Bold
                    )
                } else {
                    Text("You've reached the highest currently configured fixed-reward tier. Keep the momentum going.", fontWeight = FontWeight.Bold)
                }

            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Device Payment", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        }
        HorizontalDivider()
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 180.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("DEVICE PAYMENT CARD", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold)
                        Text(code, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        Text("Payment progression and earnings estimate", style = MaterialTheme.typography.bodyMedium)
                        Text("Choose the exact source to share", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        listOf("SMS Checker", "Loaded Report").forEach { option ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = shareSource == option, onClick = { shareSource = option })
                                Text(option, modifier = Modifier.clickable { shareSource = option })
                            }
                        }
                        // Share the exact estimate object shown in the corresponding payment card.
                        // Device Monitor is the merged payment-cycle resolution (Loaded Report seed + SMS overrides),
                        // not the SMS-only intermediate estimate. The share renderer must never calculate a new total.
                        val shareEstimate = if (shareSource == "SMS Checker") deviceMonitorEstimate else loadedReportEstimate
                        if (shareEstimate == null) {
                            Text("No figures are available from $shareSource for this device. No estimate will be substituted.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        DevMonitorButton(
                            onClick = {
                                val linkedAgent = deviceMonitorStore?.agentForCodeDetails(code)
                                val linkedAgentName = linkedAgent?.name ?: staff.takeIf { it != "-" } ?: "Unlinked agent"
                                val cardDisplayName = linkedAgentName
                                val linkedPhone = linkedAgent?.let { deviceMonitorStore?.phonesForAgent(it.id)?.firstOrNull()?.phone }.orEmpty()
                                val payload = PaymentCardSharePayload(
                                    agentName = cardDisplayName, deviceCode = code, source = shareSource,
                                    agentPhotoPath = linkedAgent?.photoPath, agentPhone = linkedPhone,
                                    period = PaymentRules.paymentCycleLabel(PaymentRules.currentAwareDate()),
                                    asOf = if (shareSource == "SMS Checker") (PaymentRules.currentAwareDate().toString()) else PaymentRules.currentAwareDate().toString(),
                                    estimate = shareEstimate!!,
                                    activationDetail = "Figures taken from $shareSource only; no source mixing.",
                                    identityLabel = if (linkedAgent != null) "AGENT" else if (profileDisplayName.trim().isNotBlank()) "PROFILE" else "AGENT"
                                )
                                ReportExportPack.sharePaymentCardAsync(context, payload) { ok ->
                                    if (!ok) android.widget.Toast.makeText(context, "Could not create the earnings card image. Please try again.", android.widget.Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = shareEstimate != null
                        ) { Text("Share this card as image") }
                    }
                }
            }
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Device details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Partner: $partner")
                        Text("Partner / Trade code: $trade")
                        Text("Agent / Staff: $staff")
                        Text("Territory: $territory")
                        Text("Region: $region")
                        Text("Cluster: $cluster")
                    }
                }
            }

            if (showBothSources) {
                if (deviceMonitorAvailable) {
                    item {
                        EstimateBlock(
                            title = "DEVICE MONITOR PAYMENT ESTIMATE",
                            source = resolvedCycle?.source?.ifBlank { "Current payment-cycle sources" } ?: "Current payment-cycle sources",
                            estimate = deviceMonitorEstimate!!,
                            showSunday = false,
                            monitorSource = true
                        )
                    }
                }
                if (loadedReportAvailable) {
                    item {
                        EstimateBlock(
                            title = "LOADED REPORT PAYMENT ESTIMATE",
                            source = "Normalized Loaded Reports — current 21st–20th payment cycle",
                            estimate = loadedReportEstimate!!,
                            showSunday = true,
                            monitorSource = false
                        )
                    }
                    if (companyCycleContributions.isNotEmpty()) {
                        item {
                            AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text("Loaded report contributions", fontWeight = FontWeight.Bold)
                                    companyCycleContributions.forEach { part ->
                                        val range = listOfNotNull(part.coverageStart, part.coverageEnd).joinToString(" → ")
                                        Text("${part.sourceName}${if (range.isNotBlank()) " ($range)" else ""}: ${part.activationCount} activations")
                                    }
                                }
                            }
                        }
                    }
                }
                if (!deviceMonitorAvailable && !loadedReportAvailable) {
                    item {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("No payment result available yet", fontWeight = FontWeight.ExtraBold)
                                Text("This device has no usable Device Monitor or Loaded Reports activation evidence yet.")
                            }
                        }
                    }
                }
            } else if (deviceMonitorMode) {
                item {
                    if (deviceMonitorEstimate != null) {
                        EstimateBlock(
                            title = "DEVICE MONITOR PAYMENT ESTIMATE",
                            source = when {
                                resolvedCycle?.source?.contains("Device Monitor Active") == true -> "Device Monitor: current payment-cycle SMS"
                                else -> "Device Monitor: current payment-cycle Loaded Reports"
                            },
                            estimate = deviceMonitorEstimate,
                            showSunday = false,
                            monitorSource = true
                        )
                    } else {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("CURRENT PAYMENT PROGRESSION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("No Device Monitor activation figure is available for this device yet.")
                                Text("Keep monitoring the device; an estimate will appear when activation evidence becomes available.")
                            }
                        }
                    }
                }
            } else {
                item {
                    if (loadedReportEstimate != null) {
                        EstimateBlock(
                            title = "LOADED REPORT PAYMENT ESTIMATE",
                            source = "HQ Activation report / normalized Loaded Reports",
                            estimate = loadedReportEstimate,
                            showSunday = true,
                            monitorSource = false
                        )
                    } else if (row != null && !reportIsActivation) {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("CURRENT PAYMENT PROGRESSION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("This HQ report is a SIM Reg/registration report. Registration totals are not converted into activation payout estimates.", fontWeight = FontWeight.Bold)
                                Text("Use Device Monitor or an HQ Activations report when activation evidence is available.")
                            }
                        }
                    } else {
                        AuroraGlassCard(Modifier.fillMaxWidth(), AuroraCyan) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("CURRENT PAYMENT PROGRESSION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                Text("No activation figure is available for this device yet.")
                            }
                        }
                    }
                }
            }

            if (deviceMonitorMode && !deviceMonitorAvailable) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("⚠ PAYMENT ESTIMATION NOT READY", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                            Text(
                                resolvedCycle?.warning
                                    ?: "There is not enough historical data yet to calculate this Device Monitor payment-cycle progression. Continue Device Monitor queries and/or load a report covering the 20th."
                            )
                        }
                    }
                }
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("⚠ PAYMENT / INCENTIVE WARNING", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                        Text("DevMonitor figures are for monitoring / estimation only. Company official data remains final.", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun Int.formatNaira(): String = "%d".format(java.util.Locale.US, this)

@Composable
fun PaymentLandingScreen(
    report: SimRegReport?,
    localRecords: Map<String, QueryRecord>,
    agents: List<Agent>,
    companyActivations: CompanyActivationStore? = null,
    myDevicesStore: MyDevicesStore? = null,
    deviceMonitorStore: DatabaseStore? = null,
    paymentDataRevision: Long = 0L
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var selectedCode by remember { mutableStateOf<String?>(null) }
    var selectedPartner by remember { mutableStateOf<String?>(null) }

    val normalizedQuery = query.trim().uppercase()
    val activationReport = report?.takeIf { it.isActivationReport }
    val hqRows = report?.rows.orEmpty()
    val localByCode = remember(localRecords) { localRecords.values.associateBy { canonicalDeviceCode(it.code) } }
    val hqByCode = remember(hqRows) { hqRows.associateBy { canonicalDeviceCode(it.deviceId) } }

    if (selectedCode != null) {
        val code = selectedCode!!
        DevicePaymentCardScreen(
            row = hqByCode[canonicalDeviceCode(code)],
            localRecord = localByCode[canonicalDeviceCode(code)],
            reportIsActivation = activationReport != null,
            reportMonth = activationReport?.coverageEnd?.let(YearMonth::from),
            reportCutoffDay = activationReport?.cutoffDay,
            companyActivations = companyActivations,
            myDevicesStore = myDevicesStore,
            deviceMonitorStore = deviceMonitorStore,
            deviceMonitorMode = false,
            showBothSources = true,
            paymentDataRevision = paymentDataRevision,
            onBack = { selectedCode = null }
        )
        return
    }

    if (selectedPartner != null) {
        val partnerKey = selectedPartner!!
        val partnerRows = hqRows.filter {
            it.partnerName.equals(partnerKey, ignoreCase = true) || it.tradeCode.equals(partnerKey, ignoreCase = true)
        }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selectedPartner = null }) { Text("‹ Back") }
                Text("Partner Overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            }
            HorizontalDivider()
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(partnerKey, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            Text("${partnerRows.size} device${if (partnerRows.size == 1) "" else "s"} found")
                            Text("Tap a device to open its full payment card.")
                        }
                    }
                }
                items(partnerRows, key = { canonicalDeviceCode(it.deviceId) }) { row ->
                    val local = localByCode[canonicalDeviceCode(row.deviceId)]
                    val count = when {
                        local?.result?.active != null -> local.result.active ?: 0
                        activationReport != null -> row.mtd(activationReport.cutoffDay)
                        else -> null
                    }
                    val sundayActivations = activationReport?.coverageEnd?.let { PaymentRules.qualifyingSundayActivations(row.daily, YearMonth.from(it), activationReport.cutoffDay) } ?: 0
                    val estimate = count?.let { PaymentRules.estimate(it, sundayActivations) }
                    Card(Modifier.fillMaxWidth().clickable { selectedCode = row.deviceId }) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(row.deviceId, fontWeight = FontWeight.ExtraBold)
                            Text("Agent: ${row.staffName.ifBlank { "-" }}")
                            Text("Activations: ${count ?: "-"} • Category: ${estimate?.let { when { it.activations >= 300 -> "300+"; it.activations >= 250 -> "250"; it.activations >= 200 -> "200"; it.activations >= 150 -> "150"; it.activations >= 100 -> "100"; it.activations >= 70 -> "70"; it.activations >= 50 -> "50"; it.activations >= 30 -> "30"; else -> "<30" } } ?: "-"}")
                            if (estimate != null) Text("Estimated: ₦${estimate.estimatedSubtotal.formatNaira()}")
                            if (estimate?.nextThreshold != null) Text(
                                "${estimate.activationsToNext} more to ${estimate.nextThreshold}. " + when {
                                    estimate.activations >= 250 -> "You're close to the top reach step. Keep your momentum."
                                    estimate.activations >= 200 -> "You're in a strong position—push toward the next step."
                                    estimate.activations >= 150 -> "Your next milestone is within reach. Keep connecting."
                                    estimate.activations >= 100 -> "Every new activation moves you closer to the next category."
                                    estimate.activations >= 70 -> "Keep the consistency going; your next reach step is ahead."
                                    estimate.activations >= 50 -> "You're progressing—keep building your network."
                                    estimate.activations >= 30 -> "A steady start matters. Keep growing your reach."
                                    else -> "Start strong: each qualifying activation brings the next step closer."
                                }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                    Text("PAYMENT INTELLIGENCE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(4.dp))
                    Text("Payment intelligence", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("View estimated agent, device and partner payment based on the available HQ/SIMReg data.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                }
            }
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraBlue) {
                    Text("PAYMENT SEARCH", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text("Search the available HQ/SIMReg and Device Monitor data.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(mode == "AGENT", onClick = { mode = "AGENT"; query = "" }, label = { Text("AGENT / DEVICE TAG") }, modifier = Modifier.weight(1f))
                        FilterChip(mode == "PARTNER", onClick = { mode = "PARTNER"; query = "" }, label = { Text("PARTNER") }, modifier = Modifier.weight(1f))
                    }
                    if (mode != null) {
                        Spacer(Modifier.height(10.dp))
                        TextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text(if (mode == "AGENT") "Device Tag / Device ID" else "Partner name / Partner code") },
                            placeholder = { Text(if (mode == "AGENT") "e.g. GLO-GD-235N" else "e.g. partner name or code") }
                        )
                    }
                }
            }
            if (mode == "AGENT" && normalizedQuery.isNotBlank()) {
                val matches = buildList {
                    hqRows.filter { canonicalDeviceCode(it.deviceId).contains(normalizedQuery) || it.deviceId.uppercase().contains(normalizedQuery) || it.partnerName.uppercase().contains(normalizedQuery) || it.staffName.uppercase().contains(normalizedQuery) }.forEach { add(canonicalDeviceCode(it.deviceId)) }
                    localRecords.keys.filter { canonicalDeviceCode(it).contains(normalizedQuery) }.forEach { add(canonicalDeviceCode(it)) }
                }.distinct().take(100)
                if (matches.isEmpty()) item {
                    DevMonitorEmptyState(
                        title = "No matching device",
                        message = "No device was found in the available HQ Activation/SIMReg and Device Monitor data."
                    )
                }
                items(matches, key = { it }) { code ->
                    AuroraGlassCard(Modifier.fillMaxWidth().clickable { selectedCode = code }, AuroraBlue) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(code, fontWeight = FontWeight.ExtraBold)
                            val row = hqByCode[code]
                            val contextLine = listOfNotNull(
                                row?.partnerName?.trim()?.takeIf { it.isNotEmpty() },
                                row?.staffName?.trim()?.takeIf { it.isNotEmpty() }
                            ).joinToString(" • ")
                            if (contextLine.isNotBlank()) {
                                Text(contextLine)
                            }
                            Text("Tap to view payment card", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (mode == "PARTNER" && normalizedQuery.isNotBlank()) {
                val matches = buildList {
                    hqRows.filter { it.partnerName.uppercase().contains(normalizedQuery) || it.tradeCode.uppercase().contains(normalizedQuery) }.mapNotNull { it.partnerName.ifBlank { it.tradeCode.ifBlank { null } } }.forEach { add(it) }
                    agents.filter { it.name.uppercase().contains(normalizedQuery) }.forEach { add(it.name) }
                }.distinct().take(50)
                if (matches.isEmpty()) item {
                    DevMonitorEmptyState(
                        title = "No matching partner",
                        message = "No partner was found in the available data. Check the name or trade code and try again."
                    )
                }
                items(matches, key = { it }) { partner ->
                    AuroraGlassCard(Modifier.fillMaxWidth().clickable { selectedPartner = partner }, AuroraViolet) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(partner, fontWeight = FontWeight.ExtraBold)
                            Text("Tap to view all matching devices and payment progression.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                AuroraGlassCard(Modifier.fillMaxWidth(), AuroraViolet) {
                    Column(Modifier.padding(0.dp)) {
                        Image(
                            painter = painterResource(com.aziitech.simregmonitor.R.drawable.payment_structure),
                            contentDescription = "Company payment structure",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth
                        )
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("⚠ PAYMENT / INCENTIVE WARNING", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                        Text("DevMonitor figures are for monitoring / estimation only. Company official data remains final.", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentTrackingDialog(store: DatabaseStore, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Payment Tracking") }, text = { Text("Payment tracking is now available from the full Payments page.") }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}


@Composable
private fun OpenStreetMapAgentPinPicker(
    initialLatitude: Double?,
    initialLongitude: Double?,
    onConfirm: (GeoPoint) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val startPoint = remember(initialLatitude, initialLongitude) {
        if (initialLatitude != null && initialLongitude != null && initialLatitude in -90.0..90.0 && initialLongitude in -180.0..180.0)
            GeoPoint(initialLatitude, initialLongitude) else GeoPoint(9.0820, 8.6753)
    }
    var selectedPoint by remember(initialLatitude, initialLongitude) { mutableStateOf(startPoint) }
    var mapReady by remember { mutableStateOf(false) }
    val mapView = remember {
        val osmdroidRoot = java.io.File(context.cacheDir, "osmdroid").apply { mkdirs() }
        val tileCache = java.io.File(osmdroidRoot, "tiles").apply { mkdirs() }
        Configuration.getInstance().load(context, context.getSharedPreferences("osmdroid", android.content.Context.MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = "${context.packageName}/4.7.0 (DevMonitor Android)"
        Configuration.getInstance().osmdroidBasePath = osmdroidRoot
        Configuration.getInstance().osmdroidTileCache = tileCache
        MapView(context).apply {
            setTileSource(org.osmdroid.tileprovider.tilesource.TileSourceFactory.MAPNIK)
            setUseDataConnection(true)
            setMultiTouchControls(true)
            setBuiltInZoomControls(true)
            setTilesScaledToDpi(true)
        }
    }
    var marker by remember { mutableStateOf<Marker?>(null) }

    DisposableEffect(mapView) {
        mapView.onResume()
        mapView.controller.setZoom(if (initialLatitude != null && initialLongitude != null) 16.0 else 6.0)
        mapView.controller.setCenter(startPoint)
        mapView.overlays.add(CopyrightOverlay(context))
        val markerOverlay = Marker(mapView).apply {
            position = startPoint
            title = "Agent location"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            setDraggable(true)
            setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
                override fun onMarkerDragStart(marker: Marker) {}
                override fun onMarkerDrag(marker: Marker) { selectedPoint = marker.position }
                override fun onMarkerDragEnd(marker: Marker) { selectedPoint = marker.position; mapView.invalidate() }
            })
        }
        marker = markerOverlay
        val mapEvents = MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(point: GeoPoint): Boolean {
                selectedPoint = point
                markerOverlay.position = point
                mapView.invalidate()
                return true
            }
            override fun longPressHelper(point: GeoPoint): Boolean {
                selectedPoint = point
                markerOverlay.position = point
                mapView.invalidate()
                return true
            }
        })
        mapView.overlays.add(mapEvents)
        mapView.overlays.add(markerOverlay)
        mapReady = true
        mapView.invalidate()
        onDispose {
            mapView.onPause()
            mapView.onDetach()
            marker = null
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(),
        title = { Text("Select location on map") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AndroidView(
                    factory = { mapView },
                    modifier = Modifier.fillMaxWidth().height(320.dp),
                    update = { it.onResume() }
                )
                if (!mapReady) Text("Preparing map…", style = MaterialTheme.typography.bodySmall)
                Text("Pin: ${"%.6f".format(java.util.Locale.US, selectedPoint.latitude)}, ${"%.6f".format(java.util.Locale.US, selectedPoint.longitude)}", style = MaterialTheme.typography.bodySmall)
                Text("Tap or long-press the map to move the pin, or drag the marker. Map tiles require an internet connection. Confirm returns coordinates to the editor; tap Save Agent to store them.", style = MaterialTheme.typography.bodySmall)
                Text("© OpenStreetMap contributors", style = MaterialTheme.typography.labelSmall)
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(selectedPoint) }) { Text("Confirm pin") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
