package com.aziitech.simregmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Small profile-scoped store for staff-managed partner codes. Independent of My Devices. */
data class MyPartnerRecord(val id: String, val name: String, val code: String)

class MyPartnerStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("devmonitor_my_partner", Context.MODE_PRIVATE)
    private fun key(profileId: String) = "partners_${profileId.ifBlank { "default" }}"

    fun load(profileId: String): List<MyPartnerRecord> {
        val raw = prefs.getString(key(profileId), null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.optJSONObject(i) ?: return@mapNotNull null
                val name = o.optString("name").trim()
                val code = o.optString("code").trim().uppercase()
                if (name.isBlank() || code.isBlank()) null else MyPartnerRecord(
                    o.optString("id").ifBlank { UUID.randomUUID().toString() }, name, code
                )
            }
        }.getOrDefault(emptyList())
    }

    fun save(profileId: String, records: List<MyPartnerRecord>) {
        val array = JSONArray()
        records.distinctBy { it.code.trim().uppercase() }.forEach { record ->
            if (record.name.isNotBlank() && record.code.isNotBlank()) {
                array.put(JSONObject().put("id", record.id).put("name", record.name.trim()).put("code", record.code.trim().uppercase()))
            }
        }
        prefs.edit().putString(key(profileId), array.toString()).apply()
    }
}
