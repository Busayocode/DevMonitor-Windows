# Android v338 — SMS Checker Daily History

## Scope

This increment adds date-based history to the Android SMS Checker in both Device Monitor and My Partners. The two menus use separate SQLite history files and never share or overwrite one another's history.

## Databases

- `sms_checker_devices_history.db` — Device Monitor SMS Checker results.
- `sms_checker_partners_history.db` — My Partners SMS Checker results.

Each database stores completed checks with the local activity date, canonical code, completion timestamp, and a complete serialized `QueryRecord` (including the parsed SIMReg result or failure details).

## Retention and views

- Retain the current calendar month and the immediately previous calendar month.
- Prune older dates on database initialization, when dates are listed, and whenever a new completed result is saved.
- Whole day view: select a date and see the latest result for each code checked that day, with daily counts/status summary.
- Per-device/partner view: enter a code and see every completed check/recheck for that code in the retained period.
- Store terminal success, not-found, timeout, send-failure, and unrecognized outcomes. Intermediate SENDING/WAITING states are not recorded as completed checks.
- Rechecks are append-only events; a later result does not erase an earlier check from that same day.

## Migration

On first launch after upgrade, import the existing legacy history table from each menu's working database once. The legacy table only contains successful and not-found results, so only those available records can be carried forward. Older activity that was never stored cannot be reconstructed.

## Protected behavior

- No changes to SMS destination, retry order, timeout duration, parsing rules, SIM selection, payment calculations, MOM rules, or loaded-report logic.
- Clearing/replacing the active code list does not delete daily history.
- Device Monitor and My Partners history remain isolated.

## Known boundary

The existing Google Drive backup path backs up the primary working database, not these two new history databases. This increment stores history locally on the Android installation; inclusion in a future multi-database cloud backup is separate work.

## Verification status

- Source changes and ZIP structure: prepared.
- Local Gradle compile: not completed because the environment could not download Gradle 8.7 (`services.gradle.org` was unreachable).
- GitHub Actions Android build and physical-device verification: pending.
- Windows/PC parity: not included in this Android-only increment; check whether a native PC SMS Checker counterpart exists before marking parity complete.
