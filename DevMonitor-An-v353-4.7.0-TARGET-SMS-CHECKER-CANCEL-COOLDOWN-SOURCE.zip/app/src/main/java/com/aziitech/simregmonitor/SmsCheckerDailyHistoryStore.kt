package com.aziitech.simregmonitor

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

/** A menu-specific, append-only history of completed SMS Checker enquiries. */
data class SmsCheckerHistoryEvent(
    val activityDate: String,
    val completedAt: Long,
    val record: QueryRecord
)

class SmsCheckerDailyHistoryStore(
    context: Context,
    databaseName: String
) : SQLiteOpenHelper(context.applicationContext, databaseName, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE sms_checker_daily_results (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "activity_date TEXT NOT NULL," +
                "code TEXT NOT NULL," +
                "completed_at INTEGER NOT NULL," +
                "record_json TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_sms_history_date ON sms_checker_daily_results(activity_date, completed_at DESC)")
        db.execSQL("CREATE INDEX idx_sms_history_code ON sms_checker_daily_results(code, completed_at DESC)")
        db.execSQL("CREATE TABLE sms_checker_history_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
    }

    init {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM sms_checker_daily_results WHERE id NOT IN (SELECT MAX(id) FROM sms_checker_daily_results GROUP BY activity_date, UPPER(code))")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sms_history_one_daily_result ON sms_checker_daily_results(activity_date, code)")
            pruneOldMonths(db)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // This database is intentionally isolated from the live checker stores.
        // Future schema changes must preserve existing history rows.
    }

    /** Store only completed outcomes; intermediate SENDING/WAITING states are not history events. */
    /** Keep exactly one latest completed SMS result per device and local calendar date. */
    fun recordCompleted(record: QueryRecord, completedAtOverride: Long = record.completedAt) {
        if (record.status !in setOf(
                AttemptStatus.SUCCESS, AttemptStatus.NOT_FOUND, AttemptStatus.TIMEOUT,
                AttemptStatus.SEND_FAILED, AttemptStatus.UNRECOGNIZED
            )) return
        val timestamp = completedAtOverride.takeIf { it > 0L } ?: System.currentTimeMillis()
        val activityDate = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        val code = canonicalDeviceCode(record.code)
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("sms_checker_daily_results", "activity_date=? AND UPPER(code)=?",
                arrayOf(activityDate, code.uppercase(java.util.Locale.US)))
            db.execSQL(
                "INSERT INTO sms_checker_daily_results(activity_date,code,completed_at,record_json) VALUES(?,?,?,?)",
                arrayOf(activityDate, code, timestamp, recordToJson(record).toString())
            )
            pruneOldMonths(db)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Import the limited legacy success/not-found log once, without duplicating it on later launches. */
    fun migrateLegacyHistoryOnce(legacyHistory: List<HistoryRecord>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS sms_checker_history_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
            val alreadyMigrated = db.rawQuery(
                "SELECT value FROM sms_checker_history_meta WHERE key='legacy_history_migrated'",
                null
            ).use { it.moveToFirst() && it.getString(0) == "1" }
            if (!alreadyMigrated) {
                legacyHistory.sortedBy { it.completedAt }.forEach { item ->
                    val record = item.record
                    if (record.status !in setOf(AttemptStatus.SUCCESS, AttemptStatus.NOT_FOUND)) return@forEach
                    val timestamp = item.completedAt.takeIf { it > 0L } ?: record.completedAt
                    val activityDate = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                    val code = canonicalDeviceCode(record.code)
                    db.delete("sms_checker_daily_results", "activity_date=? AND UPPER(code)=?",
                        arrayOf(activityDate, code.uppercase(java.util.Locale.US)))
                    db.execSQL(
                        "INSERT INTO sms_checker_daily_results(activity_date,code,completed_at,record_json) VALUES(?,?,?,?)",
                        arrayOf(activityDate, code, timestamp, recordToJson(record).toString())
                    )
                }
                db.execSQL("INSERT OR REPLACE INTO sms_checker_history_meta(key,value) VALUES('legacy_history_migrated','1')")
            }
            pruneOldMonths(db)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Available dates in descending order; retention is the current and immediately previous calendar month. */
    fun availableDates(): List<String> {
        pruneOldMonths(writableDatabase)
        val out = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT DISTINCT activity_date FROM sms_checker_daily_results ORDER BY activity_date DESC",
            null
        ).use { cursor -> while (cursor.moveToNext()) out.add(cursor.getString(0)) }
        return out
    }

    /** All completed checks made on one date, newest first. Rechecks remain separate events. */
    fun recordsForDate(date: String): List<SmsCheckerHistoryEvent> = queryEvents(
        "activity_date=?",
        arrayOf(date)
    )

    /** Permanently remove all daily SMS history rows for the supplied device/trade codes. */
    fun deleteCodes(codes: Set<String>) {
        val normalized = codes.map { canonicalDeviceCode(it).uppercase(java.util.Locale.US) }.filter { it.isNotBlank() }.toSet()
        if (normalized.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            normalized.forEach { code ->
                db.delete("sms_checker_daily_results", "UPPER(code)=?", arrayOf(code))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Rename a device key in its history, retaining the newest result if the destination already has that day. */
    fun renameCode(oldCode: String, newCode: String) {
        val oldKey = canonicalDeviceCode(oldCode).uppercase(java.util.Locale.US)
        val newKey = canonicalDeviceCode(newCode)
        val newUpper = newKey.uppercase(java.util.Locale.US)
        if (oldKey.isBlank() || newUpper.isBlank() || oldKey == newUpper) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val rows = mutableListOf<Triple<String, Long, String>>()
            db.rawQuery(
                "SELECT activity_date,completed_at,record_json FROM sms_checker_daily_results WHERE UPPER(code)=?",
                arrayOf(oldKey)
            ).use { cursor ->
                while (cursor.moveToNext()) rows.add(Triple(cursor.getString(0), cursor.getLong(1), cursor.getString(2)))
            }
            rows.forEach { (date, completedAt, jsonText) ->
                val existing = db.rawQuery(
                    "SELECT completed_at FROM sms_checker_daily_results WHERE activity_date=? AND UPPER(code)=?",
                    arrayOf(date, newUpper)
                ).use { cursor -> if (cursor.moveToFirst()) cursor.getLong(0) else null }
                if (existing == null || completedAt >= existing) {
                    val recordJson = JSONObject(jsonText).put("code", newKey).toString()
                    db.delete("sms_checker_daily_results", "activity_date=? AND UPPER(code)=?",
                        arrayOf(date, newUpper))
                    db.execSQL(
                        "UPDATE sms_checker_daily_results SET code=?,record_json=? WHERE activity_date=? AND UPPER(code)=?",
                        arrayOf(newKey, recordJson, date, oldKey)
                    )
                } else {
                    db.delete("sms_checker_daily_results", "activity_date=? AND UPPER(code)=?",
                        arrayOf(date, oldKey))
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Latest saved result for each device/date in the retained two-month window. */
    fun allDailySnapshots(): List<SmsCheckerHistoryEvent> {
        pruneOldMonths(writableDatabase)
        val out = mutableListOf<SmsCheckerHistoryEvent>()
        readableDatabase.rawQuery(
            "SELECT activity_date,completed_at,record_json FROM sms_checker_daily_results ORDER BY activity_date ASC,code ASC",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                runCatching {
                    SmsCheckerHistoryEvent(
                        cursor.getString(0), cursor.getLong(1),
                        jsonToRecord(JSONObject(cursor.getString(2)))
                    )
                }.getOrNull()?.let(out::add)
            }
        }
        return out
    }

    /** All completed checks for one device/partner code during the retained two-month window. */
    fun recordsForCode(code: String): List<SmsCheckerHistoryEvent> = queryEvents(
        "UPPER(code)=?",
        arrayOf(canonicalDeviceCode(code).uppercase(java.util.Locale.US))
    )

    private fun queryEvents(selection: String, args: Array<String>): List<SmsCheckerHistoryEvent> {
        val out = mutableListOf<SmsCheckerHistoryEvent>()
        readableDatabase.rawQuery(
            "SELECT activity_date,completed_at,record_json FROM sms_checker_daily_results WHERE $selection ORDER BY completed_at DESC,id DESC",
            args
        ).use { cursor ->
            while (cursor.moveToNext()) {
                runCatching {
                    SmsCheckerHistoryEvent(
                        cursor.getString(0),
                        cursor.getLong(1),
                        jsonToRecord(JSONObject(cursor.getString(2)))
                    )
                }.getOrNull()?.let(out::add)
            }
        }
        return out
    }

    private fun pruneOldMonths(db: SQLiteDatabase) {
        val cutoff = YearMonth.now().minusMonths(1).atDay(1).toString()
        db.delete("sms_checker_daily_results", "activity_date<?", arrayOf(cutoff))
    }

    private fun resultToJson(result: SimRegResult) = JSONObject()
        .put("code", result.code)
        .put("type", result.type.name)
        .put("receivedAt", result.receivedAt)
        .put("today", result.today)
        .put("mtd", result.mtd)
        .put("active", result.active)
        .put("bar48", result.bar48)
        .put("bar96", result.bar96)
        .put("duplicates", result.duplicates)
        .put("monthlyTarget", result.monthlyTarget)
        .put("status", result.status.name)
        .put("raw", result.raw)

    private fun jsonToResult(json: JSONObject) = SimRegResult(
        json.optString("code"),
        runCatching { QueryType.valueOf(json.optString("type")) }.getOrDefault(QueryType.UNKNOWN),
        json.optString("receivedAt"),
        optionalInt(json, "today"),
        optionalInt(json, "mtd"),
        optionalInt(json, "active"),
        optionalInt(json, "bar48"),
        optionalInt(json, "bar96"),
        optionalInt(json, "duplicates"),
        optionalInt(json, "monthlyTarget"),
        runCatching { AttemptStatus.valueOf(json.optString("status")) }.getOrDefault(AttemptStatus.UNRECOGNIZED),
        json.optString("raw")
    )

    private fun recordToJson(record: QueryRecord) = JSONObject()
        .put("code", record.code)
        .put("type", record.type.name)
        .put("attempt", record.attempt)
        .put("repetitionsSent", record.repetitionsSent)
        .put("responseCount", record.responseCount)
        .put("status", record.status.name)
        .put("error", record.error)
        .put("firstAttemptStatus", record.firstAttemptStatus?.name)
        .put("completedAt", record.completedAt)
        .put("result", record.result?.let(::resultToJson))

    private fun jsonToRecord(json: JSONObject) = QueryRecord(
        json.optString("code"),
        runCatching { QueryType.valueOf(json.optString("type")) }.getOrDefault(QueryType.UNKNOWN),
        json.optInt("attempt", 1),
        json.optInt("repetitionsSent", 0),
        json.optInt("responseCount", 0),
        runCatching { AttemptStatus.valueOf(json.optString("status")) }.getOrDefault(AttemptStatus.QUEUED),
        json.optJSONObject("result")?.let(::jsonToResult),
        json.optString("error").takeIf { it.isNotBlank() && it != "null" },
        json.optString("firstAttemptStatus").takeIf { it.isNotBlank() }?.let {
            runCatching { AttemptStatus.valueOf(it) }.getOrNull()
        },
        json.optLong("completedAt", System.currentTimeMillis())
    )

    private fun optionalInt(json: JSONObject, key: String): Int? =
        if (json.isNull(key)) null else json.optInt(key)

    companion object {
        private const val DATABASE_VERSION = 1
    }
}
