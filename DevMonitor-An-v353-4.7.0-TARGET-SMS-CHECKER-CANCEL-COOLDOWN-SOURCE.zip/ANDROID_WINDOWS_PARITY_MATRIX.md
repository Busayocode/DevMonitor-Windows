# Android / Windows Feature Parity Matrix — Android v309 / Windows current source (2026-10-23)

## Android v310 — Agent list photo thumbnail (2026-10-23)
- Added the saved agent's photo thumbnail to each agent card on the main Agents & Partners menu, alongside name, address and linked-device details.
- Added a consistent avatar placeholder when no photo is saved or the saved photo file is unavailable, so every list entry has a visible photo area.
- Uses the same app-private `photoPath` as Add/Edit; no duplicate photo storage or new permissions are introduced.
- Preserves the working OpenStreetMap picker and contact-photo preview/import workflow. No payment calculations, MOM snapshots, HQ activation snapshots, target rules, or device-link rules were intentionally changed.
- Validation: source inspection and ZIP integrity; Android compilation and phone runtime must still be confirmed by GitHub Actions/device test.

## Android v309 compile correction
- Added the missing Compose `clip` import required by the v308 agent photo thumbnail preview. No Windows source changes or business-logic changes are included in this Android-only compile correction.
- Agent records and device associations remain Android-authoritative.


## Agent workflow follow-up
- Android remains authoritative for agent records and device associations. Main agent list refreshes immediately after agent mutations.
- Contact import previews individual phone/email values, attempts contact-photo import using both provider photo stream and PHOTO_URI fallback, then opens agent details for completion when creating a new record.
- Agent email entry and device linking are in the same scrollable Add/Edit Agent form. Every available My Devices code must be reachable; no 250-row cap. Save synchronizes selected links.
- Windows remains a synced display of Android-owned agent/contact/link data; no parallel agent CRUD added.
- Protected payment engine/rules, MOM snapshots, HQ activation snapshots, target rules and report authority remain unchanged.
- Build/runtime verification pending.

---

# Android / Windows Feature Parity Matrix — Android v302 / Windows v286 (2026-10-22)

## Agent data ownership and OpenStreetMap pin selection
- Android is authoritative for agent records and device associations. Windows only receives/displays synced agent details and linked device state; do not build a parallel native agent CRUD workflow.
- Android single-contact import includes a review/merge step. Multi-contact batch import is deferred by explicit user decision.
- Android location picker uses OpenStreetMap/osmdroid: tap or long-press to place pin, drag to refine, confirm coordinates into the editor, then explicitly save the agent. Postal address is a separate field.
- No Google Maps API key or Google Maps billing setup is required for the pin picker. Map tiles require internet and OpenStreetMap attribution is displayed; tile service use remains subject to its usage policy.
- Windows displays synced names, addresses, phones, emails and device links. Android-local photo paths are not image payloads and must not be treated as portable photos.
- Payment engine/rules/cards and MOM physical DB/snapshot behavior remain protected.
- Source/ZIP checks only; build/runtime verification pending.

---

# Android / Windows Feature Parity Matrix — v295 / Windows v281 (2026-10-21)

## Monthly target delivery forecast (current requirement)
- Both platforms show only the current calendar month against the active profile's configured target.
- Neutral figures only: monthly target, delivered so far, projected month-end at the observed daily rate, target achieved percentage, and remaining target balance.
- Do not display management verdicts or pressure-inducing status labels: no “on track”, “at risk”, red shortfall warnings, or equivalent judgement text.
- Daily sales lists/charts include only recorded observation dates; missing dates are not treated as zero sales.
- Data retention remains two calendar months. Do not expand retention to support trends.
- Projection uses cumulative current-month delivered sales / latest observed calendar day × days in the current month. It is an estimate, not a guarantee.
- Preserve the existing profile/ownership target scoping and agent fixed target of 150 where applicable.
- Payment engine/rules, payment card logic, MOM physical databases/snapshots, report import authority and cutoff rules are protected and unchanged.

## v294 source status
- Android source updated to v294; build/device verification pending.
- Windows source updated to v280; build/runtime verification pending.
- Cross-platform parity is source-level only until both builds and real imported-data comparisons are tested.

---

# Android / Windows Feature Parity Matrix — v293 (2026-10-21)

Purpose: keep phone and Windows-native DevMonitor implementations aligned on product behaviour, not just labels. Update this document alongside `MASTER_WORK_SHEET.md`, `CHANGE_LOG.md`, `NEXT_LEVEL_ROADMAP.md`, and `NEXT_LEVEL_TRACKER.md` for cross-platform changes.

| Feature / contract | Android | Windows native | Acceptance rule |
|---|---|---|---|
| Trend period | Current calendar month vs target | Current calendar month vs target | No 7/30-day or 6/12-month selector; neutral target figures only; no management verdicts. |
| Monthly target forecast | Current calendar month only; no 6/12-month selector | Same neutral monthly target forecast | Show target, sales so far, projected month-end sales, target achieved percentage, and remaining balance only; no management verdicts or risk labels. |
| Forecast basis | Current-month sales delivered to date divided by elapsed days, projected through the current month end | Same forecast basis | Label as an estimate; do not add historical comparisons or synthesize missing observations as zero. |
| Scope and retention | Current calendar month only | Same scope | Existing two-month data retention remains unchanged. |
| Active total | Latest observed active snapshot within each month | Same aggregation | Do not sum daily active snapshots into a monthly total. |
| Refresh | Explicit user action | Explicit user action | Profile navigation/import must not silently trigger expensive trend recalculation. |
| Protected logic | Payment rules, payment-cycle boundaries, MOM/HQ storage and report authority unchanged | Same protected contracts | Trend implementation must not modify payment or MOM business logic. |
| Documentation | Master sheet, changelog, roadmap, tracker and this matrix | Same shared contract | Mark platform implementation/test status separately; do not claim parity until both builds are verified. |

## v293 Android status

- Source implementation updated to calendar-month aggregation and same-period month-on-month sales comparison.
- Source ZIP integrity and targeted source assertions passed.
- Android Gradle build/device verification: pending.
- Windows-native implementation/build parity: not verified in this Android source package; the Windows project must implement and test the same acceptance rules before parity is marked complete.

## Package naming rule and monthly target forecast — ANDROID v294

- Required filenames place `An` (Android) or `PC` (Windows native) immediately before the version number.
- GitHub Actions workflow remains unchanged by this naming convention.
- Forecast labels are neutral only; no management verdicts or pressure-inducing status labels.
- Build and runtime status must be recorded separately for each platform.


## AI voice and notification sounds (planned)
- Android v295 and Windows v281 must share event categories: important actionable alerts and user-requested task completions only.
- Both platforms should support spoken announcement and futuristic sound effects independently, plus preview/mute and safe fallback.
- No announcements for routine progress/background events; do not speak sensitive report/device/payment details.
- Status: plan documented; implementation and cross-platform tests pending.


## AI voice notification parity — finalized audio approach

- Both platforms bundle and play the same fixed pre-rendered alert and task-completion WAVs; neither relies on device speech synthesis.
- Only warning/error alerts and explicit completed tasks announce; ordinary info/progress notices remain silent.
- Audio is non-blocking/best-effort and must not trigger data refreshes or alter payment, MOM, HQ/report, or retention behavior.
- Android and Windows build/device verification is still pending.

## Agents, linked devices and card personalization — Android v299 / Windows v284

| Capability | Android v299 | Windows/PC v284 | Status |
|---|---|---|---|
| Agent ↔ My Devices relationship | Existing saved link/unlink retained and surfaced in agent details | Existing relationship archive and partner/device summary retained | Existing support; source/runtime verification pending |
| Multiple phone numbers and labels | Contact picker imports multiple values; duplicate values skipped | Retained in synced Android archive | Partial parity |
| Multiple email addresses and labels | New local table; add/remove UI; contact import; sync export | New family accepted and retained in archive | Partial parity |
| Contact thumbnail | Copies to app-private storage if no photo already exists; used by Android share card | Android-local file path is not portable; native PC photo support not implemented | Android-only in this increment |
| Personalized device share card | Linked agent name, local photo if available, first phone number | Existing queued cards and linked-agent name remain; native photo personalization not implemented | Partial parity |
| Contact preview/merge, edit/clear photo, saved map-pin picker | Not yet implemented in this increment | Not yet implemented | Outstanding |
| Payment and MOM rules | Unchanged by design | Unchanged by design | Protected |

Do not mark full Agents parity complete until the outstanding rows are implemented and both builds/runtime workflows are verified.

## Agents database follow-up (2026-10-22, v300 / PC v285)
- Shared: agent email rows are synchronized and shown on Windows; Android now offers replace/clear for saved agent photos, a contact review/merge step with editable name/address, labeled phone/email preview and duplicate skipping, plus address-to-coordinate lookup with explicit save.
- Android-specific: contact photo import is offline after copying to app-private storage; replace/clear is available from the Agents database.
- Still not parity-complete: multi-contact selection in one import session, tap/move map pin and return-to-app save, Windows native contact/photo editing, image-byte transfer, and PC-side personalized image cards.
- Photo `photo_path` values are Android-local file paths, not image content. Windows must not attempt to open those paths as if they were PC paths.

## Android v304 agent workflow correction
Android remains authoritative for agent records. Agent list refreshes immediately on opening; contact import is available before saving a new record and preserves existing links on merge. OpenStreetMap uses app-local tile cache configuration without a Google Maps API key.

## Android v305 Agents workflow refinement (2026-10-23)
- Android contact review supports per-number selection before import; only checked phone numbers are saved. Windows-native equivalent is not claimed.
- Agents menu uses an explicit saved-record list and separates details/device linking from secondary edit/contact/photo/delete actions.
- Map action label is **Select location on map**. `ACCESS_NETWORK_STATE` was added to support osmdroid network handling; map tile rendering remains pending physical-device verification.

## Event-driven sync update — 2026-10-24

| Capability | Android | Windows PC | Status |
|---|---|---|---|
| Change-triggered sync | SQLite/WAL observer + operational fingerprint; PC `/events` listener | SQLite/WAL file watcher + `/events` long-poll endpoint | Implemented in source; compile/device verification pending |
| Recovery fallback | 5-second sync while Next Level screen is active; existing retry/backoff retained | Bridge must remain running | Keep fallback at 5 seconds until reliability tests pass |
| Protected data | HQ snapshots/targets and payment/MOM calculations excluded from sync projection | HQ/payment tables are not merged by bridge | Must remain excluded |


## Android v337 compile correction (2026-11-04)
- Corrected the stale `return@forEachIndexed` in the SMS Checker sequential queue's `while` loop to `continue`, allowing the queue to advance after an SMS send failure.
- Android versionCode: 337. Windows source/build unchanged.
- Payment/MOM logic and SMS query parameters remain protected.
- Validation: source review and ZIP integrity; GitHub Actions Android + Windows builds pending.

## Android v338 — SMS Checker daily history

| Capability | Android v338 | Windows/PC | Status |
|---|---|---|---|
| Separate Device Monitor daily history database | `sms_checker_devices_history.db` | Not assessed in this increment | Android source added; build/device test pending |
| Separate My Partners daily history database | `sms_checker_partners_history.db` | Not assessed in this increment | Android source added; build/device test pending |
| Current + previous calendar month retention | Implemented in Android history store | Not assessed | Android source added; test month rollover |
| Whole-day report and per-code history | Date selection shows latest daily result per code; per-code view retains all completed rechecks | Not assessed | Android source added; UI/device test pending |
| Legacy history migration | Imports existing successful/not-found entries once per menu | Not assessed | Limited to records already present in legacy history |
| Cloud backup of history DBs | Not included in existing single-database Drive backup | Not assessed | Separate follow-up |

Do not mark cross-platform parity complete until Windows capability is checked and any applicable implementation is built and tested. Payment/MOM calculations and SMS query behavior remain protected.
