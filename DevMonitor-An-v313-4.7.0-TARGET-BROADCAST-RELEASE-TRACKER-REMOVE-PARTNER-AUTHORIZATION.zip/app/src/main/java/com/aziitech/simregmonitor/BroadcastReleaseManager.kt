package com.aziitech.simregmonitor

import android.content.Context
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.Timestamp
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.util.Date

/** Cloud broadcast delivery and per-release What's New tracking. Public reads; writes are guarded by Firestore rules. */
data class DevMonitorBroadcast(
    val message: String,
    val placement: String,
    val active: Boolean,
    val expiresAtMillis: Long,
    val updatedAtMillis: Long
)

class BroadcastReleaseManager(private val context: Context) {
    private val db get() = FirebaseFirestore.getInstance()

    suspend fun activeBroadcast(): DevMonitorBroadcast? = runCatching {
        val snap = db.collection("app_config").document("devmonitor_broadcast").get().await()
        val data = snap.data ?: return@runCatching null
        val message = data["message"]?.toString().orEmpty().trim()
        val active = data["active"] as? Boolean ?: false
        val expiry = (data["expiresAt"] as? Timestamp)?.toDate()?.time ?: 0L
        if (!active || message.isBlank() || (expiry > 0L && expiry <= System.currentTimeMillis())) return@runCatching null
        DevMonitorBroadcast(message, data["placement"]?.toString()?.uppercase() ?: "TOP", true, expiry,
            (data["updatedAt"] as? Timestamp)?.toDate()?.time ?: 0L)
    }.getOrNull()

    suspend fun publishBroadcast(message: String, placement: String, expiryDays: Int) {
        require(message.trim().isNotEmpty()) { "Enter a message first." }
        require(message.trim().length <= 500) { "Messages must be 500 characters or fewer." }
        val expiry = Timestamp(Date(System.currentTimeMillis() + expiryDays.coerceIn(1, 30) * 86_400_000L))
        db.collection("app_config").document("devmonitor_broadcast").set(mapOf(
            "message" to message.trim(), "placement" to placement.uppercase(), "active" to true,
            "expiresAt" to expiry, "updatedAt" to FieldValue.serverTimestamp(),
            "updatedBy" to (com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "")
        ), SetOptions.merge()).await()
    }

    suspend fun stopBroadcast() {
        db.collection("app_config").document("devmonitor_broadcast").set(mapOf(
            "active" to false, "updatedAt" to FieldValue.serverTimestamp()
        ), SetOptions.merge()).await()
    }

    /** Release notes are generated from version/change documentation during the build. */
    fun bundledReleaseNotes(): List<String> = runCatching {
        val raw = context.assets.open("release_notes.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        if (root.optLong("versionCode") != BuildConfig.VERSION_CODE.toLong()) return@runCatching emptyList()
        val items = root.optJSONArray("highlights") ?: return@runCatching emptyList()
        (0 until items.length()).map { items.optString(it).trim() }.filter { it.isNotBlank() }.take(12)
    }.getOrDefault(emptyList())

    suspend fun remoteReleaseNotes(versionCode: Long): List<String> = runCatching {
        val snap = db.collection("app_releases").document(versionCode.toString()).get().await()
        val data = snap.data ?: return@runCatching emptyList()
        val items = data["highlights"] as? List<*> ?: return@runCatching emptyList()
        items.mapNotNull { it?.toString()?.trim()?.takeIf(String::isNotBlank) }.take(12)
    }.getOrDefault(emptyList())

    suspend fun publishReleaseNotes(versionCode: Long, versionName: String, highlights: List<String>) {
        db.collection("app_releases").document(versionCode.toString()).set(mapOf(
            "versionCode" to versionCode, "versionName" to versionName,
            "highlights" to highlights.take(12), "publishedAt" to FieldValue.serverTimestamp(),
            "publishedBy" to (com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "")
        ), SetOptions.merge()).await()
    }
}
