# v231 — Connection icon and Android system notifications

- Starting point: DevMonitor Android v230 Library source package.
- Removed the persistent connection banner and added a compact state icon beside the notification bell. Tapping opens Next Level connection details; sync controls remain in Next Level > Health.
- Mirrored locally created in-app notifications to Android system notifications, including channel creation, expanded message text, and tap-to-open.
- Added POST_NOTIFICATIONS permission for Android 13+.
- Version code advanced to 231.
- Payment calculations were not modified.
- Not locally compiled; validate in GitHub Actions and test on a physical Android device.
