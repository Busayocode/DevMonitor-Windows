# v240 — My Partner in-menu SMS flow

- Advanced Android versionCode to 240.
- Fixed the My Partner “Check by SMS” action so it no longer closes My Partner or switches to the main SMS Checker tab before the SIM selection overlay.
- Partner summary requests continue to use the selected partner trade code and write their check result to the separate `my_partner.db` history.
- Earnings card visuals and payment calculation logic were not changed.

## Verification
ZIP integrity and source assertions are checked when packaging. Android compilation and physical-device SMS flow have not been verified in this environment. This is a targeted flow fix, not yet the full implementation of all eight requested partner actions.
