# DevMonitor 4.6.0-NEXT v237 — App-wide Android notification delivery fix

- Retains the existing in-app notification inbox and event triggers.
- Queues the first notification when Android permission is requested and posts it after permission grant.
- Adds a Test alert action to Notifications & Inbox for immediate delivery verification.
- Android permission and device notification settings remain authoritative.
- No payment logic or business calculations changed.
- ZIP integrity checked; Android build and on-device delivery are not yet verified.
