# DevMonitor 4.6.0-NEXT v235 — My Partner visibility fix

## Issue
The My Partner entry existed only in the navigation drawer and was gated by a strict active-profile user-type lookup. This could make the new feature difficult to discover or hide it if the profile value was temporarily blank.

## Fix
- Added a dedicated My Partner dashboard card for staff.
- Resolved staff status from the active profile first, then falls back to the persisted My Devices user type if the profile type is blank.
- Card opens the existing My Partner management dialog and reloads the active profile's partner list.
- Partner records remain profile-scoped and separate from My Devices.
- No payment formulas or payment calculations changed.

## Verification
Source edits and ZIP integrity can be checked locally; an Android Gradle build still needs to run in GitHub Actions.
