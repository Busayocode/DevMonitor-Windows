# DevMonitor Android v230 — Earnings flier, reach-step messages, and connection status

- Refines the earnings-card direction toward a promotional flier: branded hierarchy, prominent amount, source/period context, and a dedicated reach-step encouragement band.
- Replaces repeated generic encouragement with copy selected from the existing activation/reach-step thresholds. Thresholds only choose wording; they do not change payment calculations or category assignment.
- Preserves exact selected-source figures and the existing no-source-mixing behavior.
- Retains the v229 PC–Android connection-status work.
- Master work sheet and change log updated.
- Validation: source edits and ZIP structure checked; Android compilation/device rendering not run in this environment.
