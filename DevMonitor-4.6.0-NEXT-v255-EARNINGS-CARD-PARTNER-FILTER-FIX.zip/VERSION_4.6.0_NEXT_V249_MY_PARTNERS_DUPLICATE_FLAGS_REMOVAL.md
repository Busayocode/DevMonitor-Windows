# DevMonitor 4.6.0-NEXT v249 — My Partners Duplicate Flags Control Removal

- Removed the duplicate in-content Flags chip from the My Partners screen.
- Kept the global Flags Centre button in the app bar, alongside the existing top-right controls.
- Preserved the Flags chip in the original Device Monitor screen; no original SMS Checker behavior was intentionally changed.
- Advanced Android versionCode from 248 to 249.
- No payment logic, database schema, or checker behavior changed.

Verification: source-level conditional and ZIP integrity checked. A full Android build/device test was not available in this environment.
