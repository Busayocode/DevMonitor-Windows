# DevMonitor 4.6.0-NEXT v243 — SMS Checker 2

Adds a separate **SMS Checker 2** item in the navigation drawer. It opens the same complete SMS Checker experience as the original entry, including device-code input, list management, Quick Check, permission flow, Zero Devices when available, Excel loading, saved/archived lists, run progress and results.

The original menu remains. Both entries share the existing SMS Checker engine and result store to avoid changing payment logic or introducing divergent behavior. My Partner remains removed.

Version code: 243. Android build and device testing have not been run in this package preparation.
