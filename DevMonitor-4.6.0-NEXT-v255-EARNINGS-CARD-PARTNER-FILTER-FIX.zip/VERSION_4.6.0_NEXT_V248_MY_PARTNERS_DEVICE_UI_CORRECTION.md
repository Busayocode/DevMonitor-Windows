# DevMonitor v248 — My Partners device-control and wording correction (2026-10-14)

- Hardened the My Partners route so the Zero Devices action is explicitly blocked while My Partners is active; its original Device Monitor behavior remains available.
- Guarded the My Devices setup action so it cannot launch from My Partners. The partner empty state remains partner-specific and has no setup action.
- Updated partner-code input examples to use partner/trade identifiers (PT-001, TRADE-2048), with explanatory text specifically describing partner Trade Codes.
- Updated the results heading to “My Partners Result” and made Quick Check progress text refer to partner codes rather than devices.
- Preserved the isolated `sms_checker_2.db`, staff-only visibility rules, original SMS Checker/Device Monitor actions, and payment calculations.
- Advanced Android `versionCode` from 247 to 248; `versionName` remains `4.6.0-NEXT`.
- Verification: source assertions and ZIP integrity only; compilation and on-device UI validation remain pending.
