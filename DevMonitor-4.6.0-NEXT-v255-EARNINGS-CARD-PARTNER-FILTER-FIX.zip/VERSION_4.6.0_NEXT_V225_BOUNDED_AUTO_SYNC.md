# DevMonitor 4.6.0-NEXT v225 — Bounded Phone/PC Auto-Sync

## Implemented
- While the Phone ↔ PC Sync Bridge screen is active and valid endpoint/pairing details are saved, attempt automatic sync.
- Retry policy: one initial attempt plus up to five retries per cycle, with 2, 5, 10, 20 and 30-second backoff delays.
- After a failed cycle, wait five minutes before the next reachability/sync attempt.
- After a successful exchange, repeat sync every 30 seconds while the screen remains active.
- UI status reports reconnecting, connected/auto-sync active, or standby.

## Explicit limitation
This is not an always-on Android background service. Android may suspend the loop when the app is backgrounded or the screen is left. Background continuous sync requires a separately implemented and appropriately disclosed foreground service or OS-scheduled work strategy. Windows must keep its local bridge running for direct LAN sync.

## Preserved boundaries
HQ monthly snapshots, imported HQ reports, and payment records are excluded from sync. Payment calculation, payment-cycle, and report-import logic are unchanged.

## Verification
Source ZIP integrity checked after packaging. Gradle build, live LAN pairing, disconnect/reconnect, duplicate handling and offline catch-up still require GitHub Actions/device testing.
