# DevMonitor 4.6.0-NEXT v252 — My Partners live loaded-report search

## Fix
My Partners now queries the persisted HQ report tables directly whenever the search text changes. This removes the dependency on an in-memory partner list loaded only when the My Partners screen opens, which could be stale or empty if the report was loaded/refreshed later.

## Behaviour
- Search by partner/channel-partner name or Trade Code.
- Results are collapsed by Trade Code so multiple devices belonging to one partner do not produce repeated entries.
- Selecting a match adds its official Trade Code to the My Partners input and keeps its freshly queried metadata available for the result card.
- Adds partner-name and Trade-Code indexes and upgrades existing monthly HQ databases without clearing their report data.

## Preservation
The original SMS Checker, payment formulas, estimates, thresholds, and HQ snapshot replacement rules are unchanged.

## Validation status
ZIP/source and database-query checks are required before release. Kotlin compilation and physical-device testing have not yet been verified in this environment.
