# DevMonitor 4.6.0-NEXT v224 — Analytics + Phone/PC Sync Bridge Continuation

## Package identity
- Android `versionCode`: `224` (advanced from 222 to remove ambiguity).
- Android `versionName`: `4.6.0-NEXT`.
- Package: `com.aziitech.simregmonitor`.

## Carried-forward features
- Carries forward the v222 Firebase Analytics / Crashlytics integration and app-version/update-check instrumentation.
- Carries forward the v218-v221 encrypted, explicitly user-triggered Phone ↔ PC Sync Bridge, extended operational archive families, and bridge tombstone handling.
- Keeps existing analytics event parameters categorical and excludes operational identifiers and payment values from the explicitly authored analytics events.

## Protected logic
- No payment calculation, payment-cycle boundary, HQ report import, Month-on-Month formula, or sync payload contract was intentionally changed for this version increment.
- The sync bridge remains user-triggered; this note does not claim complete feature parity or automatic/background sync.
- Windows-native analytics parity is not included in this Android-only source package and must be merged against the current Windows project separately.

## Build workflow compatibility
- This ZIP contains a Gradle Android project at its root, including `gradlew`, `settings.gradle.kts`, `app/build.gradle.kts`, and `.github/workflows/android-build.yml`.
- The existing Android release workflow can extract the project and locate its Gradle wrapper. Its signed-release job still requires the repository secrets documented in that workflow (release keystore/passwords, key alias/password, and Drive report API key).
- A valid ZIP and source-level checks do not establish that the APK compiles. The GitHub Actions build must pass before calling this build-verified.

## Validation checklist
- [x] Incremented Android versionCode to 224.
- [x] Confirmed Gradle wrapper and app module are present at the project root.
- [x] Confirmed Firebase Analytics and Crashlytics dependencies and bridge client source are present.
- [ ] Full Gradle release build and APK signing verification in GitHub Actions.
- [ ] Runtime test of Android ↔ Windows pairing, merge conflicts, and deletion tombstones.
- [ ] Review Firebase Analytics / Crashlytics collection, access, and retention before public release.


## v224 hotfix
- Fixed root Gradle Kotlin DSL configuration: Firebase Crashlytics plugin declaration is inside the root `plugins {}` block.
- Advanced Android `versionCode` to 224 to distinguish the corrected package from v223.
- No payment calculation or report-import logic changes.
