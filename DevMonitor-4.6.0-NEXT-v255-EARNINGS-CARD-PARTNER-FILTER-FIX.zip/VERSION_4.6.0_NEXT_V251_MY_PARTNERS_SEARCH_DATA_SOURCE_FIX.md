# v251 — My Partners search data-source fix

- Fixed My Partners partner lookup to search the full loaded HQ/company partner directory (`CompanyActivationStore.latestDeviceScopeRows`) rather than `importedSimRegReport`, which is scoped to the active My Devices list and may be null or omit unrelated partners.
- Loads the directory asynchronously when My Partners opens and resets the lookup query on entry.
- Partner result cards now resolve full partner name, Trade Code, cluster, region and territory from the same loaded company directory.
- Search matches partner name and Trade Code and selecting a match appends its Trade Code to the My Partners input.
- Original SMS Checker screen and payment calculations are unchanged.
- Version code advanced to 251; version name remains 4.6.0-NEXT.
- Validation: source and ZIP integrity checks only. Kotlin compilation and on-device search testing are pending.
