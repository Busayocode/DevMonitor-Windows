# DevMonitor 4.6.0-NEXT v245 — SMS Checker selectedTab compile fix

- Moved `selectedTab` declaration before its first use in `SimRegMonitorApp`.
- Keeps SMS Check 2 routed to its separate `sms_checker_2.db` store.
- Version code: 245.
- GitHub Actions build and on-device validation are still required.
