# DevMonitor 4.6.0-NEXT v246 — My Partners dashboard refinement

- Renamed the separate SMS Checker 2 user-facing menu and screen title to **My Partners**.
- Restored the four dashboard quick-action cards that predated SMS Checker 2: SMS Checker, My Devices, Load Report, and Earning Progress.
- Added the standalone My Partners dashboard card directly above Month-on-Month Comparison (MOM).
- Kept My Partners on its existing separate `sms_checker_2.db` database. The original SMS Checker remains available and unchanged.
- Advanced Android `versionCode` to 246; `versionName` remains `4.6.0-NEXT`.
- No payment calculation or HQ report-import logic intentionally changed.

Source package ZIP integrity and source-level checks are performed; compile and device testing must be confirmed by GitHub Actions.
