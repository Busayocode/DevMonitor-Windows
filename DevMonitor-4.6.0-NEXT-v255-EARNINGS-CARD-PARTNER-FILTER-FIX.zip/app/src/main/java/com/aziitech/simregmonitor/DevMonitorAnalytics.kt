package com.aziitech.simregmonitor

import android.content.Context
import android.os.Build
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics

/** Privacy-conscious diagnostics. Event parameters must never contain operational identifiers. */
object DevMonitorAnalytics {
    private fun channel(context: Context): String {
        val installer = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getInstallerPackageName(context.packageName)
            }
        }.getOrNull().orEmpty().lowercase()
        return when {
            installer.contains("xiaomi") || installer.contains("getapps") || installer.contains("market") -> "getapps"
            installer.contains("google") || installer.contains("play") -> "play"
            else -> "website_or_sideload"
        }
    }

    fun initialize(context: Context) {
        runCatching {
            val crash = FirebaseCrashlytics.getInstance()
            crash.setCustomKey("app_version", BuildConfig.VERSION_NAME)
            crash.setCustomKey("app_version_code", BuildConfig.VERSION_CODE)
            crash.setCustomKey("android_version", Build.VERSION.RELEASE ?: "unknown")
            crash.setCustomKey("install_channel", channel(context))
            crash.setCrashlyticsCollectionEnabled(true)
            val prefs = context.getSharedPreferences("devmonitor_analytics_state", Context.MODE_PRIVATE)
            val previousVersion = prefs.getInt("last_version_code", 0)
            if (previousVersion > 0 && BuildConfig.VERSION_CODE > previousVersion) {
                log(context, "update_completed", mapOf("install_channel" to channel(context)))
            }
            prefs.edit().putInt("last_version_code", BuildConfig.VERSION_CODE).apply()
            log(context, "devmonitor_open", mapOf("install_channel" to channel(context)))
        }
    }

    fun log(context: Context, event: String, parameters: Map<String, String> = emptyMap()) {
        runCatching {
            val bundle = Bundle()
            parameters.forEach { (key, value) ->
                // Only small, non-identifying categorical values are accepted here.
                if (key.length <= 40 && value.length <= 80) bundle.putString(key, value)
            }
            FirebaseAnalytics.getInstance(context).logEvent(event.take(40), bundle)
        }
    }

    fun recordNonFatal(error: Throwable, area: String) {
        runCatching {
            FirebaseCrashlytics.getInstance().setCustomKey("error_area", area.take(60))
            FirebaseCrashlytics.getInstance().recordException(error)
        }
    }
}
