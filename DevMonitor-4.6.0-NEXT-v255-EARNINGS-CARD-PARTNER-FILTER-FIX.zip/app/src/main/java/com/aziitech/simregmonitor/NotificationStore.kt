package com.aziitech.simregmonitor

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Lightweight, profile-scoped in-app notification store. It never performs work in the background. */
data class DevMonitorNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val kind: String,
    val read: Boolean
)

object NotificationStore {
    private const val PREFS = "devmonitor_notifications"
    private const val MAX_ITEMS = 80

    private fun key(profileId: String) = "items_${profileId.ifBlank { "default" }}"

    fun list(context: Context, profileId: String): List<DevMonitorNotification> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key(profileId), "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                add(
                    DevMonitorNotification(
                        id = o.optString("id"),
                        title = o.optString("title"),
                        message = o.optString("message"),
                        timestamp = o.optLong("timestamp"),
                        kind = o.optString("kind", "info"),
                        read = o.optBoolean("read", false)
                    )
                )
            }
        }.sortedByDescending { it.timestamp }
    }.getOrDefault(emptyList())

    fun add(context: Context, profileId: String, title: String, message: String, kind: String = "info") {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = list(context, profileId).toMutableList()
        current.add(0, DevMonitorNotification(UUID.randomUUID().toString(), title, message, System.currentTimeMillis(), kind, false))
        val array = JSONArray()
        current.take(MAX_ITEMS).forEach { n ->
            array.put(JSONObject().apply {
                put("id", n.id); put("title", n.title); put("message", n.message)
                put("timestamp", n.timestamp); put("kind", n.kind); put("read", n.read)
            })
        }
        prefs.edit().putString(key(profileId), array.toString()).apply()
        postSystemNotification(context, current.first())
    }

    /** Re-post the event that originally triggered Android's permission dialog after permission is granted. */
    fun flushPendingSystemNotification(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString("pending_system_notification", null) ?: return
        val item = runCatching {
            val o = JSONObject(raw)
            DevMonitorNotification(
                id = o.optString("id"), title = o.optString("title"),
                message = o.optString("message"), timestamp = o.optLong("timestamp"),
                kind = o.optString("kind", "info"), read = o.optBoolean("read", false)
            )
        }.getOrNull() ?: return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("pending_system_notification").apply()
        postSystemNotification(context, item)
    }

    private fun postSystemNotification(context: Context, item: DevMonitorNotification) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "devmonitor_alerts"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(channelId) == null) {
            manager.createNotificationChannel(NotificationChannel(channelId, "DevMonitor alerts", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Monitoring alerts, reminders and important DevMonitor events"
            })
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Keep the event so it can be posted immediately if the user grants permission.
            val permissionPrefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            permissionPrefs.edit().putString("pending_system_notification", JSONObject().apply {
                put("id", item.id); put("title", item.title); put("message", item.message)
                put("timestamp", item.timestamp); put("kind", item.kind); put("read", item.read)
            }.toString()).apply()
            // Request once automatically. If denied, the in-app inbox remains available and Android Settings can enable alerts later.
            if (!permissionPrefs.getBoolean("post_permission_prompted", false) && context is android.app.Activity) {
                permissionPrefs.edit().putBoolean("post_permission_prompted", true).apply()
                context.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2301)
            }
            return
        }
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("devmonitor_notification_id", item.id)
        }
        val pending = PendingIntent.getActivity(context, item.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val icon = R.drawable.devmonitor_icon
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(icon)
            .setContentTitle(item.title)
            .setContentText(item.message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.message))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setCategory(when (item.kind.lowercase()) { "warning", "error" -> NotificationCompat.CATEGORY_ERROR; "reminder" -> NotificationCompat.CATEGORY_REMINDER; else -> NotificationCompat.CATEGORY_STATUS })
            .setPriority(if (item.kind.equals("warning", true) || item.kind.equals("error", true)) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(item.id.hashCode(), notification) }
    }

    /** Upsert a notification received from a paired desktop using its stable source ID. */
    fun upsertSynced(context: Context, profileId: String, incoming: DevMonitorNotification) {
        val current = list(context, profileId).toMutableList()
        val index = current.indexOfFirst { it.id == incoming.id }
        if (index >= 0) {
            val old = current[index]
            // Prefer the newer version of the same notification, including read-state changes.
            if (incoming.timestamp >= old.timestamp) current[index] = incoming
        } else current.add(incoming)
        val array = JSONArray()
        current.sortedByDescending { it.timestamp }.take(MAX_ITEMS).forEach { n ->
            array.put(JSONObject().apply {
                put("id", n.id); put("title", n.title); put("message", n.message)
                put("timestamp", n.timestamp); put("kind", n.kind); put("read", n.read)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key(profileId), array.toString()).apply()
    }

    fun deleteSynced(context: Context, profileId: String, id: String) = rewrite(context, profileId) { items -> items.filterNot { it.id == id } }

    fun markRead(context: Context, profileId: String, id: String) = rewrite(context, profileId) { it.map { n -> if (n.id == id) n.copy(read = true) else n } }

    fun markAllRead(context: Context, profileId: String) = rewrite(context, profileId) { it.map { n -> n.copy(read = true) } }

    fun clear(context: Context, profileId: String) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key(profileId)).apply()

    private fun rewrite(context: Context, profileId: String, transform: (List<DevMonitorNotification>) -> List<DevMonitorNotification>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = JSONArray()
        transform(list(context, profileId)).take(MAX_ITEMS).forEach { n ->
            array.put(JSONObject().apply {
                put("id", n.id); put("title", n.title); put("message", n.message)
                put("timestamp", n.timestamp); put("kind", n.kind); put("read", n.read)
            })
        }
        prefs.edit().putString(key(profileId), array.toString()).apply()
    }
}
