# 4.6.0-NEXT v236 — My Partner Standalone SMS Checker

- Reworked My Partner into a full-screen, SMS Checker-style workspace rather than a small add/edit dialog.
- Added loaded-report search by partner name or trade code. Selecting a match fills the partner name and trade code automatically; manual entry remains available when no match is found.
- Moved My Partner records into a dedicated SQLite database (`my_partner.db`) with profile-scoped partner lists and a separate check-history table.
- Successful, not-found, and no-response SMS partner checks are recorded in the separate My Partner database. Loaded Report partner summaries are recorded there as well.
- My Partner reads the loaded company report to find partners but does not write to My Devices, normal SMS Checker observations, or payment progression. No payment calculations, thresholds, or formulas were changed.
- Build verification: ZIP/source checks only; Android compilation and on-device testing must be confirmed by GitHub Actions.
