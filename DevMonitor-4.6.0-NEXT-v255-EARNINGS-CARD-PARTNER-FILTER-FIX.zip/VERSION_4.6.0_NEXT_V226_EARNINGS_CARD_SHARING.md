# DevMonitor 4.6.0-NEXT v226 — Earnings-card sharing

## User-facing changes
- Share an existing device payment card as a PNG from the card itself.
- Batch Share Earnings Cards from Agent / Partner Database, choosing SMS Checker or Loaded Report as the only source for the batch.
- Batch images are one per linked device; missing source figures are reported/skipped, never estimated from the other source.
- Link/unlink My Devices codes from an agent record.

## Calculation protection
This release does not add payment formulas. Individual card export uses the existing displayed IncentiveEstimate. Batch export calls the existing source-specific PaymentEngine calculator and PaymentRules estimate, with no cross-source fallback for SMS Checker batch cards. Payment-cycle boundaries, HQ import rules, and sync intervals are unchanged.

## Sharing limitation
Android opens the system share sheet for WhatsApp or another available app. User confirms recipients and sends. Silent WhatsApp sending is not implemented.

## Verification
The ZIP must be compiled through the existing GitHub Actions workflow before the build is considered verified.
