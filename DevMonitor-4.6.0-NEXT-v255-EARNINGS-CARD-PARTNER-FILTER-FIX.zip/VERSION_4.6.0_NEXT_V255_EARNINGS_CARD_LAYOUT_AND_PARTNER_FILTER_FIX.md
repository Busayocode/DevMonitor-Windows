# v255 — Earnings Card Layout and Partner Filter Fix

- Reworked the Android shareable earnings card to better match the approved flyer reference: compact branded header, agent identity row, large earnings hero, milestone progression, green encouragement panel, and branded footer.
- Fixed progress visualization to use the configured 0–300 activation scale. The next milestone is highlighted independently.
- Selecting a result in My Partners no longer writes the selected Trade Code into the separate SMS Checker partner-code filter. The filter keeps its own user-entered state.
- Payment engine, estimate figures, and source boundaries are unchanged.
- Build/visual verification remains pending in the ARM-compatible Android build environment.
