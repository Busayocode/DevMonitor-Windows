# DevMonitor 4.6.0-NEXT v250 — My Partners lookup and share cards

## Changes
- Search the loaded report by Channel Partner Name or Trade Code.
- Select a matching partner to add its official Trade Code to the My Partners code-entry list.
- Show full partner name, Trade Code, and available cluster/region/territory on My Partners result cards.
- Share an individual result as a branded PNG with partner details and latest check metrics/status.

## Scope and safeguards
- Changes are gated to My Partners (selected tab 6).
- Original SMS Checker and payment formulas are not intentionally modified.
- Keep separate `sms_checker_2.db` and existing Staff-only visibility.

## Verification
- ZIP integrity and source-level checks required. GitHub Actions compile and on-device validation are pending.
