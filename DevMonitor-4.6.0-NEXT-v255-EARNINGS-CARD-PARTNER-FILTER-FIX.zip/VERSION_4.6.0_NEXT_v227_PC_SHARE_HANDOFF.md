# Android v227 — PC-initiated share handoff

Receives PC-prepared PNG earnings/progression cards through the existing AES-GCM encrypted sync exchange. When cards arrive during an active sync, Android opens the system share sheet so the user can select WhatsApp or another installed app and confirm the recipient/send action. Card IDs are acknowledged on the next sync cycle after the share sheet is launched. Android displays the supplied PNGs only; it does not recalculate figures.

Limits: up to 20 images per transfer; individual image payload capped at 2 MB on Android; the existing bridge request size cap remains 15 MB. This is not automatic WhatsApp delivery and does not prove the recipient received a message.
