# DevMonitor 4.6.0-NEXT v247 — Staff-only My Partners refinement

- My Partners is a partner-code-only checker workspace with independent `sms_checker_2.db` storage.
- The dashboard card and drawer entry are available only after a Staff profile is successfully saved and that Staff profile is active.
- The card stays immediately above Month-on-Month Comparison (MOM); the original four quick-action cards remain restored.
- Partner-code input examples, search prompt, empty state, and result heading are partner-specific.
- Zero Devices and Open My Devices setup are not available from My Partners. Device ownership and earning-progression/payment-estimate actions are hidden in this workspace. The original Device Monitor keeps its own Zero Devices and payment features.
- The first-launch crash mentioned during feedback has not been diagnosed from a Logcat trace; source and ZIP validation cannot establish that it is fixed.
- No payment formulas or thresholds were intentionally changed.
- Android `versionCode`: 247; `versionName`: `4.6.0-NEXT`.
