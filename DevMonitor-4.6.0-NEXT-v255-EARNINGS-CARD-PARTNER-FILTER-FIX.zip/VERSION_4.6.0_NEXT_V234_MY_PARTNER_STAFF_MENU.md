# v234 — Staff-only My Partner

## Scope
- New separate My Partner menu entry shown only for a profile whose user type is STAFF.
- Each profile has its own saved partner list, independent of My Devices.
- Staff add partner name and code after profile creation. The profile setup flow does not generate partner codes.
- Check by SMS calls the existing SMS Checker permissions and `beginRun` path for that single code without adding it to My Devices.
- Loaded Report opens the existing report viewer focused on the partner code.
- Add, edit, and remove actions are available. Existing report history is not deleted when a saved partner entry is removed.
- Uses a simple SMS Checker-like list for this first iteration; bespoke performance table deferred.

## Guardrails
- No payment logic/calculations changed.
- Partner list is stored in profile-scoped app preferences and is separate from the My Devices store.
- Build/test still required in GitHub Actions and on-device, especially confirming SMS results and Loaded Report matching for real partner codes.
