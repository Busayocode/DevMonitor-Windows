# DevMonitor 4.6.0-NEXT v253 — Restore proven My Partners search path

## Change
- Restored the v239 search strategy in the current My Partners screen: query `companyActivations.latestDeviceScopeRows()` and filter rows directly as the search text changes.
- Matches partner/channel-partner name or Trade Code case-insensitively; waits until at least two characters are entered; deduplicates by normalized Trade Code; excludes blank Trade Codes; shows up to 12 suggestions.
- Selecting a result still adds the official Trade Code to the My Partners input and retains the selected row's partner metadata for its result card.
- Removed the 150 ms debounce and dependency on `searchPartnerDirectory()` for this screen's live suggestions. Existing database schema/index additions are left intact; no destructive database changes.

## Scope and preservation
- Search behavior change is confined to My Partners.
- Original SMS Checker behavior, separate `sms_checker_2.db` isolation, payment calculations/thresholds, HQ snapshot/import semantics, notification work, and other features are preserved.
- Android `versionCode` advanced from 252 to 253; `versionName` remains `4.6.0-NEXT`.

## Verification status
- Source-level patch and ZIP integrity checks are required.
- Kotlin compilation, GitHub Actions build, and physical-device search verification remain pending; this package must not be described as build-verified until those checks pass.
