# DevMonitor 4.6.0-NEXT v238 — Android permission callback compile fix

## Problem
GitHub Actions failed in `MainActivity.kt` because `onRequestPermissionsResult` used `Array<out String>`, which did not match the override signature exposed by the configured Android toolchain. The call to `super.onRequestPermissionsResult` also failed with an array type mismatch.

## Fix
Changed the override parameter to `permissions: Array<String>`. The callback still flushes pending system notifications when notification permission is granted.

## Protected scope
No changes to payment logic, report imports, database schemas, or notification event triggers.

## Build status
Source-level validation only. The GitHub Actions build and on-device notification delivery have not yet been verified.
