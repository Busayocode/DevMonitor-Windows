Release notes — v244 SMS Check 2

# DevMonitor 4.6.0-NEXT v244 — SMS Check 2

- Adds a separate **SMS CHECK 2** dashboard card and keeps its navigation item.
- Uses a dedicated `sms_checker_2.db` database. Current codes/results, saved lists, archives, history, and SMS query attempt logs are isolated from the primary SMS Checker database.
- Reuses the existing SMS workflow and the device's SMS permission/SIM hardware.
- HQ report storage, payment logic, My Devices, and the original checker are not intentionally changed.
- Validation: source edits and ZIP integrity checks; compile and on-device testing are pending.
