# DevMonitor Android v241 — Remove My Partner menu

This build removes the standalone staff-only My Partner menu from navigation and removes its UI/search dialog. The existing Partner Summary and My Devices flows remain in place because they are separate existing app features. Payment calculations, HQ report import rules, and notification code were not intentionally modified.

Validation: source-level checks and ZIP integrity only. Android compilation and physical-device regression tests remain pending.
