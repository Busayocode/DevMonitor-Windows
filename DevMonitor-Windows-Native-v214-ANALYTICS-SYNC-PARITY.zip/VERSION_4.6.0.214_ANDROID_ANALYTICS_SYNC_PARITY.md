# DevMonitor Windows v214 — Android Analytics and Sync Bridge Alignment

- Advanced Windows assembly, file, informational, and installer versions to `4.6.0.214`.
- Retained the v213 opt-in local-only analytics foundation: app/page opens, report import outcomes, report snapshot storage, exceptions, and version/OS context.
- Analytics remains disabled unless the user enables it in Settings. Events stay in `%LOCALAPPDATA%\DevMonitor\diagnostics\events.jsonl`; no telemetry upload or new external endpoint was added.
- Retained the encrypted Phone ↔ PC sync bridge, operational archive allowlist, and deletion-tombstone exchange/relay merge support from the current Windows v213 source.
- PaymentRules.cs, HQ monthly snapshots, payment records, and authoritative report import behaviour are unchanged.
- The Android v223 ZIP contains Firebase-based app analytics; Windows deliberately keeps a separate opt-in, local-only implementation until a privacy-reviewed shared telemetry endpoint is explicitly approved.

## Validation status
- [x] Source version references advanced to v214.
- [x] Windows project and installer source included.
- [x] ZIP structure and archive integrity checked.
- [ ] .NET publish, relay publish, and Inno Setup installer build in GitHub Actions.
- [ ] Live Android/Windows sync, tombstone, and conflict tests on real devices.
