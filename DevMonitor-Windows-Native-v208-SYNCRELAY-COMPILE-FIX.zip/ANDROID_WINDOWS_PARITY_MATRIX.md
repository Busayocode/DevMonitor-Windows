# DevMonitor Android → Windows parity matrix (source review v220 / v206)

The bridge is now a working source-level implementation, but **the Windows app is not yet at full Android feature parity**. This matrix prevents the current release from being misrepresented as complete.

## Present in the Windows source
- Local dashboard and profile/company summary
- Device Monitor and payment estimate surfaces using the existing Windows `PaymentRules.cs`
- HQ report import and two-month snapshot database
- Month-on-Month comparison and CSV export
- My Devices list
- SMS Checker stored results/history surface (Windows does not send SMS)
- Tasks/follow-ups, notes, notifications, timeline, trends, Action Centre and export screens in the current Windows shell
- `.dmdata` import/export fallback
- New v1 phone/PC bridge for My Devices codes, operational tasks, notes and SMS inbox history
- Extended Android operational archive transfer: current/archived query codes, query records/history, saved query lists, daily observations, SMS query-attempt metadata, agents, agent phones and agent-device relationships, profile metadata and in-app notifications
- Windows Android Data Archive browser with family filtering/search, JSON/CSV export, and generic add/edit/delete controls for operational record families; extended records also travel in the `.dmdata` fallback
- Windows imports Android notifications into the native inbox using stable source keys; read-state updates are included in the next explicit sync
- Phone sync now applies returned desktop edits to Android operational tables for query codes/results, saved lists/history, daily observations, SMS query attempts, agents, phones and agent-device links; profile notification read state is reconciled by stable notification ID
- Android current query records are mapped into the Windows phone-result store; agent phone/device assignments have a read-only joined view

## Still requires parity implementation and tests
- Dedicated typed editors (instead of the generic JSON editor) for Android query lists, archived codes, query history and SMS recovery state; data can now be edited in the Windows archive, but family-specific validation and guided workflows are still pending
- Dedicated typed agent/phone/device forms and ID allocation for new records; existing relationship rows can be edited through the archive JSON editor
- Full settings/preferences sync and profile metadata write-back; notification read-state is reconciled, but profile-scoped notification delivery needs additional testing
- Full reconciliation of phone query-result/history records into the Windows Device Monitor and daily observation calculations
- Company activation database / report history views and full report/export parity
- Full visual/workflow parity for all Android screens, role-specific flows, guided tours and profile-scoped features
- Deletion tombstones, conflict review UI, sync audit history, resumable batches and background scheduling
- Automated cross-platform golden tests proving payment outputs and cutoff boundaries match Android
- Background/resumable sync and delete tombstone semantics remain intentionally disabled until conflict/reconciliation tests exist

## Non-negotiable protections
- Do not sync-replace HQ monthly snapshots through the operational bridge. HQ import remains a separate authoritative replace-all operation per month, with out-of-order month imports handled by the report importer.
- Do not change `PaymentRules.cs` or Android `PaymentRules.kt` formulas/cutoffs as part of transport work.
- Do not implement cellular SMS sending on Windows.
- Treat sync as explicit and user-initiated until retries, tombstones, audit and reconciliation tests are complete.
