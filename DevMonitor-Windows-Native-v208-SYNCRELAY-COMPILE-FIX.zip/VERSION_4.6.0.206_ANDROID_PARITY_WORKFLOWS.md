# DevMonitor Windows 4.6.0.206 — Android parity workflows

## Implemented
- Android Data Archive now supports adding, editing and deleting operational archive records through a validated JSON editor, with family filtering/search and export retained.
- Agent & Partners links to archive management for agents, agent phone contacts and agent-device assignments.
- Android-originated notifications are merged into the Windows inbox with a stable source-key map; imported notification read state is retained and can be returned to Android on the next explicit sync.
- Android sync applies desktop-side updates to matching native operational tables: query codes, query records, saved query lists, query history, daily observations, SMS query attempts, agents, agent phones and agent-device links. Stable existing row IDs are preserved.
- HQ snapshots, payment records and payment rules remain outside sync and outside the generic archive editor. Windows does not send SMS.

## Still not claimed complete
- Deletion tombstones and conflict-resolution UI are not yet implemented; archive deletions are local and may be reintroduced by a later phone sync.
- Dedicated typed forms and robust globally unique IDs for creating agent/contact/query entities remain future work.
- Profile/settings synchronization and profile-scoped notification round-trip require device-level verification.
- No successful .NET or Gradle build is claimed by this source preparation; GitHub Actions must compile both archives.


## v207 sync reliability update
- Added operational archive deletion tombstones. Windows archive deletes are retained as sync markers and applied after incoming upserts so a stale copy does not immediately recreate the deleted archive record. Tombstones are exchanged through the encrypted bridge.
- HTTPS relay merge now unions extended Android records and tombstones rather than silently discarding those families after the first relay sync.
- This does not yet detect every edit/delete race or make native Android-side deletions observable; conflict review and complete two-way deletion semantics remain follow-up work.
