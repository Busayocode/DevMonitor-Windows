#define MyAppName "DevMonitor"
#define MyAppVersion "4.6.0.206"
#define MyAppPublisher "AziiTech"
#define MyAppExeName "DevMonitor.exe"

[Setup]
AppId={{7A6D4C19-5B7E-4C7A-9B11-460000000202}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\DevMonitor
DefaultGroupName={#MyAppName}
OutputDir=installer
OutputBaseFilename=DevMonitor-Setup-v{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
PrivilegesRequired=admin
UninstallDisplayIcon={app}\{#MyAppExeName}
SetupIconFile=Assets\DevMonitor.ico
DisableProgramGroupPage=yes

[Files]
Source: "publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\DevMonitor"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\DevMonitor"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch DevMonitor"; Flags: nowait postinstall skipifsilent
