# DevMonitor Phone ↔ PC Sync Bridge — Protocol v1

## Included in v204 / Android v218
- Windows LAN bridge endpoint: `http://<PC-LAN-IP>:43827/sync` (health: `/health`).
- Android Sync Centre accepts the bridge URL and the same pairing key.
- AES-256-GCM envelope encryption uses SHA-256(pairing key) as the AES key; each payload has a random 12-byte nonce followed by GCM ciphertext+tag, Base64 encoded in JSON property `payload`. Authentication failure rejects the payload.
- Two-way merge covers My Devices codes, operational tasks, notes and SMS history. Duplicate records are matched by stable natural keys (task/note title + creation time; SMS sender + body + received time).
- Existing `.dmdata` manual import/export remains available.
- HQ monthly snapshots, imported HQ rows, daily payment observations, payment cycles and payment calculations are explicitly excluded from bridge merge. Windows does not send SMS.

## Local pairing
1. On Windows open **Phone Data Exchange** and choose **Start local sync bridge**.
2. Allow DevMonitor through Windows Defender Firewall on **Private networks only**. Use the displayed LAN IP and port 43827 on the phone, for example `http://192.168.1.10:43827`.
3. Copy the generated pairing key into Android **Next Level → Health → Phone ↔ PC Sync Bridge** and tap **Sync now**.
4. Keep the key private; stop the bridge when finished. The HTTP body is AES-GCM encrypted at the application layer.

If Windows refuses to listen due to URL ACL, run an elevated terminal once: `netsh http add urlacl url=http://+:43827/ user=%USERDOMAIN%\%USERNAME%`. Remove it with `netsh http delete urlacl url=http://+:43827/`.

## Internet sync
Use a trusted VPN or an HTTPS reverse proxy with a valid certificate forwarding `/sync` and `/health` to the Windows bridge. Do **not** expose port 43827 directly to the public internet, and do not use plain HTTP over the internet. The pairing-key encryption remains enabled through the proxy. For cloud relay when the PC is offline, a hosted relay service and deployment credentials are still required; this source revision does not claim to provide a managed cloud relay.

## Scope and known limits
This is the first transport/protocol implementation, not yet complete database-wide feature parity. It synchronizes the operational entities listed above only. Agent/partner records, notifications, phone query-result history, settings, and all HQ/activation/report tables are not merged yet. Deleted records are not tombstoned in protocol v1, so deletion is not propagated. Resolve these before using it as a complete system of record.


## v207 sync reliability update
- Added operational archive deletion tombstones. Windows archive deletes are retained as sync markers and applied after incoming upserts so a stale copy does not immediately recreate the deleted archive record. Tombstones are exchanged through the encrypted bridge.
- HTTPS relay merge now unions extended Android records and tombstones rather than silently discarding those families after the first relay sync.
- This does not yet detect every edit/delete race or make native Android-side deletions observable; conflict review and complete two-way deletion semantics remain follow-up work.
