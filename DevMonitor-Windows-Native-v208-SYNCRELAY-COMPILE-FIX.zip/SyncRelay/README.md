# DevMonitor HTTPS Sync Relay

Small .NET 8 relay for remote two-way synchronization when the phone and PC are on different networks. The relay stores only AES-GCM-encrypted merged operational snapshots in SQLite. The pairing key is sent only to the relay over HTTPS and is never stored; a one-way hash selects the room.

## Run behind HTTPS

```powershell
dotnet publish .\DevMonitor.SyncRelay.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

Run behind a valid HTTPS listener/reverse proxy. The service intentionally rejects requests when `HttpContext.Request.IsHttps` is false. If using a reverse proxy, configure its IP/network in `ForwardedHeadersOptions.KnownProxies` or `KnownNetworks` before deployment; the app uses forwarded headers only from configured trusted proxies. Verify `Request.IsHttps` is true at the app. Do not clear the trusted-proxy list or trust arbitrary forwarded headers. Set `DEVMONITOR_RELAY_DB` to a persistent writable path. Keep backups of this encrypted database.

Use the base URL in Android Sync Centre or Windows Phone Data Exchange; clients append `/sync`. Health check: `/health`.

## Security notes
- Create a strong random pairing key (at least 16 characters; use 32+ random characters in production) and use the same key on both devices.
- TLS is required. Do not publish this endpoint on plain HTTP.
- Each request/response is additionally AES-256-GCM encrypted using SHA-256(pairing key); the relay persists only the encrypted merged snapshot.
- This v1 relay synchronizes My Devices codes, tasks, notes, and SMS history only. It does not merge HQ snapshots, imported report rows, payment records, agent/partner management, notifications, or device query history.
- Deletions are not propagated in v1. Conflicting task/note updates use the latest `updatedAt` timestamp.


## v207 sync reliability update
- Added operational archive deletion tombstones. Windows archive deletes are retained as sync markers and applied after incoming upserts so a stale copy does not immediately recreate the deleted archive record. Tombstones are exchanged through the encrypted bridge.
- HTTPS relay merge now unions extended Android records and tombstones rather than silently discarding those families after the first relay sync.
- This does not yet detect every edit/delete race or make native Android-side deletions observable; conflict review and complete two-way deletion semantics remain follow-up work.
