using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Data.Sqlite;
using Microsoft.AspNetCore.HttpOverrides;

var builder=WebApplication.CreateBuilder(args);
var app=builder.Build();
var forwarded=new ForwardedHeadersOptions { ForwardedHeaders=ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto };
// Trust forwarded headers only from explicitly configured reverse proxies. For a local reverse proxy,
// configure KnownProxies/KnownNetworks here before deployment; do not blindly trust internet headers.
app.UseForwardedHeaders(forwarded);
var dbPath=Environment.GetEnvironmentVariable("DEVMONITOR_RELAY_DB") ?? Path.Combine(AppContext.BaseDirectory,"devmonitor-relay.db");
Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(dbPath))!);
using(var c=new SqliteConnection($"Data Source={dbPath}")){c.Open();using var cmd=c.CreateCommand();cmd.CommandText="CREATE TABLE IF NOT EXISTS rooms(room_id TEXT PRIMARY KEY, encrypted_payload TEXT NOT NULL, updated_at TEXT NOT NULL)";cmd.ExecuteNonQuery();}
app.MapGet("/health",()=>Results.Json(new{service="DevMonitor Sync Relay",protocol=1,encryptedAtRest=true}));
app.MapPost("/sync",async (HttpContext ctx)=>{
    if(!ctx.Request.IsHttps) return Results.BadRequest(new{error="https_required"});
    var token=ctx.Request.Headers["X-DevMonitor-Pairing-Key"].ToString();
    if(token.Length<16 || token.Length>512) return Results.Unauthorized();
    if(ctx.Request.ContentLength is > 15_000_000) return Results.StatusCode(413);
    try{
        using var reader=new StreamReader(ctx.Request.Body);var raw=await reader.ReadToEndAsync();var incomingEnvelope=JsonDocument.Parse(raw);var incomingCipher=Convert.FromBase64String(incomingEnvelope.RootElement.GetProperty("payload").GetString()??"");var key=SHA256.HashData(Encoding.UTF8.GetBytes(token));var incoming=Decrypt(incomingCipher,key);var root=JsonNode.Parse(incoming) as JsonObject ?? throw new InvalidDataException("Invalid sync JSON.");
        if(root["protocol"]?.GetValue<int>()!=1) return Results.BadRequest(new{error="unsupported_protocol"});
        var room=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("DevMonitor-room:"+token)));
        using var db=new SqliteConnection($"Data Source={dbPath}");db.Open();string? prior=null;
        using(var q=db.CreateCommand()){q.CommandText="SELECT encrypted_payload FROM rooms WHERE room_id=$id";q.Parameters.AddWithValue("$id",room);prior=q.ExecuteScalar()?.ToString();}
        JsonObject merged=root;
        if(!string.IsNullOrWhiteSpace(prior)){var priorCipher=Convert.FromBase64String(prior);var old=JsonNode.Parse(Decrypt(priorCipher,key)) as JsonObject ?? new JsonObject();merged=Merge(old,root);}
        var plain=merged.ToJsonString(new JsonSerializerOptions{WriteIndented=false});var encrypted=Encrypt(plain,key);var stored=Convert.ToBase64String(encrypted);
        using(var tx=db.BeginTransaction()){using var up=db.CreateCommand();up.Transaction=tx;up.CommandText="INSERT INTO rooms(room_id,encrypted_payload,updated_at) VALUES($id,$p,$t) ON CONFLICT(room_id) DO UPDATE SET encrypted_payload=$p,updated_at=$t";up.Parameters.AddWithValue("$id",room);up.Parameters.AddWithValue("$p",stored);up.Parameters.AddWithValue("$t",DateTimeOffset.UtcNow.ToString("O"));up.ExecuteNonQuery();tx.Commit();}
        return Results.Json(new{payload=stored},new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
    }catch(CryptographicException){return Results.Unauthorized();}catch(Exception ex){return Results.BadRequest(new{error="sync_failed",message=ex.Message});}
});
app.Run();

static byte[] Encrypt(string plain,byte[] key){var bytes=Encoding.UTF8.GetBytes(plain);var nonce=RandomNumberGenerator.GetBytes(12);var cipher=new byte[bytes.Length+16];using var aes=new AesGcm(key,16);aes.Encrypt(nonce,bytes,cipher.AsSpan(0,bytes.Length),cipher.AsSpan(bytes.Length,16));return nonce.Concat(cipher).ToArray();}
static string Decrypt(byte[] input,byte[] key){if(input.Length<28)throw new CryptographicException("Bad envelope");var nonce=input.AsSpan(0,12);var data=input.AsSpan(12);var plain=new byte[data.Length-16];using var aes=new AesGcm(key,16);aes.Decrypt(nonce,data[..^16],data[^16..],plain);return Encoding.UTF8.GetString(plain);}
static JsonObject Merge(JsonObject a,JsonObject b){
    var result=(JsonObject)a.DeepClone();result["protocol"]=1;result["createdAt"]=DateTimeOffset.UtcNow.ToString("O");
    result["myDevices"]=MergeStrings(a["myDevices"] as JsonArray,b["myDevices"] as JsonArray);
    result["tasks"]=MergeRows(a["tasks"] as JsonArray,b["tasks"] as JsonArray,"title","createdAt","updatedAt");
    result["notes"]=MergeRows(a["notes"] as JsonArray,b["notes"] as JsonArray,"title","createdAt","updatedAt");
    result["sms"]=MergeRows(a["sms"] as JsonArray,b["sms"] as JsonArray,"sender","body","received");
    result["extendedData"]=MergeExtended(a["extendedData"] as JsonArray,b["extendedData"] as JsonArray);
    return result;
}
static JsonArray MergeStrings(JsonArray? a,JsonArray? b){var set=new SortedSet<string>(StringComparer.OrdinalIgnoreCase);foreach(var x in a??new JsonArray())if(x!=null)set.Add(x.ToString());foreach(var x in b??new JsonArray())if(x!=null)set.Add(x.ToString());var r=new JsonArray();foreach(var x in set)r.Add(x);return r;}
static JsonArray MergeRows(JsonArray? a,JsonArray? b,string k1,string k2,string versionKey){var map=new Dictionary<string,JsonObject>(StringComparer.OrdinalIgnoreCase);void Add(JsonArray? rows){foreach(var n in rows??new JsonArray()){if(n is not JsonObject o)continue;var key=(o[k1]?.ToString()??"")+"\u001f"+(o[k2]?.ToString()??"")+(k1=="sender"?"\u001f"+(o["received"]?.ToString()??""):"");if(!map.TryGetValue(key,out var prior)){map[key]=(JsonObject)o.DeepClone();continue;}var oldV=DateTimeOffset.TryParse(prior[versionKey]?.ToString(),out var od)?od:DateTimeOffset.MinValue;var newV=DateTimeOffset.TryParse(o[versionKey]?.ToString(),out var nd)?nd:DateTimeOffset.MinValue;if(newV>=oldV)map[key]=(JsonObject)o.DeepClone();}}Add(a);Add(b);var result=new JsonArray();foreach(var v in map.Values.OrderBy(x=>x[k1]?.ToString()).ThenBy(x=>x[k2]?.ToString()))result.Add(v);return result;}

static JsonArray MergeExtended(JsonArray? a,JsonArray? b){
    var map=new Dictionary<string,JsonObject>(StringComparer.OrdinalIgnoreCase);
    void Add(JsonArray? rows){foreach(var n in rows??new JsonArray()){
        if(n is not JsonObject o)continue;
        var type=o["type"]?.ToString()??"";var key=o["key"]?.ToString()??"";
        if(string.IsNullOrWhiteSpace(type)||string.IsNullOrWhiteSpace(key))continue;
        var id=type+"\u001f"+key;
        if(!map.TryGetValue(id,out var prior)){map[id]=(JsonObject)o.DeepClone();continue;}
        var oldPayload=prior["payload"] as JsonObject;var newPayload=o["payload"] as JsonObject;
        var oldStamp=Stamp(oldPayload);var newStamp=Stamp(newPayload);
        if(newStamp>=oldStamp)map[id]=(JsonObject)o.DeepClone();
    }}
    Add(a);Add(b);var result=new JsonArray();
    foreach(var row in map.Values.OrderBy(x=>x["type"]?.ToString()).ThenBy(x=>x["key"]?.ToString()))result.Add(row);
    return result;
}
static DateTimeOffset Stamp(JsonObject? p){
    if(p==null)return DateTimeOffset.MinValue;
    foreach(var name in new[]{"updated_at","updatedAt","timestamp","deletedAt","deleted_at","received_at","receivedAt"}){
        var raw=p[name]?.ToString();if(long.TryParse(raw,out var ms)){try{return DateTimeOffset.FromUnixTimeMilliseconds(ms);}catch{}}
        if(DateTimeOffset.TryParse(raw,out var dt))return dt;
    }
    return DateTimeOffset.MinValue;
}
