namespace DevMonitor.Windows;

public sealed record DeviceRow(
    string DeviceId,
    string TradeCode,
    string PartnerName,
    string Cluster,
    string Region,
    string Territory,
    string StaffName,
    Dictionary<DateTime,int> Daily);

public sealed record DeviceSnapshot(
    string DeviceId, string Source, string Ownership,
    int Today, int Mtd, int Active, int Bar48, int Bar96,
    DateTime AsOf, string? Flag);

public sealed record IncentiveEstimate(
    int Activations, int FixedReward, int RechargeBonus,
    int SundayActivations, int SundayBonus, int Subtotal,
    int? NextThreshold, int ActivationsToNext, int? NextReward);

public sealed record ReportInfo(
    string Id, DateTime Month, DateTime CoverageStart, DateTime CoverageEnd,
    string SourceFile, DateTime ImportedAt, int DeviceCount);


public sealed record OperationalTask(long Id,string Title,string Details,string? DueDate,string Priority,string? LinkType,string? LinkValue,bool Completed,DateTime CreatedAt,DateTime UpdatedAt);
public sealed record OperationalNote(long Id,string Title,string Body,string? LinkType,string? LinkValue,bool Pinned,DateTime CreatedAt,DateTime UpdatedAt);
public sealed record AppNotification(long Id,string Title,string Message,DateTime Timestamp,string Kind,bool Read);
public sealed record LocalProfile(string Name,string Role,string Partner,string Region,string Territory,string Staff);
public sealed record PhoneQueryResult(string DeviceId,string Status,int? Today,int? Mtd,int? Active,int? Bar48,int? Bar96,DateTime ResultAt,string Raw);
public sealed record PhoneExchangePackage(string Version,string CreatedAt,List<string> MyDevices,List<OperationalTask> Tasks,List<OperationalNote> Notes,List<AppNotification> Notifications,List<(string Sender,string Body,DateTime Received)> Sms);

public sealed record AndroidRecord(string Type,string Key,string PayloadJson,DateTime UpdatedAt);
