# DevMonitor Windows v4.6.0.205 — Android Feature Data Parity Expansion

## Added
- Extended phone/PC sync with an allowlisted operational data archive: current/archived query codes, query result JSON, saved query lists, query history, daily observations, SMS query-attempt metadata, agents, agent phone contacts, agent-device relationships, profile metadata and per-profile notifications.
- Added Android Data Archive navigation with family filter, text search, offline browsing and JSON/CSV export.
- Added an Android agent directory/assignment panel to Agents & Partners, joining imported agent records with phone contacts and assigned device codes.
- Mapped Android current query records into the Windows stored phone-result stream so the latest phone observations can participate in Device Monitor precedence rules; duplicate syncs are deduplicated.
- Added archive records to the Windows `.dmdata` fallback format.
- Added whole-payload validation for extended records before merge/import and enforced supported-family, key-size and payload-size limits.

## Explicit exclusions
- HQ monthly snapshots and activation bridge history.
- Payment cycles, payment records, and all payment calculation/cutoff logic.
- Authentication/account credentials and authorization audit records.
- Cellular SMS sending on Windows.

## Parity status
This version improves data parity and offline visibility. Android-only data families that are not native Windows workflows are stored in a searchable archive; native create/edit/delete screens and cross-platform golden calculation tests remain outstanding. The Windows payment engine and authoritative two-month HQ import model are unchanged.

## Build verification
Source archive integrity and source structure were checked in this environment. A .NET 8 Windows compilation was not available here; GitHub Actions must be used to confirm the Windows build.
